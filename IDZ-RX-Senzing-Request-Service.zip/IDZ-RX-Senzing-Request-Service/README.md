# KafkaStreams SpringBoot Framework for B50 Kafka Consumers

This is a Spring Boot example of how to read in JSON from a Kakfa topic and, via Kafka Streams, create a single json doc from subsequent JSON documents. 

This can be used as an example framework for all B50 Kafka Consumer SpringBoot applications

To use this, 

<<Steps will be provided>>
    
