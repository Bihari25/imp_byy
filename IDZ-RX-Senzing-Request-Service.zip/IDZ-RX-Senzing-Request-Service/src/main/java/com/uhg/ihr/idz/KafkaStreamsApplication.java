package com.uhg.ihr.idz;

import java.io.IOException;

import com.uhg.ihr.idz.utils.PropertySourceConfig;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.beans.factory.annotation.Autowired;



@SpringBootApplication
@ComponentScan(basePackages = {"com.uhg.ihr", "com.uhg.ihr.idz"})
public class KafkaStreamsApplication {

	static Logger logger = LoggerFactory.getLogger(KafkaStreamsApplication.class);
	/**
	 *
	 * @param args
	 * @throws IOException
	 */

	@Autowired
	private PropertySourceConfig envConfig;

	public static void main(String[] args) throws IOException {
		try {
			SpringApplication.run(KafkaStreamsApplication.class, args);
		} catch (Exception e) {
			logger.error("Application Failed to process the messages" + e.getMessage());
		}
	}

	public void run(String... args) throws Exception {
		logger.info("using profile:" + envConfig.getProfiles());

	}
}
