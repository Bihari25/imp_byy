package com.uhg.ihr.idz.constants;

/**
 * @author Srinivasarao Polagani
 * @version 1.0
 * @category Constants
 * @date 08/28/2019
 */
public class RXConstants {

    public static final String[] PHARMACY_CLAIMS_MESSAGE_HEADER = new String[]{"recordidentifier",
            "processoridnumber", "processorbatchnumber", "serviceproviderid", "serviceprovideridqualifier",
            "claimoriginationflag", "pharmacynetworkcode", "serviceprovidername", "serviceproviderrelationshipcode",
            "serviceproviderdispenserclass", "serviceproviderdispensertype", "prescriptionservicereferencenumber",
            "dateofservice", "productserviceid", "productidqualifier", "productlabelname", "productmanufacturer",
            "neworrefillcode", "metricdecimalquantity", "dayssupply", "drugrxotcindicator", "drugstrength",
            "unitofmeasure", "routeofadministration", "dosageform", "hcpcscode", "basisofreimbursement",
            "basisofcostdetermination", "costtypecodeapproved", "drugunitcost", "paymenttypeflag",
            "ingredientcostbilled", "ingredientcostsubmitted", "ingredientcostcalculated", "dispensingfeebilled",
            "outofnetworkpenalty", "patientpayamount", "salestaxbilled", "clientcopay", "netpatientpay", "plancopay",
            "productselectiondifferential", "professionalservicefee", "incentiveamountbilled",
            "claimadjustmentwithhold", "totalamountbilled", "otherpayeramount", "otheramountbilled",
            "patientpayamountattributedtodeductible", "usualandcustomary", "patientfirstname", "patientlastname",
            "patientmiddleinitial", "patientdateofbirth", "gender", "memberidnumber", "memberzip", "personcode",
            "patientrelationshiptocardholder", "prescriberid", "prescriberidqualifier", "prescriberdeanumber",
            "prescriberlastname", "prescriberfirstname", "prescriberspecialtycode", "prescribernetworkid",
            "diagnosiscode", "diagnosiscodequalifier", "priorauthorizationmedicalcertificationqualifier",
            "priorauthorizationid", "priorauthreasoncode", "cardholderid", "cardholderlastname", "cardholderfirstname",
            "cardholdermiddleinitial", "cardholderdateofbirth", "cardholderaddress1", "cardholderaddress2",
            "cardholdercity", "cardholderstate", "cardholderzip", "placeofservice", "rxorigin", "patientresidence",
            "dateprescriptionwritten", "productselectioncode", "othercoveragecode", "thirdpartyrestriction",
            "specialtyflag", "compoundcode", "formularystatus", "plandrugstatus", "numberofrefillsauthorized",
            "multisourcecode", "brandnamecode", "drugdeaclasscode", "primarycareproviderid", "carefacilityidcode",
            "carequalifiercode", "plancode", "unitdoseindicator", "maintenancedrugcode", "ahfscode",
            "genericproductindex", "druggenericname", "genericcodenumber", "genericcodesequence", "carrier", "account",
            "groupid", "socialsecuritynumber", "submitdateofclaim", "submittimeofclaim", "rxclaimsnumber",
            "sequencenumberofclaim", "claimstatus", "transactioncode", "brandgenericindicator", "claimmessage",
            "benefitmaximumflag", "clientflag", "outofpocketmaxapplied", "benefitmaximumapplied", "processcycledate",
            "filler", "formularyclaimflag", "medicalclaimflag", "priorauthclaimflag", "transplantflag",
            "injectableproductflag", "rxsolformularyflag", "halftab", "reserved1", "reserved2", "remittancetype",
            "checkdate", "checknumber", "plantypecode", "clientproductcode", "clientridercode", "clientbenefitcode",
            "planqualifiercode", "tiervalue", "healthreimbursementamount", "alternateinsuranceflag", "adminfee",
            "regionaldisasteroverride", "claimadjustment", "filler", "clientdefined", "processorreserved",
            "modmemberidnumber"};

    public static final char PHARMACY_CLAIMS_MESSAGE_DELEMETER = '|';
    public static final String APPLICATION_ID_CONFIG = "test-streams";
    public static final String BOOTSTRAP_SERVERS_CONFIG = "test";


}
