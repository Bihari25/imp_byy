package com.uhg.ihr.idz.component;


import com.uhg.ihr.idz.framework.constants.IDZConstants;
import com.uhg.ihr.idz.framework.model.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.util.ArrayList;

@Component("rxSenzingRequestMessageBuilder")
public class RXSenzingRequestMessageBuilder extends SenzingRequestMessageBuilder {
    Logger logger = LoggerFactory.getLogger(RXSenzingRequestMessageBuilder.class);

    private static final String INTERFACE_TYPE = IDZConstants.INTERFACE_NAME_RX;



    @Value("${application.hybrid}")
    private String hybrid;

    private boolean isHybrid;

    @PostConstruct
    public void init(){
        isHybrid = IDZConstants.FLAG_YES.equalsIgnoreCase(hybrid.trim());
    }


    public RXSenzingRequestMessageBuilder() {
        super(INTERFACE_TYPE);
    }

//working on this completed
    private void parseAndMapSubscriberDetails(ExtendedIDZSenzingRequestMessage senzingRequestMessage, IDZDebatchedMessage idzDebatchedMessage, PharmacyClaims claim) {

        try {
            //SenzingRXJSONSubscriber senzingRXJSONSubscriber = createSenzingRXJSONSubscriber(claim);
            SenzingRXJSONSubscriber senzingRXJSONSubscriber = new SenzingRXJSONSubscriber(claim);
            senzingRequestMessage.getSenzingRequestList().add(senzingRXJSONSubscriber);
        } catch (Exception e) {
            logger.error("Error occured while parsing JSONSubscriber" + e.getStackTrace());
            senzingRequestMessage.getExceptions().add(new Exception(e));
        }
    }
//working  on this  completed
    private void parseAndMapHybridSubscriberDetails(ExtendedIDZSenzingRequestMessage senzingRequestMessage, IDZDebatchedMessage debatchedMessage, PharmacyClaims claim) {
        try {
            //SenzingRXJSONSubscriberHybrid senzingRXJSONSubscriber = createSenzingRXJSONHybridSubscriber(claim);
            SenzingRXJSONSubscriberHybrid senzingRXJSONSubscriber = new SenzingRXJSONSubscriberHybrid(claim);
            senzingRequestMessage.getSenzingRequestList().add(senzingRXJSONSubscriber);
        } catch (Exception e) {
            logger.error("Error occured while parsing JSONSubscriber" + e.getStackTrace());
            senzingRequestMessage.getExceptions().add(new Exception(e));
        }
        
    }


    //TODO move this to the model class and make it a constructor
   /* private SenzingRXJSONSubscriberHybrid createSenzingRXJSONHybridSubscriber(PharmacyClaims claim) {
        SenzingRXJSONSubscriberHybrid subscriber = new SenzingRXJSONSubscriberHybrid();
        subscriber.setCorrelationId(IDZConstants.CORRELATION_RX_PATIENT);

        subscriber.setFirstName(claim.getPatientfirstname());
        subscriber.setLastName(claim.getPatientlastname());
        subscriber.setDob(claim.getPatientdateofbirth());
        subscriber.setGender(claim.getGender());
        subscriber.setSsn(claim.getSocialsecuritynumber());
        //todo:map the fields here appropriately
        //subscriber.set(claim.getCardholderid());
        //hybrid code changes start
        subscriber.setHcid(claim.getMemberidnumber());//493-512(subScriber id ie memberid no)
        subscriber.setUhcHcid(claim.getMemberidnumber());
        subscriber.setSubscriberId(claim.getMemberidnumber());
        subscriber.setMedicareBenfId(claim.getMemberidnumber());
        //hybrid code changes end
        subscriber.setAddress1(claim.getCardholderaddress1());
        subscriber.setCity(claim.getCardholdercity());
        subscriber.setState(claim.getCardholderstate());
        subscriber.setPostalCode(claim.getCardholderzip());

        return subscriber;
    }*/
//working  on this completed
    private void parseAndMapPharmacyDetails(ExtendedIDZSenzingRequestMessage senzingRequestMessage, IDZDebatchedMessage debatchedMessage, PharmacyClaims claim) {

        try {
            //SenzingJSONRXProvider senzingRxJSONPharmacyProvider = createSenzingRXJSONPharmacy(claim);
            SenzingJSONRXProvider senzingRxJSONPharmacyProvider = new SenzingJSONRXProvider(claim);
            senzingRequestMessage.getSenzingRequestList().add(senzingRxJSONPharmacyProvider);
        } catch (Exception e) {
            logger.error("Error occured while parsing JSONPharmacy" + e.getStackTrace());
            //senzingRequestMessage.getExceptions().add(e);//check null
            senzingRequestMessage.getExceptions().add(new Exception(e));
        }
    }

    private void parseAndMapPrescriberDetails(ExtendedIDZSenzingRequestMessage senzingRequestMessage, IDZDebatchedMessage debatchedMessage, PharmacyClaims claim) {
        try {
           // SenzingJSONRXProvider senzingRxJSONPrescriber = createSenzingRXJSONPrescriber(claim);
            SenzingJSONRXProvider senzingRxJSONPrescriber = new SenzingJSONRXProvider(claim, debatchedMessage);
            senzingRequestMessage.getSenzingRequestList().add(senzingRxJSONPrescriber);
        } catch (Exception e) {
            logger.error("Error occured while parsing JSONPrescriber" + e.getStackTrace());
            //senzingRequestMessage.getExceptions().add(e); //check null
            senzingRequestMessage.getExceptions().add(new Exception(e));
        }
    }

    //TODO move this to the model class and make it a constructor
    // need to remove once testing is done
    /*public SenzingRXJSONSubscriber createSenzingRXJSONSubscriber(PharmacyClaims claim) {

        SenzingRXJSONSubscriber subscriber = new SenzingRXJSONSubscriber();
        subscriber.setCorrelationId(IDZConstants.CORRELATION_RX_PATIENT);
        subscriber.setSsn(claim.getSocialsecuritynumber());
        subscriber.setSubscriberId(claim.getMemberidnumber());
        subscriber.setCardholderId(claim.getCardholderid());
        subscriber.setFirstName(claim.getPatientfirstname());
        subscriber.setLastName(claim.getPatientlastname());
        subscriber.setDob(claim.getPatientdateofbirth());
        subscriber.setGender(claim.getGender());
        subscriber.setAddress1(claim.getCardholderaddress1());
        subscriber.setCity(claim.getCardholdercity());
        subscriber.setState(claim.getCardholderstate());
        subscriber.setPostalCode(claim.getCardholderzip());

        return subscriber;
    }*/

    //TODO move this to the model class and make it a constructor
    // need to remove once testing is done
   /* public SenzingJSONRXProvider createSenzingRXJSONPharmacy(PharmacyClaims claim) {

        SenzingJSONRXProvider pharamcy = new SenzingJSONRXProvider();
        if (claim.getServiceprovideridqualifier().trim().equalsIgnoreCase("07")) {
            pharamcy.setNcpdp(claim.getServiceproviderid());
        } else {
            pharamcy.setNpi(claim.getServiceproviderid());
        }
        pharamcy.setProviderType(IDZConstants.PHARMACY);
        pharamcy.setCorrelationId(IDZConstants.CORRELATION_RX_PHARMACY);

        return pharamcy;
    }*/

   /* //TODO move this to the model class and make it a constructor
    public SenzingJSONRXProvider createSenzingRXJSONPrescriber(PharmacyClaims claim) {

        SenzingJSONRXProvider prescriber = new SenzingJSONRXProvider();
        if(claim.getPrescriberidqualifier().trim().equalsIgnoreCase("12")){
            prescriber.setDea(claim.getPrescriberid());
        }else {
            prescriber.setNpi(claim.getPrescriberid());
        }
        prescriber.setProviderType(IDZConstants.PRESCRIBER);
        prescriber.setCorrelationId(IDZConstants.CORRELATION_RX_PRESCRIBER);

        return prescriber;
    }*/

    @Override
    protected void createExtendedSenzingJSON(ExtendedIDZSenzingRequestMessage senzingRequestMessage,
                                             IDZDebatchedMessage debatchedMessage) {
        ArrayList<IDZSenzingJSON> senzingRequestJSON = new ArrayList<>();
        senzingRequestMessage.setSenzingRequestList(senzingRequestJSON);
        PharmacyClaims claim = new PharmacyClaims(debatchedMessage.getPayload());

        if(isHybrid) {
            parseAndMapHybridSubscriberDetails(senzingRequestMessage, debatchedMessage, claim);
        }else{
            parseAndMapSubscriberDetails(senzingRequestMessage, debatchedMessage, claim);
            parseAndMapPrescriberDetails(senzingRequestMessage, debatchedMessage, claim);
            parseAndMapPharmacyDetails(senzingRequestMessage, debatchedMessage, claim);
        }

    }


    @Override
    protected void populateRecordIdentifier(ExtendedIDZSenzingRequestMessage idzSenzingRequestMessage, IDZDebatchedMessage idzDebatchedMessage) {

        String recordIdentifier = IDZConstants.EMPTY;

        if (isHybrid) {
            try {
                SenzingRXJSONSubscriberHybrid senzingJSONSubscriber = (SenzingRXJSONSubscriberHybrid) idzSenzingRequestMessage.getSenzingRequestList().get(0);
                //IDZSenzingRequestMessage SenzingRequestMessage= new IDZSenzingRequestMessage();
                //todo: Add hybrid record identifiers here completed
                recordIdentifier = "SUBSCRIBER_ID:" + senzingJSONSubscriber.getSubscriberId() + "," +
                        "FIRST_NAME:" + senzingJSONSubscriber.getFirstName() + "," +
                        "LAST_NAME:" + senzingJSONSubscriber.getLastName() + "," +
                        "DOB:" + senzingJSONSubscriber.getDob() + "," +
                        "GENDER:" + senzingJSONSubscriber.getGender() + "," +
                        "STATE:" + senzingJSONSubscriber.getState() + "," +
                        "SSN_NUMBER:" + senzingJSONSubscriber.getSubscriberId() + "," +
                        "HCID:" + senzingJSONSubscriber.getHcid() + "," +
                        "UHC_HCID:" + senzingJSONSubscriber.getUhcHcid() + "," +
                        "MEDICARE_BENF_ID:" + senzingJSONSubscriber.getMedicareBenfId() + "," +
                        "Rx_CLAIM_NUMBER:" + idzDebatchedMessage.getPayload().split("\\|", -1)[113].trim();



                idzSenzingRequestMessage.setRecordIdentifier(recordIdentifier);
            } catch (Exception e) {
                e.getMessage();
                logger.error("Error occured while populating RecordIdentifier" + e.getStackTrace());
                idzSenzingRequestMessage.getExceptions().add(new Exception(e));
            }
        }else{
            try {
                SenzingRXJSONSubscriber senzingJSONSubscriber = (SenzingRXJSONSubscriber) idzSenzingRequestMessage.getSenzingRequestList().get(0);
                //IDZSenzingRequestMessage SenzingRequestMessage= new IDZSenzingRequestMessage();
                recordIdentifier = "SUBSCRIBER_ID:" + senzingJSONSubscriber.getSubscriberId() + "," +
                        "FIRST_NAME:" + senzingJSONSubscriber.getFirstName() + "," +
                        "LAST_NAME:" + senzingJSONSubscriber.getLastName() + "," +
                        "DOB:" + senzingJSONSubscriber.getDob() + "," +
                        "GENDER:" + senzingJSONSubscriber.getGender() + "," +
                        "STATE:" + senzingJSONSubscriber.getState() + "," +
                        "SSN_NUMBER:" + senzingJSONSubscriber.getSubscriberId() + "," +
                        "CARDHOLDER_ID:" + senzingJSONSubscriber.getCardholderId() + "," +
                        "Rx_CLAIM_NUMBER:" + idzDebatchedMessage.getPayload().split("\\|", -1)[113].trim();
                
                //TODO add SSN and CardholderId completed

                idzSenzingRequestMessage.setRecordIdentifier(recordIdentifier);
            } catch (Exception e) {
                e.getMessage();
                logger.error("Error occured while populating RecordIdentifier" + e.getStackTrace());
                idzSenzingRequestMessage.getExceptions().add(new Exception(e));
            }

        }

    }

    @Override
    protected void validateSenzingRequestMessage(ExtendedIDZSenzingRequestMessage senzingRequestMessage) {
        // First Actor in the message will be subscriber in all scenarios
        for (IDZSenzingJSON senzingJSON : senzingRequestMessage.getSenzingRequestList()) {
            senzingRequestMessage.getExceptions().addAll(senzingJSON.retreiveValidationErrors());
        }
    }


}
