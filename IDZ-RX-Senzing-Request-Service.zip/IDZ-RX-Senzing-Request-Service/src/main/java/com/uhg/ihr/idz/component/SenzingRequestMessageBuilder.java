package com.uhg.ihr.idz.component;


import com.uhg.ihr.idz.framework.model.ExtendedIDZSenzingRequestMessage;
import com.uhg.ihr.idz.framework.model.IDZDebatchedMessage;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public abstract class SenzingRequestMessageBuilder {
    Logger logger = LoggerFactory.getLogger(SenzingRequestMessageBuilder.class);

    private String INTERFACE_TYPE = null;

    public SenzingRequestMessageBuilder(String INTERFACE_TYPE) {
        this.INTERFACE_TYPE = INTERFACE_TYPE;
    }

    public String getType() {
        return INTERFACE_TYPE;
    }

    /**
     * Do not override, works for general scenario, should be overriden only if required
     *
     *
     * @param senzingRequestMessage
     * @param idzDebatchedMessage
     * @return
     */
    public ExtendedIDZSenzingRequestMessage buildExtendedSenzingRequestMessage(ExtendedIDZSenzingRequestMessage senzingRequestMessage, IDZDebatchedMessage idzDebatchedMessage) {
        try {
            senzingRequestMessage.mapIDZMetaData(idzDebatchedMessage);
            createExtendedSenzingJSON(senzingRequestMessage,idzDebatchedMessage);
            validateSenzingRequestMessage(senzingRequestMessage);
            populateRecordIdentifier(senzingRequestMessage,idzDebatchedMessage);
        } catch (Exception e) {
            logger.error("Error occured while processing record : UUID" + idzDebatchedMessage.getUuid() +
                    " Interface Name" + idzDebatchedMessage.getInterfaceType() +
                    " File Name" + idzDebatchedMessage.getFileName());
            logger.error(String.valueOf(e.getStackTrace()));
            senzingRequestMessage.getExceptions().add(new Exception(e));
        }
        logger.info("Senzing request creation successful");
        return senzingRequestMessage;
    }

    protected abstract void populateRecordIdentifier(ExtendedIDZSenzingRequestMessage senzingRequestMessage, IDZDebatchedMessage idzDebatchedMessage);

    protected abstract void validateSenzingRequestMessage(ExtendedIDZSenzingRequestMessage senzingRequestMessage);

    protected abstract void  createExtendedSenzingJSON(ExtendedIDZSenzingRequestMessage senzingRequestMessage, IDZDebatchedMessage debatchedMessage);

}
