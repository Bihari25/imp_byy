package com.uhg.ihr.idz.topology;

import org.apache.kafka.common.serialization.Serdes;
import org.apache.kafka.streams.kstream.KStream;
import org.apache.kafka.streams.kstream.Produced;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.support.serializer.JsonSerde;
import org.springframework.stereotype.Service;

import com.uhg.ihr.idz.component.SenzingRequestMessageBuilder;
import com.uhg.ihr.idz.component.SenzingRequestMessageBuilderFactory;
import com.uhg.ihr.idz.framework.constants.IDZConstants;
import com.uhg.ihr.idz.framework.model.ExtendedIDZSenzingRequestMessage;
import com.uhg.ihr.idz.framework.model.IDZDebatchedMessage;
import com.uhg.ihr.idz.framework.model.IDZIndexMessage;
import com.uhg.ihr.idz.framework.model.IDZSenzingRequestMessage;


@Service
public class KafkaTopology {
    Logger logger = LoggerFactory.getLogger(KafkaTopology.class);

    private String outputTopic;
    private String errorTopic;
    private String indexingTopic;
    private String appName;
    private String appVersion;

    public KafkaTopology(@Value("${application.streams.topic.output}") String outputTopic,
                         @Value("${application.streams.topic.error}") String errorTopic,
                         @Value("${application.streams.topic.indexing}") String indexingTopic,
                         @Value("${application.name}") String appName,
                         @Value("${application.version}") String appVersion) {
        super();
        this.setOutputTopic(outputTopic);
        this.setErrorTopic(errorTopic);
        this.setIndexingTopic(indexingTopic);
        this.setAppName(appName);
        this.setAppVersion(appVersion);
    }


    public void processRecords(KStream<String, IDZDebatchedMessage> inboundStream){
        logger.info("************processRecords - Begin");
        KStream<String, ExtendedIDZSenzingRequestMessage> initialStream = inboundStream.mapValues(value -> transformValue(value));

        KStream<String, ExtendedIDZSenzingRequestMessage>[] branches =
                initialStream.branch(
                        (key, value) -> value.isAGoodMessage(),
                        (key, value) -> value.hasExceptions()
                );

        branches[0].mapValues(value -> value.buildIDZSenzingRequestMessage())
		        //.peek((key, value) -> IDZKafkaLogger.logTransactionIndexing(value, IDZConstants.SENZING_REQUEST_STATUS, IDZConstants.MESSAGE_STATUS_COMPLETE))
		        .to(outputTopic, Produced.with(Serdes.String(), new JsonSerde<>(IDZSenzingRequestMessage.class)));
        branches[0].mapValues(value -> new IDZIndexMessage(value, IDZConstants.SENZING_REQUEST_STATUS, IDZConstants.MESSAGE_STATUS_COMPLETE, appName, appVersion))
        		.to(indexingTopic, Produced.with(Serdes.String(), new JsonSerde<>(IDZIndexMessage.class)));
       
        
        branches[1]
                //.peek((key, value) -> IDZKafkaLogger.logTransactionIndexing(value, IDZConstants.SENZING_REQUEST_STATUS, IDZConstants.MESSAGE_STATUS_ERROR))
                .to(errorTopic, Produced.with(Serdes.String(), new JsonSerde<>(IDZSenzingRequestMessage.class)));
        branches[1].mapValues(value -> new IDZIndexMessage(value, IDZConstants.SENZING_REQUEST_STATUS, IDZConstants.MESSAGE_STATUS_ERROR, appName, appVersion))
				.to(indexingTopic, Produced.with(Serdes.String(), new JsonSerde<>(IDZIndexMessage.class)));

        logger.debug("************processRecords - complete");
    }


    public ExtendedIDZSenzingRequestMessage transformValue(IDZDebatchedMessage value){
        logger.info("************Creating output JSON New***********");
        ExtendedIDZSenzingRequestMessage idzSenzingRequestMessage = new ExtendedIDZSenzingRequestMessage();
        try {
            SenzingRequestMessageBuilder builder = SenzingRequestMessageBuilderFactory.getBuilder(value.getInterfaceType());
            idzSenzingRequestMessage = builder.buildExtendedSenzingRequestMessage(idzSenzingRequestMessage,value);
        } catch (Exception e) {
            logger.error("Error occured while tranforming the data" + e);
            idzSenzingRequestMessage.mapIDZMetaData(value);
            idzSenzingRequestMessage.getExceptions().add(e);
        }
        return idzSenzingRequestMessage;
    }




    public String getOutputTopic() {
        return outputTopic;
    }

    public void setOutputTopic(String outputTopic) {
        this.outputTopic = outputTopic;
    }

    public String getErrorTopic() {
        return errorTopic;
    }

    public void setErrorTopic(String errorTopic) {
        this.errorTopic = errorTopic;
    }

    

	public String getIndexingTopic() {
		return indexingTopic;
	}


	public void setIndexingTopic(String indexingTopic) {
		this.indexingTopic = indexingTopic;
	}


	public String getAppName() {
		return appName;
	}


	public void setAppName(String appName) {
		this.appName = appName;
	}


	public String getAppVersion() {
		return appVersion;
	}


	public void setAppVersion(String appVersion) {
		this.appVersion = appVersion;
	}
    
    

}
