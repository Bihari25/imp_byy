package com.uhg.ihr.idz.component;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Component("senzingRequestMessageBuilderFactory")
public class SenzingRequestMessageBuilderFactory {

    @Autowired
    private List<SenzingRequestMessageBuilder> builders;

    private static final Map<String, SenzingRequestMessageBuilder> builderCache = new HashMap<>();

    @PostConstruct
    public void initBuilderCache() {
        for(SenzingRequestMessageBuilder builder : builders) {
            builderCache.put(builder.getType(), builder);
        }
    }

    public static SenzingRequestMessageBuilder getBuilder(String type) {
        SenzingRequestMessageBuilder builder = builderCache.get(type);
        if(builder == null) throw new RuntimeException("Unknown builder type: " + type);
        return builder;
    }

}

