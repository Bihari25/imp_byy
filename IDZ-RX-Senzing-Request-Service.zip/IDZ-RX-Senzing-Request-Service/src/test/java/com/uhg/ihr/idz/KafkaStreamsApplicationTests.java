/*
package com.uhg.ihr.chil;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.io.IOException;

@RunWith(SpringRunner.class)
@SpringBootTest
public class KafkaStreamsApplicationTests {


    @Test
    public void contextLoads() {

        try {
            MockProducer.produce("ctc2hz1-02-s26:31200", "b50-pharmacy-vivek-input", 100);
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }


}
*/
