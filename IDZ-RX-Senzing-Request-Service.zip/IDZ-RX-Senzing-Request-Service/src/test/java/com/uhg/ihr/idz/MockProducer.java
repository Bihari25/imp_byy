/*
package com.uhg.ihr.chil;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerRecord;

import java.io.IOException;
import java.util.Properties;
import java.util.UUID;

public class MockProducer {

    public static void produce(String brokers, String topicName, int msgCount) throws IOException {

        // Set properties used to configure the producer
        Properties properties = new Properties();
        // Set the brokers (bootstrap servers)
        properties.setProperty("bootstrap.servers", brokers);
        // Set how to serialize key/value pairs
        properties.setProperty("key.serializer", "org.apache.kafka.common.serialization.StringSerializer");
        properties.setProperty("value.serializer", "org.apache.kafka.connect.json.JsonSerializer");
        // specify the protocol for SSL Encryption This is needed for secure clusters
        //properties.setProperty(CommonClientConfigs.SECURITY_PROTOCOL_CONFIG, "SASL_PLAINTEXT");

        KafkaProducer<Object, JsonNode> producer = new KafkaProducer<Object, JsonNode>(properties);
        ObjectMapper objectMapper = new ObjectMapper();

        try {

            for (int i = 0; i < msgCount; i++) {

                SampleInputMessage message = new SampleInputMessage();
                message.setUuid(i + "-" + UUID.randomUUID().toString());
                message.setFilename("1_FS_UHCCOMM20190106_RXCHF70CL.TXT");
                message.setInterfacetype("RXCLAIMS");
                message.setPayload(
                        "4|0000004659|2019006|324234234|01|T|N3P45|LIMESTONE DRUG|00605|1|1|000007613632|20190105|60505014201|03|GLIPIZIDE    TAB 10MG|APOTEX|02|60.000|030|S|10.000|MG|OR|TABS||06|06|MACHU|0.56575|P|3.54|33.95|3.54|0.90|0.00|4.44|0.00|0.00|4.44|10.00|0.00|0.00|0.00|0.00|0.00|0.00|0.00|4.44|43.00|ANDY|JACKSON|E|19850125|1|91551431700|35613|00|1|1003014705|01|FJ2345730000|ANIL|KUMAR|35|||||||91551431700|ANDY|CLIFFORD|E|19510115|17856 AL HWY 251||EDEN|AL|35613|00|3||20181105|0|00|||1|Y|F|03|Y|G|0||||UXZA03394||X|12412414|27200030000310|fffffsHHH TAB 10 MG|10841|001776|UHCACIS01|A|020321300010001|233445|20190105|071028|190052582881246|999|P|B1|G|Deductible not met||P|4.44|0.00|20190105||||||||N|||E|00000000||COMMERC|PS1||65192|U6-ASO*TN|01|0.00||0.00||000000000||0203213        000001066000001066000001066000001066000000000000000000    0000000  0000000  0000000                                                                000000000000000000||432423423");
                JsonNode jsonNode = objectMapper.valueToTree(message);
                ProducerRecord<Object, JsonNode> rec = new ProducerRecord<Object, JsonNode>(topicName, message.getUuid(), jsonNode);
                producer.send(rec);
                System.out.println("***********Sending Done**********");

            }







        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            producer.close();
        }
    }

}
*/
