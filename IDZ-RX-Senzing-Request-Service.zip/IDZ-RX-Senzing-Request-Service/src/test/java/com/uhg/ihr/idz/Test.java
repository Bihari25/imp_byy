package com.uhg.ihr.idz;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Test {

    public static String convertsDOBFormate(String dateString) {
        System.out.println("Given date is " + dateString);
        try {
            DateFormat sdf = new SimpleDateFormat("yyyyMMdd");
            Date date = sdf.parse(dateString);

            return new SimpleDateFormat("MM-dd-yyyy").format(date);
        } catch (Exception e) {
            e.getMessage();

        }
        return dateString;
    }

    public static String convertsGender(String gender) {

        String male="M";
        String female="F";
        String unknown="U";
        System.out.println("Given date is " + gender);

            if(gender.equals("1")) {
                return male;
            }
            if (gender.equals("2"))
            {
                return female;
            }
            else
                return unknown;

        }






    public static void main(String[] args) {
       String datefor=" ".trim();
        //String a= convertsDOBFormate(datefor);
       // System.out.println("return date is " + a);*/
       String a=convertsGender(datefor).trim();
        System.out.println("return gender is " + a);



    }

}
