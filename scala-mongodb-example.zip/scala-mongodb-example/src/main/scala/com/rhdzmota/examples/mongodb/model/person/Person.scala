package com.rhdzmota.examples.mongodb.model.person

import org.mongodb.scala.bson.ObjectId
import com.rhdzmota.examples.mongodb.model.MongoModel
import com.rhdzmota.examples.mongodb.model.gender.{Female, Gender, Male}
import com.rhdzmota.examples.mongodb.model.language.{En, Es, Fr, Language}
import com.rhdzmota.examples.mongodb.model.shape.Shape
import com.rhdzmota.examples.mongodb.util.ListSyntax._

case class Person(_id: ObjectId, firstName: String, lastName: String, age: Int, gender: Option[Gender], languages: List[Language], favShape: Option[Shape]) extends MongoModel

object Person {
  val firstNames= "Casey"
  val lastNames = "Stewart"

  def apply(firstName: String, lastName: String, age: Int, gender: Option[Gender], languages: List[Language], favShape: Option[Shape]): Person =
    Person(new ObjectId(), firstName, lastName, age, gender, languages, favShape)

  def Person = Person(
   val  firstName = firstNames.get
    lastName  = lastNames.get

  )
}
