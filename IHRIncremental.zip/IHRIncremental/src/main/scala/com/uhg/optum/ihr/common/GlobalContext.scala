package com.uhg.optum.ihr.common

import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.fs.FileSystem
import org.apache.hadoop.hbase.HBaseConfiguration
import org.apache.hadoop.hbase.client.{HTable, Scan}
import org.apache.hadoop.hbase.mapreduce.TableInputFormat
import org.apache.hadoop.hbase.spark.HBaseContext
import org.apache.spark.SparkContext
import org.apache.spark.sql.SparkSession

/**
  * Created by rkodur on 12/20/2017.
  */
class GlobalContext {

  var spark: SparkContext = this.createSparkSession("IHRIncremental").sparkContext

  def createSparkSession(appName: String): SparkSession = {
    try {
      val sparkSession = SparkSession.builder().appName(appName).getOrCreate()
      sparkSession.conf.set("spark.serializer", "org.apache.spark.serializer.KryoSerializer")
      sparkSession
    }
    catch {
      case e: Exception => Logger.log.error(s"Exception at GlobalContext CreateSparkSession function:" + e.getStackTrace.toString)
        throw e
    }
  }

  val hBaseConf:org.apache.hadoop.conf.Configuration = HBaseConfiguration.create()
  val hbaseContext = new HBaseContext(spark, hBaseConf)
  val fs: FileSystem = FileSystem.get(spark.hadoopConfiguration)
  val hBaseConf1:org.apache.hadoop.conf.Configuration = HBaseConfiguration.create()
  hBaseConf1.set(TableInputFormat.INPUT_TABLE, spark.getConf.get("spark.ihrCtlTab"))
  val ihrCtlTab: HTable = new HTable(hBaseConf1, spark.getConf.get("spark.ihrCtlTab"))
  val hBaseConf2:org.apache.hadoop.conf.Configuration = HBaseConfiguration.create()
  hBaseConf2.set(TableInputFormat.INPUT_TABLE, spark.getConf.get("spark.ihrEitTab"))
  val ihrEitTab: HTable = new HTable(hBaseConf1, spark.getConf.get("spark.ihrEitTab"))
}