Job Overview:
-------------
-> Extracts PMDM professional and Organization xmls from Datalake HBase Table with Timerange scan and perform flattening to create HIVE Tables on top of Flattened xml data. 
The watermark Timestamp called lastRnLdTs column maintains last run time status to pull xmls with in the time range.

Below is the ihr_entity_info HBase table for Professional and Organization domains:

Professional:
-------------

hbase(main):002:0> get '/datalake/optum/optuminsight/p_edh/prd/uhc/ihr/prd/p_mtables/ihr_entity_info','UHG-PMD-PRACTITIONERFLAT'
COLUMN                                                       CELL                                                                                                                                                                             
 ei:lastRnLdTs                                               timestamp=1534430314785, value=2018-08-16 08:55:34.205                                                                                                                           
 ei:outFileNm                                                timestamp=1527798777138, value=PRACTITIONERFLAT                                                                                                                                  
 ei:prtnrCd                                                  timestamp=1527798777138, value=UHG                                                                                                                                               
 ei:srcCd                                                    timestamp=1527798777138, value=PMD                                                                                                                                               
4 row(s) in 0.0100 seconds

Organization:
-------------

hbase(main):003:0> get '/datalake/optum/optuminsight/p_edh/prd/uhc/ihr/prd/p_mtables/ihr_entity_info','UHG-PMD-PROVORGFLAT'
COLUMN                                                       CELL                                                                                                                                                                             
 ei:lastRnLdTs                                               timestamp=1534435336064, value=2018-08-16 08:52:54.127                                                                                                                           
 ei:outFileNm                                                timestamp=1527798777092, value=PROVORGFLAT                                                                                                                                       
 ei:prtnrCd                                                  timestamp=1527798777092, value=UHG                                                                                                                                               
 ei:srcCd                                                    timestamp=1527798777092, value=PMD                                                                                                                                               
4 row(s) in 0.0030 seconds

-> PMDM-XML-Flattened job croned using Oozie workflow on daily basis to trigger everyday 8:50AM CST.

Job WorkFlow:
-------------
Job --> Triggers Parallel Fashion --> 1) ProvOrgXmlFlatInc       -->Updates Audit Tracking     ---> Success/Failure Sends a Mail 
                                      2) PractitionerXmlFlatInc  -->Updates Audit Tracking     ---> Success/Failure Sends a Mail

Runnable command to submit via Oozie:
-------------------------------------
/opt/mapr/oozie/oozie-4.3.0/bin/oozie job -oozie="https://apsrp05219.uhc.com:11443/oozie/" -config /mapr/datalake/optum/optuminsight/p_edh/prd/uhc/ihr/prd/p_conf/oozie/pmdoozie/IHROozieJob.properties -run
