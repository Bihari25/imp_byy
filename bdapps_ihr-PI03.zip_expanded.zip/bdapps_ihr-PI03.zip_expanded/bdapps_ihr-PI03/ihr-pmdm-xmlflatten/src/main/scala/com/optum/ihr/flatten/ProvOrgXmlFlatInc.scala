package com.optum.ihr.flatten

import java.text.SimpleDateFormat

import com.optum.ihr.common.{Lib, Logger}
import org.apache.hadoop.fs.{FileSystem, Path}
import org.apache.hadoop.hbase.client.{HTable, Put, Scan}
import org.apache.hadoop.hbase.filter.CompareFilter.CompareOp
import org.apache.hadoop.hbase.filter.{BinaryComparator, RowFilter}
import org.apache.hadoop.hbase.mapreduce.TableInputFormat
import org.apache.hadoop.hbase.protobuf.ProtobufUtil
import org.apache.hadoop.hbase.protobuf.generated.ClientProtos
import org.apache.hadoop.hbase.{HBaseConfiguration, TableName}
import org.apache.hadoop.hbase.spark.HBaseContext
import org.apache.hadoop.hbase.util.{Base64, Bytes}
import org.apache.spark.SparkContext
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.{SaveMode, SparkSession}
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions.row_number
import org.apache.spark.sql.functions.col


object ProvOrgXmlFlatInc {
  var properties = scala.collection.immutable.Map[String, String]()

  def main(args: Array[String]) {

    /* val sparkConf = new SparkConf().setAppName("CENTRI ORGANIZATION RECORD PARSER")
     val sc = new SparkContext(sparkConf)*/

    val sc = SparkSession.builder()
      .appName("CENTRI ORGANIZATION RECORD PARSER")
      .config("hive.metastore.uris","thrift://dbslp0567.uhc.com:11016")
      .enableHiveSupport()
      .getOrCreate().sparkContext

    val rowKey = args(0)
    if (args.length != 1) {
      println("Please enter RowKey for PMDM Flattening:")
      sc.stop()
    }
    /* val propFilePath = args(0)
     val propFile = sc.textFile(propFilePath)
     properties = propFile.map(x => (x.split("=")(0), x.split("=")(1))).collect().toMap*/
    processPMDMGoldenSnapshot(sc, rowKey)

  }

  //case class Address(organization_name : String, address_line_1 : String, city : String, zip : String, state : String,
  // county : String, country : String, latitude : String, longitude : String)
  //case class Keychain(key_chain : String, key_value : String)

  //case class PMdmCol(entity_id : String, first_name : String, middle_name  : String, last_name  : String, birth_date : String,
  // ssn : String, address : List[Address],key_chain : List[Keychain])

  case class PMdmCol(inserttimestamp: String, organization_code: String, proveff_startdate: String,
                     partytype_codetype: String, providobj_enterprise_id: String, /*organization_name : String,
      org_effstartdate : String,*/ organization_id: String, source_name: String,
                     source_id: String, source_effstartdate: String, source_effenddate: String,
                     tax_id: String, tax_code: String, tax_effstartdate: String,
                     legal_ownername: String, legal_ownereffstartdate: String,
                     legal_ownereffenddate: String, provider_servicemodeltype_code: String,
                     provider_servicemodel_effstartdate: String, provider_servicemodel_effenddate: String, hcotinowner_enterpriseid: String, tinowner_effdate_startdt: String,
                     tinowner_remittance_typecode: String, tinowner_pymtmthd_typecode: String, tinowner_elecpymnt_prefind: String,
                     /*nonvalid_npi_name : String, nonvalid_npi_value : String, nonvalid_npi_srcsystm : String, nonvalid_npi_effstrtdt : String,
                     nonvalid_npi_adddt : String,*/
                     nonvalidnpitax: List[Nonvalidnpitaxonmy], orgidobjotherid: List[Orgidobjotherid], orgidobj_otherid_name: String, orgidobj_otherid_value: String, orgidobj_otherid_effstartdt: String,
                     healthcaresolopractice_name: String, healthcaresolopractice_code: String, healthcaregroup_name: String, healthcaregroup_code: String, servcprov_name: String, servcprov_effstrtdt: String, servcprov_hosptlind: String, servcprov_taxidnbr: String,
                     servcprov_typecode: String, servcprov_entityidentifier: String, servcprov_source_name: String, servcprov_source_value: String, servcprov_source_effstartdate: String, servcprov_mdcareid_name: String, servcprov_mdcareid_value: String,
                     servcprov_mdcareid_effstartdate: String, servcprov_mdcareid_statuscd: String,
                     servcprov_otherid_name: String, servcprov_otherid_value: String, servcprov_otherid_effstartdate: String, servcprov_lic_nbr: String, servcprov_lic_add_state: String, servcprov_lic_add_countrycd: String, servcprov_lic_effstrtdt: String, servcprov_lic_typecd: String, servcprov_lic_statuscd: String, pracloctele: List[Pracloctele], locidobj: List[Locationidobj], correpndnce_address_line1: String, correpndnce_city: String,
                     correpndnce_countycode: String, correpndnce_state: String, correpndnce_postalcode_part1: String, correpndnce_postalcode_part2: String, correpndnce_type: String, correpndnce_latitude: String,
                     correpndnce_longitude: String, correpndnce_country: String, correpndnce_effstrtdt: String, correpndnce_telephone_typecode: String, correpndnce_telephone_countrycode: String, correpndnce_telephone_areacode: String, correpndnce_telephone_subscriber: String,
                     correpndnce_telephone_telephonenbr: String, correpndnce_telephone_primind: String, correspondence: List[Correspondence], pracloc_survey_code: String, pracloc_survey_hndcpaccessind: String, rltdorgid_taxidnbr: String, rltdorgid_taxid_typecode: String,
                     rltdorgid_taxid_numbreffstrtdt: String, rltdorgid_taxid_ownername: String, rltdorgid_tieredproviderservcmodltypcd: String, rltdorgid_tieredproviderservcmodleffstrtdt: String, rltdorgid_taxid_enterpriseid: String,
                     rltdorgid_hcotinowner_enterpriseid: String, healthcarecorporation_name: String, healthcarecorporation_code: String, taxonomy_providertypecode: String, taxonomy_effstartdate: String, taxonomyclass_info: List[Taxonomyclass], txnmyclsspclty_info: List[Txnmyclsspclty], healthcarefacility_name: String, healthcarefacility_code: String,
                     eleccommu_info: List[Eleccommu], praclocschedule_info: List[Praclocschedule], orgnames: List[Orgnames], nonvalidnpi: List[Nonvalidnpi], orgtxnmy: List[Orgtxnmy], orgidobjmpin: List[Orgidobjmpin], hlthcarecredsts: List[Hlthcarecredsts], alternatenms: List[Alternatenms], hcotinownercorr_info: List[Hcotinownercorr], serprovpracloc: List[Serprovpracloc],
                     hlthcareeleccomm: List[Hlthcareeleccomm])

  case class Locationidobj(locidobj_identifier: String, locidobj_addtypcode: String, locidobj_effstrtdt: String)

  case class Correspondence(correpndnce_matchaddr_othrprovloc: String, correpndnce_effstrtdtmatch_otherprovloc: String, correpndnce_othrprov_identifier: String, correpndnce_othrprov_addtypcode: String, correpndnce_othrprov_effstrtdt: String)

  case class Nonvalidnpitaxonmy(nonvalid_npiid_match_taxnmy: String, nonvalid_npi_taxnmy_effstrtdt: String, nonvalid_npi_taxnmy_adddt: String, nonvalid_npi_taxnmy_srctypcd: String, nonvalid_npi_taxnmy_code: String)

  case class Orgidobjotherid(organization_orgid: String, orgidobj_otherid_name: String, orgidobj_otherid_value: String, orgidobj_otherid_effstartdt: String)

  case class Taxonomyclass(taxonomy_provtypcd_match_class: String, taxonomy_classicode: String, taxonomy_classieffstrtdt: String, taxonomy_classieffcancldt: String, taxonomy_classiprimclassind: String,
                           taxonomy_classisrctype: String, taxonomy_classisrctypecode: String, taxonomy_classipracspclind: String, taxonomy_classispclbrdcertcode: String, taxonomy_classispclbrdcertdate: String,
                           taxonomy_classispclbrdexamdate: String, taxonomy_classispclbrdexpdate: String, taxonomy_classirecerteffdate: String)

  case class Txnmyclsspclty(txnmy_clss_match_code: String, txnmyclsspclty_code: String, txnmyclsspclty_effstrtdt: String, txnmyclsspclty_effcancldt: String, txnmyclsspclty_datasrctypcd: String, txnmyclsspclty_pracspclind: String, txnmyclsspclty_primspclind: String, txnmyclsspclty_srctypecode: String)

  case class Pracloctele(praclocaddline_matchtelephone: String, pracloc_telephone_typecode: String, pracloc_telephone_countrycode: String, pracloc_telephone_areacode: String, pracloc_telephone_subscriber: String, pracloc_telephone_telephonenbr: String, pracloc_telephone_primind: String)

  case class Eleccommu(praclocaddline_matcheleccommu: String, eleccommu_addrtypecode: String, eleccommu_addrtext: String, eleccommu_statscode: String)

  case class Praclocschedule(praclocadd_matchschedule: String, praclocschedule_dayofweek: String, praclocschedule_starttime: String, praclocschedule_endtime: String)

  case class Orgnames(org_name: String, org_effstrtdt: String, org_effenddt: String)

  case class Nonvalidnpi(organization_orgid: String, nonvalidnpi_name: String, nonvalidnpi_value: String, nonvalidnpi_sourcesystm: String, nonvalidnpi_effstrtdt: String, nonvalidnpi_effcncldt: String, nonvalidnpi_adddt: String)

  case class Orgtxnmy(orgtxnmy_providertypcode: String, orgtxnmy_effstrtdt: String, orgtxnmy_effenddt: String)

  case class Orgidobjmpin(organization_orgid: String, orgidobjmpin_name: String, orgidobjmpin_value: String, orgidobjmpin_effstrtdt: String, orgidobjmpin_effenddt: String)

  case class Hlthcarecredsts(hlthcarecredsts_ststypcd: String, hlthcarecredsts_credtypcd: String, hlthcarecredsts_credtypcd_desc: String, hlthcarecredsts_effstrtdt: String, hlthcarecredsts_effcancldt: String, hlthcarecredsts_credrespcd: String, hlthcarecredsts_corpbussegcd: String, hlthcarecredsts_org_id: String)

  case class Alternatenms(alternatenms_servprov_match_nm: String, alternatenms_name: String, alternatenms_nametypcd: String, alternatenms_stscd: String)

  case class Hcotinownercorr(tinowner_match_taxid: String, tinowner_address_line1: String, tinowner_city: String, tinowner_county_code: String, tinowner_state: String,
                             tinowner_postalcode_part1: String, tinowner_postalcode_part2: String, tinowner_type: String, tinowner_latitude: String, tinowner_longitude: String,
                             tinowner_country: String, tinowner_locationidobj_identifier: String, tinowner_locationidobj_addrtypcode: String, tinowner_corrspeffstrtdt: String,
                             tinowner_effectivedtrange_strtdt: String)

  case class Serprovpracloc(pracloc_address_line1: String, pracloc_city: String, pracloc_countycode: String,
                            pracloc_state: String, pracloc_postalcode_part1: String, pracloc_postalcode_part2: String, pracloc_type: String, pracloc_primaryind: String, pracloc_latitude: String, pracloc_longitude: String, pracloc_country: String,
                            pracloc_location_effstrtdt: String, pracloc_locationname: String)

  case class Hlthcareeleccomm(hlthcareeleccommu_addrtypecode: String, hlthcareeleccommu_addrtext: String, hlthcareeleccommu_statscode: String)

  def processPMDMGoldenSnapshot(sc: SparkContext, rowKey: String) = {

    @transient val hBaseConf: org.apache.hadoop.conf.Configuration = HBaseConfiguration.create()
    val hbaseContext = new HBaseContext(sc, hBaseConf)

    Logger.log.info("============> Starting Extract for Organization Flattening <===========")
    val ihrCtlTab = sc.getConf.get("spark.ihrCtlTab")
    val currDt = Lib.getCurrentDate

    Logger.log.info("Current Run  Date: " + currDt)
    val prevDt = Lib.dateAddDay(s"$currDt", -1, "yyyyMMdd", "yyyyMMdd")
    Logger.log.info("Previous Run Date: " + prevDt)
    val bkpDelDt = Lib.dateAddDay(s"$currDt", -2, "yyyyMMdd", "yyyyMMdd")
    Logger.log.info("1 Day Before Run Date: " + bkpDelDt)

    val fs: FileSystem = FileSystem.get(sc.hadoopConfiguration)

    def rmDirIfExist(dir: String): Unit = {
      try {
        if (fs.exists(new Path(s"$dir"))) {
          fs.delete(new Path(dir), true)
        }
        else {
          Logger.log.info(s"Working Dir: $dir doesn't exist, Please check for Errors.")
        }
      } catch {
        case e: Exception => Logger.log.error("Exception at HBase Put Commands at IHR_enttiy_info" :+ e.getMessage)
          throw e
      }
    }

    val ihrEitTab: HTable = new HTable(hBaseConf, sc.getConf.get("spark.ihrEitTab"))

    def hbaseEitPut(eitRowKey: String, colFm: String, colNm: String, value: String): Unit = {
      try {
        val p = new Put(s"$eitRowKey".getBytes())
        p.addColumn(s"$colFm".getBytes(), s"$colNm".getBytes(), s"$value".getBytes())
        ihrEitTab.put(p)
      } catch {
        case e: Exception => Logger.log.error("Exception at HBase EIT Put Commands at IHR_enttiy_info IHR_ADT_DTL" :+ e.getMessage)
          throw e
      }
    }

    Logger.log.info("IHR PMDM Flattening Configuration Table: " + ihrCtlTab)

    def getEntityInfo(rowKey: String): String = {
      try {
        println(s"ihrCtlTab ihr_ent_cfg for PMDM Flattening: $ihrCtlTab")
        val scanner = new Scan()
        scanner.setCaching(10000)
        scanner.setCacheBlocks(false)
        val filter1 = new RowFilter(CompareOp.EQUAL, new BinaryComparator(Bytes.toBytes(s"$rowKey")))
        scanner.setFilter(filter1)
        val ihrInfo = hbaseContext.hbaseRDD(TableName.valueOf(ihrCtlTab), scanner).cache()
        val ihrEntRDD = ihrInfo.map(tuple => {
          val result = tuple._2
          (Bytes.toString(result.getValue(Bytes.toBytes("ei"), Bytes.toBytes("srcCd"))),
            Bytes.toString(result.getValue(Bytes.toBytes("ei"), Bytes.toBytes("prtnrCd"))),
            Bytes.toString(result.getValue(Bytes.toBytes("ei"), Bytes.toBytes("outFileNm"))),
            Bytes.toString(result.getValue(Bytes.toBytes("ei"), Bytes.toBytes("lastRnLdTs")))
          )
        })
        if (ihrEntRDD.isEmpty()) {
          println(s"Please Provide Appropriate RowKey / Check ihr_ent_cfg table Properties for $rowKey properly")
          ihrEntRDD.collect().map(x => x.productIterator.mkString("|")).mkString
        }
        else {
          ihrEntRDD.collect().map(x => x.productIterator.mkString("|")).mkString
        }
      } catch {
        case e: Exception => println(s"Exception while getting Configuration from ihr_entity_info Tab" :+ e.getMessage)
          throw e
      }
    }


    val configInfo = getEntityInfo(rowKey)
    Logger.log.info("Configurations for Organization extract " + configInfo)

    val Array(srcCd, prtnrCd, outFileNm, lastRnLdTs) = configInfo.split("\\|")
    val endTs = Lib.getMilliSecCurrentTimeFormat

    def getTimestamp(DateFormat: String): Long = {
      val timestampformat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS")
      timestampformat.parse(DateFormat).getTime()
    }

    val eitRowKey = s"${rowKey.toUpperCase()}-${java.util.UUID.randomUUID()}"

    Logger.log.info("HBase EIT Row Key for Organization Flattening: " + eitRowKey)
    hbaseEitPut(eitRowKey, "pi", "prtnrCd", s"$prtnrCd")
    hbaseEitPut(eitRowKey, "pi", "srcCd", srcCd)
    hbaseEitPut(eitRowKey, "pi", "prcNm", outFileNm)
    hbaseEitPut(eitRowKey, "pi", "prcDt", currDt)

    @transient val conf: org.apache.hadoop.conf.Configuration = HBaseConfiguration.create()
    @transient val scan = new Scan()

    val dLOrgTab = sc.getConf.get("spark.dlOrgTab")

    conf.set(TableInputFormat.INPUT_TABLE, dLOrgTab)

    scan.setCaching(10000)
    scan.setCacheBlocks(false)
    scan.setTimeRange(getTimestamp(s"$lastRnLdTs"), getTimestamp(s"$endTs"))

    def convertScanToString(scan: Scan): String = {
      val proto: ClientProtos.Scan = ProtobufUtil.toScan(scan)
      return Base64.encodeBytes(proto.toByteArray)
    }

    conf.set(TableInputFormat.SCAN, convertScanToString(scan))

    val hbaseRDD = sc.newAPIHadoopRDD(conf, classOf[TableInputFormat],
      classOf[org.apache.hadoop.hbase.io.ImmutableBytesWritable],
      classOf[org.apache.hadoop.hbase.client.Result])


    val keyValueRDD: RDD[(String)] = hbaseRDD.map(tuple => {
      val result = tuple._2
      (Bytes.toString(result.getValue(Bytes.toBytes("ri"), Bytes.toBytes("rawMsg"))))
    })

    val keyCntRDD: RDD[(String)] = hbaseRDD.map(tuple => {
      val result = tuple._2
      (Bytes.toString(result.getRow()))
    })


    Logger.log.info(s"Extracting Organizational Records from $lastRnLdTs to $endTs=====>")
    val extractCnt = keyCntRDD.count()
    Logger.log.info(s"Total Organizational records from $lastRnLdTs to $endTs: " + keyCntRDD.count())

    try {
      val flattenedMDMRecords = keyValueRDD.map(mdmRec => parsePMDMGoldenXml(mdmRec))

      val sqlContext = new org.apache.spark.sql.SQLContext(sc)
      import sqlContext.implicits._
      val parsedDF = flattenedMDMRecords.toDF.repartition(2000)
      val userWindow = Window.partitionBy("providobj_enterprise_id").orderBy(col("inserttimestamp").desc)
      val dedupParseDF = parsedDF.withColumn("rank", row_number().over(userWindow)).where(col("rank") === 1).drop("rank").persist(org.apache.spark.api.java.StorageLevels.MEMORY_AND_DISK_SER)
      dedupParseDF.printSchema()

      val orgOutFilePth = sc.getConf.get("spark.orgOutPath")

      val resPath = s"$orgOutFilePth/organization/$currDt"

      Logger.log.info("Saving Extract to the organization OutPath Loc =>: " + orgOutFilePth)
      dedupParseDF.write.save(s"$resPath")

      val dedupCnt = dedupParseDF.select("providobj_enterprise_id").count()

      Logger.log.info("Deduped Messages from Organizational from Datalake: " + dedupCnt)

      val prevResPath = s"$orgOutFilePth/organization/${prevDt}"

      Logger.log.info(s"Previous Day Location: $prevResPath")


      if (fs.exists(new Path(s"$resPath")) && fs.exists(new Path(s"$prevResPath"))) {
        Logger.log.info("Previous Day location and current Day locations exists, saving result to temp for Dedup")
        val mergeDf = sqlContext.read.parquet(s"$resPath", s"$prevResPath")
        //Save Data to the Temp Location:
        val tempLoc = s"$orgOutFilePth/organization/${outFileNm}_temp"
        mergeDf.write.mode(SaveMode.Overwrite).save(s"$tempLoc")
        val combineDF = sqlContext.read.parquet(s"$tempLoc")
        val combineDFCnt = combineDF.select("providobj_enterprise_id").count()
        Logger.log.info(s"$currDt and ${prevDt} Combined Count: " + combineDFCnt)
        val dedupMergeDF = combineDF.withColumn("rank", row_number().over(userWindow)).where(col("rank") === 1).drop("rank").persist(org.apache.spark.api.java.StorageLevels.MEMORY_AND_DISK_SER)
        val dedupMergeDFCnt = dedupMergeDF.select("providobj_enterprise_id").count()
        Logger.log.info(s"$currDt and ${prevDt} Combined Dedup Count: " + dedupMergeDFCnt)

        //Drop Table Before saving to Actual location:

        Logger.log.info(s"Droping Table bdapps_ihr_centri.$outFileNm before refreshing Data")

        sqlContext.sql(s"drop table bdapps_ihr_centri.$outFileNm")

        dedupMergeDF.write.mode(SaveMode.Overwrite).option("path", s"$resPath").saveAsTable(s"bdapps_ihr_centri.$outFileNm")

        Logger.log.info(s"Refresh Done, Hence Updating ${endTs} TS to IHR Configuration table")

        Logger.log.info(s"Deleting 1 day before backup Data with $bkpDelDt date")

        val bkpDir = s"$orgOutFilePth/organization/$bkpDelDt"

        Logger.log.info(s"Backup Directory Path: $bkpDir")

        rmDirIfExist(s"$bkpDir")

        Logger.log.info(s"Deletion Done for the day before Day with Date: $bkpDelDt")

        Logger.log.info("====>Hence Updating Audit Tracking table with Entries<=====")

        hbaseEitPut(eitRowKey, "pi", "RecCnt", s"$extractCnt")
        hbaseEitPut(eitRowKey, "pi", "dedupRecCnt", s"$dedupCnt")
        hbaseEitPut(eitRowKey, "pi", "prcSts", s"Success")

        @transient val hBaseCtlConf: org.apache.hadoop.conf.Configuration = HBaseConfiguration.create()
        hBaseCtlConf.set(TableInputFormat.INPUT_TABLE, ihrCtlTab)
        val ihrCtlTabPut: HTable = new HTable(hBaseCtlConf, ihrCtlTab)
        val p = new Put(s"$rowKey".getBytes())
        p.addColumn(s"ei".getBytes(), "lastRnLdTs".getBytes(), s"$endTs".getBytes())
        ihrCtlTabPut.put(p)

        Logger.log.info("==================> Job Completed Successfully <==================")

      } else {
        Logger.log.info(s"Folder Paths Does not exists Please check Once $prevResPath & $resPath")
        hbaseEitPut(eitRowKey, "eri", "errCd", "Exception folder does not exist, please check the Directory Path")
        hbaseEitPut(eitRowKey, "eri", "errDesc", s"Please check the prevDt and Currect Date Direcory Path")
        hbaseEitPut(eitRowKey, "pi", "prcSts", s"Failure")
      }
    } catch {
      case e: Exception =>
        hbaseEitPut(eitRowKey, "eri", "errCd", "Exception at Provider Organization, Please check")
        hbaseEitPut(eitRowKey, "eri", "errDesc", s"${e.getMessage}")
        hbaseEitPut(eitRowKey, "pi", "prcSts", s"Failure")
    }
  }

  def parsePMDMGoldenXml(in: String): PMdmCol = {

    var org_name = ""
    var org_effstrtdt = ""
    var org_effenddt = ""
    var organization_code = ""
    var proveff_startdate = ""
    var partytype_codetype = ""
    var providobj_enterprise_id = ""
    var enterprise_id = ""
    var organization_name = ""
    var org_effstartdate = ""
    var organization_id = ""
    var source_name = ""
    var source_id = ""
    var source_effstartdate = ""
    var source_effenddate = ""
    var tax_id = ""
    var tax_code = ""
    var tax_effstartdate = ""
    var legal_ownername = ""
    var legal_ownereffstartdate = ""
    var legal_ownereffenddate = ""
    var provider_servicemodeltype_code = ""
    var provider_servicemodel_effstartdate = ""
    var provider_servicemodel_effenddate = ""
    var tinowner_match_taxid = ""
    var tinowner_match_effstrtdt = ""
    var tinowner_address_line1 = ""
    var tinowner_city = ""
    var tinowner_county_code = ""
    var tinowner_state = ""
    var hcotinowner_enterpriseid = ""
    var tinowner_postalcode_part1 = ""
    var tinowner_postalcode_part2 = ""
    var tinowner_type = ""
    var tinowner_longitude = ""
    var tinowner_latitude = ""
    var tinowner_country = ""
    var tinowner_locationidobj_identifier = ""
    var tinowner_locationidobj_addrtypcode = ""
    var tinowner_corrspeffstrtdt = ""
    var tinowner_effectivedtrange_strtdt = ""
    var tinowner_effdate_startdt = ""
    var tinowner_elecpymnt_prefind = ""
    var healthcaresolopractice_name = ""
    var healthcaresolopractice_code = ""
    var servcprov_name = ""
    var servcprov_effstrtdt = ""
    var servcprov_hosptlind = ""
    var servcprov_taxidnbr = ""
    var servcprov_typecode = ""
    var servcprov_entityidentifier = ""
    var servcprov_source_name = ""
    var servcprov_source_value = ""
    var servcprov_source_effstartdate = ""
    var servcprov_mdcareid_name = ""
    var servcprov_mdcareid_value = ""
    var servcprov_mdcareid_effstartdate = ""
    var servcprov_mdcareid_statuscd = ""
    var servcprov_otherid_name = ""
    var servcprov_otherid_value = ""
    var servcprov_otherid_effstartdate = ""
    var pracloc_address_line1 = ""
    var pracloc_city = ""
    var pracloc_countycode = ""
    var pracloc_state = ""
    var pracloc_postalcode_part1 = ""
    var pracloc_postalcode_part2 = ""
    var pracloc_type = ""
    var pracloc_primaryind = ""
    var pracloc_latitude = ""
    var pracloc_longitude = ""
    var pracloc_country = ""
    var pracloc_location_effstrtdt = ""
    var pracloc_locationname = ""
    var pracloc_telephone_typecode = ""
    var pracloc_telephone_countrycode = ""
    var pracloc_telephone_areacode = ""
    var pracloc_telephone_subscriber = ""
    var pracloc_telephone_telephonenbr = ""
    var pracloc_telephone_primind = ""
    var locidobj_identifier = ""
    var locidobj_addtypcode = ""
    var locidobj_effstrtdt = ""
    var correpndnce_address_line1 = ""
    var correpndnce_city = ""
    var correpndnce_countycode = ""
    var correpndnce_state = ""
    var correpndnce_postalcode_part1 = ""
    var correpndnce_postalcode_part2 = ""
    var correpndnce_type = ""
    var correpndnce_latitude = ""
    var correpndnce_longitude = ""
    var correpndnce_country = ""
    var correpndnce_effstrtdt = ""
    var correpndnce_telephone_typecode = ""
    var correpndnce_telephone_countrycode = ""
    var correpndnce_telephone_areacode = ""
    var correpndnce_telephone_subscriber = ""
    var correpndnce_telephone_telephonenbr = ""
    var correpndnce_telephone_primind = ""
    var correpndnce_othrprov_identifier = ""
    var correpndnce_othrprov_addtypcode = ""
    var correpndnce_othrprov_effstrtdt = ""
    var pracloc_survey_code = ""
    var pracloc_survey_hndcpaccessind = ""
    var rltdorgid_taxidnbr = ""
    var rltdorgid_taxid_typecode = ""
    var rltdorgid_taxid_numbreffstrtdt = ""
    var rltdorgid_taxid_ownername = ""
    var rltdorgid_tieredproviderservcmodltypcd = ""
    var rltdorgid_tieredproviderservcmodleffstrtdt = ""
    var rltdorgid_taxid_enterpriseid = ""
    var rltdorgid_hcotinowner_enterpriseid = ""
    var healthcarecorporation_name = ""
    var healthcarecorporation_code = ""
    var tinowner_remittance_typecode = ""
    var tinowner_pymtmthd_typecode = ""
    var orgidobj_otherid_name = ""
    var orgidobj_otherid_value = ""
    var orgidobj_otherid_effstartdt = ""
    var nonvalid_npi_name = ""
    var nonvalid_npi_value = ""
    var nonvalid_npi_srcsystm = ""
    var nonvalid_npi_effstrtdt = ""
    var nonvalid_npi_adddt = ""
    var nonvalid_npiid_match_taxnmy = ""
    var nonvalid_npi_taxnmy_effstrtdt = ""
    var nonvalid_npi_taxnmy_adddt = ""
    var nonvalid_npi_taxnmy_srctypcd = ""
    var nonvalid_npi_taxnmy_code = ""
    var healthcaregroup_name = ""
    var healthcaregroup_code = ""
    var taxonomy_providertypecode = ""
    var taxonomy_effstartdate = ""
    var taxonomy_provtypcd_match_class = ""
    var taxonomy_classicode = ""
    var taxonomy_classieffstrtdt = ""
    var taxonomy_classieffcancldt = ""
    var taxonomy_classiprimclassind = ""
    var taxonomy_classisrctype = ""
    var taxonomy_classisrctypecode = ""
    var taxonomy_classipracspclind = ""
    var taxonomy_classispclbrdcertcode = ""
    var taxonomy_classispclbrdcertdate = ""
    var taxonomy_classispclbrdexamdate = ""
    var taxonomy_classispclbrdexpdate = ""
    var taxonomy_classirecerteffdate = ""
    var txnmy_clss_match_code = ""
    var txnmyclsspclty_code = ""
    var txnmyclsspclty_effstrtdt = ""
    var txnmyclsspclty_effcancldt = ""
    var txnmyclsspclty_datasrctypcd = ""
    var txnmyclsspclty_pracspclind = ""
    var txnmyclsspclty_primspclind = ""
    var txnmyclsspclty_srctypecode = ""
    var healthcarefacility_name = ""
    var healthcarefacility_code = ""
    var praclocaddline_matcheleccommu = ""
    var eleccommu_addrtypecode = ""
    var eleccommu_addrtext = ""
    var eleccommu_statscode = ""
    var servcprov_lic_nbr = ""
    var servcprov_lic_add_state = ""
    var servcprov_lic_add_countrycd = ""
    var servcprov_lic_effstrtdt = ""
    var servcprov_lic_typecd = ""
    var servcprov_lic_statuscd = ""
    var praclocadd_matchschedule = ""
    var praclocschedule_dayofweek = ""
    var praclocschedule_starttime = ""
    var praclocschedule_endtime = ""
    var nonvalidnpi_name = ""
    var nonvalidnpi_value = ""
    var nonvalidnpi_sourcesystm = ""
    var nonvalidnpi_effstrtdt = ""
    var nonvalidnpi_effcncldt = ""
    var nonvalidnpi_adddt = ""
    var organization_orgid = ""
    var orgtxnmy_providertypcode = ""
    var orgtxnmy_effstrtdt = ""
    var orgtxnmy_effenddt = ""
    var praclocaddline_matchtelephone = ""
    var orgidobjmpin_name = ""
    var orgidobjmpin_value = ""
    var orgidobjmpin_effstrtdt = ""
    var orgidobjmpin_effenddt = ""
    var correpndnce_matchaddr_othrprovloc = ""
    var correpndnce_effstrtdtmatch_otherprovloc = ""
    var hlthcarecredsts_ststypcd = ""
    var hlthcarecredsts_credtypcd = ""
    var hlthcarecredsts_credtypcd_desc = ""
    var hlthcarecredsts_effstrtdt = ""
    var hlthcarecredsts_effcancldt = ""
    var hlthcarecredsts_credrespcd = ""
    var hlthcarecredsts_corpbussegcd = ""
    var hlthcarecredsts_org_id = ""
    var alternatenms_servprov_match_nm = ""
    var alternatenms_name = ""
    var alternatenms_nametypcd = ""
    var alternatenms_stscd = ""
    var hlthcareeleccommu_addrtypecode = ""
    var hlthcareeleccommu_addrtext = ""
    var hlthcareeleccommu_statscode = ""
    //var record_gen_ts = ""
    //var record_gen_dt = ""

    val xml = scala.xml.XML.loadString(in)

    /*val orecord_gen_ts = xml\\"ProvMasterMsg"\\"headerObj"\\"timeStamp"
    if (orecord_gen_ts != null && orecord_gen_ts.length >0 ) {
     record_gen_ts =  orecord_gen_ts(0).text
     record_gen_dt = record_gen_ts.split("T").array(0)
    }*/

    val timestamp = xml \\ "ProvMasterMsg" \\ "headerObj" \\ "timeStamp"

    val oprovEff_startdate = xml \\ "ProvMasterMsg" \\ "body" \\ "provider" \\ "provEffDate" \\ "effStartDate"
    if (oprovEff_startdate != null && oprovEff_startdate.length > 0) {
      proveff_startdate = oprovEff_startdate(0).text
    }

    val opartyType_CodeType = xml \\ "ProvMasterMsg" \\ "body" \\ "provider" \\ "partyTypeCodeType" \\ "code"
    if (opartyType_CodeType != null && opartyType_CodeType.length > 0) {
      partytype_codetype = opartyType_CodeType(0).text
    }

    val oenterpriseID = xml \\ "ProvMasterMsg" \\ "body" \\ "provider" \\ "providerIDObj" \\ "enterpriseID" \\ "value"
    if (oenterpriseID != null && oenterpriseID.length > 0) {
      providobj_enterprise_id = oenterpriseID(0).text
    }


    val organizationxml = xml \\ "ProvMasterMsg" \\ "body" \\ "provider" \\ "organization"


    val otaxonomy_providertypecode = organizationxml \\ "taxonomy" \\ "providerType" \\ "code"
    if (otaxonomy_providertypecode != null && otaxonomy_providertypecode.length > 0) {
      taxonomy_providertypecode = otaxonomy_providertypecode(0).text
    }

    val otaxonomy_effdates = organizationxml \\ "taxonomy" \\ "taxonomyEffDates" \\ "effStartDate"
    if (otaxonomy_effdates != null && otaxonomy_effdates.length > 0) {
      taxonomy_effstartdate = otaxonomy_effdates(0).text
    }



    /*val oorganization_code  = organizationxml \\ "code"
    if (oorganization_code  != null && oorganization_code .length >0 ) {
      println("1.......")
      organization_code = oorganization_code(0).text*/


    for (curLoc <- organizationxml) {
      organization_code = ""
      organization_name = ""
      org_effstartdate = ""
      organization_id = ""
      source_name = ""
      source_id = ""
      source_effstartdate = ""
      source_effenddate = ""
      tax_id = ""
      tax_code = ""
      tax_effstartdate = ""
      legal_ownername = ""
      legal_ownereffstartdate = ""
      legal_ownereffenddate = ""
      provider_servicemodeltype_code = ""
      provider_servicemodel_effstartdate = ""
      provider_servicemodel_effenddate = ""
      hcotinowner_enterpriseid = ""
      tinowner_effdate_startdt = ""
      tinowner_elecpymnt_prefind = ""
      healthcaresolopractice_name = ""
      healthcaresolopractice_code = ""
      healthcarecorporation_name = ""
      healthcarecorporation_code = ""
      healthcaregroup_name = ""
      healthcaregroup_code = ""
      healthcarefacility_name = ""
      healthcarefacility_code = ""
      servcprov_name = ""
      servcprov_effstrtdt = ""
      servcprov_hosptlind = ""
      servcprov_taxidnbr = ""
      servcprov_typecode = ""
      servcprov_entityidentifier = ""
      servcprov_source_name = ""
      servcprov_source_value = ""
      servcprov_source_effstartdate = ""
      servcprov_mdcareid_name = ""
      servcprov_mdcareid_value = ""
      servcprov_mdcareid_effstartdate = ""
      servcprov_mdcareid_statuscd = ""
      servcprov_otherid_name = ""
      servcprov_otherid_value = ""
      servcprov_otherid_effstartdate = ""
      tinowner_remittance_typecode = ""
      tinowner_pymtmthd_typecode = ""
      nonvalid_npi_name = ""
      nonvalid_npi_value = ""
      nonvalid_npi_srcsystm = ""
      nonvalid_npi_effstrtdt = ""
      nonvalid_npi_adddt = ""
      servcprov_lic_nbr = ""
      servcprov_lic_add_state = ""
      servcprov_lic_add_countrycd = ""
      servcprov_lic_effstrtdt = ""
      servcprov_lic_typecd = ""
      servcprov_lic_statuscd = ""


      val curLoc1 = curLoc.child
      for (curLoc2 <- curLoc1) {
        if (curLoc2.label == "code") {
          organization_code = curLoc2.text
          for (curLoc3 <- organizationxml \\ "organizationNames") {
            val curLoc4 = curLoc3.child
            for (curLoc5 <- curLoc4) {
              if (curLoc5.label == "name") {
                organization_name = curLoc5.text
              }
              if (curLoc5.label == "effectiveDate") {
                val curLoc6 = curLoc5.child
                for (curLoc7 <- curLoc6) {
                  if (curLoc7.label == "effStartDate") {
                    org_effstartdate = curLoc7.text
                  }
                }
              }
            }
          }
          for (curLoc8 <- organizationxml \\ "orgIDObj") {
            val curLoc9 = curLoc8.child
            for (curLoc10 <- curLoc9) {
              if (curLoc10.label == "organizationId") {
                for (curLoc11 <- curLoc10.child) {
                  if (curLoc11.label == "value") {
                    organization_id = curLoc11.text
                  }
                }
              }
              if (curLoc10.label == "mpin") {
                for (curLoc11 <- curLoc10.child) {
                  if (curLoc11.label == "name") {
                    source_name = curLoc11.text
                  }
                  if (curLoc11.label == "value") {
                    source_id = curLoc11.text
                  }
                  if (curLoc11.label == "effDateRange") {
                    for (curLoc12 <- curLoc11.child) {
                      if (curLoc12.label == "startDate") {
                        source_effstartdate = curLoc12.text
                      }
                      if (curLoc12.label == "endDate") {
                        source_effenddate = curLoc12.text
                      }
                    }
                  }
                }
              }
              if (curLoc10.label == "hcoTINOwner") {
                for (curLoc11 <- curLoc10.child) {
                  if (curLoc11.label == "taxID") {
                    for (curLoc12 <- curLoc11.child) {
                      if (curLoc12.label == "taxIdNbr") {
                        tax_id = curLoc12.text
                      }
                      if (curLoc12.label == "typeCode") {
                        for (curLoc13 <- curLoc12.child) {
                          if (curLoc13.label == "code") {
                            tax_code = curLoc13.text
                          }
                        }
                      }
                      if (curLoc12.label == "numberEffDate") {
                        for (curLoc13 <- curLoc12.child) {
                          if (curLoc13.label == "effStartDate") {
                            tax_effstartdate = curLoc13.text
                          }
                        }
                      }
                      if (curLoc12.label == "legalOwnerName") {
                        for (curLoc13 <- curLoc12.child) {
                          if (curLoc13.label == "name") {
                            legal_ownername = curLoc13.text
                          }
                          if (curLoc13.label == "effectiveDate") {
                            for (curLoc14 <- curLoc13.child) {
                              if (curLoc14.label == "effStartDate") {
                                legal_ownereffstartdate = curLoc14.text
                              }
                              if (curLoc14.label == "effEndDate") {
                                legal_ownereffenddate = curLoc14.text
                              }
                            }
                          }
                        }
                      }
                      if (curLoc12.label == "tieredProviderServiceModel") {
                        for (curLoc13 <- curLoc12.child) {
                          if (curLoc13.label == "tieredProviderServiceModelTypeCode") {
                            for (curLoc14 <- curLoc13.child) {
                              if (curLoc14.label == "code") {
                                provider_servicemodeltype_code = curLoc14.text
                              }
                            }
                          }
                          if (curLoc13.label == "tieredProviderServiceModelEffDate") {
                            for (curLoc14 <- curLoc13.child) {
                              if (curLoc14.label == "effStartDate") {
                                provider_servicemodel_effstartdate = curLoc14.text
                              }
                              if (curLoc14.label == "effEndDate") {
                                provider_servicemodel_effenddate = curLoc14.text
                              }
                            }
                          }
                        }
                      }
                      if (curLoc12.label == "enterpriseId") {
                        hcotinowner_enterpriseid = curLoc12.text
                      }

                    }
                  }
                  if (curLoc11.label == "effDate") {
                    for (curLoc12 <- curLoc11.child) {
                      if (curLoc12.label == "effStartDate") {
                        tinowner_effdate_startdt = curLoc12.text
                      }
                    }
                  }
                  if (curLoc11.label == "remittanceTypeCode") {
                    for (curLoc12 <- curLoc11.child) {
                      if (curLoc12.label == "code") {
                        tinowner_remittance_typecode = curLoc12.text
                      }
                    }
                  }
                  if (curLoc11.label == "paymentMethodTypeCode") {
                    for (curLoc12 <- curLoc11.child) {
                      if (curLoc12.label == "code") {
                        tinowner_pymtmthd_typecode = curLoc12.text
                      }
                    }
                  }
                  if (curLoc11.label == "electronicPaymentPreferedInd") {
                    tinowner_elecpymnt_prefind = curLoc11.text
                  }
                }
              }
              if (curLoc10.label == "nonValidatedNPI") {
                for (curLoc11 <- curLoc10.child) {
                  if (curLoc11.label == "name") {
                    nonvalid_npi_name = curLoc11.text
                  }
                  if (curLoc11.label == "value") {
                    nonvalid_npi_value = curLoc11.text
                  }
                  if (curLoc11.label == "sourceSystem") {
                    nonvalid_npi_srcsystm = curLoc11.text
                  }
                  if (curLoc11.label == "effectiveDates") {
                    for (curLoc12 <- curLoc11.child) {
                      if (curLoc12.label == "effStartDate") {
                        nonvalid_npi_effstrtdt = curLoc12.text
                      }
                    }
                  }
                  if (curLoc11.label == "addDate") {
                    nonvalid_npi_adddt = curLoc11.text
                  }
                }
              }
            }
          }
        }
        if (curLoc2.label == "healthCareSoloPractice") {
          for (curLoc3 <- curLoc2.child) {
            if (curLoc3.label == "name") {
              healthcaresolopractice_name = curLoc3.text
            }
            if (curLoc3.label == "nameTypeCode") {
              for (curLoc4 <- curLoc3.child) {
                if (curLoc4.label == "code") {
                  healthcaresolopractice_code = curLoc4.text
                }
              }
            }
          }
        }
        if (curLoc2.label == "healthCareCorporation") {
          for (curLoc3 <- curLoc2.child) {
            if (curLoc3.label == "name") {
              healthcarecorporation_name = curLoc3.text
            }
            if (curLoc3.label == "nameTypeCode") {
              for (curLoc4 <- curLoc3.child) {
                if (curLoc4.label == "code") {
                  healthcarecorporation_code = curLoc4.text
                }
              }
            }
          }
        }
        if (curLoc2.label == "healthCareGroup") {
          for (curLoc3 <- curLoc2.child) {
            if (curLoc3.label == "name") {
              healthcaregroup_name = curLoc3.text
            }
            if (curLoc3.label == "nameTypeCode") {
              for (curLoc4 <- curLoc3.child) {
                if (curLoc4.label == "code") {
                  healthcaregroup_code = curLoc4.text
                }
              }
            }
          }
        }
        if (curLoc2.label == "healthCareFacility") {
          for (curLoc3 <- curLoc2.child) {
            if (curLoc3.label == "name") {
              healthcarefacility_name = curLoc3.text
            }
            if (curLoc3.label == "nameTypeCode") {
              for (curLoc4 <- curLoc3.child) {
                if (curLoc4.label == "code") {
                  healthcarefacility_code = curLoc4.text
                }
              }
            }
          }
        }
        if (curLoc2.label == "serviceProvider") {
          for (curLoc3 <- curLoc2.child) {
            if (curLoc3.label == "name") {
              for (curLoc4 <- curLoc3.child) {
                if (curLoc4.label == "name") {
                  servcprov_name = curLoc4.text
                }
              }
            }
            if (curLoc3.label == "effDates") {
              for (curLoc4 <- curLoc3.child) {
                if (curLoc4.label == "effStartDate") {
                  servcprov_effstrtdt = curLoc4.text
                }
              }
            }
            if (curLoc3.label == "hospitalInd") {
              servcprov_hosptlind = curLoc3.text
            }
            if (curLoc3.label == "serviceProviderIDObj") {
              for (curLoc4 <- curLoc3.child) {
                if (curLoc4.label == "taxID") {
                  for (curLoc5 <- curLoc4.child) {
                    if (curLoc5.label == "taxIdNbr") {
                      servcprov_taxidnbr = curLoc5.text
                    }
                    if (curLoc5.label == "typeCode") {
                      for (curLoc6 <- curLoc5.child) {
                        if (curLoc6.label == "code") {
                          servcprov_typecode = curLoc5.text
                        }
                      }
                    }
                  }
                }
                if (curLoc4.label == "entityIdentifier") {
                  for (curLoc5 <- curLoc4.child) {
                    if (curLoc5.label == "value") {
                      servcprov_entityidentifier = curLoc5.text
                    }
                  }
                }
                if (curLoc4.label == "mpin") {
                  for (curLoc5 <- curLoc4.child) {
                    if (curLoc5.label == "name") {
                      servcprov_source_name = curLoc5.text
                    }
                    if (curLoc5.label == "value") {
                      servcprov_source_value = curLoc5.text
                    }
                    if (curLoc5.label == "effDateRange") {
                      for (curLoc6 <- curLoc5.child) {
                        if (curLoc6.label == "startDate") {
                          servcprov_source_effstartdate = curLoc5.text
                        }
                      }
                    }
                  }
                }
                if (curLoc4.label == "medicareID") {
                  for (curLoc5 <- curLoc4.child) {
                    if (curLoc5.label == "name") {
                      servcprov_mdcareid_name = curLoc5.text
                    }
                    if (curLoc5.label == "value") {
                      servcprov_mdcareid_value = curLoc5.text
                    }
                    if (curLoc5.label == "effDate") {
                      for (curLoc6 <- curLoc5.child) {
                        if (curLoc6.label == "effStartDate") {
                          servcprov_mdcareid_effstartdate = curLoc5.text
                        }
                      }
                    }
                    if (curLoc5.label == "statusCode") {
                      for (curLoc6 <- curLoc5.child) {
                        if (curLoc6.label == "code") {
                          servcprov_mdcareid_statuscd = curLoc5.text
                        }
                      }
                    }
                  }
                }
                if (curLoc4.label == "otherID") {
                  for (curLoc5 <- curLoc4.child) {
                    if (curLoc5.label == "name") {
                      servcprov_otherid_name = curLoc5.text
                    }
                    if (curLoc5.label == "value") {
                      servcprov_otherid_value = curLoc5.text
                    }
                    if (curLoc5.label == "effDate") {
                      for (curLoc6 <- curLoc5.child) {
                        if (curLoc6.label == "effStartDate") {
                          servcprov_otherid_effstartdate = curLoc5.text
                        }
                      }
                    }
                  }
                }
              }
            }
            if (curLoc3.label == "license") {
              for (curLoc4 <- curLoc3.child) {
                if (curLoc4.label == "licenseNbr") {
                  servcprov_lic_nbr = curLoc4.text
                }
                if (curLoc4.label == "address") {
                  for (curLoc5 <- curLoc4.child) {
                    if (curLoc5.label == "state") {
                      servcprov_lic_add_state = curLoc5.text
                    }
                    if (curLoc5.label == "country") {
                      for (curLoc6 <- curLoc5.child) {
                        if (curLoc6.label == "code") {
                          servcprov_lic_add_countrycd = curLoc6.text
                        }
                      }
                    }
                  }
                }
                if (curLoc4.label == "effDates") {
                  for (curLoc5 <- curLoc4.child) {
                    if (curLoc5.label == "effStartDate") {
                      servcprov_lic_effstrtdt = curLoc5.text
                    }
                  }
                }
                if (curLoc4.label == "licenseType") {
                  for (curLoc5 <- curLoc4.child) {
                    if (curLoc5.label == "code") {
                      servcprov_lic_typecd = curLoc5.text
                    }
                  }
                }
                if (curLoc4.label == "statusCode") {
                  for (curLoc5 <- curLoc4.child) {
                    if (curLoc5.label == "code") {
                      servcprov_lic_statuscd = curLoc5.text
                    }
                  }
                }
              }
            }
          }
        }
      }
    }


    var orgtxnmyList: List[Orgtxnmy] = List()
    for (orgtxnmy0 <- xml \\ "ProvMasterMsg" \\ "body" \\ "provider" \\ "organization") {
      orgtxnmy_providertypcode = ""
      orgtxnmy_effstrtdt = ""
      orgtxnmy_effenddt = ""
      for (orgtxnmyx <- orgtxnmy0.child) {
        if (orgtxnmyx.label == "taxonomy") {
          for (orgtxnmy1 <- orgtxnmyx.child) {
            if (orgtxnmy1.label == "providerType") {
              for (orgtxnmy2 <- orgtxnmy1.child) {
                if (orgtxnmy2.label == "code") {
                  orgtxnmy_providertypcode = orgtxnmy1.text
                }
              }
            }
            if (orgtxnmy1.label == "taxonomyEffDates") {
              for (orgtxnmy2 <- orgtxnmy1.child) {
                if (orgtxnmy2.label == "effStartDate") {
                  orgtxnmy_effstrtdt = orgtxnmy2.text
                }
                if (orgtxnmy2.label == "effCancelDate") {
                  orgtxnmy_effenddt = orgtxnmy2.text
                }
              }
            }
          }

          val orgtxnmy = Orgtxnmy(orgtxnmy_providertypcode, orgtxnmy_effstrtdt, orgtxnmy_effenddt)
          orgtxnmyList = orgtxnmy :: orgtxnmyList
        }
      }
    }


    var orgidobjmpinList: List[Orgidobjmpin] = List()
    for (orgid0 <- organizationxml \\ "orgIDObj" \\ "organizationId") {
      for (orgid1 <- orgid0.child) {
        if (orgid1.label == "value") {
          organization_orgid = orgid1.text
        }
      }
    }
    for (orgidobjmpin0 <- organizationxml \\ "orgIDObj" \\ "mpin") {
      orgidobjmpin_name = ""
      orgidobjmpin_value = ""
      orgidobjmpin_effstrtdt = ""
      orgidobjmpin_effenddt = ""

      for (orgidobjmpin1 <- orgidobjmpin0.child) {
        if (orgidobjmpin1.label == "name") {
          orgidobjmpin_name = orgidobjmpin1.text
        }
        if (orgidobjmpin1.label == "value") {
          orgidobjmpin_value = orgidobjmpin1.text
        }
        if (orgidobjmpin1.label == "effDateRange") {
          for (orgidobjmpin2 <- orgidobjmpin1.child) {
            if (orgidobjmpin2.label == "startDate") {
              orgidobjmpin_effstrtdt = orgidobjmpin2.text
            }
            if (orgidobjmpin2.label == "endDate") {
              orgidobjmpin_effenddt = orgidobjmpin2.text
            }
          }
        }
      }
      val orgidobjmpin = Orgidobjmpin(organization_orgid, orgidobjmpin_name, orgidobjmpin_value, orgidobjmpin_effstrtdt, orgidobjmpin_effenddt)
      orgidobjmpinList = orgidobjmpin :: orgidobjmpinList
    }


    var nonvalidnpiList: List[Nonvalidnpi] = List()
    for (orgid0 <- organizationxml \\ "orgIDObj" \\ "organizationId") {
      for (orgid1 <- orgid0.child) {
        if (orgid1.label == "value") {
          organization_orgid = orgid1.text
        }
      }
    }
    for (nonvalidnpi0 <- organizationxml \\ "orgIDObj" \\ "nonValidatedNPI") {
      nonvalidnpi_name = ""
      nonvalidnpi_value = ""
      nonvalidnpi_sourcesystm = ""
      nonvalidnpi_effstrtdt = ""
      nonvalidnpi_effcncldt = ""
      nonvalidnpi_adddt = ""
      for (nonvalidnpi1 <- nonvalidnpi0.child) {
        if (nonvalidnpi1.label == "name") {
          nonvalidnpi_name = nonvalidnpi1.text
        }
        if (nonvalidnpi1.label == "value") {
          nonvalidnpi_value = nonvalidnpi1.text
        }
        if (nonvalidnpi1.label == "sourceSystem") {
          nonvalidnpi_sourcesystm = nonvalidnpi1.text
        }
        if (nonvalidnpi1.label == "effectiveDates") {
          for (nonvalidnpi2 <- nonvalidnpi1.child) {
            if (nonvalidnpi2.label == "effStartDate") {
              nonvalidnpi_effstrtdt = nonvalidnpi2.text
            }
            if (nonvalidnpi2.label == "effCancelDate") {
              nonvalidnpi_effcncldt = nonvalidnpi2.text
            }
          }
        }
        if (nonvalidnpi1.label == "addDate") {
          nonvalidnpi_adddt = nonvalidnpi1.text
        }
      }
      val nonvalidnpi = Nonvalidnpi(organization_orgid, nonvalidnpi_name, nonvalidnpi_value, nonvalidnpi_sourcesystm, nonvalidnpi_effstrtdt, nonvalidnpi_effcncldt, nonvalidnpi_adddt)
      nonvalidnpiList = nonvalidnpi :: nonvalidnpiList
    }


    //Organization Names

    var orgnamesList: List[Orgnames] = List()
    for (orgnames0 <- organizationxml \\ "organizationNames") {
      org_name = ""
      org_effstrtdt = ""
      org_effenddt = ""
      for (orgnames1 <- orgnames0.child) {
        if (orgnames1.label == "name") {
          org_name = orgnames1.text
        }
        if (orgnames1.label == "effectiveDate") {
          for (orgnames2 <- orgnames1.child) {
            if (orgnames2.label == "effStartDate") {
              org_effstrtdt = orgnames2.text
            }
            if (orgnames2.label == "effCancelDate") {
              org_effenddt = orgnames2.text
            }
          }
        }
      }
      val orgnames = Orgnames(org_name, org_effstrtdt, org_effenddt)
      orgnamesList = orgnames :: orgnamesList
    }


    var praclocteleList: List[Pracloctele] = List()

    for (praclocaddline0 <- organizationxml \\ "serviceProvider" \\ "practiceLocations") {
      for (praclocaddline1 <- praclocaddline0.child) {

        praclocaddline_matchtelephone = ""
        if (praclocaddline1.label == "line1") {
          praclocaddline_matchtelephone = praclocaddline1.text

          for (pracloctele0 <- praclocaddline0 \\ "telephones") {
            pracloc_telephone_typecode = ""
            pracloc_telephone_countrycode = ""
            pracloc_telephone_areacode = ""
            pracloc_telephone_subscriber = ""
            pracloc_telephone_telephonenbr = ""
            pracloc_telephone_primind = ""
            if (pracloctele0.label == "telephones") {
              for (pracloctele1 <- pracloctele0.child) {
                if (pracloctele1.label == "telephone") {
                  for (pracloctele2 <- pracloctele1.child) {
                    if (pracloctele2.label == "phoneTypeCode") {
                      for (pracloctele3 <- pracloctele2.child) {
                        if (pracloctele3.label == "code") {
                          pracloc_telephone_typecode = pracloctele3.text
                        }
                      }
                    }
                    if (pracloctele2.label == "country") {
                      pracloc_telephone_countrycode = pracloctele2.text
                    }
                    if (pracloctele2.label == "area") {
                      pracloc_telephone_areacode = pracloctele2.text
                    }
                    if (pracloctele2.label == "subscriber") {
                      pracloc_telephone_subscriber = pracloctele2.text
                    }
                    if (pracloctele2.label == "telephoneNbr") {
                      pracloc_telephone_telephonenbr = pracloctele2.text
                    }
                    if (pracloctele2.label == "primInd") {
                      pracloc_telephone_primind = pracloctele2.text
                    }
                  }
                  val pracloctele = Pracloctele(praclocaddline_matchtelephone, pracloc_telephone_typecode, pracloc_telephone_countrycode, pracloc_telephone_areacode, pracloc_telephone_subscriber, pracloc_telephone_telephonenbr, pracloc_telephone_primind)
                  praclocteleList = pracloctele :: praclocteleList
                }
              }
            }
          }
        }
      }
    }

    var praclocscheduleList: List[Praclocschedule] = List()

    for (praclocadd0 <- organizationxml \\ "serviceProvider" \\ "practiceLocations") {
      for (praclocadd1 <- praclocadd0.child) {

        praclocadd_matchschedule = ""

        if (praclocadd1.label == "line1") {
          praclocadd_matchschedule = praclocadd1.text

          for (schedule0 <- praclocadd0 \\ "schedule") {
            praclocschedule_dayofweek = ""
            praclocschedule_starttime = ""
            praclocschedule_endtime = ""
            for (schedule1 <- schedule0.child) {
              if (schedule1.label == "dayOfWeekType") {
                praclocschedule_dayofweek = schedule1.text
              }
              if (schedule1.label == "timeRanges") {
                for (schedule2 <- schedule1.child) {
                  if (schedule2.label == "startTime") {
                    praclocschedule_starttime = schedule2.text
                  }
                  if (schedule2.label == "endTime") {
                    praclocschedule_endtime = schedule2.text
                  }
                }
              }
            }
            val praclocschedule_info = Praclocschedule(praclocadd_matchschedule, praclocschedule_dayofweek, praclocschedule_starttime, praclocschedule_endtime)
            praclocscheduleList = praclocschedule_info :: praclocscheduleList
          }
        }
      }
    }

    var nonvalidnpitaxonmyList: List[Nonvalidnpitaxonmy] = List()
    for (nonvalidnpi0 <- xml \\ "ProvMasterMsg" \\ "body" \\ "provider" \\ "organization" \\ "orgIDObj" \\ "nonValidatedNPI") {

      for (nonvalidnpi1 <- nonvalidnpi0.child) {
        nonvalid_npiid_match_taxnmy = ""
        if (nonvalidnpi1.label == "value") {
          nonvalid_npiid_match_taxnmy = nonvalidnpi1.text

          for (nonvalidnpitax0 <- nonvalidnpi0 \\ "taxonomy") {
            nonvalid_npi_taxnmy_effstrtdt = ""
            nonvalid_npi_taxnmy_adddt = ""
            nonvalid_npi_taxnmy_srctypcd = ""
            nonvalid_npi_taxnmy_code = ""
            if (nonvalidnpitax0.label == "taxonomy") {
              for (nonvalidnpitax1 <- nonvalidnpitax0.child) {
                if (nonvalidnpitax1.label == "taxonomyEffDates") {
                  for (nonvalidnpitax2 <- nonvalidnpitax1.child) {
                    if (nonvalidnpitax2.label == "effStartDate") {
                      nonvalid_npi_taxnmy_effstrtdt = nonvalidnpitax2.text
                    }
                  }
                }
                if (nonvalidnpitax1.label == "addDate") {
                  nonvalid_npi_taxnmy_adddt = nonvalidnpitax1.text
                }
                if (nonvalidnpitax1.label == "sourceTypeCode") {
                  for (nonvalidnpitax2 <- nonvalidnpitax1.child) {
                    if (nonvalidnpitax2.label == "code") {
                      nonvalid_npi_taxnmy_srctypcd = nonvalidnpitax2.text
                    }
                  }
                }
                if (nonvalidnpitax1.label == "code") {
                  for (nonvalidnpitax2 <- nonvalidnpitax1.child) {
                    if (nonvalidnpitax2.label == "code") {
                      nonvalid_npi_taxnmy_code = nonvalidnpitax2.text
                    }
                  }
                }
              }
              val nonvalidnpitax = Nonvalidnpitaxonmy(nonvalid_npiid_match_taxnmy, nonvalid_npi_taxnmy_effstrtdt, nonvalid_npi_taxnmy_adddt, nonvalid_npi_taxnmy_srctypcd, nonvalid_npi_taxnmy_code)
              nonvalidnpitaxonmyList = nonvalidnpitax :: nonvalidnpitaxonmyList
            }
          }
        }
      }
    }

    var orgidobjotheridList: List[Orgidobjotherid] = List()
    for (orgid0 <- organizationxml \\ "orgIDObj" \\ "organizationId") {
      for (orgid1 <- orgid0.child) {
        if (orgid1.label == "value") {
          organization_orgid = orgid1.text
        }
      }
    }
    for (orgidobj0 <- xml \\ "ProvMasterMsg" \\ "body" \\ "provider" \\ "organization" \\ "orgIDObj" \\ "otherID") {
      orgidobj_otherid_name = ""
      orgidobj_otherid_value = ""
      orgidobj_otherid_effstartdt = ""
      for (orgidobj1 <- orgidobj0.child) {
        if (orgidobj1.label == "name") {
          orgidobj_otherid_name = orgidobj1.text
        }
        if (orgidobj1.label == "value") {
          orgidobj_otherid_value = orgidobj1.text
        }
        if (orgidobj1.label == "EffDate") {
          for (orgidobj2 <- orgidobj1.child) {
            if (orgidobj2.label == "effStartDate") {
              orgidobj_otherid_effstartdt = orgidobj2.text
            }
          }
        }
      }
      val orgidobjotherid = Orgidobjotherid(organization_orgid, orgidobj_otherid_name, orgidobj_otherid_value, orgidobj_otherid_effstartdt)
      orgidobjotheridList = orgidobjotherid :: orgidobjotheridList
    }


    var locidobjList: List[Locationidobj] = List()

    for (locidobj0 <- organizationxml \\ "serviceProvider" \\ "practiceLocations" \\ "locationIDObj" \\ "otherProvLocId") {
      locidobj_identifier = ""
      locidobj_addtypcode = ""
      locidobj_effstrtdt = ""
      for (locidobj1 <- locidobj0.child) {
        if (locidobj1.label == "identifiers") {
          for (locidobj2 <- locidobj1.child) {
            if (locidobj2.label == "value") {
              locidobj_identifier = locidobj2.text
            }
          }
        }
        if (locidobj1.label == "addressTypeCode") {
          for (locidobj2 <- locidobj1.child) {
            if (locidobj2.label == "code") {
              locidobj_addtypcode = locidobj2.text
            }
          }
        }
        if (locidobj1.label == "effectiveDateRange") {
          for (locidobj2 <- locidobj1.child) {
            if (locidobj2.label == "effStartDate") {
              locidobj_effstrtdt = locidobj2.text
            }
          }
        }
      }
      val locidobj = Locationidobj(locidobj_identifier, locidobj_addtypcode, locidobj_effstrtdt)
      locidobjList = locidobj :: locidobjList
    }

    for (correpndnce0 <- organizationxml \\ "serviceProvider" \\ "practiceLocations" \\ "correspondence") {
      correpndnce_address_line1 = ""
      correpndnce_city = ""
      correpndnce_countycode = ""
      correpndnce_state = ""
      correpndnce_postalcode_part1 = ""
      correpndnce_postalcode_part2 = ""
      correpndnce_type = ""
      correpndnce_latitude = ""
      correpndnce_longitude = ""
      correpndnce_country = ""
      correpndnce_effstrtdt = ""
      correpndnce_telephone_typecode = ""
      correpndnce_telephone_countrycode = ""
      correpndnce_telephone_areacode = ""
      correpndnce_telephone_subscriber = ""
      correpndnce_telephone_telephonenbr = ""
      correpndnce_telephone_primind = ""
      for (correpndnce1 <- correpndnce0.child) {
        if (correpndnce1.label == "corrspAddr") {
          for (correpndnce2 <- correpndnce1.child) {
            if (correpndnce2.label == "line1") {
              correpndnce_address_line1 = correpndnce2.text
            }
            if (correpndnce2.label == "city") {
              correpndnce_city = correpndnce2.text
            }
            if (correpndnce2.label == "countyCode") {
              correpndnce_countycode = correpndnce2.text
            }
            if (correpndnce2.label == "state") {
              correpndnce_state = correpndnce2.text
            }
            if (correpndnce2.label == "postalCode") {
              for (correpndnce3 <- correpndnce2.child) {
                if (correpndnce3.label == "part1") {
                  correpndnce_postalcode_part1 = correpndnce3.text
                }
                if (correpndnce3.label == "part2") {
                  correpndnce_postalcode_part2 = correpndnce3.text
                }
              }
            }
            if (correpndnce2.label == "type") {
              correpndnce_type = correpndnce2.text
            }
            if (correpndnce2.label == "latLong") {
              for (correpndnce3 <- correpndnce2.child) {
                if (correpndnce3.label == "lat") {
                  correpndnce_latitude = correpndnce3.text
                }
                if (correpndnce3.label == "long") {
                  correpndnce_longitude = correpndnce3.text
                }
              }
            }
            if (correpndnce2.label == "country") {
              for (correpndnce3 <- correpndnce2.child) {
                if (correpndnce3.label == "code") {
                  correpndnce_country = correpndnce3.text
                }
              }
            }
          }
        }
        if (correpndnce1.label == "corrspEffDates") {
          for (correpndnce2 <- correpndnce1.child) {
            if (correpndnce2.label == "effStartDate") {
              correpndnce_effstrtdt = correpndnce2.text
            }
          }
        }
        if (correpndnce1.label == "telephones") {
          for (correpndnce2 <- correpndnce1.child) {
            if (correpndnce2.label == "telephone") {
              for (correpndnce3 <- correpndnce2.child) {
                if (correpndnce3.label == "phoneTypeCode") {
                  for (correpndnce4 <- correpndnce3.child) {
                    if (correpndnce4.label == "code") {
                      correpndnce_telephone_typecode = correpndnce4.text
                    }
                  }
                }
                if (correpndnce3.label == "country") {
                  correpndnce_telephone_countrycode = correpndnce3.text
                }
                if (correpndnce3.label == "area") {
                  correpndnce_telephone_areacode = correpndnce3.text
                }
                if (correpndnce3.label == "subscriber") {
                  correpndnce_telephone_subscriber = correpndnce3.text
                }
                if (correpndnce3.label == "telephoneNbr") {
                  correpndnce_telephone_telephonenbr = correpndnce3.text
                }
                if (correpndnce3.label == "primInd") {
                  correpndnce_telephone_primind = correpndnce3.text
                }
              }
            }
          }
        }
      }
    }

    var correpndnceList: List[Correspondence] = List()

    for (corresaddline0 <- organizationxml \\ "serviceProvider" \\ "practiceLocations" \\ "correspondence") {
      for (corresaddline1 <- corresaddline0.child) {

        correpndnce_matchaddr_othrprovloc = ""
        correpndnce_effstrtdtmatch_otherprovloc = ""

        if (corresaddline1.label == "corrspAddr") {
          for (corresaddlinex <- corresaddline1.child) {
            if (corresaddlinex.label == "line1") {
              correpndnce_matchaddr_othrprovloc = corresaddlinex.text

              for (corresaddeffdt0 <- corresaddline0) {
                for (corresaddeffdt1 <- corresaddeffdt0.child) {

                  if (corresaddeffdt1.label == "corrspEffDates") {
                    for (corresaddeffdt2 <- corresaddeffdt1.child) {
                      if (corresaddeffdt2.label == "effStartDate") {
                        correpndnce_effstrtdtmatch_otherprovloc = corresaddeffdt2.text
                      }
                    }
                  }
                }
              }


              for (correpndnce0 <- corresaddline0 \\ "otherProvLocId") {
                correpndnce_othrprov_identifier = ""
                correpndnce_othrprov_addtypcode = ""
                correpndnce_othrprov_effstrtdt = ""

                for (correpndnce1 <- correpndnce0.child) {
                  if (correpndnce1.label == "identifiers") {
                    for (correpndnce2 <- correpndnce1.child) {
                      if (correpndnce2.label == "value") {
                        correpndnce_othrprov_identifier = correpndnce2.text
                      }
                    }
                  }
                  if (correpndnce1.label == "addressTypeCode") {
                    for (correpndnce2 <- correpndnce1.child) {
                      if (correpndnce2.label == "code") {
                        correpndnce_othrprov_addtypcode = correpndnce2.text
                      }
                    }
                  }
                  if (correpndnce1.label == "effectiveDateRange") {
                    for (correpndnce2 <- correpndnce1.child) {
                      if (correpndnce2.label == "effStartDate") {
                        correpndnce_othrprov_effstrtdt = correpndnce2.text
                      }
                    }
                  }
                }
                val correspondence = Correspondence(correpndnce_matchaddr_othrprovloc, correpndnce_effstrtdtmatch_otherprovloc, correpndnce_othrprov_identifier, correpndnce_othrprov_addtypcode, correpndnce_othrprov_effstrtdt)
                correpndnceList = correspondence :: correpndnceList
              }
            }

          }
        }
      }
    }
    /* var correpndnceList:List[Correspondence] = List()

    for ( correpndnce0 <- organizationxml \\ "serviceProvider" \\ "practiceLocations" \\ "correspondence" \\ "otherProvLocId" ){
      correpndnce_othrprov_identifier = ""
      correpndnce_othrprov_addtypcode = ""
      correpndnce_othrprov_effstrtdt = ""
      for ( correpndnce1 <- correpndnce0.child){
       if( correpndnce1.label == "identifiers"){
         for(correpndnce2 <- correpndnce1.child){
           if( correpndnce2.label == "value"){
           correpndnce_othrprov_identifier = correpndnce2.text
           }
         }
       }
       if( correpndnce1.label == "addressTypeCode"){
         for(correpndnce2 <- correpndnce1.child){
           if( correpndnce2.label == "code"){
           correpndnce_othrprov_addtypcode = correpndnce2.text
           }
         }
       }
       if( correpndnce1.label == "effectiveDateRange"){
         for(correpndnce2 <- correpndnce1.child){
           if( correpndnce2.label == "effStartDate"){
           correpndnce_othrprov_effstrtdt = correpndnce2.text
           }
         }
       }
      }
      val correspondence = Correspondence(correpndnce_othrprov_identifier, correpndnce_othrprov_addtypcode, correpndnce_othrprov_effstrtdt)
       correpndnceList =  correspondence :: correpndnceList
    }*/

    for (survy0 <- organizationxml \\ "serviceProvider" \\ "practiceLocations" \\ "surveys") {
      for (survy1 <- survy0.child) {
        if (survy1.label == "score") {
          pracloc_survey_code = survy1.text
        }
        if (survy1.label == "handicapAccessibleInd") {
          pracloc_survey_hndcpaccessind = survy1.text
        }
      }
    }


    for (rltdorgids0 <- organizationxml \\ "serviceProvider" \\ "relatedOrgIds") {
      rltdorgid_taxidnbr = ""
      rltdorgid_taxid_typecode = ""
      rltdorgid_taxid_numbreffstrtdt = ""
      rltdorgid_taxid_ownername = ""
      rltdorgid_tieredproviderservcmodltypcd = ""
      rltdorgid_tieredproviderservcmodleffstrtdt = ""
      rltdorgid_taxid_enterpriseid = ""
      rltdorgid_hcotinowner_enterpriseid = ""
      for (rltdorgids1 <- rltdorgids0.child) {
        if (rltdorgids1.label == "hcoTINOwner") {
          for (role5 <- rltdorgids1.child) {
            if (role5.label == "taxID") {
              for (role6 <- role5.child) {
                if (role6.label == "taxIdNbr") {
                  rltdorgid_taxidnbr = role6.text
                }
                if (role6.label == "typeCode") {
                  for (role7 <- role6.child) {
                    if (role7.label == "code") {
                      rltdorgid_taxid_typecode = role7.text
                    }
                  }
                }
                if (role6.label == "numberEffDate") {
                  for (role7 <- role6.child) {
                    if (role7.label == "effStartDate") {
                      rltdorgid_taxid_numbreffstrtdt = role7.text
                    }
                  }
                }
                if (role6.label == "legalOwnerName") {
                  for (role7 <- role6.child) {
                    if (role7.label == "name") {
                      rltdorgid_taxid_ownername = role7.text
                    }
                  }
                }
                if (role6.label == "tieredProviderServiceModel") {
                  for (role7 <- role6.child) {
                    if (role7.label == "tieredProviderServiceModelTypeCode") {
                      for (role8 <- role7.child) {
                        if (role8.label == "code") {
                          rltdorgid_tieredproviderservcmodltypcd = role8.text
                        }
                      }
                    }
                    if (role7.label == "tieredProviderServiceModelEffDate") {
                      for (role8 <- role7.child) {
                        if (role8.label == "effStartDate") {
                          rltdorgid_tieredproviderservcmodleffstrtdt = role8.text
                        }
                      }
                    }
                  }
                }
                if (role6.label == "enterpriseId") {
                  rltdorgid_taxid_enterpriseid = role6.text
                }
              }
            }
            if (role5.label == "enterpriseId") {
              rltdorgid_hcotinowner_enterpriseid = role5.text
            }
          }
        }
      }
    }


    var taxonomyclassList: List[Taxonomyclass] = List()
    for (taxonomyclass0 <- (organizationxml \\ "taxonomy")) {
      for (taxonomyclassx <- taxonomyclass0.child) {
        taxonomy_provtypcd_match_class = ""
        if (taxonomyclassx.label == "providerType") {
          taxonomy_provtypcd_match_class = taxonomyclassx.text

          for (taxonomyclassi0 <- (taxonomyclass0 \\ "classification")) {
            taxonomy_classicode = ""
            taxonomy_classieffstrtdt = ""
            taxonomy_classieffcancldt = ""
            taxonomy_classiprimclassind = ""
            taxonomy_classisrctype = ""
            taxonomy_classisrctypecode = ""
            taxonomy_classipracspclind = ""
            taxonomy_classispclbrdcertcode = ""
            taxonomy_classispclbrdcertdate = ""
            taxonomy_classispclbrdexamdate = ""
            taxonomy_classispclbrdexpdate = ""
            taxonomy_classirecerteffdate = ""
            if (taxonomyclassi0.label == "classification") {
              for (taxonomyclassi1 <- taxonomyclassi0.child) {
                if (taxonomyclassi1.label == "code") {
                  taxonomy_classicode = taxonomyclassi1.text
                }
                if (taxonomyclassi1.label == "effDateRange") {
                  for (taxonomyclassi2 <- taxonomyclassi1.child) {
                    if (taxonomyclassi2.label == "effStartDate") {
                      taxonomy_classieffstrtdt = taxonomyclassi2.text
                    }
                    if (taxonomyclassi2.label == "effCancelDate") {
                      taxonomy_classieffcancldt = taxonomyclassi2.text
                    }
                  }
                }
                if (taxonomyclassi1.label == "dataSourceType") {
                  for (taxonomyclassi2 <- taxonomyclassi1.child) {
                    if (taxonomyclassi2.label == "code") {
                      taxonomy_classisrctype = taxonomyclassi2.text
                    }
                  }
                }
                if (taxonomyclassi1.label == "taxonomyVerificationSourceTypeCode") {
                  for (taxonomyclassi2 <- taxonomyclassi1.child) {
                    if (taxonomyclassi2.label == "code") {
                      taxonomy_classisrctypecode = taxonomyclassi2.text
                    }
                  }
                }
                if (taxonomyclassi1.label == "practicingSpecialtyInd") {
                  taxonomy_classipracspclind = taxonomyclassi1.text
                }
                if (taxonomyclassi1.label == "primClassInd") {
                  taxonomy_classiprimclassind = taxonomyclassi1.text
                }
                if (taxonomyclassi1.label == "specialtyBoardCertificationCode") {
                  for (taxonomyclassi2 <- taxonomyclassi1.child) {
                    if (taxonomyclassi2.label == "code") {
                      taxonomy_classispclbrdcertcode = taxonomyclassi2.text
                    }
                  }
                }
                if (taxonomyclassi1.label == "spclBrdCertDate") {
                  taxonomy_classispclbrdcertdate = taxonomyclassi1.text
                }
                if (taxonomyclassi1.label == "spclBrdExamDate") {
                  taxonomy_classispclbrdexamdate = taxonomyclassi1.text
                }
                if (taxonomyclassi1.label == "spclBrdExpDate") {
                  taxonomy_classispclbrdexpdate = taxonomyclassi1.text
                }
                if (taxonomyclassi1.label == "recertEffDate") {
                  for (taxonomyclassi2 <- taxonomyclassi1.child) {
                    if (taxonomyclassi2.label == "EffStartDate") {
                      taxonomy_classirecerteffdate = taxonomyclassi2.text
                    }
                  }
                }
              }

              val taxonomyclass_info = Taxonomyclass(taxonomy_provtypcd_match_class, taxonomy_classicode, taxonomy_classieffstrtdt, taxonomy_classieffcancldt, taxonomy_classiprimclassind, taxonomy_classisrctype, taxonomy_classisrctypecode, taxonomy_classipracspclind, taxonomy_classispclbrdcertcode, taxonomy_classispclbrdcertdate, taxonomy_classispclbrdexamdate, taxonomy_classispclbrdexpdate, taxonomy_classirecerteffdate)
              taxonomyclassList = taxonomyclass_info :: taxonomyclassList
            }
          }
        }
      }
    }

    var txnmyclsspcltyList: List[Txnmyclsspclty] = List()

    for (txnmyclsspcl0 <- (organizationxml \\ "taxonomy" \\ "classification")) {
      for (txnmyclsspcl1 <- txnmyclsspcl0.child) {
        txnmy_clss_match_code = ""

        if (txnmyclsspcl1.label == "code") {
          txnmy_clss_match_code = txnmyclsspcl1.text


          for (txnmyclsspclty0 <- (txnmyclsspcl0 \\ "specialty")) {
            txnmyclsspclty_code = ""
            txnmyclsspclty_effstrtdt = ""
            txnmyclsspclty_effcancldt = ""
            txnmyclsspclty_datasrctypcd = ""
            txnmyclsspclty_pracspclind = ""
            txnmyclsspclty_primspclind = ""
            txnmyclsspclty_srctypecode = ""
            if (txnmyclsspclty0.label == "specialty") {
              for (txnmyclsspclty1 <- txnmyclsspclty0.child) {
                if (txnmyclsspclty1.label == "code") {
                  txnmyclsspclty_code = txnmyclsspclty1.text
                }
                if (txnmyclsspclty1.label == "effDateRange") {
                  for (txnmyclsspclty2 <- txnmyclsspclty1.child) {
                    if (txnmyclsspclty2.label == "effStartDate") {
                      txnmyclsspclty_effstrtdt = txnmyclsspclty2.text
                    }
                    if (txnmyclsspclty2.label == "effCancelDate") {
                      txnmyclsspclty_effcancldt = txnmyclsspclty2.text
                    }
                  }
                }

                if (txnmyclsspclty1.label == "practicingSpecialtyInd") {
                  txnmyclsspclty_pracspclind = txnmyclsspclty1.text
                }
                if (txnmyclsspclty1.label == "primSpclInd") {
                  txnmyclsspclty_primspclind = txnmyclsspclty1.text
                }
                if (txnmyclsspclty1.label == "dataSourceType") {
                  for (txnmyclsspclty2 <- txnmyclsspclty1.child) {
                    if (txnmyclsspclty2.label == "code") {
                      txnmyclsspclty_datasrctypcd = txnmyclsspclty2.text
                    }
                  }
                }
                if (txnmyclsspclty1.label == "taxonomyVerificationSourceTypeCode") {
                  for (txnmyclsspclty2 <- txnmyclsspclty1.child) {
                    if (txnmyclsspclty2.label == "code") {
                      txnmyclsspclty_srctypecode = txnmyclsspclty2.text
                    }
                  }
                }
              }
              val txnmyclsspclty_info = Txnmyclsspclty(txnmy_clss_match_code, txnmyclsspclty_code, txnmyclsspclty_effstrtdt, txnmyclsspclty_effcancldt, txnmyclsspclty_datasrctypcd, txnmyclsspclty_pracspclind, txnmyclsspclty_primspclind, txnmyclsspclty_srctypecode)
              txnmyclsspcltyList = txnmyclsspclty_info :: txnmyclsspcltyList
            }
          }
        }
      }
    }


    var eleccommuList: List[Eleccommu] = List()
    for (praclocaddreleccomm0 <- organizationxml \\ "serviceProvider" \\ "practiceLocations") {
      for (praclocaddreleccomm1 <- praclocaddreleccomm0.child) {

        praclocaddline_matcheleccommu = ""
        if (praclocaddreleccomm1.label == "line1") {
          praclocaddline_matcheleccommu = praclocaddreleccomm1.text

          for (eleccomm <- (praclocaddreleccomm0 \\ "elecCommunications")) {
            eleccommu_addrtypecode = ""
            eleccommu_addrtext = ""
            eleccommu_statscode = ""
            if (eleccomm.label == "elecCommunications") {
              for (eleccomm0 <- eleccomm.child) {
                if (eleccomm0.label == "elecCommType") {
                  for (eleccomm1 <- eleccomm0.child) {
                    if (eleccomm1.label == "elecAddrTypeCode") {
                      for (eleccomm2 <- eleccomm1.child) {
                        if (eleccomm2.label == "code") {
                          eleccommu_addrtypecode = eleccomm1.text
                        }
                      }
                    }
                    if (eleccomm1.label == "elecAddrText") {
                      eleccommu_addrtext = eleccomm1.text
                    }
                    if (eleccomm1.label == "statusCode") {
                      for (eleccomm2 <- eleccomm1.child) {
                        if (eleccomm2.label == "code") {
                          eleccommu_statscode = eleccomm2.text
                        }
                      }
                    }
                  }
                }
              }
              val eleccommu_info = Eleccommu(praclocaddline_matcheleccommu, eleccommu_addrtypecode, eleccommu_addrtext, eleccommu_statscode)
              eleccommuList = eleccommu_info :: eleccommuList
            }
          }
        }
      }
    }


    var hlthcarecredstsList: List[Hlthcarecredsts] = List()
    for (hlthcarecred0 <- organizationxml \\ "healthCareCredentialStatuses") {
      hlthcarecredsts_ststypcd = ""
      hlthcarecredsts_credtypcd = ""
      hlthcarecredsts_credtypcd_desc = ""
      hlthcarecredsts_effstrtdt = ""
      hlthcarecredsts_effcancldt = ""
      hlthcarecredsts_credrespcd = ""
      hlthcarecredsts_corpbussegcd = ""
      hlthcarecredsts_org_id = ""
      for (hlthcarecred1 <- hlthcarecred0.child) {
        if (hlthcarecred1.label == "statusTypeCode") {
          for (hlthcarecred2 <- hlthcarecred1.child) {
            if (hlthcarecred2.label == "code") {
              hlthcarecredsts_ststypcd = hlthcarecred2.text
            }
          }
        }
        if (hlthcarecred1.label == "credentialTypeCode") {
          for (hlthcarecred2 <- hlthcarecred1.child) {
            if (hlthcarecred2.label == "code") {
              hlthcarecredsts_credtypcd = hlthcarecred2.text
            }
            if (hlthcarecred2.label == "desc") {
              hlthcarecredsts_credtypcd_desc = hlthcarecred2.text
            }
          }
        }
        if (hlthcarecred1.label == "effectiveDateRange") {
          for (hlthcarecred2 <- hlthcarecred1.child) {
            if (hlthcarecred2.label == "effStartDate") {
              hlthcarecredsts_effstrtdt = hlthcarecred2.text
            }
            if (hlthcarecred2.label == "effCancelDate") {
              hlthcarecredsts_effcancldt = hlthcarecred2.text
            }
          }
        }
        if (hlthcarecred1.label == "credResponsibilityCode") {
          for (hlthcarecred2 <- hlthcarecred1.child) {
            if (hlthcarecred2.label == "code") {
              hlthcarecredsts_credrespcd = hlthcarecred2.text
            }
          }
        }
        if (hlthcarecred1.label == "corpBusinessSegmentCode") {
          for (hlthcarecred2 <- hlthcarecred1.child) {
            if (hlthcarecred2.label == "code") {
              hlthcarecredsts_corpbussegcd = hlthcarecred2.text
            }
          }
        }
        if (hlthcarecred1.label == "organizationId") {
          for (hlthcarecred2 <- hlthcarecred1.child) {
            if (hlthcarecred2.label == "value") {
              hlthcarecredsts_org_id = hlthcarecred2.text
            }
          }
        }
      }
      val hlthcarecredsts_info = Hlthcarecredsts(hlthcarecredsts_ststypcd, hlthcarecredsts_credtypcd, hlthcarecredsts_credtypcd_desc, hlthcarecredsts_effstrtdt, hlthcarecredsts_effcancldt, hlthcarecredsts_credrespcd, hlthcarecredsts_corpbussegcd, hlthcarecredsts_org_id)
      hlthcarecredstsList = hlthcarecredsts_info :: hlthcarecredstsList
    }


    var alternatenmsList: List[Alternatenms] = List()
    for (alternatenm0 <- organizationxml \\ "serviceProvider" \\ "name") {
      alternatenms_servprov_match_nm = ""
      for (alternatenm1 <- alternatenm0.child) {
        if (alternatenm1.label == "name") {
          alternatenms_servprov_match_nm = alternatenm1.text

          alternatenms_name = ""
          alternatenms_nametypcd = ""
          alternatenms_stscd = ""
          for (alternatenms0 <- organizationxml \\ "serviceProvider" \\ "alternateName") {
            for (alternatenms1 <- alternatenms0.child) {
              if (alternatenms1.label == "name") {
                alternatenms_name = alternatenms1.text
              }
              if (alternatenms1.label == "nameTypeCode") {
                for (alternatenms2 <- alternatenms1.child) {
                  if (alternatenms2.label == "code") {
                    alternatenms_nametypcd = alternatenms2.text
                  }
                }
              }
              if (alternatenms1.label == "statusCode") {
                for (alternatenms2 <- alternatenms1.child) {
                  if (alternatenms2.label == "code") {
                    alternatenms_stscd = alternatenms2.text
                  }
                }
              }
            }
            val alternatenms_info = Alternatenms(alternatenms_servprov_match_nm, alternatenms_name, alternatenms_nametypcd, alternatenms_stscd)
            alternatenmsList = alternatenms_info :: alternatenmsList
          }
        }
      }
    }


    var hcotinownercorrList: List[Hcotinownercorr] = List()

    for (hcotinownercorrx <- organizationxml \\ "orgIDObj" \\ "hcoTINOwner" \\ "taxID") {
      for (hcotinownercorry <- hcotinownercorrx.child) {
        tinowner_match_taxid = ""
        if (hcotinownercorry.label == "taxIdNbr") {
          tinowner_match_taxid = hcotinownercorry.text
          //	for (hcotinownercorrz <- hcotinownercorry.child){
          //	tinowner_match_effstrtdt = ""
          //	if ( hcotinownercorrz.label == "numberEffDate"){
          //	tinowner_match_effstrtdt = hcotinownercorrz.text
          //	}
          //	}
          for (hcotinownercorr0 <- hcotinownercorrx \\ "hcoTINOwnerCorrespondence") {
            tinowner_address_line1 = ""
            tinowner_city = ""
            tinowner_county_code = ""
            tinowner_state = ""
            tinowner_postalcode_part1 = ""
            tinowner_postalcode_part2 = ""
            tinowner_type = ""
            tinowner_longitude = ""
            tinowner_latitude = ""
            tinowner_country = ""
            tinowner_locationidobj_identifier = ""
            tinowner_locationidobj_addrtypcode = ""
            tinowner_corrspeffstrtdt = ""
            tinowner_effectivedtrange_strtdt = ""
            if (hcotinownercorr0.label == "hcoTINOwnerCorrespondence") {
              for (curLoc13 <- hcotinownercorr0.child) {
                if (curLoc13.label == "correspondenceAddr") {
                  for (curLoc14 <- curLoc13.child) {
                    if (curLoc14.label == "line1") {
                      tinowner_address_line1 = curLoc14.text
                    }
                    if (curLoc14.label == "city") {
                      tinowner_city = curLoc14.text
                    }
                    if (curLoc14.label == "countyCode") {
                      tinowner_county_code = curLoc14.text
                    }
                    if (curLoc14.label == "state") {
                      tinowner_state = curLoc14.text
                    }
                    if (curLoc14.label == "postalCode") {
                      for (curLoc15 <- curLoc14.child) {
                        if (curLoc15.label == "part1") {
                          tinowner_postalcode_part1 = curLoc15.text
                        }
                        if (curLoc15.label == "part2") {
                          tinowner_postalcode_part2 = curLoc15.text
                        }
                      }
                    }
                    if (curLoc14.label == "type") {
                      tinowner_type = curLoc14.text
                    }
                    if (curLoc14.label == "latLong") {
                      for (curLoc15 <- curLoc14.child) {
                        if (curLoc15.label == "lat") {
                          tinowner_latitude = curLoc15.text
                        }
                        if (curLoc15.label == "long") {
                          tinowner_longitude = curLoc15.text
                        }
                      }
                    }
                    if (curLoc14.label == "country") {
                      tinowner_country = curLoc14.text
                    }
                    if (curLoc14.label == "locationIDObj") {
                      for (curLoc15 <- curLoc14.child) {
                        if (curLoc15.label == "otherProvLocId") {
                          for (curLoc16 <- curLoc15.child) {
                            if (curLoc16.label == "identifiers") {
                              for (curLoc17 <- curLoc16.child) {
                                if (curLoc17.label == "value") {
                                  tinowner_locationidobj_identifier = curLoc17.text
                                }
                              }
                            }
                            if (curLoc16.label == "addressTypeCode") {
                              for (curLoc17 <- curLoc16.child) {
                                if (curLoc17.label == "code") {
                                  tinowner_locationidobj_addrtypcode = curLoc17.text
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
                if (curLoc13.label == "corrspEffDates") {
                  for (curLoc14 <- curLoc13.child) {
                    if (curLoc14.label == "effStartDate") {
                      tinowner_corrspeffstrtdt = curLoc14.text
                    }
                  }
                }
                if (curLoc13.label == "tinOwnerEffectiveDateRange") {
                  for (curLoc14 <- curLoc13.child) {
                    if (curLoc14.label == "startDate") {
                      tinowner_effectivedtrange_strtdt = curLoc14.text
                    }
                  }
                }
              }
              val hcotinownercorr_info = Hcotinownercorr(tinowner_match_taxid, tinowner_address_line1, tinowner_city, tinowner_county_code, tinowner_state, tinowner_postalcode_part1,
                tinowner_postalcode_part2, tinowner_type, tinowner_latitude, tinowner_longitude, tinowner_country,
                tinowner_locationidobj_identifier, tinowner_locationidobj_addrtypcode, tinowner_corrspeffstrtdt, tinowner_effectivedtrange_strtdt)
              hcotinownercorrList = hcotinownercorr_info :: hcotinownercorrList
            }
          }
        }
      }
    }

    var serprovpraclocList: List[Serprovpracloc] = List()

    for (serprovpracloc0 <- (organizationxml \\ "serviceProvider" \\ "practiceLocations")) {
      pracloc_address_line1 = ""
      pracloc_city = ""
      pracloc_countycode = ""
      pracloc_state = ""
      pracloc_postalcode_part1 = ""
      pracloc_postalcode_part2 = ""
      pracloc_type = ""
      pracloc_primaryind = ""
      pracloc_latitude = ""
      pracloc_longitude = ""
      pracloc_country = ""
      pracloc_location_effstrtdt = ""
      pracloc_locationname = ""
      if (serprovpracloc0.label == "practiceLocations") {
        for (curLoc4 <- serprovpracloc0.child) {
          if (curLoc4.label == "line1") {
            pracloc_address_line1 = curLoc4.text
          }
          if (curLoc4.label == "city") {
            pracloc_city = curLoc4.text
          }
          if (curLoc4.label == "countyCode") {
            pracloc_countycode = curLoc4.text
          }
          if (curLoc4.label == "state") {
            pracloc_state = curLoc4.text
          }
          if (curLoc4.label == "postalCode") {
            for (curLoc5 <- curLoc4.child) {
              if (curLoc5.label == "part1") {
                pracloc_postalcode_part1 = curLoc5.text
              }
              if (curLoc5.label == "part2") {
                pracloc_postalcode_part2 = curLoc5.text
              }
            }
          }
          if (curLoc4.label == "type") {
            pracloc_type = curLoc4.text
          }
          if (curLoc4.label == "primaryInd") {
            pracloc_primaryind = curLoc4.text
          }
          if (curLoc4.label == "latLong") {
            for (curLoc5 <- curLoc4.child) {
              if (curLoc5.label == "lat") {
                pracloc_latitude = curLoc5.text
              }
              if (curLoc5.label == "long") {
                pracloc_longitude = curLoc5.text
              }
            }
          }
          if (curLoc4.label == "country") {
            for (curLoc5 <- curLoc4.child) {
              if (curLoc5.label == "code") {
                pracloc_country = curLoc5.text
              }
            }
          }
          if (curLoc4.label == "locationEffDate") {
            for (curLoc5 <- curLoc4.child) {
              if (curLoc5.label == "effStartDate") {
                pracloc_location_effstrtdt = curLoc5.text
              }
            }
          }
          if (curLoc4.label == "locationName") {
            pracloc_locationname = curLoc4.text
          }
        }
      }
      val serprovpracloc = Serprovpracloc(pracloc_address_line1, pracloc_city, pracloc_countycode, pracloc_state, pracloc_postalcode_part1, pracloc_postalcode_part2,
        pracloc_type, pracloc_primaryind, pracloc_latitude, pracloc_longitude, pracloc_country, pracloc_location_effstrtdt, pracloc_locationname)
      serprovpraclocList = serprovpracloc :: serprovpraclocList
    }

    var hlthcareeleccommList: List[Hlthcareeleccomm] = List()

    for (hlthcareeleccomm0 <- (organizationxml \\ "healthCareElectronicCommunication")) {
      hlthcareeleccommu_addrtypecode = ""
      hlthcareeleccommu_addrtext = ""
      hlthcareeleccommu_statscode = ""


      if (hlthcareeleccomm0.label == "healthCareElectronicCommunication") {
        for (eleccomm0 <- hlthcareeleccomm0.child) {
          if (eleccomm0.label == "elecCommType") {
            for (eleccomm1 <- eleccomm0.child) {
              if (eleccomm1.label == "elecAddrTypeCode") {
                for (eleccomm2 <- eleccomm1.child) {
                  if (eleccomm2.label == "code") {
                    hlthcareeleccommu_addrtypecode = eleccomm1.text
                  }
                }
              }
              if (eleccomm1.label == "elecAddrText") {
                hlthcareeleccommu_addrtext = eleccomm1.text
              }
              if (eleccomm1.label == "statusCode") {
                for (eleccomm2 <- eleccomm1.child) {
                  if (eleccomm2.label == "code") {
                    hlthcareeleccommu_statscode = eleccomm2.text
                  }
                }
              }
            }
          }
        }
        val hlthcareeleccomm = Hlthcareeleccomm(hlthcareeleccommu_addrtypecode, hlthcareeleccommu_addrtext, hlthcareeleccommu_statscode)
        hlthcareeleccommList = hlthcareeleccomm :: hlthcareeleccommList
      }
    }


    return PMdmCol(timestamp.text, organization_code, proveff_startdate, partytype_codetype, providobj_enterprise_id, /*organization_name, org_effstartdate,*/ organization_id, source_name, source_id, source_effstartdate, source_effenddate, tax_id,
      tax_code, tax_effstartdate, legal_ownername, legal_ownereffstartdate, legal_ownereffenddate, provider_servicemodeltype_code, provider_servicemodel_effstartdate, provider_servicemodel_effenddate, hcotinowner_enterpriseid,
      tinowner_effdate_startdt, tinowner_remittance_typecode, tinowner_pymtmthd_typecode, tinowner_elecpymnt_prefind,
      /*nonvalid_npi_name, nonvalid_npi_value, nonvalid_npi_srcsystm, nonvalid_npi_effstrtdt, nonvalid_npi_adddt,*/ nonvalidnpitaxonmyList, orgidobjotheridList, orgidobj_otherid_name, orgidobj_otherid_value, orgidobj_otherid_effstartdt,
      healthcaresolopractice_name, healthcaresolopractice_code, healthcaregroup_name, healthcaregroup_code, servcprov_name, servcprov_effstrtdt, servcprov_hosptlind, servcprov_taxidnbr, servcprov_typecode, servcprov_entityidentifier, servcprov_source_name, servcprov_source_value,
      servcprov_source_effstartdate, servcprov_mdcareid_name, servcprov_mdcareid_value, servcprov_mdcareid_effstartdate, servcprov_mdcareid_statuscd,
      servcprov_otherid_name, servcprov_otherid_value, servcprov_otherid_effstartdate, servcprov_lic_nbr, servcprov_lic_add_state, servcprov_lic_add_countrycd, servcprov_lic_effstrtdt, servcprov_lic_typecd, servcprov_lic_statuscd, /*pracloc_address_line1 , pracloc_city , pracloc_countycode , pracloc_state ,
         pracloc_postalcode_part1 , pracloc_postalcode_part2 , pracloc_type ,pracloc_primaryind, pracloc_latitude , pracloc_longitude , pracloc_country , pracloc_location_effstrtdt , pracloc_locationname ,*/ praclocteleList, locidobjList, correpndnce_address_line1, correpndnce_city,
      correpndnce_countycode, correpndnce_state, correpndnce_postalcode_part1, correpndnce_postalcode_part2, correpndnce_type, correpndnce_latitude, correpndnce_longitude, correpndnce_country, correpndnce_effstrtdt,
      correpndnce_telephone_typecode, correpndnce_telephone_countrycode, correpndnce_telephone_areacode, correpndnce_telephone_subscriber, correpndnce_telephone_telephonenbr, correpndnce_telephone_primind, correpndnceList, pracloc_survey_code,
      pracloc_survey_hndcpaccessind, rltdorgid_taxidnbr, rltdorgid_taxid_typecode, rltdorgid_taxid_numbreffstrtdt, rltdorgid_taxid_ownername, rltdorgid_tieredproviderservcmodltypcd, rltdorgid_tieredproviderservcmodleffstrtdt,
      rltdorgid_taxid_enterpriseid, rltdorgid_hcotinowner_enterpriseid, healthcarecorporation_name, healthcarecorporation_code, taxonomy_providertypecode, taxonomy_effstartdate, taxonomyclassList, txnmyclsspcltyList, healthcarefacility_name, healthcarefacility_code, eleccommuList, praclocscheduleList, orgnamesList,
      nonvalidnpiList, orgtxnmyList, orgidobjmpinList, hlthcarecredstsList, alternatenmsList, hcotinownercorrList, serprovpraclocList, hlthcareeleccommList)

  }

}
