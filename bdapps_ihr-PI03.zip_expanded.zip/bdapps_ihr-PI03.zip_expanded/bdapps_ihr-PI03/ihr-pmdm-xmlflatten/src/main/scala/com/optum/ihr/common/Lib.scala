package com.optum.ihr.common

import java.text.SimpleDateFormat
import java.util.Calendar

object Lib {

  def getMilliSecCurrentTimeFormat: String = getCurrentDateTime("yyyy-MM-dd HH:mm:ss.SSS")

  def getCurrentDate: String = getCurrentDateTime("yyyyMMdd")

  def getCurrentDateTime(dateTimeFormat: String): String = {
    val dateFormat = new SimpleDateFormat(dateTimeFormat)
    val cal = Calendar.getInstance()
    dateFormat.format(cal.getTime)
  }


  def dateAddDay(date: String, days: Int, inputFormat: String, outputFormat: String): String = {
    val dateAux = Calendar.getInstance()
    dateAux.setTime(new SimpleDateFormat(inputFormat).parse(date))
    dateAux.add(Calendar.DATE, days)
    return new SimpleDateFormat(outputFormat).format(dateAux.getTime())
  }


}
