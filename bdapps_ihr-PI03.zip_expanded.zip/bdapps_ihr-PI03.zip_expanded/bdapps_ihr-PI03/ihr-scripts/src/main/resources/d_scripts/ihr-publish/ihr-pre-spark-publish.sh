#!/bin/sh


domain=$1
inbound_path=$2
archive_path=$3

#cp ${inbound_path}/${domain}/*.hl7 ${archive_path}/${domain}/ 

sed -i 's/\r/\f/g' ${inbound_path}/${domain}/*.hl7

if [ $? -ne 0 ];
then
  echo hl7 files not found
fi
