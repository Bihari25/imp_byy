#!/bin/sh


file_base_location=$1
domain=$2

file_location=${file_base_location}/${domain}
file_count=`ls -l ${file_location}/* | wc -l`
rowkey=`ls ${file_location} | head -1 |  cut -d "." -f1`
if [ ${file_count} -eq 0 ]
then
  numberOfFiles=0
  recordCount=0
elif [ ${file_count} -eq 1 ]
then
  numberOfFiles=1
  recordCount=`wc -l ${file_location}/* | tr -s " " "|" | cut -d "|" -f1`
else
  numberOfFiles=${file_count}
  recordCount=`wc -l ${file_location}/* | tr -s " " "|" | grep total | cut -d "|" -f2`
fi

echo numberOfFiles=${numberOfFiles}
echo recordCount=$recordCount
batchId=${domain}_`date '+%Y%m%d%H%M%S'`
echo batchId=${batchId}
echo rowkey=${rowkey}
