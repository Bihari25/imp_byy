package com.optum.centriihr;


import com.rabbitmq.client.*;
import java.util.*;
import java.io.IOException;

/**
 * @author fsiddiq3
 */
public class TestSend {

    private final static String QUEUE_NAME = "PHARMACY_CLAIMS_OPTUMRX_test2";

    public static long n = 0;

    public static void main(String[] argv) throws Exception {

        ConnectionFactory factory = new ConnectionFactory();
        factory.setHost("10.204.74.179");//"10.204.96.186");

        factory.setPort(Integer.parseInt("6673"));
        factory.setUsername("admin");
        factory.setPassword("admin");
        factory.setVirtualHost("/");

        Connection connection = factory.newConnection();
        System.out.println("connection="+connection);
        Channel channel = connection.createChannel();

        channel.queueDeclare(QUEUE_NAME, true, false, false, null);

        //channel.txSelect();



        final SortedSet<Long> unconfirmedSet = Collections.synchronizedSortedSet(new TreeSet());

        channel.addConfirmListener(new ConfirmListener() {

            public void handleAck(long seqNo, boolean multiple) {
                System.out.println("ACK Ack received multiple="+multiple+", seqNo="+seqNo);
                if (multiple) {
                    unconfirmedSet.headSet(seqNo+1).clear();
                } else {
                    unconfirmedSet.remove(seqNo);
                }
            }
            public void handleNack(long seqNo, boolean multiple) {
                System.out.println("NACK Not ack received");
            }


        });
        channel.confirmSelect();

        for (long i = 0; i < 100000; ++i) {
            unconfirmedSet.add(channel.getNextPublishSeqNo());
            channel.basicPublish("", QUEUE_NAME, MessageProperties.PERSISTENT_TEXT_PLAIN, "hello".getBytes("UTF-8"));
        }
        while (unconfirmedSet.size() > 0)
            Thread.sleep(10);




        //channel.txCommit();

        //System.out.println("confirmSelect="+channel.confirmSelect().hasContent());

    }


}
