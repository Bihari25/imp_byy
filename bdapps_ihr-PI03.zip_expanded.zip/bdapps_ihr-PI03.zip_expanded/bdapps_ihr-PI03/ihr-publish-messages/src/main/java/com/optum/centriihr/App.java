package com.optum.centriihr;


import com.optum.centriihr.common.HBaseCommon;
import com.optum.centriihr.domain.IHRAuditTrackingDTO;
import org.apache.hadoop.fs.permission.FsAction;
import org.apache.hadoop.fs.permission.FsPermission;

import java.io.*;
import java.nio.file.Path;
import java.nio.file.attribute.PosixFilePermission;
import java.security.Permission;
import java.security.PermissionCollection;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashSet;
import java.util.Properties;
import java.util.Set;

/**
 * @author fsiddiq3
 */
public class App {

    public static DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

    public static String getCurrentTime() {
        return dateFormat.format(Calendar.getInstance().getTime());
    }

    public static Long getCurrentTimeInLong(String dateString) throws Exception {
        return dateFormat.parse(dateString).getTime();
    }

    public static void main(String[] args) throws  Exception {
        String processStartTime = getCurrentTime();
        IHRAuditTrackingDTO auditDTO = new IHRAuditTrackingDTO();
        //auditDTO.setPrcStTm(processStartTime);

        String processEndTime = "";
        System.out.println("Hello World!");
        WebServiceCall webServiceCall = new WebServiceCall();
        int errorCode = 0;

        String requestType = args[0];
        String domain = args[1];
        String batchId = args[2];//"filename_2017";
        String hbaseRowKey = "";

        String ihrPublishPropertiesPath = System.getProperty("ihr.publish.properties");
        Properties ihrPublishProperties = new Properties();

        if (ihrPublishPropertiesPath != null) {
            final FileInputStream in = new FileInputStream(ihrPublishPropertiesPath);
            ihrPublishProperties.load(in);
        } else {
            errorCode = 1;  // 1 - property file not found
        }

        String processMetrics = "";

        String wsdlURL = ihrPublishProperties.getProperty("ihr_wsdl");
        String hbaseAuditTable = ihrPublishProperties.getProperty("spark.ihr.audit.table");
        String processName = ihrPublishProperties.getProperty(domain + "_rowkey");
        //String hbaseRowKey = processName + "-" + batchId.substring(batchId.lastIndexOf("_")+1);
        //auditDTO.setPrcName(processName+"-"+batchId);

        String translatorIdOrRecCount = "";
        String response = "";

        System.out.println("wsdlURL="+wsdlURL);
        //auditDTO.setPrtnrCd(processName.split("-")[0]);
        //auditDTO.setSrcCd(processName.split("-")[1]);

        try {


            if ("receivedBatchRequest".equalsIgnoreCase(requestType)) {
                processMetrics = ihrPublishProperties.getProperty("ihr_hdfs")+"/"+domain+"-rbr.process"; // .replaceAll("/mapr", "")
                //hbaseRowKey = hbaseRowKey + "-rbr";
                hbaseRowKey = args[3];
                auditDTO.setId(hbaseRowKey);
                translatorIdOrRecCount = ihrPublishProperties.getProperty(domain + "_translator"); //"MSC_TEST";
                response = webServiceCall.callReceivedBatch(wsdlURL, batchId, translatorIdOrRecCount);
            } else { // enqueuedBatchRequest
                processMetrics = ihrPublishProperties.getProperty("ihr_hdfs")+"/"+domain+"-ebr.process"; // .replaceAll("/mapr", "")
                //hbaseRowKey = hbaseRowKey + "-ebr";
                hbaseRowKey = args[4];
                auditDTO.setId(hbaseRowKey);
                translatorIdOrRecCount = args[3];

                response = webServiceCall.callEnqueuedBatch(wsdlURL, batchId, translatorIdOrRecCount);
            }
            //String recordCount = args[1];//"99";
            //String translatorId = ihrPublishProperties.getProperty(domain+"_translator"); //"MSC_TEST";


            System.out.println("response=" + response);
            //auditDTO.setIncPrcSts("Success");



            errorCode = 0;
            //hbaseRowKey


        } catch (Exception ex) {
            errorCode = 1;
            //auditDTO.setIncPrcSts("Error in soap service call");
            StringWriter sw = new StringWriter();
            PrintWriter pw = new PrintWriter(sw);
            ex.printStackTrace(pw);
            auditDTO.setErrCd(requestType);
            auditDTO.setErrDesc(sw.toString());
            HBaseCommon.writeToHBase(hbaseAuditTable, auditDTO);
            ex.printStackTrace();
        }

        //processEndTime = getCurrentTime();
        //auditDTO.setPrcEndTm(processEndTime);



        File propertyFile = new File(System.getProperty("oozie.action.output.properties"));
        Properties properties = new Properties();
        properties.setProperty("response", response);
        properties.setProperty("errorCode", "" + errorCode);
        properties.setProperty("hbaseRowKey", hbaseRowKey);
        OutputStream os = new FileOutputStream(propertyFile);
        properties.store(os, "properties");
        os.close();

        File processFile = new File(processMetrics);
        OutputStream processOS = new FileOutputStream(processFile);
        properties.setProperty("request", webServiceCall.requestBody);
        properties.store(processOS, "ihr soap service call process info");

        processOS.close();

    }

}
