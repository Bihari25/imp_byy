package com.optum.centriihr.common

import com.optum.centriihr.domain.IHRAuditTracking
import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.hbase.{HBaseConfiguration, TableName}
import org.apache.hadoop.hbase.client._
import org.apache.hadoop.hbase.io.ImmutableBytesWritable
import org.apache.hadoop.hbase.mapreduce.TableInputFormat
import org.apache.hadoop.hbase.util.Bytes
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

class HBaseUtil(sparkSession: SparkSession) {

  val conf: Configuration = HBaseConfiguration.create()
  val conn: Connection = ConnectionFactory.createConnection(conf)

  def readFromHBase(tableName: String): org.apache.spark.rdd.RDD[Result] = {
    conf.set(TableInputFormat.INPUT_TABLE, tableName)
    val hBaseRDD = sparkSession.sparkContext.newAPIHadoopRDD(conf, classOf[TableInputFormat], classOf[ImmutableBytesWritable], classOf[Result])
    val resultRDD = hBaseRDD.map(tuple => tuple._2);
    //val rdd : RDD[Any] = resultRDD.map(IHR.parseHbaseIHRRow)
    resultRDD
  }


  def writeToHBase(tableName: String, iHRAuditTracking: IHRAuditTracking): Unit = {
    val hbaseTableName: TableName = TableName.valueOf(tableName)
    val hbaseTable: Table = conn.getTable(hbaseTableName)
    val put = new Put(Bytes.toBytes(iHRAuditTracking.id))
    put.addColumn(Bytes.toBytes("po"), Bytes.toBytes("prtnrCd"), Bytes.toBytes(iHRAuditTracking.prtnrCd))
    put.addColumn(Bytes.toBytes("po"), Bytes.toBytes("srcCd"), Bytes.toBytes(iHRAuditTracking.srcCd))
    put.addColumn(Bytes.toBytes("po"), Bytes.toBytes("prcNm"), Bytes.toBytes(iHRAuditTracking.prcName))
    put.addColumn(Bytes.toBytes("po"), Bytes.toBytes("incPrcSts"), Bytes.toBytes(iHRAuditTracking.incPrcSts))
    put.addColumn(Bytes.toBytes("po"), Bytes.toBytes("prcDate"), Bytes.toBytes(iHRAuditTracking.prcDate.toString))
    put.addColumn(Bytes.toBytes("po"), Bytes.toBytes("prcStTm"), Bytes.toBytes(iHRAuditTracking.prcStTm.toString))
    put.addColumn(Bytes.toBytes("po"), Bytes.toBytes("prcEndTm"), Bytes.toBytes(iHRAuditTracking.prcEndTm.toString))
    put.addColumn(Bytes.toBytes("po"), Bytes.toBytes("recCount"), Bytes.toBytes(iHRAuditTracking.reccnt))

    if(iHRAuditTracking.errCd != null && iHRAuditTracking.errCd.length>0) {
      put.addColumn(Bytes.toBytes("eri"), Bytes.toBytes("errCd"), Bytes.toBytes(iHRAuditTracking.errCd))
      put.addColumn(Bytes.toBytes("eri"), Bytes.toBytes("errDesc"), Bytes.toBytes(iHRAuditTracking.errDesc))
    }
    hbaseTable.put(put)
  }

  def cleanup(): Unit = {
    conn.close()
  }


}

object IHRTestJob {

  def testMe(): Unit = {

    val conf = HBaseConfiguration.create

    val admin = new HBaseAdmin(conf)
    var oldTableName = "/datalake/optum/optuminsight/udw/ihr/dev/d_mtables/ihr_audit_tracking"
    var newTableName = "/datalake/optum/optuminsight/udw/ihr/dev/d_mtables/ihr_audit_tracking_new"
    var snapshotName = "/datalake/optum/optuminsight/udw/ihr/dev/d_mtables/ihr_audit_tracking_snap"

    admin.disableTable(oldTableName)

    admin.snapshot(snapshotName, oldTableName)

    admin.cloneSnapshot(snapshotName, newTableName)

    admin.deleteSnapshot(snapshotName)
    admin.enableTable(oldTableName)

    //admin.deleteTable(oldTableName)
  }
  def main(args: Array[String]): Unit = {
    testMe()
  }
}

