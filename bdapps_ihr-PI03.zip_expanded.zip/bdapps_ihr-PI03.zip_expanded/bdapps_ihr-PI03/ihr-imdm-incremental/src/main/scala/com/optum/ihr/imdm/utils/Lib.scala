package com.optum.ihr.imdm.utils

import java.io.File
import java.text.SimpleDateFormat
import java.util.Calendar

import org.apache.hadoop.fs.{FileSystem, FileUtil, Path}
import org.apache.hadoop.hbase.TableName
import org.apache.hadoop.hbase.client.{Put, Scan}
import org.apache.hadoop.hbase.filter.CompareFilter.CompareOp
import org.apache.hadoop.hbase.filter._
import org.apache.hadoop.hbase.util.Bytes


object Lib {
  val globalContext = new GlobalContext

  def getCurrentTimeFormat: String = getCurrentDateTime("yyyy-MM-dd HH:mm:ss")

  def getCurrentTsFormat: String = getCurrentDateTime("yyyyMMddHHmmssSS").substring(0, 16)

  def getCurrentDateTime(dateTimeFormat: String): String = {
    val dateFormat = new SimpleDateFormat(dateTimeFormat)
    val cal = Calendar.getInstance()
    dateFormat.format(cal.getTime)
  }

  def getTimestamp(DateFormat: String): Long = {
    try {
      val timestampformat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
      timestampformat.parse(DateFormat).getTime
    } catch {
      case e: Exception => Logger.log.error("Exception while getting current date/time" :+ e.getMessage)
        0
    }
  }

  def filterListAnd(filters: Filter*) = new FilterList(FilterList.Operator.MUST_PASS_ALL, filters: _*)

  def filterListOr(filters: Filter*) = new FilterList(FilterList.Operator.MUST_PASS_ONE, filters: _*)

  def hbaseEitPut(eitRowKey: String, colFm: String, colNm: String, value: String): Unit = {
    try {
      val p = new Put(s"$eitRowKey".getBytes())
      p.addColumn(s"$colFm".getBytes(), s"$colNm".getBytes(), s"$value".getBytes())
      globalContext.ihrEitTab.put(p)
    } catch {
      case e: Exception => Logger.log.error("Exception at HBase EIT Put Commands at IHR_entity_info IHR_ADT_DTL" :+ e.getStackTrace.mkString)
        throw e
    }
  }

  def getEntityInfo(rowKey: String): Array[(String, String, String)] = {
    try {
      val ihrEntityInfoTab = globalContext.spark.getConf.get("spark.ihrEitTab")
      Logger.log.info(s"ihrEntityInfoTab config-spark.ihrEitTab: $ihrEntityInfoTab")
      val scanner = new Scan()
      scanner.setCaching(1000)
      scanner.setCacheBlocks(false)
      val filter1 = new RowFilter(CompareOp.EQUAL, new BinaryComparator(Bytes.toBytes(s"$rowKey")))
      scanner.setFilter(filter1)

      val ihrInfo = globalContext.hbaseContext.hbaseRDD(TableName.valueOf(ihrEntityInfoTab), scanner).cache()

      val ihrEntRDD = ihrInfo.map(tuple => {
        val result = tuple._2
        (Bytes.toString(result.getValue(Bytes.toBytes("ei"), Bytes.toBytes("prtnrCd"))),
          Bytes.toString(result.getValue(Bytes.toBytes("ei"), Bytes.toBytes("srcCd"))),
          Bytes.toString(result.getValue(Bytes.toBytes("is"), Bytes.toBytes("lastRnTs"))))
      })

      Logger.log.info(s"ihrEntRDD result successful")

      if (ihrEntRDD.isEmpty()) {
        Logger.log.info(s"Please Provide Appropriate RowKey / Check ihr_entity_info Tab for $rowKey properly")
      }

      ihrEntRDD.collect()

    } catch {
      case e: Exception => Logger.log.error(s"Exception while getting Configuration from ihr_entity_info Tab" :+ e.getMessage)
        throw e
    }
  }

  def tsScanOnImdmCrosswalkTb(incStTime: String, incEndTs: String): org.apache.spark.rdd.RDD[String] = {
      try {
        val startTime = s"$incStTime"
        val endTime = s"$incEndTs"
        val imdmCrossWalkTab = globalContext.spark.getConf.get("spark.imdmCwTab")
        Logger.log.info(s"imdmCrossWalkTab: $imdmCrossWalkTab")

        val prefixFilter1 = "CDB_PA"
        val prefixFilter2 = "CR"
        val prefixFilter3 = "CDB_SH"
        val prefixFilter4 = "GPS"
        val prefixFilter5 = "CDB_CS"
        val prefixFilter6 = "CDB_OX"

        val filter1 = new PrefixFilter(Bytes.toBytes(prefixFilter1))
        val filter2 = new PrefixFilter(Bytes.toBytes(prefixFilter2))
        val filter3 = new PrefixFilter(Bytes.toBytes(prefixFilter3))
        val filter4 = new PrefixFilter(Bytes.toBytes(prefixFilter4))
        val filter5 = new PrefixFilter(Bytes.toBytes(prefixFilter5))
        val filter6 = new PrefixFilter(Bytes.toBytes(prefixFilter6))

        val scanner = new Scan()
        scanner.setCaching(1000)
        scanner.setCacheBlocks(false)
        scanner.setFilter(filterListOr(filter1, filter2, filter3, filter4, filter5, filter6))
        scanner.setTimeRange(getTimestamp(startTime), getTimestamp(endTime))
        val snapInfo = globalContext.hbaseContext.hbaseRDD(TableName.valueOf(imdmCrossWalkTab), scanner).cache()
        val snapRDD = snapInfo.map(tuple => {
          val result = tuple._2
          (Bytes.toString(result.getRow()),
            Bytes.toString(result.getValue(Bytes.toBytes("ci"), Bytes.toBytes("crossWalkType"))),
            Bytes.toString(result.getValue(Bytes.toBytes("ci"), Bytes.toBytes("effStrDate"))),
            Bytes.toString(result.getValue(Bytes.toBytes("ci"), Bytes.toBytes("masterIndividualId"))),
            Bytes.toString(result.getValue(Bytes.toBytes("ci"), Bytes.toBytes("masterSourceSystemCode"))),
            Bytes.toString(result.getValue(Bytes.toBytes("ci"), Bytes.toBytes("sourceIndividulId"))),
            Bytes.toString(result.getValue(Bytes.toBytes("ci"), Bytes.toBytes("sourceSystemCode"))))
      })
        snapRDD.map(tuple => (tuple._1 + "," +tuple._2 + ","+ tuple._3 + "," + tuple._4 + "," + tuple._5 + "," + tuple._6 + "," + tuple._7))
    } catch {
      case e: Exception => Logger.log.error(s"Exception while getting record from imdmCrossWalkTab" :+ e.getMessage)
        throw e
    }
  }

  def rmDirIfExist(dir: String): Unit = {
    try {
      if (globalContext.fs.exists(new Path(s"$dir"))) {
        globalContext.fs.delete(new Path(dir), true)
      }
      else {
        Logger.log.info(s"Working Dir: $dir doesn't exist, Please check for Errors.")
      }
    } catch {
      case e: Exception => Logger.log.error("Exception at HBase Put Commands at IHR_enttiy_info" :+ e.getStackTrace.toString)
        throw e
    }
  }

  def filterRawFileExist(filePath: String): Boolean = {
    globalContext.fs.exists(new Path(s"$filePath"))
  }

  def merge(srcPath: String, dstPath: String): Boolean = {
    val hdfs = FileSystem.get(globalContext.spark.hadoopConfiguration)
    FileUtil.copyMerge(hdfs, new Path(srcPath), hdfs, new Path(dstPath), false, globalContext.spark.hadoopConfiguration, null)
  }

  def getType(lastRnTime: String, currTime: String): String = {
    val format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
    val days: Long = ((format.parse(lastRnTime).getTime - format.parse(currTime).getTime) / 86400000)
    if (days > 31) {
      "FULL"
    }
    else {
      "INCR"
    }
  }

  def putAuditReport(row_key:String, status:String, startTime: String, endTime: String, successRowCount: Long, errorcode: String,errorDesc: String):Unit={
    val prtnrCd="UHG"
    val srcCd="IMDM"
    hbaseAuditPut(row_key,"pi","prcNm",row_key)
    hbaseAuditPut(row_key,"pi","incPrcSts",status)
    hbaseAuditPut(row_key,"pi","prcEndTm",endTime)
    hbaseAuditPut(row_key,"pi","prcStTm",startTime)
    hbaseAuditPut(row_key,"pi","prtnrCd","UHG")
    hbaseAuditPut(row_key,"pi","srcCd","IMDM")
    if (status.equalsIgnoreCase("Failed")) {
      hbaseAuditPut(row_key,"eri","errCd",errorcode)
      hbaseAuditPut(row_key,"eri","errDesc",errorDesc)
    } else {
      hbaseAuditPut(row_key,"pi","processed-reccnt", successRowCount.toString)
    }
  }

  def hbaseAuditPut(eitRowKey: String, colFm: String, colNm: String, value: String): Unit = {
    try {
      val p = new Put(s"$eitRowKey".getBytes())
      p.addColumn(s"$colFm".getBytes(), s"$colNm".getBytes(), s"$value".getBytes())
      globalContext.ihrAuditTrackingTab.put(p)
    } catch {
      case e: Exception => Logger.log.info("Exception at HBase EIT Put Commands at IHR_entity_info IHR_ADT_DTL" :+ e.getStackTrace.mkString)
        throw e
    }
  }

  def getListOfFiles(dir: String):List[File] = {
    val d = new File(dir)
    if (d.exists && d.isDirectory) {
      d.listFiles.filter(_.isFile).toList
    } else {
      List[File]()
    }
  }

  def convertoString(str1:String, str2:String, str3:String, str4:String, str5:String, str6:String):String = {
    val str = str1 + "," + str2 + "," + str3 + ","+ str4 + "," + str5 + ","+ str6
    println(s"==========printing str========== :" + str)
    str
  }

}