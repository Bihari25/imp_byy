package com.optum.ihr.imdm

import com.optum.ihr.imdm.utils.{GlobalContext, Lib, Logger}
import org.apache.spark.sql.{Row, SaveMode}
import org.apache.spark.sql.types.{StringType, StructField, StructType, _}

/**
  * Created by ldevadi on 06/04/2018
  */

object CrosswalkIncremental {

  def main(args: Array[String]): Unit = {
    val globalContext = new GlobalContext
    val spark = globalContext.createSparkSession("iMDMCrosswalkIncremental")
    Logger.log.info("=============> Starting iMDM Crosswalk Incremental WorkFlow <=============")

    val entityInfo_RowKey = "UHG-IMDM-CW_INCREMENTAL"
    val imdmCwAudit_RowKey = s"$entityInfo_RowKey-${java.util.UUID.randomUUID.toString}"
    val prcStTs = Lib.getCurrentTimeFormat
    var prcEndTs = Lib.getCurrentTimeFormat
    var rowCount: Long = 0
    var lastRnTs_EntityInfo: String = "" //to capture previous successful Run TimeStamp, incase the current BatchJob Run fail Update this in ihr_entity_info
    Logger.log.info(s"Printing variables ::: iMDM_Cw_Autit_RowKey: $imdmCwAudit_RowKey, Process_Start_timeStamp: $prcStTs")

    try {
      // Get Batch start time i.e., last_run_timestamp from ihr_enity_info....
      val entityRow = Lib.getEntityInfo(entityInfo_RowKey)
      Logger.log.info(s"Entity Config for ${entityInfo_RowKey} from ihr_entity_info Table: " + entityRow.mkString)

      entityRow.foreach { case (patnrCd_, srcCd_, lastRnTs_) =>
        val ptnrCd = s"${patnrCd_.toUpperCase()}".trim
        val srcCd = s"${srcCd_.toUpperCase()}".trim
        lastRnTs_EntityInfo = s"${lastRnTs_.toUpperCase()}".trim

        Logger.log.info(s"ImdmCrossWalkTab scan timestamp range: $lastRnTs_EntityInfo and $prcStTs")

        //RDD return
        val tabScanRdd = Lib.tsScanOnImdmCrosswalkTb(lastRnTs_EntityInfo, prcStTs).cache()

        rowCount = tabScanRdd.count()
        Logger.log.info(s"==========printing tabScanRdd.toString: " + tabScanRdd.toString() + s" : and rowCount: $rowCount")

        tabScanRdd.take(10).foreach(println) // For testing, print RDD content..
        if (tabScanRdd.isEmpty()) {
          Logger.log.info(s"No record found in imdmCrossWalkTab with in the timestamp range: $lastRnTs_EntityInfo and $prcStTs. Will Audit and exit..!! ")
          Lib.putAuditReport(imdmCwAudit_RowKey, "Success", prcStTs, prcEndTs, rowCount, "", "")
          Logger.log.info(s"Audit successful with RowKey: $imdmCwAudit_RowKey, Status:Success, prcStTs:$prcStTs, prcEndTs:$prcEndTs, rowCount:$rowCount")
          System.exit(1)
        }

        //Create DataFrame from RDD
        val schema = dfSchema(List("iMDM_Unique_Identifier", "domain_crosswalk", "last_update_date", "golden_record_entity_id", "golden_record_source", "source_system_record_id", "source_system"))
        val data = tabScanRdd.map(_.split(",").to[List]).map(row)
        val df = spark.createDataFrame(data, schema)

        //  Generate Initial outbound file
        val imdmIncrementalOutputPath = globalContext.outboundPath
        val outboundFilePath = imdmIncrementalOutputPath + imdmCwAudit_RowKey + ".dat"
        val outboundFilePath_temp = imdmIncrementalOutputPath + imdmCwAudit_RowKey + "_temp"

        Logger.log.info(s"File creation triggered in temp outbound path $outboundFilePath_temp")
        df.repartition(1).write.format("csv").option("delimiter", "|").option("nullValue", "").option("header", false).save(outboundFilePath_temp)
        Logger.log.info(s"Successfully file created in temp outbound: $outboundFilePath_temp")

        df.unpersist
        Logger.log.info("dataframe unpersisted")

        Lib.merge(outboundFilePath_temp, outboundFilePath)
        Logger.log.info("_temp outbound file merged to actual outbound directory and added .dat extension")

        Lib.rmDirIfExist(outboundFilePath_temp)
        Logger.log.info("_temp directory removed....")
      }

      prcEndTs = Lib.getCurrentTimeFormat
      Lib.hbaseEitPut(entityInfo_RowKey, "ei", "incPrcSts", "Success")
      Lib.hbaseEitPut(entityInfo_RowKey, "is", "lastRnTs", prcStTs)
      Logger.log.info(s"Upsert in ihrEitTab with lastRnTs i.e., current prcStTm as ${prcStTs} , rowCount with $rowCount in  for rowKey:$entityInfo_RowKey")

      Lib.putAuditReport(imdmCwAudit_RowKey, "Success", prcStTs, prcEndTs, rowCount, "", "")
      Logger.log.info(s"Audit successful with RowKey: $imdmCwAudit_RowKey, Status:Success, prcStTs:$prcStTs, prcEndTs:$prcEndTs, rowCount:$rowCount")
      Logger.log.info("Imdm Crosswalk Incremental process successful..!!")

    } catch {
      case e: Exception => Logger.log.error("================Exception at Main IncrementalMain Object===============" :+ e.getMessage)
        val errMessage = e.getMessage
        Lib.hbaseEitPut(entityInfo_RowKey, "ei", "lastRnTs", lastRnTs_EntityInfo)
        Lib.putAuditReport(imdmCwAudit_RowKey, "Failed",prcStTs, prcEndTs, 0, "", errMessage)
        Logger.log.info(s"Audit successful with RowKey: $imdmCwAudit_RowKey, Status:Success, prcStTs:$prcStTs, prcEndTs:$prcEndTs, rowCount:$rowCount, e.getMessage: $errMessage ")
        globalContext.spark.stop()
        throw e

    } finally {
      globalContext.spark.stop()
    }

  }

  def dfSchema(columnNames: List[String]): StructType =
    StructType(
      Seq(
        StructField(name = "iMDM_Unique_Identifier", dataType = StringType, nullable = false),
        StructField(name = "domain_crosswalk", dataType = StringType, nullable = false),
        StructField(name = "last_update_date", dataType = StringType, nullable = false),
        StructField(name = "golden_record_entity_id", dataType = StringType, nullable = false),
        StructField(name = "golden_record_source", dataType = StringType, nullable = false),
        StructField(name = "source_system_record_id", dataType = StringType, nullable = false),
        StructField(name = "source_system", dataType = StringType, nullable = false)
      )
    )

  def row(line: List[String]): Row = Row(line(0), line(1), line(2), line(3), line(4), line(5), line(6))

}