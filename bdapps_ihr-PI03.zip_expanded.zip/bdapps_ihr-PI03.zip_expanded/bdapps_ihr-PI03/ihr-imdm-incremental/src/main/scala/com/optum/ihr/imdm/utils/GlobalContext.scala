package com.optum.ihr.imdm.utils

import org.apache.hadoop.fs.FileSystem
import org.apache.hadoop.hbase.HBaseConfiguration
import org.apache.hadoop.hbase.client.{HTable, Scan}
import org.apache.hadoop.hbase.mapreduce.TableInputFormat
import org.apache.hadoop.hbase.spark.HBaseContext
import org.apache.spark.SparkContext
import org.apache.spark.sql.SparkSession

class GlobalContext {
  var spark: SparkContext = this.createSparkSession("iMDMCrosswalkIncremental").sparkContext

  def createSparkSession(appName: String): SparkSession = {
    try {
      val sparkSession = SparkSession.builder().appName(appName).enableHiveSupport().getOrCreate()
      sparkSession.conf.set("spark.serializer", "org.apache.spark.serializer.KryoSerializer")
      sparkSession
    }
    catch {
      case e: Exception => Logger.log.error(s"Exception at GlobalContext CreateSparkSession function:" + e.getMessage)
        throw e
    }
  }

  val hBaseConf:org.apache.hadoop.conf.Configuration = HBaseConfiguration.create()
  val hbaseContext = new HBaseContext(spark, hBaseConf)

  val fs: FileSystem = FileSystem.get(spark.hadoopConfiguration)

  val hBaseConf1:org.apache.hadoop.conf.Configuration = HBaseConfiguration.create()
  hBaseConf1.set(TableInputFormat.INPUT_TABLE, spark.getConf.get("spark.ihrEitTab"))
  val ihrEitTab: HTable = new HTable(hBaseConf1, spark.getConf.get("spark.ihrEitTab"))

  val hBaseConf2:org.apache.hadoop.conf.Configuration = HBaseConfiguration.create()
  hBaseConf2.set(TableInputFormat.INPUT_TABLE, spark.getConf.get("spark.ihrAuditTrackTab"))
  val ihrAuditTrackingTab: HTable = new HTable(hBaseConf1, spark.getConf.get("spark.ihrAuditTrackTab"))

  val hBaseConf3:org.apache.hadoop.conf.Configuration = HBaseConfiguration.create()
  hBaseConf3.set(TableInputFormat.INPUT_TABLE, spark.getConf.get("spark.imdmCwTab"))
  val imdmCwTab: HTable = new HTable(hBaseConf1, spark.getConf.get("spark.imdmCwTab"))

  val logDir:String = spark.getConf.get("spark.logdir")
  val outboundPath:String=spark.getConf.get("spark.outboundPath")
}