USE df2_gps_lakeprd;
SELECT  DISTINCT
	q.gps_member_id,
	q.LAST_NAME,
	q.FIRST_NAME,
	q.MIDDLE_NAME,
	q.NAME_PREFIX_ID,
	q.NAME_SUFFIX_ID,
	q.GENDER_CD,
	q.DATE_OF_BIRTH,
	q.DATE_OF_DEATH,
	q.MEDICARE_CLAIM_NUM,
	q.SOCIAL_SECURITY_NUMBER,
	q.MEDICARE_BENEFICIARY_ID,
	q.LOB_BIT_VALUE,
	q.BUSINESS_UNIT_ID,
	q.EMAIL_ADDR,
	q.LANGUAGE_PREFERENCE_ID,
	'Spoken' AS language_mode,
	q.SPOKEN_LANGUAGE_ID,
	q.PART_A_EFFECTIVE_DATE,
	q.PART_B_EFFECTIVE_DATE,
	q.PART_D_ELIGIBILITY_EFFT_DATE,
	q.PART_A_STOP_DATE,
	q.PART_B_STOP_DATE,
	q.PART_D_ELIGIBILITY_STOP_DATE,
	q.DAYTIME_PHONE_NUM,
	q.DAYTIME_PHONE_NUM_EXTN,
	q.EVENING_PHONE_NUM,
	q.EVENING_PHONE_NUM_EXTN,
	q.MOBILE_PHONE_NUM,
	q.GPS_HOUSEHOLD_ID,
	q.GPS_MEMBER_ADDRESS_ID,
	q.ADDRESS_TYPE_ID,
	q.ADDRESS_LINE_1,
	q.ADDRESS_LINE_2,
	q.CITY,
	q.STATE,
	q.COUNTRY,
	q.ZIP,
	q.membership_number_card_id
FROM
	(
		SELECT
			I.INDIVIDUAL_ID							  					 AS gps_member_id,
			TRIM(REGEXP_REPLACE(I.LAST_NAME,'^\\?$',''))				 AS LAST_NAME,
			TRIM(REGEXP_REPLACE(I.FIRST_NAME,'^\\?$',''))				 AS FIRST_NAME,
			TRIM(REGEXP_REPLACE(I.MIDDLE_NAME,'^\\?$',''))			  	 AS MIDDLE_NAME,
			I.NAME_PREFIX_ID											 AS NAME_PREFIX_ID,
			I.NAME_SUFFIX_ID											 AS NAME_SUFFIX_ID,
			TRIM(REGEXP_REPLACE(I.GENDER_CD,'^\\?$',''))				 AS GENDER_CD,
			SUBSTR(I.DATE_OF_BIRTH,1,10)								 AS DATE_OF_BIRTH,
			SUBSTR(I.DATE_OF_DEATH,1,10)								 AS DATE_OF_DEATH,
			TRIM(REGEXP_REPLACE(i.MEDICARE_CLAIM_NUM,'^\\?$',''))		 AS MEDICARE_CLAIM_NUM,
			TRIM(REGEXP_REPLACE(i.SOCIAL_SECURITY_NUMBER,'^\\?$',''))	 AS SOCIAL_SECURITY_NUMBER,
			TRIM(REGEXP_REPLACE (i.MEDICARE_BENEFICIARY_ID,'^\\?$',''))  AS MEDICARE_BENEFICIARY_ID,
			i.LOB_BIT_VALUE											 	 AS LOB_BIT_VALUE,
			LOB.LINE_OF_BUSINESS_ID									 	 AS BUSINESS_UNIT_ID,
			TRIM(REGEXP_REPLACE (i.EMAIL_ADDR,'^\\?$',''))			  	 AS EMAIL_ADDR,
			i.LANGUAGE_PREFERENCE_ID									 AS LANGUAGE_PREFERENCE_ID,
			i.SPOKEN_LANGUAGE_ID										 AS SPOKEN_LANGUAGE_ID,
			SUBSTR(i.PART_A_EFFECTIVE_DATE,1,10)						 AS PART_A_EFFECTIVE_DATE,
			SUBSTR(i.PART_B_EFFECTIVE_DATE,1,10)						 AS PART_B_EFFECTIVE_DATE,
			SUBSTR(i.PART_D_ELIGIBILITY_EFFT_DATE,1,10)				 	 AS PART_D_ELIGIBILITY_EFFT_DATE,
			SUBSTR(i.PART_A_STOP_DATE,1,10)							 	 AS PART_A_STOP_DATE,
			SUBSTR(i.PART_B_STOP_DATE,1,10)							 	 AS PART_B_STOP_DATE,
			SUBSTR(i.PART_D_ELIGIBILITY_STOP_DATE,1,10)				 	 AS PART_D_ELIGIBILITY_STOP_DATE,
			TRIM(REGEXP_REPLACE (HH.DAYTIME_PHONE_NUM,'^\\?$',''))	  	 AS DAYTIME_PHONE_NUM,
			TRIM(REGEXP_REPLACE (HH.DAYTIME_PHONE_NUM_EXTN,'^\\?$',''))  AS DAYTIME_PHONE_NUM_EXTN,
			TRIM(REGEXP_REPLACE (HH.EVENING_PHONE_NUM,'^\\?$',''))	  	 AS EVENING_PHONE_NUM,
			TRIM(REGEXP_REPLACE (HH.EVENING_PHONE_NUM_EXTN,'^\\?$',''))  AS EVENING_PHONE_NUM_EXTN,
			TRIM(REGEXP_REPLACE (HH.MOBILE_PHONE_NUM,'^\\?$',''))		 AS MOBILE_PHONE_NUM,
			HH.HOUSEHOLD_ID											 	 AS GPS_HOUSEHOLD_ID,
			ha.HOUSEHOLD_ADDRESS_ID									 	 AS GPS_MEMBER_ADDRESS_ID,
			ha.ADDRESS_TYPE_ID										  	 AS ADDRESS_TYPE_ID,
			TRIM(REGEXP_REPLACE (ha.ADDRESS_LINE_1,'^\\?$',''))		 	 AS ADDRESS_LINE_1,
			TRIM(REGEXP_REPLACE (ha.ADDRESS_LINE_2,'^\\?$',''))		 	 AS ADDRESS_LINE_2,
			TRIM(REGEXP_REPLACE (ha.CITY,'^\\?$',''))					 AS CITY,
			TRIM(REGEXP_REPLACE (ha.STATE_CD,'^\\?$',''))				 AS STATE,
			TRIM(REGEXP_REPLACE (ha.COUNTRY_CD,'^\\?$',''))			 	 AS COUNTRY,
			TRIM(REGEXP_REPLACE (lpad(ha.ZIP_CD,5,0) ,'^\\?$',''))	  	 AS ZIP,
			TRIM(REGEXP_REPLACE (hp.membership_number,'^\\?$',''))	 AS membership_number_card_id, -- Changed by Pamela, 2018-07-26	- see new membnum sub-query below		
		row_number() OVER (
					PARTITION BY i.individual_id, ip.insured_plan_id, ha.address_type_id
					ORDER BY ip.last_modified_date DESC, ha.hhold_addr_stop_date DESC, hp.last_modified_date DESC, ha.LAST_MODIFIED_DATE DESC
					)													 AS row_num
		FROM (
			    SELECT * FROM individual_snapshot 
				WHERE (individual_termination_date >= '2015-10-01' OR Trim(NVL(individual_termination_date,'')) = '')
				ORDER BY individual_id
		) i
		INNER JOIN line_of_business_snapshot lob
			ON i.lob_bit_value = lob.bit_value
		INNER JOIN household_member_snapshot hm
			ON  i.individual_id = hm.individual_id
		INNER JOIN ( 
			SELECT * FROM (
				SELECT household_id, membership_number, membership_num_sys_id, hhold_profile_start_date, hhold_profile_stop_date, last_modified_date, 
					row_number() OVER (
							PARTITION BY household_id 
							ORDER BY last_modified_date DESC, Coalesce(hhold_profile_stop_date,'9999-12-31 00:00:00.000') DESC, hhold_profile_start_date DESC, membership_number DESC
						) AS row_num
				FROM household_profile_snapshot
				WHERE Coalesce(delete_ind,'N')='N'
			) q
			WHERE row_num = 1
		) hp ON hm.household_id=hp.household_id
		INNER JOIN household_snapshot hh
			ON hm.household_id = hh.household_id
		LEFT JOIN household_address_snapshot ha 
			ON hh.household_id = ha.household_id
			AND NVL(ha.DELETE_IND,'N') = 'N'
			AND NVL(ha.INVALID_ADDRESS_IND,'N') = 'N'
		INNER JOIN insured_plan_snapshot ip
			ON i.individual_id = ip.individual_id
		INNER JOIN region_plan_profile_snapshot rpp 
			ON ip.region_plan_id=rpp.region_plan_id 
		INNER JOIN region_plan_snapshot rp 
			ON ip.region_plan_id=rp.region_plan_id 
		INNER JOIN plan_snapshot PL 
			ON ip.plan_cd=PL.PLAN_CD 
		INNER JOIN plan_type_snapshot pt 
			ON pl.Plan_Type_Id=pt.plan_type_id 
		INNER JOIN region_snapshot rg 
			ON rp.region_id=rg.region_id 
		INNER JOIN contract_snapshot con 
			ON rp.contract_id=con.contract_id 
		LEFT JOIN plan_attachability_snapshot pa 
			ON ip.plan_attachability_id=pa.plan_attachability_id 
			AND pa.rider_bit_value=0 
		LEFT JOIN employer_household_snapshot eh 
			ON hm.household_id=eh.household_id 
			AND NVL(eh.delete_ind, 'N')='N' 
		INNER JOIN legal_entity_snapshot le 
			ON rp.legal_entity_id=le.legal_entity_id 
		WHERE ( ip.insured_plan_termination_date >= '2015-10-01'  OR  Trim(NVL(ip.insured_plan_termination_date,''))='' )
			AND substr(ip.insured_plan_effective_date,1,10) BETWEEN 
				substr(rp.region_plan_start_date,1,10) AND
				CASE WHEN Trim(Nvl(rp.region_plan_stop_date,''))='' THEN '9999-12-31' ELSE substr(rp.region_plan_stop_date,1,10) END
			AND substr(ip.insured_plan_effective_date,1,10) BETWEEN 
				substr(rpp.region_plan_profile_start_date,1,10) AND 
				CASE WHEN Trim(Nvl(rpp.region_plan_profile_stop_date,''))='' THEN '9999-12-31' ELSE substr(rpp.region_plan_profile_stop_date,1,10) END
			AND substr(ip.insured_plan_effective_date,1,10) BETWEEN 
				substr(hp.hhold_profile_start_date,1,10) AND
				CASE WHEN Trim(Nvl(hp.hhold_profile_stop_date,''))='' THEN '9999-12-31' ELSE substr(hp.hhold_profile_stop_date,1,10) END
			AND ( -- Change by Pamela, 2018-07-26: pa table is left-joined UNLESS a where clause REQUIRES that it have date values
				 pa.plan_attachability_id IS NULL
				 OR
				 SUBSTR(ip.insured_plan_effective_date,1,10) BETWEEN 
					SUBSTR (pa.plan_attachability_start_date,1,10) AND
					CASE WHEN Trim(Nvl(pa.plan_attachability_stop_date,''))='' THEN '9999-12-31' ELSE substr(pa.plan_attachability_stop_date,1,10) END
				)
			AND ( 
				 eh.household_id IS NULL
				 OR
				 substr(ip.insured_plan_effective_date,1,10) BETWEEN 
					substr(eh.emp_hhold_start_date,1,10) AND 
					CASE WHEN Trim(Nvl(eh.emp_hhold_stop_date,''))='' THEN '9999-12-31' ELSE substr(eh.emp_hhold_stop_date,1,10) END
				)
			AND NOT ( ip.insured_plan_effective_date=NVL(ip.insured_plan_termination_date, '9999-12-01') ) 
			AND ip.insured_plan_id=ip.parent_insured_plan_id 
			AND rpp.membership_num_sys_id=hp.membership_num_sys_id 

			AND NOT Concat(Concat(con.contract_number, '-'), rpp.pbp) IN (
			'H0169-001',
			'H0169-002',
			'H0169-003',
			'H0251-002',
			'H0251-004',
			'H0321-002',
			'H0321-004',
			'H1045-039',
			'H1045-040',
			'H2228-041',
			'H2228-042',
			'H2228-043',
			'H2228-046',
			'H2247-001',
			'H3113-005',
			'H3113-009',
			'H3113-011',
			'H3113-012',
			'H3387-010',
			'H3794-002',
			'H4514-001',
			'H5008-002',
			'H5008-009',
			'H5008-010',
			'H5008-011',
			'H5008-012',
			'H5253-024',
			'H5253-059',
			'H5322-025',
			'H5322-028',
			'H5322-029',
			'H5322-031',
			'H7464-001',
			'R1548-001',
			'R1548-001',
			'R3175-003',
			'R7444-012',
			'R7444-013')
) q 	
WHERE q.row_num = 1;					)	