WITH
    main AS
    (
        SELECT
            a.* ,
            a1.grgr_id
        FROM
            FAC_CMC_MEME_MEMBER a
        JOIN
            FAC_CMC_GRGR_GROUP a1
        ON
            a.GRGR_CK = a1.GRGR_CK
        ORDER BY
            meme_ck
    )
SELECT DISTINCT
    a.MEME_RECORD_NO             AS member_record_number,
    a.MEME_CK                    AS member_contrived_key,
    a.GRGR_CK                    AS group_contrived_key,
    a.SBSB_CK                    AS subscriber_contrived_key,
    a.MEME_REL                   AS relationship,
    a.MEME_LAST_NAME             AS last_name,
    a.MEME_FIRST_NAME            AS first_name,
    a.MEME_MID_INIT              AS middle_initial,
    a.MEME_TITLE                 AS title,
    a.MEME_SSN                   AS social_security_number,
    a.MEME_SEX                   AS gender,
    SUBSTR(a.MEME_BIRTH_DT,1,10) AS birth_date,
    h.SBSB_ID                    AS subscriber_identifier,
    a.MEME_HEALTH_ID             AS standard_unique_health_id,
    a.MEME_HICN                  AS medicare_number,
    a.MEME_MEDCD_NO              AS medicaid_number,
    a.MEME_MARITAL_STATUS        AS marital_status,
    a.MEME_MCTR_LANG             AS language,
    a.MEME_FAM_LINK_ID           AS family_link_id,
    k.PYPY_ID                    AS payor_id,
    a.GRGR_ID                    AS group_identifier,
    b1.CSCS_ID                   AS class_identifier,
    b1.CSPI_ID                   AS class_plan_identifier,
    b1.PDPD_ID                   AS product_identifier,
    b1.MEPE_FI                   AS family_indicator,
    SUBSTR(b1.MEPE_EFF_DT,1,10)  AS effective_date,
    SUBSTR(b1.MEPE_TERM_DT,1,10) AS termination_date,
    b1.MEPE_ELIG_IND             AS coverage_indicator,
    ''                           AS mbi ,
    m1.cici_id                   AS client_id
FROM
    main a,
    FAC_CMC_MEPE_PRCS_ELIG b1,
    FAC_CMC_SBSB_SUBSC h,
    FAC_CMC_PDPD_PRODUCT i,
    FAC_CMC_LOBD_LINE_BUS j,
    FAC_CMC_PYPY_PAYOR k,
    FAC_CMC_GRGR_GROUP m1
WHERE
    a.MEME_CK = b1.MEME_CK
AND a.GRGR_CK = b1.GRGR_CK
AND a.GRGR_CK = m1.GRGR_CK
AND a.SBSB_CK = h.SBSB_CK
AND a.GRGR_CK = h.GRGR_CK
AND b1.PDPD_ID = i.PDPD_ID
AND i.LOBD_ID = j.LOBD_ID
AND k.PYPY_ID = j.PYPY_ID
AND b1.MEPE_TERM_DT >= '2015-10-01'
AND mepe_elig_ind = 'Y'