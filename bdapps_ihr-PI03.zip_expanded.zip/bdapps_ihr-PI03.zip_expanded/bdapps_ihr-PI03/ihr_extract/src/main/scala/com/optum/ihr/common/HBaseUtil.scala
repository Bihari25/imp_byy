package com.optum.ihr.common

import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.hbase.client._
import org.apache.hadoop.hbase.mapreduce.TableInputFormat
import org.apache.hadoop.hbase.util.Bytes
import org.apache.hadoop.hbase.{CellUtil, HBaseConfiguration, TableName}
import org.apache.spark.sql.SparkSession

class HBaseUtil(sparkSession : SparkSession) {

  val conf: Configuration = HBaseConfiguration.create()
  val conn: Connection = ConnectionFactory.createConnection(conf)



  def read(tableName:String, rowkey:String, cf:String, col:String): String = {
    val table = conn.getTable(TableName.valueOf( Bytes.toBytes(tableName) ) )
    var get = new Get(Bytes.toBytes(rowkey))
    var result = table.get(get)
    Bytes.toString(result.getValue(cf.getBytes,col.getBytes))
  }

  def read(tableName:String, rowkey:String): Map[String, String] = {
    var cellsMap = scala.collection.mutable.Map[String, String]()
    val table = conn.getTable(TableName.valueOf( Bytes.toBytes(tableName) ) )
    var get = new Get(Bytes.toBytes(rowkey))
    var result = table.get(get)

    val cells = result.rawCells
    for(cell <- cells){
      cellsMap +=(Bytes.toString(CellUtil.cloneQualifier(cell)) -> Bytes.toString(CellUtil.cloneValue(cell)))
    }

    cellsMap.toMap
  }

  def write(tableName:String, rowkey:String, cf:String, col:String, data:String): Unit = {
    val table = conn.getTable(TableName.valueOf( Bytes.toBytes(tableName) ) )
    var put = new Put(Bytes.toBytes(rowkey))
    put.addColumn(Bytes.toBytes(cf), Bytes.toBytes(col), Bytes.toBytes(data))
    table.put(put)
  }





  def getValue(tableName:String, rowkey:String, cf:String, col:String) : String = {

    conf.set(TableInputFormat.INPUT_TABLE, tableName)
    conf.set(TableInputFormat.SCAN_ROW_START, rowkey)
    conf.set(TableInputFormat.SCAN_ROW_STOP, rowkey.concat("0"))

    val hBaseRDD = sparkSession.sparkContext.newAPIHadoopRDD(conf, classOf[TableInputFormat], classOf[org.apache.hadoop.hbase.io.ImmutableBytesWritable], classOf[org.apache.hadoop.hbase.client.Result])
    val resultRDD = hBaseRDD.map(tuple => tuple._2)

    val keyValueRDD = resultRDD.map(result => (Bytes.toString(result.getValue(cf.getBytes(), col.getBytes()))))
    keyValueRDD.first

  }


  def writeToHBase(tableName: String, iHRAuditTracking: IHRAuditTracking): Unit = {
    val hbaseTableName: TableName = TableName.valueOf(tableName)
    val hbaseTable: Table = conn.getTable(hbaseTableName)
    val put = new Put(Bytes.toBytes(iHRAuditTracking.id))
    put.addColumn(Bytes.toBytes("pf"), Bytes.toBytes("prtnrCd"), Bytes.toBytes(iHRAuditTracking.prtnrCd))
    put.addColumn(Bytes.toBytes("pf"), Bytes.toBytes("srcCd"), Bytes.toBytes(iHRAuditTracking.srcCd))
    put.addColumn(Bytes.toBytes("pf"), Bytes.toBytes("prcNm"), Bytes.toBytes(iHRAuditTracking.prcName))
    put.addColumn(Bytes.toBytes("pf"), Bytes.toBytes("incPrcSts"), Bytes.toBytes(iHRAuditTracking.incPrcSts))
    put.addColumn(Bytes.toBytes("pf"), Bytes.toBytes("prcDate"), Bytes.toBytes(iHRAuditTracking.prcDate.toString))
    put.addColumn(Bytes.toBytes("pf"), Bytes.toBytes("prcStTm"), Bytes.toBytes(iHRAuditTracking.prcStTm.toString))
    put.addColumn(Bytes.toBytes("pf"), Bytes.toBytes("prcEndTm"), Bytes.toBytes(iHRAuditTracking.prcEndTm.toString))
    put.addColumn(Bytes.toBytes("pf"), Bytes.toBytes("recCount"), Bytes.toBytes(iHRAuditTracking.reccnt))

    if(iHRAuditTracking.errCd != null && iHRAuditTracking.errCd.length>0) {
      put.addColumn(Bytes.toBytes("eri"), Bytes.toBytes("errCd"), Bytes.toBytes(iHRAuditTracking.errCd))
      put.addColumn(Bytes.toBytes("eri"), Bytes.toBytes("errDesc"), Bytes.toBytes(iHRAuditTracking.errDesc))
    }
    hbaseTable.put(put)
  }

  def cleanup(): Unit = {
    conn.close()
  }

//  def read(tableName:String) : org.apache.spark.rdd.RDD[Any] = {
//    conf.set(TableInputFormat.INPUT_TABLE, tableName)
//    val hBaseRDD = sparkSession.sparkContext.newAPIHadoopRDD(conf, classOf[TableInputFormat], classOf[ImmutableBytesWritable], classOf[Result])
//    val resultRDD = hBaseRDD.map(tuple => tuple._2);
//    val rdd : RDD[Any] = resultRDD.map(IHR.parseHbaseIHRRow)
//    log.info("rdd="+rdd+", count="+rdd.count())
//    //rdd.saveAsTextFile(sparkSession.sparkContext.getConf.get("spark.ihr.processing").replaceAll("/mapr", "")+"/"+sparkSession.sparkContext.getConf.get("spark.hbase.temp.files"))
//    rdd
//  }

}

