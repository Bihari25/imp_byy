package com.optum.ihr

import java.io.{File, FileOutputStream}
import java.text.SimpleDateFormat
import java.util.{Calendar, Properties}

import com.optum.ihr.common.IHRUtils.{getCurrentTime, getDate}
import com.optum.ihr.common.{HBaseUtil, Logger}
import org.apache.hadoop.fs.FileSystem
import org.apache.hadoop.fs.Path
import org.apache.spark.sql.{DataFrame, SQLContext, SparkSession}

import scala.io.Source

object ReadParquetFile {

    def main(args: Array[String]): Unit = {


//      if (args.length != 2) {
//        Logger.log.info("Please provide appropriate parameters for createParquetfiles job")
//        return;
//      }
      Logger.log.info("copying txt files in parquet format from inbox to ihr tenant")
      val spark = SparkSession
        .builder()
        .appName("ihr-parquetfilecreation")
        .master("yarn")
        .getOrCreate()


      val processStartTime = getCurrentTime
      var processEndTime = ""
      var processDate = getDate


      val sparkSession = SparkSession.builder().appName("IHRExtractReadParquet").getOrCreate()
      val sparkConf = sparkSession.conf
      val sqlContext: SQLContext = sparkSession.sqlContext
      val sparkContext = sparkSession.sparkContext
      val runID = args(0)
      Logger.log.info("runID=" + runID)
      //"201809180720"
      val domain = args(1)
      val processKey = args(2)//"UHC-UDW-UDW_Demographic"
      Logger.log.info("domain=" + domain)

      val hbaseAuditTable = sparkConf.get("spark.ihr.audit.table")
      val ihrEntityInfoTable = sparkConf.get("spark.ihr.entitiyInfo.table")
      val workFilePath = sparkConf.get("spark.ihr." + domain + ".workfile")
      val inputLocation = sparkConf.get("spark.ihr." + domain + ".ihrtenant")
      val outputLocation = sparkConf.get("spark.ihr." + domain + ".mq_inbound")

      Logger.log.info("got the values from conf file")

      val fs = FileSystem.get(sparkContext.hadoopConfiguration)

      var udwDF: DataFrame = null
      var i = 0
      for (inputFileNametxt <- Source.fromFile(workFilePath + "/" + domain + "_" + runID).getLines()) {

       val inputFileName = inputFileNametxt.dropRight(3)
        Logger.log.info(i+"inputFileName is " + inputLocation + "/" + inputFileName + "parquet")
        val tempDF = sqlContext.read.option("header", "true").option("delimiter", "|").parquet(inputLocation + "/" + inputFileName + "parquet")
        if (i == 0) {
          Logger.log.info("im in if")
          udwDF = tempDF
        } else {
          Logger.log.info("im in else")
          udwDF = udwDF.union(tempDF)

        }
        Logger.log.info("count is"+udwDF.count())
        i = i + 1

      }

      //val hbaseUtil = new HBaseUtil(sparkSession)
      //val sqlQuery = hbaseUtil.getValue(ihrEntityInfoTable, domain, "ei", "sqlQry")
      Logger.log.info("ihrEntityInfoTable=" +ihrEntityInfoTable+", domain="+domain)
      val hbaseUtil = new HBaseUtil(null)
      val sqlQuery = hbaseUtil.read(ihrEntityInfoTable, processKey, "ei", "sqlQry")

      Logger.log.info("sqlQry=" +sqlQuery)

      udwDF.createOrReplaceTempView(domain)
      val resultdf = spark.sql(sqlQuery)
      resultdf.repartition(1).write.option("mapreduce.fileoutputcommitter.marksuccessfuljobs", "false").option("delimiter","|").option("header", "true").format("csv").save(outputLocation + "/"+domain)
      val outputPartFileName = fs.globStatus(new org.apache.hadoop.fs.Path(outputLocation + "/"+domain + "/part-*"))(0).getPath.getName();
      fs.rename(new Path(outputLocation + "/"+domain+"/"+outputPartFileName), new Path(outputLocation + "/"+domain+"/"+processKey+"_"+runID+".dat"))

      spark.stop()
    }
  }
