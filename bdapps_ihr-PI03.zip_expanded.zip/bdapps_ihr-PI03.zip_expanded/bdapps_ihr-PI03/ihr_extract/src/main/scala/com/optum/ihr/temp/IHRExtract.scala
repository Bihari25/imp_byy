package com.optum.ihr.temp

import java.text.SimpleDateFormat
import java.util.Calendar

import com.optum.ihr.common.HBaseUtil
import org.apache.spark.sql.SparkSession

object IHRExtract {

  def main(args: Array[String]) {
    if (args.length < 1) {
      println("IHRExtract {rowkey} {working_dir}/{input_file} {output_location} {format}")
      // UHC-UDW-UDW_Demographics  inbox_location -201809181023
      return
    }

    val tableName = args(0)
    val rowkey = args(1)

    val sparkSession = SparkSession.builder().appName("IHRExtract").getOrCreate()

    try {

      val hbaseUtil = new HBaseUtil(sparkSession)
      val lastRunDate = hbaseUtil.getValue(tableName, rowkey, "is", "lastRnTs")

      val timestampFormat = new SimpleDateFormat("yyyyMMddHHmm")
      print("lastRunTs=%s",lastRunDate)
      print("currentRunTs=%s",timestampFormat.format(Calendar.getInstance().getTime()))

    }
    finally {
      sparkSession.stop()
    }
  }

}
