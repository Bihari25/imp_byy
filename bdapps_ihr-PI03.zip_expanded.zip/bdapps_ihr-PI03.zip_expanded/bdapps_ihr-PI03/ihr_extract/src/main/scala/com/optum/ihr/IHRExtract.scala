package com.optum.ihr

import java.io.{File, FileOutputStream}
import java.text.SimpleDateFormat
import java.util.{Calendar, Properties}

import com.optum.ihr.common.HBaseUtil

/**
  * this is the first step
  * 1)
  */
object IHRExtract {

  def main(args: Array[String]) : Unit ={
    if (args.length < 1) {
      println("App {tableName} {rowkey} {cf} {col}")
      return
    }


    val tableName = args(0)
    val rowKey = args(1)
    val cf = args(2)
    val col = args(3)
    val hbaseUtil = new HBaseUtil(null)
    val data = hbaseUtil.read(tableName, rowKey, cf, col)

    System.out.println(data)

    val propertyFile = new File(System.getProperty("oozie.action.output.properties"))
    val properties = new Properties()
    properties.setProperty(col, data)
    val timestampFormat = new SimpleDateFormat("yyyyMMddHHmmss")
    val runID = timestampFormat.format(Calendar.getInstance().getTime())
    properties.setProperty("runID", "" + runID)

    // 2000-03-09 16:18:01
    val hbaseTimestampFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
    val hbaseTS = hbaseTimestampFormat.format(timestampFormat.parse(runID))
    properties.setProperty("hbaseTS", "" + hbaseTS)
    System.out.println("runID="+runID+", hbaseTS="+hbaseTS)
    val os = new FileOutputStream(propertyFile)
    properties.store(os, "getLastRunTs")
    os.close
  }

}
