package com.optum.ihr


import com.optum.ihr.common.{HBaseUtil, IHRAuditTracking, Logger}
import org.apache.hadoop.fs.FileSystem
import org.apache.spark.sql.SparkSession
import org.apache.hadoop.fs.Path
import java.io.FileReader

import java.io.FileNotFoundException

import java.io.IOException

import scala.io.Source


object ParquetTransform {
  def main(args: Array[String]): Unit = {


//    if (args.length != 2) {
//      Logger.log.info("Please provide appropriate parameters for createParquetfiles job")
//      return;
//    }
    val spark = SparkSession.builder().appName("ihr-ParquetTransform").master("yarn").getOrCreate()
    try {
      Logger.log.info("copying txt files in parquet format from inbox to ihr tenant")



      val sparkContext = spark.sparkContext
      val sparkConf = sparkContext.getConf
      val fs = FileSystem.get(sparkContext.hadoopConfiguration)
      var hdfs = org.apache.hadoop.fs.FileSystem.get(sparkContext.hadoopConfiguration)
      val hbaseAuditTable = sparkConf.get("spark.ihr.audit.table")

      val runID = args(0)
      //"201809180720"
      val domain = args(1) //"UHC-UDW-UDW_Demographic"
      Logger.log.info("runID value is " + runID)
      Logger.log.info("Processkey value is " + domain)

      //working_dir=$3
      //current_run_time=$4
      //process_key=$5
      val inboxLocation = sparkConf.get("spark.ihr." + domain + ".inbox")
      val workFilePath = sparkConf.get("spark.ihr." + domain + ".workfile")
      val outputLocation = sparkConf.get("spark.ihr." + domain + ".ihrtenant")

      Logger.log.info("got the values from conf file")

      var i = 1
      Logger.log.info("Inbox location" + inboxLocation)
      Logger.log.info("Ihr tenant" + outputLocation)
      Logger.log.info("Copying the files from inbox to ihr-tenant in parquet format")

      for (inputFileNametxt <- Source.fromFile(workFilePath + "/" + domain + "_" + runID).getLines()) {
        val inputFileName = inputFileNametxt.dropRight(3)

        val inputDF = spark.read.option("header", "true").option("delimiter", "|").csv(inboxLocation + "/" + inputFileNametxt)

        inputDF.repartition(1).write.option("mapreduce.fileoutputcommitter.marksuccessfuljobs", "false").option("delimiter", "|").option("header", "true").format("parquet").save(outputLocation + "_temp/" + i)
        val outputPartFileName = fs.globStatus(new org.apache.hadoop.fs.Path(outputLocation + "_temp/" + i + "/part-*"))(0).getPath.getName();
        inputFileName.dropRight(3)


        val fileTransferStatus = fs.rename(new org.apache.hadoop.fs.Path(outputLocation + "_temp/" + i + "/" + outputPartFileName), new org.apache.hadoop.fs.Path(outputLocation + "/" + inputFileName + "parquet"))
        i = i + 1;

        if (fileTransferStatus) {
          fs.delete(new org.apache.hadoop.fs.Path(outputLocation + "_temp/"), true)
          if (fs.exists(new Path(outputLocation + "temp")))
            fs.delete(new Path(outputLocation + "temp"), true)

        }

      }

    }
    catch {

      case ex: FileNotFoundException =>{

        println("File not found Exception")

      }

      case ex: IOException => {

        println("Input /Output Exception")

      }

    }
    finally spark.stop()

    def updateAudit(sparkSession: SparkSession, hbaseTableName: String, ihrAuditTracking: IHRAuditTracking): Unit = {
    val hbaseUtil = new HBaseUtil(sparkSession)
    hbaseUtil.writeToHBase(hbaseTableName, ihrAuditTracking)
  }
}
}