package com.optum.ihr.temp

import java.text.SimpleDateFormat
import java.util.Calendar

import com.optum.ihr.common.HBaseUtil
import org.apache.spark.sql.SparkSession
/**
 * Hello world!
 *
 */
/**
  * /datalake/optum/optuminsight/t_udw/ihr/tst/t_mtables/ihr_entity_inf
  */
object App {


  def main(args: Array[String]) {
    if (args.length < 1) {
      println("App {tableName} {rowkey}")
      return
    }

    val tableName = args(0)
    val rowkey = args(1)

   val sparkSession = SparkSession.builder().appName("hbtest").getOrCreate()

    try {

      val hbaseUtil = new HBaseUtil(sparkSession)
      val lastRunDate = hbaseUtil.getValue(tableName, rowkey, "is", "lastRnTs")

      val timestampFormat = new SimpleDateFormat("yyyyMMddHHmm")
      print("lastRunTs=%s",lastRunDate)
      print("currentRunTs=%s",timestampFormat.format(Calendar.getInstance().getTime()))

      //return lastRunDate

    }
    finally {
      sparkSession.stop()
    }
  }

}
