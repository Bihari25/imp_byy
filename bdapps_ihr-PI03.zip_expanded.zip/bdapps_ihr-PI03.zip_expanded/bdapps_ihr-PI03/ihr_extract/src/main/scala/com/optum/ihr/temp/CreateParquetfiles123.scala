package com.optum.ihr.temp

import java.io.{PrintWriter, StringWriter}

import com.optum.ihr.common.IHRUtils._
import com.optum.ihr.common.{HBaseUtil, IHRAuditTracking, Logger}
import org.apache.hadoop.fs.FileSystem
import org.apache.spark.sql.{DataFrame, SparkSession}

import scala.io.Source


object CreateParquetfiles123 {
  def main(args: Array[String]): Unit = {


    if (args.length != 1) {
      Logger.log.info("Please provide appropriate parameters for createParquetfiles job")
      return;
    }
    Logger.log.info("copying txt files in parquet format from inbox to ihr tenant")
    val spark = SparkSession
      .builder()
      .appName("ihr-parquetfilecreation")
      .master("yarn")
      .getOrCreate()

    val sparkContext = spark.sparkContext
    val sparkConf = sparkContext.getConf
    val fs = FileSystem.get(sparkContext.hadoopConfiguration)
    val hbaseAuditTable = sparkConf.get("spark.ihr.audit.table")

    val runID = args(0)//"201809180720"
    val processKey = args(1)//"UHC-UDW-UDW_Demographic"

    //working_dir=$3
    //current_run_time=$4
    //process_key=$5
    val inboxLocation = sparkConf.get("spark.ihr." + processKey + ".inbox")
    val workFilePath = sparkConf.get("spark.ihr." + processKey + ".workfile")
    val outputLocation = sparkConf.get("spark.ihr." + processKey + "_ihrtenant")
    var i = 0
    var finalDF : DataFrame = null
    for(inputFileName <- Source.fromFile(workFilePath+"/"+processKey+"_"+runID).getLines()) {

      val filesdf = spark.read.option("header", "true").option("delimiter", "|").csv(inboxLocation + "/" + inputFileName)
      if (i == 0) {
        finalDF = filesdf
      } else {
        finalDF.union(filesdf)
      }
    }





    finalDF.repartition(1).write.option("mapreduce.fileoutputcommitter.marksuccessfuljobs", "false").option("delimiter","|").option("header", "true").format("parquet").save(outputLocation)







    val processStartTime = getCurrentTime
    var processEndTime = ""
    var processDate = getDate



    val fileType = args(0);  // demographic
    val rowkey = args(1)  // srcCode_partnrCode_  //  UHC-UDW-UDW_Demographics-201809181023

    // UHG-CSF-Member_MR_Coverage_2018060115013140.dat


    val inputfilelist = sparkConf.get("spark.ihr." + fileType + "_filelist")  // spark.ihr.UDW_Demographics_filelist=201809181211





    for(inputFileName <- Source.fromFile(workFilePath+"/"+processKey+"_"+runID).getLines())
      {
     try {

       var hbaseRowKey = rowkey+"-"+inputfilelist//inputFileName.split("\\.")(0);
       Logger.log.info("hbaseRowKey=" + hbaseRowKey + ", fileType=" + fileType + ", inputFileName=" + inputFileName)
       hbaseRowKey = if (!hbaseRowKey.contains("-") || hbaseRowKey.split("-").length < 2) s"NO-ROWKEY-DEFINED_$hbaseRowKey" else hbaseRowKey

       var processName = hbaseRowKey.split("-")(2)
       val filesdf = spark.read.option("header", "true").option("delimiter","|").csv(workFilePath + "/" + inputFileName)
       filesdf.repartition(1).write.option("mapreduce.fileoutputcommitter.marksuccessfuljobs", "false").option("delimiter","|").option("header", "true").format("parquet").save(outputLocation + "_temp")
       val outputPartFileName = fs.globStatus(new org.apache.hadoop.fs.Path(outputLocation + "_temp/part-*"))(0).getPath.getName();
       inputFileName.dropRight(3)

       val filetransfer = fs.rename(new org.apache.hadoop.fs.Path(outputLocation + "_temp/" + outputPartFileName), new org.apache.hadoop.fs.Path(outputLocation + "/" + inputFileName + "parquet"))
       if (filetransfer) {
         fs.delete(new org.apache.hadoop.fs.Path(outputLocation + "_temp"), true)
       }


      processEndTime = getCurrentTime

      val duration = (getCurrentTimeInLong(processEndTime) - getCurrentTimeInLong(processStartTime)) / 1000

      val iHRAuditTracking = new IHRAuditTracking(hbaseRowKey, processName, "Success", processDate, processEndTime, processStartTime, hbaseRowKey.split("-")(0), hbaseRowKey.split("-")(1), ""+"totalRowsAfterFilter", "","")
      updateAudit(spark, hbaseAuditTable, iHRAuditTracking)

    } catch {

      case ex: Exception =>
        var hbaseRowKey = inputFileName.split("\\.")(0);
        Logger.log.info("hbaseRowKey=" + hbaseRowKey + ", fileType=" + fileType + ", inputFileName=" + inputFileName)
        hbaseRowKey = if (!hbaseRowKey.contains("-") || hbaseRowKey.split("-").length < 2) s"NO-ROWKEY-DEFINED_$hbaseRowKey" else hbaseRowKey

        var processName = hbaseRowKey.split("-")(2)


        val stringWriter = new StringWriter
        ex.printStackTrace(new PrintWriter(stringWriter))

        Logger.log.info("got exception and stackTrace: " + ex.getMessage)
        Logger.log.info("got exception and stackTrace: ", ex)
        processEndTime = getCurrentTime


        // var soFarProcessed = ex.getMessage.split("")(1) + ""
        var soFarProcessed = "0"

        val duration = (getCurrentTimeInLong(processEndTime) - getCurrentTimeInLong(processStartTime)) / 1000

        val iHRAuditTracking = new IHRAuditTracking(hbaseRowKey, processName, "Failure", processDate, processEndTime, processStartTime, hbaseRowKey.split("-")(0), hbaseRowKey.split("-")(1), soFarProcessed, ex.getMessage, stringWriter.toString)
        updateAudit(spark, hbaseAuditTable, iHRAuditTracking)
      }

    }
  }

  def updateAudit(sparkSession: SparkSession, hbaseTableName: String, ihrAuditTracking: IHRAuditTracking): Unit = {
    val hbaseUtil = new HBaseUtil(sparkSession)
    hbaseUtil.writeToHBase(hbaseTableName, ihrAuditTracking)
  }
}