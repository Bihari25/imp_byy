package com.optum.ihr

import java.io.{File, FileOutputStream}
import java.text.SimpleDateFormat
import java.util.{Calendar, Properties}

import com.optum.ihr.common.HBaseUtil

/**
  * this is the last step
  * 1)
  */
object UpdateCell {

  def main(args: Array[String]) : Unit ={
    if (args.length < 1) {
      println("UpdateCell {tableName} {rowkey} {cf} {col} {value}")
      return
    }


    val tableName = args(0)
    val rowKey = args(1)
    val cf = args(2)
    val col = args(3)
    val data = args(4)
    val hbaseUtil = new HBaseUtil(null)
    hbaseUtil.write(tableName, rowKey, cf, col, data)

    val propertyFile = new File(System.getProperty("oozie.action.output.properties"))
    val properties = new Properties()
    properties.setProperty(col, data)
    properties.setProperty("status", "success")
    val os = new FileOutputStream(propertyFile)
    properties.store(os, "UpdateCell")
    os.close
  }

}
