package com.uhg.optum.ihr.provider

import com.uhg.optum.ihr.common.Logger


object LoadIHRFromDF {
  def main(args: Array[String]): Unit = {

    println("Hello world")

    if (args.length != 2) {
      Logger.log.info("Please Pass RowKey \"PATNRCD-SRCCD-ENTITYNAME\" and load-type(parquet/text) for IHR Incremental extract")
      Logger.log.info("===> Since No RowKey is Passed ending IHR Incremental extract <===")
      return;
    }
    val rowKey = args(0).toUpperCase().trim
    val loadType = args(1);

    if("parquet".equalsIgnoreCase(loadType)) {
      ParquetMain.main(Array(args(0)))
    } else if("text".equalsIgnoreCase(loadType)) {
      IncrementalMain.main(Array(args(0)))
    } else {
      Logger.log.info("Please Pass valid load-type (parquet/text) for IHR Incremental extract")
    }
  }

}
