package com.uhg.optum.ihr.provider

import com.uhg.optum.ihr.common.{GlobalContext, Lib, Logger}
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.{Dataset, SaveMode, SparkSession}
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions.row_number
import org.apache.spark.sql.functions.col
import org.apache.spark.sql.functions.{concat_ws, lit}
import scala.collection.parallel.{ForkJoinTaskSupport, ParSeq}

/**
  * Created by rkodur on 12/25/2017.
  */
object IncrementalMain {
  val globalContext = new GlobalContext

  def main(args: Array[String]): Unit = {
    try {
      val sqlContext = globalContext.createSparkSession("IHRIncremental")
      Logger.log.info("=============> Starting IHR Incremental WorkFlow <=============")
      if (args.length != 1) {
        Logger.log.info("Please Pass RowKey \"PATNRCD-SRCCD-ENTITYNAME\" for IHR Incremental extract")
        Logger.log.info("===> Since No RowKey is Passed ending IHR Incremental extract <===")
        globalContext.spark.stop()
      }
      else {
        try {
          val rowKey = args(0).toUpperCase().trim
          val eitRowKey = s"$rowKey-${java.util.UUID.randomUUID.toString}"
          // val prcDt = Lib.getCurrentTimeFormat
          // Lib.hbaseEitPut(eitRowKey, "pi", "prcDt", prcDt)
          val prcStTm = Lib.getCurrentTimeFormat
          val incEndTs = Lib.getCurrentTimeFormat
          Lib.hbaseEitPut(eitRowKey, "pi", "prcStTm", prcStTm)
          Logger.log.info(s"Scanning ihr_ent_cfg Table for rowKey provided:$rowKey")
          val rptCfgScan = Lib.getEntityInfo(rowKey)
          Logger.log.info(s"Entity Config for ${rowKey} from ihr_ent_cfg Table: " + rptCfgScan.mkString)
          rptCfgScan.foreach { case (patnrCd, srcCd, entNm, lastRunSts, isCustDelim, outDelim, outFileNm, outFileExt, nasLoc, quoteCol, isJoin, isNasLoc, isDrivers) =>
            Logger.log.info(s"==========> Triggering Incremental Extract Process for $entNm <===========")
            Logger.log.info(s"Incremental Extract Process Start Time: $prcStTm")
            Logger.log.info(s"EIT Tracking ID for ${entNm.toUpperCase}: $eitRowKey")
            if (!isJoin.equalsIgnoreCase("Yes")) {
              val ptnrCd = s"${patnrCd.toUpperCase()}".trim
              val src = s"${srcCd.toUpperCase()}".trim
              //val entName = s"${entNm.toUpperCase()}".trim
              val entName = s"${entNm}".trim
              val workingDir = s"${globalContext.spark.getConf.get("spark.workingDir")}"
              Lib.cleanOutputPath(s"$workingDir/$entName")
              val result: Boolean = Lib.eitTabScan(ptnrCd, src, entName, lastRunSts, incEndTs, isCustDelim, eitRowKey,entName)
              Lib.hbaseEitPut(eitRowKey, "pi", "prtnrCd", patnrCd)
              Lib.hbaseEitPut(eitRowKey, "pi", "srcCd", srcCd)
              Lib.hbaseEitPut(eitRowKey, "pi", "prcNm", outFileNm)
              Logger.log.info(s"Working Directory path for Incremental extract: $workingDir")
              if (result) {
                try {
                  Logger.log.info(s"Captured Incremental Extract for ${entName}")
                  Logger.log.info(s"Merging Schema for $entName from $workingDir/$entName")
                  val mergeDF = sqlContext.read.option("mergeSchema", true).parquet(s"$workingDir/$entName/$entName").persist(org.apache.spark.api.java.StorageLevels.MEMORY_AND_DISK_SER)
                  Logger.log.info(s"Merge Schema Record Count for $entName from $lastRunSts to Current Date:" + mergeDF.count)
                  Logger.log.info(s"Retrieving Primary Keys/CDC_TS Cols from Snapshot Config Table")
                  val snapRDD = Lib.getPkTs(patnrCd, srcCd, entName).cache()
                  if (!snapRDD.isEmpty()) {
                    try {
                      val cdc_ts = snapRDD.map(_._1).collect.mkString
                      Logger.log.info(s"CDC_TS Column for $entName: $cdc_ts")
                      val primaryKeys = snapRDD.map(_._2.split(";")).collect.flatten
                      Logger.log.info(s"Primary Key Columns for $entName: ${primaryKeys.mkString}")
                      snapRDD.unpersist()
                      val userWindow = Window.partitionBy(concat_ws("-", primaryKeys.map(c => col(c)): _*), lit("")).orderBy(col(s"$cdc_ts").desc)
                      val dedupDF = mergeDF.withColumn("rank", row_number().over(userWindow)).where(col("rank") === 1).drop("rank").persist(org.apache.spark.api.java.StorageLevels.MEMORY_AND_DISK_SER)
                      val dedupCnt = dedupDF.count()
                      Logger.log.info(s"Number of Records Extracted for $entName from $lastRunSts to Current Date with Dedup Logic:" + dedupCnt)
                      dedupDF.createOrReplaceTempView(s"${entName}")
                      Logger.log.info(s"Created Temp Table for $entName: ${entName} for Select Query")
                      val sqlQry = Lib.getSqlQry(s"$rowKey")
                      Logger.log.info(s"Sql Query provided for $entName from ihr_enity_infor Table: $sqlQry")
                      val resultDf = sqlContext.sql(s"$sqlQry").persist(org.apache.spark.api.java.StorageLevels.MEMORY_AND_DISK_SER)
                      val incExtCnt = resultDf.count.toString
                      Logger.log.info(s"Record Count for $entName with provided Sql Query:" + incExtCnt)
                      val quoteColFlg: Boolean = s"${quoteCol.toLowerCase}".toBoolean
                      Logger.log.info(s"Saving Out File for $entName with Field Delim: $outDelim  Quotes for Fields (true/false): $quoteColFlg")
                      val outLoc = globalContext.spark.getConf.get("spark.resultLoc")
                      val outBoundLoc = globalContext.spark.getConf.get("spark.outBoundLoc")
                      Lib.rmDirIfExist(s"$outLoc/$entName")

                      resultDf.repartition(1).write.mode(SaveMode.Overwrite).format("com.databricks.spark.csv").option("nullValue", "").option("header", "true").option("delimiter", s"$outDelim").option("quoteAll", quoteColFlg).save(s"$outLoc/$entName")
                      Logger.log.info("Updating RecordCount in to ihr audit table")
                      Lib.hbaseEitPut(eitRowKey, "pi", "prcReccnt", incExtCnt.toString)
                      Lib.hbaseEitPut(eitRowKey, "pi", "unprcReccnt", incExtCnt.toString)
                      resultDf.unpersist
                      dedupDF.unpersist
                      val outResFileNm = s"${outFileNm}_${Lib.getCurrentTsFormat}"
                      val outFileNmTs = s"$outResFileNm.${outFileExt.toLowerCase()}"
                      val outCtlFileNmTs = s"$outResFileNm.ctl"
                      Logger.log.info(s"Merge Output Result to OutBound Location with $outFileNmTs: $outFileNmTs")
                      Lib.merge(s"$outLoc/$entName", s"$outBoundLoc/$entName/$eitRowKey.dat")
                      val nasSrcLoc = s"/mapr$outLoc/$entName"
                      if (isNasLoc.equalsIgnoreCase("Yes")) {
                        val nasSrcUnixLoc = s"$nasSrcLoc/$outFileNmTs"
                        val nasSrcEncInfo = globalContext.spark.getConf.get("spark.nasSrcEncUsrInfo")
                        val nasKey = globalContext.spark.getConf.get("spark.encKey")
                        Logger.log.info(s"Provided Encrypted NasUserInfo:$nasSrcEncInfo")
                        Logger.log.info(s"Provided Nas Encryption Key:$nasKey")
                        val nasSrcUsrInfo = Lib.decrypt(nasKey.getBytes, nasSrcEncInfo)
                        val nasDestLoc = s"${nasLoc}/$outFileNmTs"
                        Logger.log.info(s"Transferring $outFileNmTs from $nasSrcUnixLoc to $nasDestLoc")
                        val trnsFlg: Boolean = Lib.maprfsToNas(nasSrcUsrInfo, nasSrcUnixLoc, nasDestLoc, eitRowKey)
                        Logger.log.info("File Transfer Status from MFS to NAS Location:" + trnsFlg)
                        if (trnsFlg) {
                          Logger.log.info("Creating Control File and Transferring to NAS Location")
                          Lib.createCtlFileToNas(nasSrcUsrInfo, eitRowKey, src, entName, incExtCnt, lastRunSts, incEndTs, nasLoc, outFileExt, outDelim, nasSrcLoc, outCtlFileNmTs)
                          Logger.log.info(s"Since Complete Incremental Processing is done for $entName,Deleting working directory:$workingDir/$entName")
                          Lib.rmDirIfExist(s"$workingDir/$entName/$entName")
                          Lib.hbaseEitPut(eitRowKey, "pi", "incPrcSts", "Success")
                          val prcEndTm = Lib.getCurrentTimeFormat
                          Lib.hbaseEitPut(eitRowKey, "pi", "prcEndTm", prcEndTm)
                          Logger.log.info(s"Updating lastRnTs as ${incEndTs} in ihr_entity_info HBase Table for EntNm:$entName")
                          Lib.hbasePut(rowKey, "is", "lastRnTs", incEndTs)
                          Logger.log.info(s"Incremental Extract Process End Time: $prcEndTm")
                          Logger.log.info(s"========> Completed Incremental Extraction for $entName with Success Status <========")
                        } else {
                          Logger.log.info(s"File Transfer Failed for $entName from MFS to CHILL, ending Process")
                          Lib.rmDirIfExist(s"$workingDir/$entName")
                          val prcEndTm = Lib.getCurrentTimeFormat
                          Logger.log.info(s"Incremental Extract Process End Time: $prcEndTm")
                          Logger.log.info(s"========> Incremental Extraction for $entName Completed with Failed Status <========")
                        }
                      } else {
                        Logger.log.info("File Transfer to NAS Location: No")
                        Logger.log.info("Creating Control File at HDFS Location")
                        Lib.createCtlFileToHdfs(src, entName, incExtCnt, lastRunSts, incEndTs, nasLoc, outFileExt, outDelim, nasSrcLoc, outCtlFileNmTs)
                        Logger.log.info(s"Since Complete Incremental Processing is done for $entName,Deleting working directory:$workingDir/$entName")
                        Lib.rmDirIfExist(s"$workingDir/$entName")
                        Lib.hbaseEitPut(eitRowKey, "pi", "incPrcSts", "Success")
                        val prcEndTm = Lib.getCurrentTimeFormat
                        Lib.hbaseEitPut(eitRowKey, "pi", "prcEndTm", prcEndTm)
                        Logger.log.info(s"Updating lastRnTs as ${incEndTs} in ihr_entity_info HBase Table for EntNm:$entName")
                        Lib.hbasePut(rowKey, "is", "lastRnTs", incEndTs)
                        Logger.log.info(s"Incremental Extract Process End Time: $prcEndTm")
                        Logger.log.info(s"========> Completed Incremental Extraction for $entName with Success Status <========")
                      }
                    } catch {
                      case e: Exception => Logger.log.error(s"Exception at Main Loading MergeSchema/SqlStatement for $entName" :+ e.getMessage)
                        Lib.rmDirIfExist(s"$workingDir/$entName")
                        throw e
                    }
                  }
                  else {
                    Logger.log.info("Snapshot PrimaryKeys / CDC Timestamp not found, Please Check HBase Snapshot_config Table")
                    Lib.hbaseEitPut(eitRowKey, "eri", "errCd", " Snapshot Primary / Timestamp")
                    Lib.hbaseEitPut(eitRowKey, "eri", "errDesc", "Snapshot PrimaryKeys / CDC Timestamp not found, Please Check HBase Snapshot_config Table")
                    Lib.hbaseEitPut(eitRowKey, "pi", "incPrcSts", "Failure")
                    val prcEndTm = Lib.getCurrentTimeFormat
                    Lib.hbaseEitPut(eitRowKey, "pi", "prcEndTm", prcEndTm)
                    Lib.rmDirIfExist(s"$workingDir/$entName")
                    Logger.log.info(s"Incremental Extract Process End Time: $prcEndTm")
                  }
                } catch {
                  case e: Exception => Logger.log.error(s"Exception at Main Loading MergeSchema/SqlStatement for $entName" :+ e.getMessage)
                    Lib.hbaseEitPut(eitRowKey, "eri", "errCd", "Exception While performing MergeSchema/SqlStatement execution")
                    Lib.hbaseEitPut(eitRowKey, "eri", "errDesc", e.getMessage)
                    Lib.hbaseEitPut(eitRowKey, "pi", "incPrcSts", "Failure")
                    val prcEndTm = Lib.getCurrentTimeFormat
                    Lib.hbaseEitPut(eitRowKey, "pi", "prcEndTm", prcEndTm)
                    Lib.rmDirIfExist(s"$workingDir/$entName")
                    Logger.log.info(s"Incremental Extract Process End Time: $prcEndTm")
                    throw e
                }
              }
              else {
                Logger.log.info(s"Since No Changes reflected for the $entNm from $lastRunSts to Till Date, Updating Record Count as 0")
                Lib.hbaseEitPut(eitRowKey, "pi", "incPrcSts", "Success")
                Lib.hbaseEitPut(eitRowKey, "pi", "prcReccnt", "0")
                Lib.hbaseEitPut(eitRowKey, "pi", "unprcReccnt", "0")
                Logger.log.info(s"Updating lastRnTs as ${incEndTs} in ihr_entity_info HBase Table for EntNm:$entName")
                Lib.hbasePut(rowKey, "is", "lastRnTs", incEndTs)
                val prcEndTm = Lib.getCurrentTimeFormat
                Lib.hbaseEitPut(eitRowKey, "pi", "prcEndTm", prcEndTm)
                Logger.log.info(s"Incremental Extract Process End Time: $prcEndTm")
              }
            } else {
              // val isDrivers = globalContext.spark.getConf.get("spark.isDrivers")
              if (isDrivers.toUpperCase.equals("YES")) {
                Logger.log.info("===================> Processing Incremental Framwork for Multiple driver Tables <===================")
                val Array(driverTab, lookUpTab) = entNm.toUpperCase.split(';')
                val driverTabList = driverTab.toUpperCase.trim.split('|')
                val lookUpTabList = lookUpTab.toUpperCase.trim.split('|')

                val ptnrCd = s"${patnrCd.toUpperCase()}".trim
                val src = s"${srcCd.toUpperCase()}".trim
                val entName = s"${outFileNm.toUpperCase()}"
                Lib.hbaseEitPut(eitRowKey, "pi", "prtnrCd", patnrCd)
                Lib.hbaseEitPut(eitRowKey, "pi", "srcCd", srcCd)
                Lib.hbaseEitPut(eitRowKey, "pi", "entNm", outFileNm)
                val workingDir = s"${globalContext.spark.getConf.get("spark.workingDir")}"
                var result: Boolean = true
                Lib.cleanOutputPath(s"$workingDir/$entName")
                driverTabList.foreach { ent =>
                  result = Lib.eitTabScan(ptnrCd, src, ent.trim, "2000-01-22 22:05:08", incEndTs, isCustDelim, eitRowKey,entName)
                }
                if (result) {
                  driverTabList.foreach { ent =>
                    Lib.driverProcessFrmWrk(src, patnrCd, ent.trim, workingDir, eitRowKey, lastRunSts)
                  }
                  val columns = globalContext.spark.getConf.get("spark.columnNames")
                  Logger.log.info("Common Field Names for driver tables:" + columns)
                  Lib.driverTableProcess(srcCd, patnrCd, driverTabList(0), workingDir, eitRowKey, lastRunSts, driverTabList.toList, columns)

                  lookUpTabList.foreach { ent =>
                    val result: Boolean = Lib.eitTabScan(ptnrCd, src, ent.trim, "2000-01-22 22:05:08", incEndTs, isCustDelim, eitRowKey,entName)
                  }
                  lookUpTabList.foreach { ent =>
                    Lib.processFrmWrk(src, patnrCd, ent.trim, workingDir, eitRowKey, "2000-01-22 22:05:08",entName)
                  }
                  val sqlQry = Lib.getSqlQry(s"$rowKey")
                  Logger.log.info(s"Sql Query provided for $outFileNm from ihr_enity_infor Table: $sqlQry")
                  val resultDfJ = sqlContext.sql(s"$sqlQry").persist(org.apache.spark.api.java.StorageLevels.MEMORY_AND_DISK_SER)
                  val incExtCnt = resultDfJ.count.toString
                  Logger.log.info(s"Record Count for $outFileNm with provided Sql Query:" + incExtCnt)
                  val quoteColFlg: Boolean = s"${quoteCol.toLowerCase()}".toBoolean
                  Logger.log.info(s"Saving Out File for with Field Delim: $outDelim  Quotes for Fields (true/false): $quoteColFlg")
                  val outLoc = globalContext.spark.getConf.get("spark.resultLoc")
                  val outBoundLoc = globalContext.spark.getConf.get("spark.outBoundLoc")
                  Lib.rmDirIfExist(s"$outLoc/$entName")

                  resultDfJ.repartition(1).write.mode(SaveMode.Overwrite).format("com.databricks.spark.csv").option("header", "true").option("delimiter", s"$outDelim").option("quoteAll", quoteColFlg).save(s"$outLoc/$entName")

                  Logger.log.info("Updating RecordCount in to ihr audit table")
                  Lib.hbaseEitPut(eitRowKey, "pi", "prcReccnt", incExtCnt.toString)
                  Lib.hbaseEitPut(eitRowKey, "pi", "unprcReccnt", "0")
                  resultDfJ.unpersist
                  val outResFileNm = s"${outFileNm}_${Lib.getCurrentTsFormat}"
                  val outFileNmTs = s"$outResFileNm.${outFileExt.toLowerCase()}"
                  val outCtlFileNmTs = s"$outResFileNm.ctl"
                  Logger.log.info(s"Merge Output Result to filename: $outFileNmTs")
                  Logger.log.info(s"Merge Output Result to OutBound Location with $outFileNmTs: $outFileNmTs")
                  Lib.merge(s"$outLoc/$entName", s"$outBoundLoc/$entName/$eitRowKey.dat")
                  val nasSrcLoc = s"/mapr$outLoc/$outFileNm"
                  if (isNasLoc.equalsIgnoreCase("Yes")) {
                    val nasSrcUnixLoc = s"$nasSrcLoc/$outFileNmTs"
                    val nasSrcEncInfo = globalContext.spark.getConf.get("spark.nasSrcEncUsrInfo")
                    val nasKey = globalContext.spark.getConf.get("spark.encKey")
                    Logger.log.info(s"Provided Encrypted NasUserInfo:$nasSrcEncInfo")
                    Logger.log.info(s"Provided Nas Encryption Key:$nasKey")
                    val nasSrcUsrInfo = Lib.decrypt(nasKey.getBytes, nasSrcEncInfo)
                    val nasDestLoc = s"${nasLoc}/$outFileNmTs"
                    Logger.log.info(s"Transferring $outFileNmTs from $nasSrcUnixLoc to $nasDestLoc")
                    val trnsFlg: Boolean = Lib.maprfsToNas(nasSrcUsrInfo, nasSrcUnixLoc, nasDestLoc, eitRowKey)
                    Logger.log.info("File Transfer Status from MFS to NAS Location:" + trnsFlg)
                    Logger.log.info(s"Since Complete Incremental Processing is done for $outFileNm,Deleting working directory:$workingDir info")
                    lookUpTabList.map(x => Lib.rmDirIfExist(s"$workingDir/$entName/${x.trim}"))
                    driverTabList.map(x=>Lib.rmDirIfExist(s"$workingDir/$entName/${x.trim}"))
                    Lib.hbaseEitPut(eitRowKey, "pi", "incPrcSts", "Success")
                    val prcEndTm = Lib.getCurrentTimeFormat
                    Lib.hbaseEitPut(eitRowKey, "pi", "prcEndTm", prcEndTm)
                    Logger.log.info(s"Updating lastRnTs as ${incEndTs} in ihr_entity_info HBase Table for EntNm:$entName")
                    Lib.hbasePut(rowKey, "is", "lastRnTs", incEndTs)
                    Logger.log.info(s"Incremental Extract Process End Time: $prcEndTm")
                    Logger.log.info(s"========> Completed Incremental Extraction for $entNm with Success Status <========")
                  } else {
                    Logger.log.info("File Transfer to NAS Location: No")
                    Logger.log.info("Skipping Creating Control File to the HDFS Location")
                    Lib.createCtlFileToHdfs(src, entName, incExtCnt, lastRunSts, incEndTs, nasLoc, outFileExt, outDelim, nasSrcLoc, outCtlFileNmTs)
                    Logger.log.info(s"Since Complete Incremental Processing is done for $outFileNm,Deleting working directory:$workingDir info")
                    lookUpTabList.map(x => Lib.rmDirIfExist(s"$workingDir/$entName/${x.trim}"))
                    driverTabList.map(x=>Lib.rmDirIfExist(s"$workingDir/$entName/${x.trim}"))
                    Lib.hbaseEitPut(eitRowKey, "pi", "incPrcSts", "Success")
                    val prcEndTm = Lib.getCurrentTimeFormat
                    Lib.hbaseEitPut(eitRowKey, "pi", "prcEndTm", prcEndTm)
                    Logger.log.info(s"Updating lastRnTs as ${incEndTs} in ihr_entity_info HBase Table for EntNm:$entName")
                    Lib.hbasePut(rowKey, "is", "lastRnTs", incEndTs)
                    Logger.log.info(s"Incremental Extract Process End Time: $prcEndTm")
                    Logger.log.info(s"========> Completed Incremental Extraction for $entNm with Success Status <========")
                  }
                }
                else {
                  Logger.log.info(s"Since No Changes reflected for the $outFileNm from $lastRunSts to Till Date, Updating Record Count as 0")
                  Lib.hbaseEitPut(eitRowKey, "pi", "incPrcSts", "Success")
                  Lib.hbaseEitPut(eitRowKey, "pi", "prcReccnt", "0")
                  Lib.hbaseEitPut(eitRowKey, "pi", "unprcReccnt", "0")
                  Logger.log.info(s"Updating lastRnTs as ${incEndTs} in ihr_entity_info HBase Table for EntNm:$entName")
                  Lib.hbasePut(rowKey, "is", "lastRnTs", incEndTs)
                  val prcEndTm = Lib.getCurrentTimeFormat
                  Lib.hbaseEitPut(eitRowKey, "pi", "prcEndTm", prcEndTm)
                  Logger.log.info(s"Incremental Extract Process End Time: $prcEndTm")
                }
              } else {
                val Array(driverTab, lookUpTab) = entNm.toUpperCase.split(';')
                val lookUpTabList = lookUpTab.toUpperCase.trim.split('|')
                val lookUpParList=lookUpTabList.par
                lookUpParList.tasksupport = new ForkJoinTaskSupport(new scala.concurrent.forkjoin.ForkJoinPool(5))
                val ptnrCd = s"${patnrCd.toUpperCase()}".trim
                val src = s"${srcCd.toUpperCase()}".trim
                val entName = s"${outFileNm}".trim
                Lib.hbaseEitPut(eitRowKey, "pi", "prtnrCd", patnrCd)
                Lib.hbaseEitPut(eitRowKey, "pi", "srcCd", srcCd)
                Lib.hbaseEitPut(eitRowKey, "pi", "entNm", outFileNm)
                val workingDir = s"${globalContext.spark.getConf.get("spark.workingDir")}"
                Lib.cleanOutputPath(s"$workingDir/$entName")
                val driverTabRes: Boolean = Lib.eitTabScan(ptnrCd, src, driverTab.trim, "2000-01-22 22:05:08", incEndTs, isCustDelim, eitRowKey,entName)
                if (driverTabRes) {
                  Lib.processFrmWrk(src, patnrCd, driverTab, workingDir, eitRowKey, lastRunSts,entName)
                  lookUpParList.foreach { ent =>
                    val result: Boolean = Lib.eitTabScan(ptnrCd, src, ent.trim, "2000-01-22 22:05:08", incEndTs, isCustDelim, eitRowKey,entName)
                  }
                  lookUpParList.foreach { ent =>
                    Lib.processFrmWrk(src, patnrCd, ent.trim, workingDir, eitRowKey, "2000-01-22 22:05:08",entName)
                  }
                  val sqlQry = Lib.getSqlQry(s"$rowKey")
                  Logger.log.info(s"Sql Query provided for $outFileNm from ihr_enity_infor Table: $sqlQry")
                  import sqlContext.implicits._
                  val resultDfJ = sqlContext.sql(s"$sqlQry").persist(org.apache.spark.api.java.StorageLevels.MEMORY_AND_DISK_SER)
                  val incExtCnt = resultDfJ.count.toString
                  Logger.log.info(s"Record Count for $outFileNm with provided Sql Query:" + incExtCnt)
                  val quoteColFlg: Boolean = s"${quoteCol.toLowerCase()}".toBoolean
                  Logger.log.info(s"Saving Out File for with Field Delim: $outDelim  Quotes for Fields (true/false): $quoteColFlg")
                  val outLoc = globalContext.spark.getConf.get("spark.resultLoc")
                  val outBoundLoc = globalContext.spark.getConf.get("spark.outBoundLoc")
                  Lib.rmDirIfExist(s"$outLoc/$entName")

                  resultDfJ.repartition(1).write.mode(SaveMode.Overwrite).format("com.databricks.spark.csv").option("header", "true").option("delimiter", s"$outDelim").option("quoteAll", quoteColFlg).save(s"$outLoc/$entName")

                  Logger.log.info("Updating RecordCount in to ihr audit table")
                  Lib.hbaseEitPut(eitRowKey, "pi", "prcReccnt", incExtCnt.toString)
                  Lib.hbaseEitPut(eitRowKey, "pi", "unprcReccnt", "0")
                  resultDfJ.unpersist
                  val outResFileNm = s"${outFileNm}_${Lib.getCurrentTsFormat}"
                  val outFileNmTs = s"$outResFileNm.${outFileExt.toLowerCase()}"
                  val outCtlFileNmTs = s"$outResFileNm.ctl"
                  Logger.log.info(s"Merge Output Result to filename: $outFileNmTs")
                  Logger.log.info(s"Merge Output Result to OutBound Location with $outFileNmTs: $outFileNmTs")
                  Lib.merge(s"$outLoc/$entName", s"$outBoundLoc/$entName/$eitRowKey.dat")
                  val nasSrcLoc = s"/mapr$outLoc/$outFileNm"
                  if (isNasLoc.equalsIgnoreCase("Yes")) {
                    val nasSrcUnixLoc = s"$nasSrcLoc/$outFileNmTs"
                    val nasSrcEncInfo = globalContext.spark.getConf.get("spark.nasSrcEncUsrInfo")
                    val nasKey = globalContext.spark.getConf.get("spark.encKey")
                    Logger.log.info(s"Provided Encrypted NasUserInfo:$nasSrcEncInfo")
                    Logger.log.info(s"Provided Nas Encryption Key:$nasKey")
                    val nasSrcUsrInfo = Lib.decrypt(nasKey.getBytes, nasSrcEncInfo)
                    val nasDestLoc = s"${nasLoc}/$outFileNmTs"
                    Logger.log.info(s"Transferring $outFileNmTs from $nasSrcUnixLoc to $nasDestLoc")
                    val trnsFlg: Boolean = Lib.maprfsToNas(nasSrcUsrInfo, nasSrcUnixLoc, nasDestLoc, eitRowKey)
                    Logger.log.info("File Transfer Status from MFS to NAS Location:" + trnsFlg)
                    if (trnsFlg) {
                      Logger.log.info("Creating Control File and Transferring to NAS Location")
                      Lib.createCtlFileToNas(nasSrcUsrInfo, eitRowKey, src, entNm, incExtCnt, lastRunSts, incEndTs, nasLoc, outFileExt, outDelim, nasSrcLoc, outCtlFileNmTs)
                      Logger.log.info(s"Since Complete Incremental Processing is done for $entName,Deleting working directory:$workingDir/$entName")
                      lookUpTabList.map(x => Lib.rmDirIfExist(s"$workingDir/$entName/$x"))
                      Lib.hbaseEitPut(eitRowKey, "pi", "incPrcSts", "Success")
                      val prcEndTm = Lib.getCurrentTimeFormat
                      Lib.hbaseEitPut(eitRowKey, "pi", "prcEndTm", prcEndTm)
                      Logger.log.info(s"Updating lastRnTs as ${incEndTs} in ihr_entity_info HBase Table for EntNm:$entName")
                      Lib.hbasePut(rowKey, "is", "lastRnTs", incEndTs)
                      Logger.log.info(s"Incremental Extract Process End Time: $prcEndTm")
                      Logger.log.info(s"========> Completed Incremental Extraction for $entNm with Success Status <========")
                    } else {
                      Logger.log.info(s"File Transfer Failed for $entName from MFS to CHILL, ending Process")
                      lookUpTabList.map(x => Lib.rmDirIfExist(s"$workingDir/$entName/${x.trim}"))
                      Lib.rmDirIfExist(s"$workingDir/$entName/$driverTab")
                      val prcEndTm = Lib.getCurrentTimeFormat
                      Logger.log.info(s"Incremental Extract Process End Time: $prcEndTm")
                      Logger.log.info(s"========> Incremental Extraction for $entNm Completed with Failed Status <========")
                    }
                  } else {
                    Logger.log.info("File Transfer to NAS Location: No")
                    Logger.log.info("Skipping Creating Control File to the HDFS Location")
                    Lib.createCtlFileToHdfs(src, entName, incExtCnt, lastRunSts, incEndTs, nasLoc, outFileExt, outDelim, nasSrcLoc, outCtlFileNmTs)
                    Logger.log.info(s"Since Complete Incremental Processing is done for $outFileNm,Deleting working directory:$workingDir info")
                    lookUpTabList.map(x => Lib.rmDirIfExist(s"$workingDir/$entName/${x.trim}"))
                    Lib.rmDirIfExist(s"$workingDir/$entName/$driverTab")
                    Lib.hbaseEitPut(eitRowKey, "pi", "incPrcSts", "Success")
                    val prcEndTm = Lib.getCurrentTimeFormat
                    Lib.hbaseEitPut(eitRowKey, "pi", "prcEndTm", prcEndTm)
                    Logger.log.info(s"Updating lastRnTs as ${incEndTs} in ihr_entity_info HBase Table for EntNm:$entName")
                    Lib.hbasePut(rowKey, "is", "lastRnTs", incEndTs)
                    Logger.log.info(s"Incremental Extract Process End Time: $prcEndTm")
                    Logger.log.info(s"========> Completed Incremental Extraction for $entNm with Success Status <========")
                  }
                }
                else {
                  Logger.log.info(s"Since No Changes reflected for the $outFileNm from $lastRunSts to Till Date, Updating Record Count as 0")
                  Lib.hbaseEitPut(eitRowKey, "pi", "incPrcSts", "Success")
                  Lib.hbaseEitPut(eitRowKey, "pi", "prcReccnt", "0")
                  Lib.hbaseEitPut(eitRowKey, "pi", "unprcReccnt", "0")
                  Logger.log.info(s"Updating lastRnTs as ${incEndTs} in ihr_entity_info HBase Table for EntNm:$entName")
                  Lib.hbasePut(rowKey, "is", "lastRnTs", incEndTs)
                  val prcEndTm = Lib.getCurrentTimeFormat
                  Lib.hbaseEitPut(eitRowKey, "pi", "prcEndTm", prcEndTm)
                  Logger.log.info(s"Incremental Extract Process End Time: $prcEndTm")
                }
              }
            }
          }
        }catch {
          case e: Exception => Logger.log.error("Exception at Main IncrementalMain Object" :+ e.getMessage)
            throw e
        }
      }
    } catch {
      case e: Exception => Logger.log.error("Exception at Main IncrementalMain Object" :+ e.getMessage)
        throw e
    }
  }
}