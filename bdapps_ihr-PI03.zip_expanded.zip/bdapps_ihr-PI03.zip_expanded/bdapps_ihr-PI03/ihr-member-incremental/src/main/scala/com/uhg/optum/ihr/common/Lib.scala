package com.uhg.optum.ihr.common

import java.io.InputStream

import org.apache.hadoop.hbase.filter._
import java.text.SimpleDateFormat
import java.util.Calendar

import jcifs.smb.{NtlmPasswordAuthentication, SmbFile, SmbFileOutputStream}
import org.apache.hadoop.fs.{FileSystem, FileUtil, Path}
import org.apache.hadoop.hbase.filter.CompareFilter.CompareOp
import org.apache.hadoop.hbase.{CellUtil, TableName}
import org.apache.hadoop.hbase.util.Bytes
import org.apache.hadoop.hbase.client.{Get, Put, Result, Scan}
import org.apache.spark.SparkContext
import org.apache.spark.sql.types._
import org.apache.spark.sql.{DataFrame, Row, SaveMode}
import java.io.{File, PrintWriter}
import javax.crypto.Cipher
import javax.crypto.spec.SecretKeySpec

import com.rabbitmq.client.ConnectionFactory
import org.apache.commons.codec.binary.Base64
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions.{col, concat_ws, lit, row_number}

import scala.collection.mutable.ListBuffer
import scala.collection.parallel.{ForkJoinTaskSupport, ParSeq}
import com.rabbitmq.client._


/**
  * Created by rkodur on 12/25/2017.
  */

object Lib {
  val globalContext = new GlobalContext

  def getCurrentTimeFormat: String = getCurrentDateTime("yyyy-MM-dd HH:mm:ss")

  def getCurrentTsFormat: String = getCurrentDateTime("yyyyMMddHHmmssSS").substring(0, 16)

  def getCurrentDateTime(dateTimeFormat: String): String = {
    val dateFormat = new SimpleDateFormat(dateTimeFormat)
    val cal = Calendar.getInstance()
    dateFormat.format(cal.getTime)
  }

  def getTimestamp(DateFormat: String): Long = {
    try {
      val timestampformat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
      timestampformat.parse(DateFormat).getTime
    } catch {
      case e: Exception => Logger.log.error("Exception while getting current date/time" :+ e.getMessage)
        0
    }
  }
  def cleanOutputPath(outputFilePath: String): Unit = {
    val outputNodeAddress=globalContext.spark.getConf.get("spark.outputNodeAddress")
    val hadoopConf = new org.apache.hadoop.conf.Configuration()
    val hdfs = org.apache.hadoop.fs.FileSystem.get(new java.net.URI(outputNodeAddress), hadoopConf)
    val path = new org.apache.hadoop.fs.Path(outputFilePath)
    if (hdfs.exists(path)) {
      Logger.log.info("Overwriting staging directory : " + path)
      try { hdfs.delete(path, true) } catch { case _: Throwable => {} }
    } else {
      Logger.log.info(s"Given directory from path: $path is empty.... Exiting clean")
    }
    hdfs.mkdirs(path)
  }

  def filterListAnd(filters: Filter*) = new FilterList(FilterList.Operator.MUST_PASS_ALL, filters: _*)

  def filterListOr(filters: Filter*) = new FilterList(FilterList.Operator.MUST_PASS_ONE, filters: _*)

  def getEppTabSchm(patnrCd: String, srcCd: String, entNm: String): org.apache.spark.rdd.RDD[(String, String)] = {
    try {
      //val eppTableName = "/datalake/uhclake/prd/p_mtables/entity_partner_profile"
      val eppTab = globalContext.spark.getConf.get("spark.eppTab")
      Logger.log.info(s"Scanning EPP HBase Table $eppTab for Entity: $entNm")
      val rdd = globalContext.spark.parallelize(Array(Bytes.toBytes(s"${patnrCd}-${srcCd}-${entNm}")))
      val getRdd = globalContext.hbaseContext.bulkGet[Array[Byte], List[(String, String)]](
        TableName.valueOf(eppTab),
        2,
        rdd,
        record => {
          val get = new Get(record)
          get.setMaxVersions(99)
        },
        (result: Result) => {
          val it = result.listCells().iterator()
          var schver = new ListBuffer[String]()
          var schm = new ListBuffer[String]()
          while (it.hasNext) {
            val cell = it.next()
            val q = Bytes.toString(CellUtil.cloneQualifier(cell))
            if (q.equals("schmVer"))
              schver += Bytes.toString(CellUtil.cloneValue(cell))
            else if (q.equals("schm"))
              schm += Bytes.toString(CellUtil.cloneValue(cell))
          }
          (schver zip schm).toList
        })
      getRdd.flatMap(x => x)
    } catch {
      case e: Exception => Logger.log.error("Exception at saveDFversionTables" :+ e.getMessage)
        throw e
    }
  }

  val sqlContext = globalContext.createSparkSession("IHRIncremental")

  def saveDataFrame(schmVer: String, schm: String, fileList: String, entNm: String, sparkConfig: SparkContext,extractNm: String): Unit = {
    try {
      Logger.log.info(s"Invoked Schema Mapping for $entNm Version $schmVer Files")
      val jsonFile = schm.split("(?<=\\}),(?=\\{)")
      Logger.log.info(s"Parsing EPP Json Schema for $entNm Version $schmVer:$schm")

      /*     To Resolve Oozie jars Conflicts Issue used below Json Code
       val jsonRdd = jsonFile.map { x =>
              val gp = JSON.parseFull(x)
              val globalMap = gp.get.asInstanceOf[Map[String, Any]]
              globalMap("COLUMN_NAME").toString
            }.toList*/
      //Parsed SuccessFully Going to Next Step

      val jsonRddSchm = globalContext.spark.parallelize(jsonFile)
      Logger.log.info("Extracting Columns from EPP Json Schema")
      val jsonRdd = sqlContext.read.json(jsonRddSchm).rdd.map(x => (x(1).toString)).collect
      Logger.log.info("Parsed Schema Using SQL Context")

      val fields = jsonRdd.map(fieldName => StructField(fieldName, StringType, nullable = true))
      val schema = StructType(fields)
      val loadFiles = sparkConfig.textFile(fileList).map(_.split("\u0001", -1)).map(x => Row(x: _*))
      val verDf = sqlContext.createDataFrame(loadFiles, schema)
      val workingDir = globalContext.spark.getConf.get("spark.workingDir")
      verDf.write.mode(SaveMode.Append).parquet(s"$workingDir/$extractNm/${entNm.toUpperCase()}")
    }
    catch {
      case e: Exception => Logger.log.error("Exception at saveDFversionTables" :+ e.getMessage)
        throw e
    }
  }

  def eitTabScan(patnrCd: String, srcCd: String, entNm: String, incStTime: String, incEndTs: String, isCustDelim: String, eitRowKey: String,extractNm:String): Boolean = {
    try {
      val workingDir = globalContext.spark.getConf.get("spark.workingDir")
      rmDirIfExist(s"$workingDir/${entNm.toUpperCase()}")
      val eitTable = globalContext.spark.getConf.get("spark.eitTab")
      val ptnr = s"${patnrCd}".toUpperCase
      val src = s"${srcCd}".toUpperCase
      val mountPath = globalContext.spark.getConf.get("spark.mountPath")
      val raw_path = s"maprfs://$mountPath/${ptnr.toLowerCase}/raw/standard_access/${src.toLowerCase}/data/"
      val entName = s"${entNm}".toUpperCase
      Logger.log.info(s"Retrieving Files for $entName from Raw: $raw_path")
      Logger.log.info(s"Processing Entity:${entName} with patnrCd:${ptnr} srcCd:${src}")
      Logger.log.info(s"Scanning Eit HBase Table: $eitTable")
      val startTime = s"$incStTime"
      val endTime = s"$incEndTs"
      Logger.log.info(s"Capturing if any Changes reflected for $entName from $startTime to $endTime")
      val rowKey = s"${ptnr}-${src}-${entName}"
      if (isCustDelim.equalsIgnoreCase("No")) {
        try {
          Logger.log.info(s"Processing ${entName} Files with Row Delimiter: \\n")
          import org.apache.hadoop.hbase.client.Scan
          val scan = new Scan()
          val filter = new PrefixFilter(Bytes.toBytes(s"${ptnr}-${src}-${entName}-"))
          val filter1 = new SingleColumnValueFilter(Bytes.toBytes("exi"), Bytes.toBytes("ingProcLogSts"), CompareOp.EQUAL, Bytes.toBytes("Success"));
          //val filter2 = new SingleColumnValueFilter(Bytes.toBytes("fi"), Bytes.toBytes("iscustrowdelim"), CompareOp.EQUAL, Bytes.toBytes("No"));
          scan.setCaching(10000)
          scan.setCacheBlocks(false)
          filter1.setFilterIfMissing(true)
          //filter2.setFilterIfMissing(true)
          scan.setFilter(filterListAnd(filter1, filter))
          scan.setTimeRange(getTimestamp(startTime), getTimestamp(endTime))
          val eitVal = globalContext.hbaseContext.hbaseRDD(TableName.valueOf(eitTable), scan).cache
          val eitInfo = eitVal.map(tuple => {
            val result = tuple._2
            (Bytes.toString(result.getValue(Bytes.toBytes("fi"), Bytes.toBytes("schmVer"))),
              Bytes.toString(result.getValue(Bytes.toBytes("fi"), Bytes.toBytes("srcFileNm"))),
              Bytes.toString(result.getValue(Bytes.toBytes("fi"), Bytes.toBytes("entprtnfldr"))))
          })
          Logger.log.info(s"Number of Entries Captured for $entName from EIT SCAN b/w $startTime and $endTime :" + eitVal.count())
          if (!eitInfo.isEmpty) {
            //  val eitFileList: List[(String, String)] = eitInfo.collect.toList.map(x => (x, s"${raw_path}${entName}/${entName}.v${x}//*"))
            val eitFileList = eitInfo.map(x => (x._1, x._2, x._3)).collect.toList.map(x => (x._1, s"${raw_path}${entNm}/${entNm}.v${x._1}/${x._3}/${x._2}"))
            val eitRawFileList = eitFileList.filter(x => filterRawFileExist(x._2))
            Logger.log.info(s"Number of Files exist in Raw with \\n record delim for $entName from EIT SCAN b/w $startTime and $endTime :" + eitRawFileList.length)
            Logger.log.info(s"List of Files from Raw with \\n record delim: ${eitRawFileList.mkString}")
            val eitRdd = globalContext.spark.parallelize(eitRawFileList)

            // val eitFileRdd = eitRdd.groupByKey.mapValues(_.mkString(","))
            //Improving performance by using reduceByKey instead of groupByKey

            val eitFileRdd = eitRdd.aggregateByKey(ListBuffer.empty[String])(
              (numList, num) => {
                numList += num;
                numList
              },
              (numList1, numList2) => {
                numList1.appendAll(numList2);
                numList1
              })
              .mapValues(_.mkString(",")).cache()

            val eppRdd: org.apache.spark.rdd.RDD[(String, String)] = getEppTabSchm(ptnr, src, entName).cache
            Logger.log.info(s"Number of Schema Versions for ${entName} retrieved from EPP HBase Table:" + eppRdd.count())
            val sparkConfig = globalContext.spark
            eppRdd.join(eitFileRdd).collect.foreach { case (schmVer, (schm, fileList)) =>
              saveDataFrame(schmVer, schm, fileList, entName, sparkConfig,extractNm)
            }
            eitVal.unpersist()
            eppRdd.unpersist()
            true
          } else {
            Logger.log.info(s"Since, No Changes Captured for $entName from $startTime to $endTime, datasets will not be generated")
            false
          }
        }
        catch {
          case e: Exception => Logger.log.info(s"Exception while Scanning Files from EIT for $entName" :+ e.getMessage)
            Lib.hbaseEitPut(eitRowKey, "eri", "errCd", "While Scanning EIT")
            Lib.hbaseEitPut(eitRowKey, "eri", "errDesc", e.getMessage)
            Lib.hbaseEitPut(eitRowKey, "pi", "incPrcSts", "Failure")
            throw e
        }
      }
      else if (isCustDelim.equalsIgnoreCase("Yes")) {
        try {
          Logger.log.info(s"Processing ${entName} Files with Row Delimiter: \\u0002 & \\u0002\\u000A")
          import org.apache.hadoop.hbase.client.Scan
          val scan = new Scan()
          val filter = new PrefixFilter(Bytes.toBytes(s"${ptnr}-${src}-${entName}-"))
          val filter1 = new SingleColumnValueFilter(Bytes.toBytes("exi"), Bytes.toBytes("ingProcLogSts"), CompareOp.EQUAL, Bytes.toBytes("Success"))
          val filter2 = new SingleColumnValueFilter(Bytes.toBytes("fi"), Bytes.toBytes("iscustrowdelim"), CompareOp.EQUAL, Bytes.toBytes("Yes"))
          scan.setCaching(100000)
          scan.setCacheBlocks(false)
          filter1.setFilterIfMissing(true)
          filter2.setFilterIfMissing(true)
          scan.setFilter(filterListAnd(filter1, filter2, filter))
          scan.setTimeRange(getTimestamp(startTime), getTimestamp(endTime))
          val eitVal = globalContext.hbaseContext.hbaseRDD(TableName.valueOf(eitTable), scan).cache
          val eitInfo = eitVal.map(tuple => {
            val result = tuple._2
            (Bytes.toString(result.getValue(Bytes.toBytes("fi"), Bytes.toBytes("schmVer"))),
              Bytes.toHex(result.getValue(Bytes.toBytes("fi"), Bytes.toBytes("rowdelim"))),
              Bytes.toString(result.getValue(Bytes.toBytes("fi"), Bytes.toBytes("srcFileNm"))),
              Bytes.toString(result.getValue(Bytes.toBytes("fi"), Bytes.toBytes("entprtnfldr"))))
          })
          Logger.log.info(s"Number of Files Captured for $entName from EIT SCAN b/w $startTime and $endTime :" + eitVal.count())
          if (!eitInfo.isEmpty()) {
            //  val eitFileListCtlB: List[(String, String)] = eitInfo.filter(x => x._2 == "2" || x._2 == "5c7530303032").map(x => (x._1, x._3, x._4)).collect.toList.map(x => (x._1, s"${raw_path}${entNm}/${entNm}.v${x._1}/${x._3}/${x._2}"))

            val eitFileListCtlB: ParSeq[(String, String)] = eitInfo.filter(x => x._2 == "2" || x._2 == "5c7530303032").map(x => (x._1, x._3, x._4)).collect.toList.map(x => (x._1, s"${raw_path}${entNm}/${entNm}.v${x._1}/${x._3}/${x._2}")).par
            eitFileListCtlB.tasksupport = new ForkJoinTaskSupport(new scala.concurrent.forkjoin.ForkJoinPool(5))

            /*val parEitFileListCtlB = eitFileListCtlB.par
            parEitFileListCtlB.tasksupport = new ForkJoinTaskSupport(new scala.concurrent.forkjoin.ForkJoinPool(10))*/

            val eitRawFileListCtlB = eitFileListCtlB.filter(x => filterRawFileExist(x._2))
            Logger.log.info(s"Number of Files exist in Raw with \\u0002 record delim for $entName from EIT SCAN b/w $startTime and $endTime :" + eitRawFileListCtlB.size)
            Logger.log.info(s"List of Files from Raw with \\u0002 record delim: ${eitRawFileListCtlB.mkString}")
            val rddCtlB = globalContext.spark.parallelize(eitRawFileListCtlB.toList)

            //   val eitFileRddCtlB = rddCtlB.groupByKey.mapValues(_.mkString(",")).cache()
            //Improving performance by using reduceByKey instead of groupByKey

            val eitFileRddCtlB = rddCtlB.aggregateByKey(ListBuffer.empty[String])(
              (numList, num) => {
                numList += num;
                numList
              },
              (numList1, numList2) => {
                numList1.appendAll(numList2);
                numList1
              })
              .mapValues(_.mkString(",")).cache()


            val eppRdd: org.apache.spark.rdd.RDD[(String, String)] = getEppTabSchm(ptnr, src, entName).cache
            Logger.log.info(s"Number of Schema Versions for ${entName} retrieved from EPP HBase Table:" + eppRdd.count())
            val sparkConfigCtlB = globalContext.spark
            sparkConfigCtlB.hadoopConfiguration.set("textinputformat.record.delimiter", "\u0002")
            eppRdd.join(eitFileRddCtlB).collect.foreach { case (schmVer, (schm, fileList)) =>
              saveDataFrame(schmVer, schm, fileList, entName, sparkConfigCtlB,extractNm)
            }
            // val eitFileListCtlBNL: List[(String, String)] = eitInfo.filter(x => x._2 == "25c6e" || x._2 == "20a").map(x => (x._1, x._3, x._4)).collect.toList.map(x => (x._1, s"${raw_path}${entNm}/${entNm}.v${x._1}/${x._3}/${x._2}"))

            val eitFileListCtlBNL: ParSeq[(String, String)] = eitInfo.filter(x => x._2 == "25c6e" || x._2 == "20a" || x._2 == "5c75303030325c6e").map(x => (x._1, x._3, x._4)).collect.toList.map(x => (x._1, s"${raw_path}${entNm}/${entNm}.v${x._1}/${x._3}/${x._2}")).par
            eitFileListCtlBNL.tasksupport = new ForkJoinTaskSupport(new scala.concurrent.forkjoin.ForkJoinPool(50))

            val eitRawFileListCtlBNL = eitFileListCtlBNL.filter(x => filterRawFileExist(x._2))
            Logger.log.info(s"Number of Files exist in Raw with \\u0002\\u000A record delim for $entName from EIT SCAN b/w $startTime and $endTime :" + eitRawFileListCtlBNL.size)
            Logger.log.info(s"List of Files from Raw with \\u0002\\u000A record delim: ${eitRawFileListCtlBNL.mkString}")
            val rddCtlBNL = globalContext.spark.parallelize(eitRawFileListCtlBNL.toList)

            // val eitFileRddCtlBNL = rddCtlBNL.groupByKey.mapValues(_.mkString(",")).cache()

            //Improving performance by using reduceByKey instead of groupByKey

            val eitFileRddCtlBNL = rddCtlBNL.aggregateByKey(ListBuffer.empty[String])(
              (numList, num) => {
                numList += num;
                numList
              },
              (numList1, numList2) => {
                numList1.appendAll(numList2);
                numList1
              })
              .mapValues(_.mkString(",")).cache()

            val sparkConfigCtlBNL = globalContext.spark
            sparkConfigCtlBNL.hadoopConfiguration.set("textinputformat.record.delimiter", "\u0002\u000A")


            eppRdd.join(eitFileRddCtlBNL).collect.foreach { case (schmVer, (schm, fileList)) =>
              saveDataFrame(schmVer, schm, fileList, entName, sparkConfigCtlBNL,extractNm)
            }

            eitVal.unpersist()
            eppRdd.unpersist()
            eitFileRddCtlB.unpersist()
            eitFileRddCtlBNL.unpersist()
            true
          }
          else {
            Logger.log.info(s"Number of Files Captured for $entName from EIT SCAN b/w $startTime and $endTime :" + 0)
            Logger.log.info(s"Since, No Changes Captured for $entName from $startTime to $endTime,datasets will not be generated")
            false
          }
        }
        catch {
          case e: Exception => Logger.log.error(s"Exception while Scanning Files from EIT for $entName" :+ e.getStackTrace.mkString)
            Lib.hbaseEitPut(eitRowKey, "eri", "errCd", "Error Occured While Scanning EIT")
            Lib.hbaseEitPut(eitRowKey, "eri", "errDesc", e.getMessage)
            Lib.hbaseEitPut(eitRowKey, "pi", "incPrcSts", "Failure")
            throw e
        }
      }
      else {
        try {
          Logger.log.info(s"Processing ${entName} Files with Row Delimiter: \\n")
          import org.apache.hadoop.hbase.client.Scan
          val scan = new Scan()
          val filter = new PrefixFilter(Bytes.toBytes(s"${ptnr}-${src}-${entName}-"))
          val filter1 = new SingleColumnValueFilter(Bytes.toBytes("exi"), Bytes.toBytes("ingProcLogSts"), CompareOp.EQUAL, Bytes.toBytes("Success"));
          val filter2 = new SingleColumnValueFilter(Bytes.toBytes("fi"), Bytes.toBytes("iscustrowdelim"), CompareOp.EQUAL, Bytes.toBytes("Yes"));
          val filter3 = new SingleColumnValueFilter(Bytes.toBytes("fi"), Bytes.toBytes("iscustrowdelim"), CompareOp.EQUAL, Bytes.toBytes("No"));
          scan.setCaching(10000)
          scan.setCacheBlocks(false)
          filter1.setFilterIfMissing(true)
          filter2.setFilterIfMissing(true)
          filter3.setFilterIfMissing(true)
          scan.setFilter(filterListAnd(filter, filter1, filterListOr(filter2, filter3)))
          scan.setTimeRange(getTimestamp(startTime), getTimestamp(endTime))
          val eitVal = globalContext.hbaseContext.hbaseRDD(TableName.valueOf(eitTable), scan).cache
          val eitInfo = eitVal.map(tuple => {
            val result = tuple._2
            (Bytes.toString(result.getValue(Bytes.toBytes("fi"), Bytes.toBytes("schmVer"))),
              Bytes.toString(result.getValue(Bytes.toBytes("fi"), Bytes.toBytes("srcFileNm"))),
              Bytes.toString(result.getValue(Bytes.toBytes("fi"), Bytes.toBytes("entprtnfldr"))))
          })
          Logger.log.info(s"Number of Entries Captured for $entName from EIT SCAN b/w $startTime and $endTime :" + eitVal.count())
          if (!eitInfo.isEmpty) {
            val eitFileList = eitInfo.map(x => (x._1, x._2, x._3)).collect.toList.map(x => (x._1, s"${raw_path}${entNm}/${entNm}.v${x._1}/${x._3}/${x._2}"))
            val eitRawFileList = eitFileList.filter(x => filterRawFileExist(x._2))
            Logger.log.info(s"Number of Files exist in Raw with \\n record delim for $entName from EIT SCAN b/w $startTime and $endTime :" + eitRawFileList.length)
            Logger.log.info(s"List of Files from Raw with \\n record delim: ${eitRawFileList.mkString}")
            val eitRdd = globalContext.spark.parallelize(eitRawFileList)
            val eitFileRdd = eitRdd.groupByKey.mapValues(_.mkString(","))
            val eppRdd: org.apache.spark.rdd.RDD[(String, String)] = getEppTabSchm(ptnr, src, entName).cache
            Logger.log.info(s"Number of Schema Versions for ${entName} retrieved from EPP HBase Table:" + eppRdd.count())
            val sparkConfig = globalContext.spark
            eppRdd.join(eitFileRdd).collect.foreach { case (schmVer, (schm, fileList)) =>
              saveDataFrame(schmVer, schm, fileList, entName, sparkConfig,extractNm)
            }
            eitVal.unpersist()
            eppRdd.unpersist()
            true
          } else {
            Logger.log.info(s"Since, No Changes Captured for $entName from $startTime to $endTime, datasets will not be generated")
            false
          }
        }
        catch {
          case e: Exception => Logger.log.info(s"Exception while Scanning Files from EIT for $entName" :+ e.getMessage)
            Lib.hbaseEitPut(eitRowKey, "eri", "errCd", "While Scanning EIT")
            Lib.hbaseEitPut(eitRowKey, "eri", "errDesc", e.getMessage)
            Lib.hbaseEitPut(eitRowKey, "pi", "incPrcSts", "Failure")
            throw e
        }
      }
    }
    catch {
      case e: Exception => Logger.log.error(s"Exception while Scanning Files from EIT for $entNm" :+ e.getStackTrace.mkString)
        Lib.hbaseEitPut(eitRowKey, "eri", "errCd", "Error Occured While Scanning EIT")
        Lib.hbaseEitPut(eitRowKey, "eri", "errDesc", e.getMessage)
        Lib.hbaseEitPut(eitRowKey, "pi", "incPrcSts", "Failure")
        throw e
    }
  }




  def eitTabScanWithParquetFile(patnrCd: String, srcCd: String, entNm: String, incStTime: String, incEndTs: String, isCustDelim: String, eitRowKey: String,extractName: String): Boolean = {
    try {
      val workingDir = globalContext.spark.getConf.get("spark.workingDir")
      rmDirIfExist(s"$workingDir/${entNm.toUpperCase()}")
      val eitTable = globalContext.spark.getConf.get("spark.eitTab")
      val ptnr = s"${patnrCd}".toUpperCase.trim
      val src = s"${srcCd}".toUpperCase.trim
      val mountPath = globalContext.spark.getConf.get("spark.mountPath")
      val raw_path = s"maprfs://$mountPath/${ptnr.toLowerCase}/raw/standard_access/${src.toLowerCase}/data/"
      val entName = s"${entNm}".toUpperCase
      Logger.log.info(s"Retrieving Files for $entName from Raw: $raw_path")
      Logger.log.info(s"Processing Entity:${entName} with patnrCd:${ptnr} srcCd:${src}")
      Logger.log.info(s"Scanning Eit HBase Table: $eitTable")
      val startTime = s"$incStTime"
      val endTime = s"$incEndTs"
      Logger.log.info(s"Capturing if any Changes reflected for $entName from $startTime to $endTime")
      val rowKey = s"${ptnr}-${src}-${entName}"

      {
        try {
          Logger.log.info(s"Processing ${entName} Files with Row Delimiter: \\n")
          import org.apache.hadoop.hbase.client.Scan
          val scan = new Scan()
          val filter = new PrefixFilter(Bytes.toBytes(s"${ptnr}-${src}-${entName}-"))
          val filter1 = new SingleColumnValueFilter(Bytes.toBytes("exi"), Bytes.toBytes("ingProcLogSts"), CompareOp.EQUAL, Bytes.toBytes("Success"));
          //val filter2 = new SingleColumnValueFilter(Bytes.toBytes("fi"), Bytes.toBytes("iscustrowdelim"), CompareOp.EQUAL, Bytes.toBytes("No"));
          scan.setCaching(10000)
          scan.setCacheBlocks(false)
          filter1.setFilterIfMissing(true)
          scan.setFilter(filterListAnd(filter1,filter))
          Logger.log.info(s"start time "+getTimestamp(startTime) +"end time "+ getTimestamp(endTime))
          scan.setTimeRange(getTimestamp(startTime), getTimestamp(endTime))
          val eitVal = globalContext.hbaseContext.hbaseRDD(TableName.valueOf(eitTable), scan).cache
          val eitInfo = eitVal.map(tuple => {
            val result = tuple._2
            (
              (Bytes.toString(result.getValue(Bytes.toBytes("fi"), Bytes.toBytes("ingstdFileNm")))),
              Bytes.toString(result.getValue(Bytes.toBytes("fi"), Bytes.toBytes("entprtnfldr")))
            )
          })
          Logger.log.info(s"Number of Entries Captured for $entName from EIT SCAN b/w $startTime and $endTime :" + eitVal.count() +"starttime="+getTimestamp(startTime)+", endtime="+getTimestamp(endTime))

          if (!eitInfo.isEmpty) {

            /*
            val eitFileList = eitInfo.map(x => (x._1, x._2)).collect.toList.map(x => s"${raw_path}${entNm}/${x._2}/${x._1}")
            Code change for DF2 to DF3
            */

            val eitFileList = eitInfo.map(x => (x._1, x._2)).collect.toList.map(x => s"${raw_path}${entNm}/${x._2}")
            val distinctEitFileList=eitFileList.distinct

            Logger.log.info("count="+distinctEitFileList.size)
            val eitRawFileList=distinctEitFileList.filter(checkFilterList(_))
            val parquetList=eitRawFileList.map(x=>x+"/*.parquet")
            Logger.log.info("filter count="+parquetList.length)

            Logger.log.info(s"Number of Files exist in Raw with \\n record delim for $entName from EIT SCAN b/w $startTime and $endTime :" + parquetList.length)


            val workingDir = globalContext.spark.getConf.get("spark.workingDir")
            Logger.log.info(s"im here before print "+parquetList.length)
            val ts = getTimestamp(endTime)
            //for(filePath <- parquetList) {
            //sqlContext.read.parquet(filePath).write.mode(SaveMode.Append).format("parquet").save(s"$workingDir/${entNm.toUpperCase()}")
            //}
            //sqlContext.read.parquet(parquetList:_*).write.mode(SaveMode.Append).format("parquet").save(s"$workingDir/${entNm.toUpperCase()}")
            val readParquet=sqlContext.read.option("mergeSchema",true).parquet(parquetList:_*)
            Logger.log.info(s"Schema $entName:"+readParquet.printSchema)
            Logger.log.info(s"Working Dir: $workingDir/$extractName/${entNm.toUpperCase()}")
            readParquet.write.mode(SaveMode.Append).format("parquet").save(s"$workingDir/$extractName/${entNm.toUpperCase()}")
            true
          } else {
            Logger.log.info(s"Since, No Changes Captured for $entName from $startTime to $endTime, datasets will not be generated")
            false
          }
        }
        catch {
          case e: Exception => Logger.log.info(s"Exception while Scanning Files from EIT for $entName" :+ e.getMessage)
            e.printStackTrace()
            Lib.hbaseEitPut(eitRowKey, "eri", "errCd", "While Scanning EIT")
            Lib.hbaseEitPut(eitRowKey, "eri", "errDesc", e.getMessage)
            Lib.hbaseEitPut(eitRowKey, "pi", "incPrcSts", "Failure")
            throw e
        }
      }
    }
    catch {
      case e: Exception => Logger.log.error(s"Exception while Scanning Files from EIT for $entNm" :+ e.getStackTrace.mkString)
        Lib.hbaseEitPut(eitRowKey, "eri", "errCd", "Error Occured While Scanning EIT")
        Lib.hbaseEitPut(eitRowKey, "eri", "errDesc", e.getMessage)
        Lib.hbaseEitPut(eitRowKey, "pi", "incPrcSts", "Failure")
        throw e
    }
  }


  def getPkTs(patnrCd: String, srcCd: String, entNm: String): org.apache.spark.rdd.RDD[(String, String)] = {
    try {
      // val snapTab = "/datalake/uhclake/prd/p_mtables/snapshot_config"
      val snapTab = globalContext.spark.getConf.get("spark.snapTab")
      Logger.log.info(s"Scanning SnapshotConfig HBase Table $snapTab for Entity : $entNm for Primary Keys/CDC_TS")
      val scanner = new Scan()
      scanner.setCacheBlocks(false)
      scanner.setCaching(10000)
      val filter1 = new RowFilter(CompareOp.EQUAL, new BinaryComparator(Bytes.toBytes(s"${patnrCd.toUpperCase}-${srcCd.toUpperCase}-${entNm.toUpperCase}")))
      val filter2 = new SingleColumnValueFilter(Bytes.toBytes("ei"), Bytes.toBytes("activeflag"), CompareOp.EQUAL, Bytes.toBytes("Y"));
      scanner.setFilter(filterListAnd(filter1, filter2))
      val snapInfo = globalContext.hbaseContext.hbaseRDD(TableName.valueOf(snapTab), scanner)
      val snapRDD = snapInfo.map(tuple => {
        val result = tuple._2
        (Bytes.toString(result.getValue(Bytes.toBytes("ei"), Bytes.toBytes("modtscol"))),
          Bytes.toString(result.getValue(Bytes.toBytes("ei"), Bytes.toBytes("prikeycols"))))
      })
      snapRDD
    } catch {
      case e: Exception => Logger.log.error(s"Exception while retriving Pk's from Snapshot Config Tab for $entNm" :+ e.getMessage)
        throw e
    }
  }

  def getEntityInfo(rowKey: String): Array[(String, String, String, String, String, String, String, String, String, String, String, String, String)] = {
    try {
      val ihrTab = globalContext.spark.getConf.get("spark.ihrCtlTab")
      Logger.log.info(s"ihrCtlTab ihr_ent_cfg: $ihrTab")
      val scanner = new Scan()
      scanner.setCaching(1000)
      scanner.setCacheBlocks(false)
      val filter1 = new RowFilter(CompareOp.EQUAL, new BinaryComparator(Bytes.toBytes(s"$rowKey")))
      scanner.setFilter(filter1)
      val ihrInfo = globalContext.hbaseContext.hbaseRDD(TableName.valueOf(ihrTab), scanner).cache()
      val ihrEntRDD = ihrInfo.map(tuple => {
        val result = tuple._2
        (Bytes.toString(result.getValue(Bytes.toBytes("ei"), Bytes.toBytes("prtnrCd"))),
          Bytes.toString(result.getValue(Bytes.toBytes("ei"), Bytes.toBytes("srcCd"))),
          Bytes.toString(result.getValue(Bytes.toBytes("ei"), Bytes.toBytes("entNm"))),
          Bytes.toString(result.getValue(Bytes.toBytes("is"), Bytes.toBytes("lastRnTs"))),
          Bytes.toString(result.getValue(Bytes.toBytes("ei"), Bytes.toBytes("isCustDelim"))),
          Bytes.toString(result.getValue(Bytes.toBytes("ei"), Bytes.toBytes("outFileDelim"))),
          Bytes.toString(result.getValue(Bytes.toBytes("ei"), Bytes.toBytes("outFileNm"))),
          Bytes.toString(result.getValue(Bytes.toBytes("ei"), Bytes.toBytes("outFileExt"))),
          Bytes.toString(result.getValue(Bytes.toBytes("ei"), Bytes.toBytes("nasLoc"))),
          Bytes.toString(result.getValue(Bytes.toBytes("ei"), Bytes.toBytes("quoteCol"))),
          Bytes.toString(result.getValue(Bytes.toBytes("ei"), Bytes.toBytes("isJoin"))),
          Bytes.toString(result.getValue(Bytes.toBytes("ei"), Bytes.toBytes("isNasLoc"))),
          Bytes.toString(result.getValue(Bytes.toBytes("ei"), Bytes.toBytes("isDrivers"))))
      })

      if (ihrEntRDD.isEmpty()) {
        Logger.log.info(s"Please Provide Appropriate RowKey / Check ihr_ent_cfg table Properties for $rowKey properly")
        ihrEntRDD.collect()
      }
      else {
        ihrEntRDD.collect()
      }
    } catch {
      case e: Exception => Logger.log.error(s"Exception while getting Configuration from ihr_entity_info Tab" :+ e.getMessage)
        throw e
    }
  }


  def getSqlQry(rowKey: String): String = {
    try {
      val ihrTab = globalContext.spark.getConf.get("spark.ihrCtlTab")
      Logger.log.info(s"Scanning ihrCtlTab:$ihrTab")
      val scanner = new Scan()
      scanner.setCaching(10000)
      scanner.setCacheBlocks(false)
      val filter1 = new RowFilter(CompareOp.EQUAL, new BinaryComparator(Bytes.toBytes(s"$rowKey")))
      scanner.setFilter(filter1)
      val ihrInfo = globalContext.hbaseContext.hbaseRDD(TableName.valueOf(ihrTab), scanner)
      val eitRDD = ihrInfo.map(tuple => {
        val result = tuple._2
        (Bytes.toString(result.getValue(Bytes.toBytes("ei"), Bytes.toBytes("sqlQry"))))
      })
      eitRDD.collect.mkString
    } catch {
      case e: Exception => Logger.log.error(s"Exception while getting SqlQry from ihr_entity_info Tab" :+ e.getStackTrace.toString)
        throw e
    }
  }


  def hbasePut(rowKey: String, colFm: String, colNm: String, value: String): Unit = {
    try {
      val p = new Put(s"$rowKey".getBytes())
      p.addColumn(s"$colFm".getBytes(), s"$colNm".getBytes(), s"$value".getBytes())
      globalContext.ihrCtlTab.put(p)
    } catch {
      case e: Exception => Logger.log.error("Exception at HBase Put Commands at IHR_enttiy_info" :+ e.getStackTrace.toString)
        throw e
    }
  }

  def hbaseEitPut(eitRowKey: String, colFm: String, colNm: String, value: String): Unit = {
    try {
      val p = new Put(s"$eitRowKey".getBytes())
      p.addColumn(s"$colFm".getBytes(), s"$colNm".getBytes(), s"$value".getBytes())
      globalContext.ihrEitTab.put(p)
    } catch {
      case e: Exception => Logger.log.error("Exception at HBase EIT Put Commands at IHR_enttiy_info IHR_ADT_DTL" :+ e.getStackTrace.mkString)
        throw e
    }
  }

  def rmDirIfExist(dir: String): Unit = {
    try {
      if (globalContext.fs.exists(new Path(s"$dir"))) {
        globalContext.fs.delete(new Path(dir), true)
      }
      else {
        Logger.log.info(s"Working Dir: $dir doesn't exist, Please check for Errors.")
      }
    } catch {
      case e: Exception => Logger.log.error("Exception at HBase Put Commands at IHR_enttiy_info" :+ e.getStackTrace.toString)
        throw e
    }
  }

  def filterRawFileExist(filePath: String): Boolean = {
    globalContext.fs.exists(new Path(s"$filePath"))
  }

  def checkFilterList(filePath: String): Boolean = {
    val sourcePath=filePath
    val hadoopConf = new org.apache.hadoop.conf.Configuration()
    val hdfs = org.apache.hadoop.fs.FileSystem.get(new java.net.URI("dbslp0564"), hadoopConf)
    val source = new org.apache.hadoop.fs.Path(sourcePath)
    val sourceFiles = hdfs.listFiles(source, true)
    sourceFiles.hasNext
  }
  def merge(srcPath: String, dstPath: String): Boolean = {
    val hdfs = FileSystem.get(globalContext.spark.hadoopConfiguration)
    FileUtil.copyMerge(hdfs, new Path(srcPath), hdfs, new Path(dstPath), false, globalContext.spark.hadoopConfiguration, null)
  }

  def maprfsToNas(userInfo: String, unixLoc: String, nasLoc: String, eitRowKey: String): Boolean = {
    try {
      // val userDetails = "ms.ds.uhc.com;rkodur:*********"
      val userDetails = s"$userInfo"
      val auth = new NtlmPasswordAuthentication(userDetails)
      //val destPath = smb://NAS01042pn/homedirs/rkodur/DF2KT/$fileName
      //val sFile = new SmbFile("smb://NAS01042pn/homedirs/rkodur/DF2KT/HelloSam.txt", auth);
      val sFile = new SmbFile(s"$nasLoc", auth)
      val sfos = new SmbFileOutputStream(sFile)
      // val fileInputStream: InputStream = new java.io.FileInputStream(new File("/mapr/datalake/uhclake/tst/developer/rkodur1/rkodur/scm/Data/DBO/CONV_FOLDFOLD/HIST_SCM_DBO_CONV_FOLDFOLD_20171206T191112.dat"))
      val fileInputStream: InputStream = new java.io.FileInputStream(new File(s"$unixLoc"))
      transfer(fileInputStream, sfos, eitRowKey)
      Logger.log.info(s"Transfer Complete to NAS================>")
      true
    } catch {
      case e: Exception => Logger.log.error("Exception while transfering file from MFS to NAS(Chill) Drive" + e.getMessage)
        Lib.hbaseEitPut(eitRowKey, "eri", "errCd", "Exception While transferring file from MFS to NAS(Chill) Drive")
        Lib.hbaseEitPut(eitRowKey, "eri", "errDesc", e.getMessage)
        Lib.hbaseEitPut(eitRowKey, "pi", "incPrcSts", "Failure")
        false
    }
  }

  def transfer(in: InputStream, out: SmbFileOutputStream, eitRowKey: String): Unit = {
    try {
      val buf = new Array[Byte](1024 * 1024 * 61)
      var length = 0
      while (length != -1) {
        length = in.read(buf)
        if (length > 0) {
          out.write(buf, 0, length)
        }
      }
    }
    catch {
      case e: Exception => Logger.log.error("Exception while transfer file from MFS to NAS(Chill) Drive" + e.getStackTrace.toString)
        Lib.hbaseEitPut(eitRowKey, "eri", "errCd", "Exception While transfering file from MFS to NAS(Chill) Drive")
        Lib.hbaseEitPut(eitRowKey, "eri", "errDesc", e.getMessage)
        Lib.hbaseEitPut(eitRowKey, "pi", "incPrcSts", "Failure")
    }
    finally {
      in.close
      out.close
    }
  }

  def getType(lastRnTime: String, currTime: String): String = {
    val format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
    val days: Long = ((format.parse(lastRnTime).getTime - format.parse(currTime).getTime) / 86400000)
    if (days > 31) {
      "FULL"
    }
    else {
      "INCR"
    }
  }

  def createCtlFileToNas(nasSrcUsrInfo: String, eitRowKey: String, src: String, entityNm: String, RecordCount: String, lastRnTime: String, incEndTs: String, etlLandLoc: String, outFileExt: String, outFileDelim: String, outLoc: String, outCtlFileNm: String): Boolean = {
    var buf = scala.collection.mutable.ArrayBuffer[String]()
    buf += s"SourceName=$src"
    buf += s"entityNm=$entityNm"
    buf += s"RecordCount=$RecordCount"
    buf += s"ExtractDateTime=$incEndTs"
    buf += s"ETLLandingDirectory=$etlLandLoc"
    buf += s"FileLoadType=${getType(incEndTs, lastRnTime)}"
    buf += "ExtractStatus=Success"
    buf += s"DataFileExtension=$outFileExt"
    buf += "FileFormatType=delimited"
    buf += s"RecordDelimiter='\\n'"
    buf += s"FieldDielimiter=$outFileDelim"
    val ctlFileBody = buf.mkString("\n")
    Logger.log.info("Ctl File Information:\n" + ctlFileBody)
    val writer = new PrintWriter(new File(s"$outLoc/$outCtlFileNm"))
    writer.write(ctlFileBody)
    writer.close
    maprfsToNas(nasSrcUsrInfo, s"$outLoc/$outCtlFileNm", s"$etlLandLoc/$outCtlFileNm", eitRowKey)
  }

  def createCtlFileToHdfs(src: String, entityNm: String, RecordCount: String, lastRnTime: String, incEndTs: String, etlLandLoc: String, outFileExt: String, outFileDelim: String, outLoc: String, outCtlFileNm: String): Unit = {
    try {
      var buf = scala.collection.mutable.ArrayBuffer[String]()
      buf += s"SourceName=$src"
      buf += s"entityNm=$entityNm"
      buf += s"RecordCount=$RecordCount"
      buf += s"ExtractDateTime=$incEndTs"
      buf += s"ETLLandingDirectory=$etlLandLoc"
      buf += s"FileLoadType=${getType(incEndTs, lastRnTime)}"
      buf += "ExtractStatus=Success"
      buf += s"DataFileExtension=$outFileExt"
      buf += "FileFormatType=delimited"
      buf += s"RecordDelimiter='\\n'"
      buf += s"FieldDielimiter=$outFileDelim"
      val ctlFileBody = buf.mkString("\n")
      Logger.log.info("Ctl File Information:\n" + ctlFileBody)
      val writer = new PrintWriter(new File(s"$outLoc/$outCtlFileNm"))
      writer.write(ctlFileBody)
      writer.close
    } catch {
      case e: Exception => Logger.log.error("Exception while Creating Control File" + e.getStackTrace.toString)
    }
  }


  def decrypt(key: Array[Byte], encryptedValue: String): String = {
    val cipher: Cipher = Cipher.getInstance("AES/ECB/PKCS5PADDING")
    val secretKeySpec = new SecretKeySpec(key, "AES")
    cipher.init(Cipher.DECRYPT_MODE, secretKeySpec)
    new String(cipher.doFinal(Base64.decodeBase64(encryptedValue)))
  }

  def processFrmWrk(srcCd: String, patnrCd: String, ent: String, workingDir: String, eitRowKey: String, lastRunSts: String,extractNm: String): Unit = {
    try {
      Logger.log.info(s"Captured Incremental Extract for ${ent}")
      Logger.log.info(s"Working Directory path for Incremental extract: $workingDir/$extractNm")
      Logger.log.info(s"Merging Schema for $ent from $workingDir/$extractNm/$ent")
      val mergeDF = sqlContext.read.option("mergeSchema", true).parquet(s"$workingDir/$extractNm/$ent").persist(org.apache.spark.api.java.StorageLevels.MEMORY_AND_DISK_SER)
      Logger.log.info(s"Merge Schema Record Count for $ent from $lastRunSts to Current Date:" + mergeDF.count)
      Logger.log.info(s"Retrieving Primary Keys/CDC_TS Cols from Snapshot Config Table")
      val snapRDD = Lib.getPkTs(patnrCd, srcCd, ent).cache()
      if (!snapRDD.isEmpty()) {
        val cdc_ts = snapRDD.map(_._1).collect.mkString
        Logger.log.info(s"CDC_TS Column for $ent: $cdc_ts")
        val primaryKeys = snapRDD.map(_._2.split(";")).collect.flatten
        Logger.log.info(s"Primary Key Columns for $ent: ${primaryKeys.mkString}")
        snapRDD.unpersist()
        //Added to Test CDC_TS get filter TimeStamp
        val mergeDF1 = mergeDF.filter(col(s"$cdc_ts") >= s"$lastRunSts").persist(org.apache.spark.api.java.StorageLevels.MEMORY_AND_DISK_SER)
        val userWindow = Window.partitionBy(concat_ws("-", primaryKeys.map(c => col(c)): _*), lit("")).orderBy(col(s"$cdc_ts").desc)
        val dedupDF = mergeDF1.withColumn("rank", row_number().over(userWindow)).where(col("rank") === 1).drop("rank").persist(org.apache.spark.api.java.StorageLevels.MEMORY_AND_DISK_SER)
        val dedupCnt = dedupDF.count()
        Logger.log.info(s"Number of Records Extracted for $ent from $lastRunSts to Current Date with Dedup Logic:" + dedupCnt)
        dedupDF.createOrReplaceTempView(s"${ent}")
        Logger.log.info(s"Created Temp Table for $ent: ${ent} for Select Query")
        dedupDF.unpersist
      }
      else {
        Logger.log.info(s"Snapshot PrimaryKeys / CDC Timestamp not found for $ent, Please Check HBase Snapshot_config Table")
        Lib.hbaseEitPut(eitRowKey, "eri", "errCd", " Snapshot Primary / Timestamp")
        Lib.hbaseEitPut(eitRowKey, "eri", "errDesc", "Snapshot PrimaryKeys / CDC Timestamp not found, Please Check HBase Snapshot_config Table")
        Lib.hbaseEitPut(eitRowKey, "pi", "incPrcSts", "Failure")
        val prcEndTm = Lib.getCurrentTimeFormat
        Lib.hbaseEitPut(eitRowKey, "pi", "prcEndTm", prcEndTm)
        Logger.log.info(s"Incremental Extract Process End Time: $prcEndTm")
        globalContext.spark.stop()
      }
    } catch {
      case e: Exception => Logger.log.error("Exception while processing working Area" + e.getMessage)
        throw e
    }
  }
  def driverProcessFrmWrk(srcCd: String, patnrCd: String, ent: String, workingDir: String, eitRowKey: String, lastRunSts: String): Unit ={
    try {
      Logger.log.info(s"Captured Incremental Extract for ${ent}")
      Logger.log.info(s"Working Directory path for Incremental extract: $workingDir")
      Logger.log.info(s"Merging Schema for $ent from $workingDir/$ent")
      val mergeDF = sqlContext.read.option("mergeSchema", true).parquet(s"$workingDir/$ent").persist(org.apache.spark.api.java.StorageLevels.MEMORY_AND_DISK_SER)
      Logger.log.info(s"Merge Schema Record Count for $ent from $lastRunSts to Current Date:" + mergeDF.count)
      Logger.log.info(s"Retrieving Primary Keys/CDC_TS Cols from Snapshot Config Table")
      val snapRDD = Lib.getPkTs(patnrCd, srcCd, ent).cache()
      if (!snapRDD.isEmpty()) {
        val cdc_ts = snapRDD.map(_._1).collect.mkString
        Logger.log.info(s"CDC_TS Column for $ent: $cdc_ts")
        val primaryKeys = snapRDD.map(_._2.split(";")).collect.flatten
        Logger.log.info(s"Primary Key Columns for $ent: ${primaryKeys.mkString}")
        snapRDD.unpersist()
        //Added to Test CDC_TS get filter TimeStamp
        val mergeDF1 = mergeDF.filter(col(s"$cdc_ts") >= s"$lastRunSts").persist(org.apache.spark.api.java.StorageLevels.MEMORY_AND_DISK_SER)
        val userWindow = Window.partitionBy(concat_ws("-", primaryKeys.map(c => col(c)): _*), lit("")).orderBy(col(s"$cdc_ts").desc)
        val dedupDF = mergeDF1.withColumn("rank", row_number().over(userWindow)).where(col("rank") === 1).drop("rank").persist(org.apache.spark.api.java.StorageLevels.MEMORY_AND_DISK_SER)
        val dedupCnt = dedupDF.count()
        Logger.log.info(s"Number of Records Extracted for $ent from $lastRunSts to Current Date with Dedup Logic:" + dedupCnt)
        val IncrementalTableName="Incremental_"+ent
        dedupDF.createOrReplaceTempView(s"$IncrementalTableName")
        Logger.log.info(s"Created Temp Table for $ent: ${IncrementalTableName} for incremental Extract")
        dedupDF.unpersist
        mergeDF.unpersist
        mergeDF1.unpersist
      }
      else {
        Logger.log.info(s"Snapshot PrimaryKeys / CDC Timestamp not found for $ent, Please Check HBase Snapshot_config Table")
        Lib.hbaseEitPut(eitRowKey, "eri", "errCd", " Snapshot Primary / Timestamp")
        Lib.hbaseEitPut(eitRowKey, "eri", "errDesc", "Snapshot PrimaryKeys / CDC Timestamp not found, Please Check HBase Snapshot_config Table")
        Lib.hbaseEitPut(eitRowKey, "pi", "incPrcSts", "Failure")
        val prcEndTm = Lib.getCurrentTimeFormat
        Lib.hbaseEitPut(eitRowKey, "pi", "prcEndTm", prcEndTm)
        Logger.log.info(s"Incremental Extract Process End Time: $prcEndTm")
        globalContext.spark.stop()
      }
    } catch {
      case e: Exception => Logger.log.error("Exception while processing working Area" + e.getMessage)
        throw e
    }
  }
  def driverTableProcess(srcCd: String, patnrCd: String, ent: String, workingDir: String, eitRowKey: String, lastRunSts: String,driverTabList: List[String],columns:String):Unit={
    Logger.log.info("Captured incremantal extract for: "+driverTabList)
    Logger.log.info(s"Working Directory path for Incremental extract: $workingDir")
    Logger.log.info(s"Merging Schema for $ent from $workingDir/$ent")
    val columnNames=columns.split(',').toList
    var driverTable=sqlContext.read.table("Incremental_"+driverTabList(0)).select(columnNames.map(col):_*)
    val RemainingDriverTables=driverTabList.drop(1)
    RemainingDriverTables.foreach { ent =>
      driverTable.union(sqlContext.read.table(s"Incremental_$ent").select(columnNames.map(col):_*))
    }
    Logger.log.info("Count after union the driving tables:"+ driverTable.count)
    val mergeDF = sqlContext.read.option("mergeSchema", true).parquet(s"$workingDir/$ent").persist(org.apache.spark.api.java.StorageLevels.MEMORY_AND_DISK_SER)
    val snapRDD = Lib.getPkTs(patnrCd, srcCd, ent).cache()
    if (!snapRDD.isEmpty()) {
      val cdc_ts = snapRDD.map(_._1).collect.mkString
      Logger.log.info(s"CDC_TS Column for $ent: $cdc_ts")
      val primaryKeys = snapRDD.map(_._2.split(";")).collect.flatten
      Logger.log.info(s"Primary Key Columns for $ent: ${primaryKeys.mkString}")
      snapRDD.unpersist()
      val joinDF=mergeDF.alias("df1").join(driverTable.alias("df2"), mergeDF(columnNames(0))===driverTable(columnNames(0)) &&
        mergeDF(columnNames(1))===driverTable(columnNames(1)) &&
        mergeDF(columnNames(2))===driverTable(columnNames(2)) &&
        mergeDF(columnNames(3))===driverTable(columnNames(3)),"inner").select("df1.*")
      val userWindow = Window.partitionBy(concat_ws("-", primaryKeys.map(c => col(c)): _*), lit("")).orderBy(col(s"$cdc_ts").desc)
      val dedupDF = joinDF.withColumn("rank", row_number().over(userWindow)).where(col("rank") === 1).drop("rank").persist(org.apache.spark.api.java.StorageLevels.MEMORY_AND_DISK_SER)
      val dedupCnt = dedupDF.count()
      Logger.log.info(s"Number of Records Extracted for $ent from $lastRunSts to Current Date with Dedup Logic:" + dedupCnt)
      dedupDF.createOrReplaceTempView(s"$ent")
      Logger.log.info(s"Created Temp Table for $ent: ${ent} for Select Query")
      dedupDF.unpersist
      mergeDF.unpersist
      RemainingDriverTables.foreach { ent =>
        driverTableCreation(srcCd,patnrCd,ent,workingDir,eitRowKey,lastRunSts,mergeDF,columns)
      }
    }
    else {
      Logger.log.info(s"Snapshot PrimaryKeys / CDC Timestamp not found for $ent, Please Check HBase Snapshot_config Table")
      Lib.hbaseEitPut(eitRowKey, "eri", "errCd", " Snapshot Primary / Timestamp")
      Lib.hbaseEitPut(eitRowKey, "eri", "errDesc", "Snapshot PrimaryKeys / CDC Timestamp not found, Please Check HBase Snapshot_config Table")
      Lib.hbaseEitPut(eitRowKey, "pi", "incPrcSts", "Failure")
      val prcEndTm = Lib.getCurrentTimeFormat
      Lib.hbaseEitPut(eitRowKey, "pi", "prcEndTm", prcEndTm)
      Logger.log.info(s"Incremental Extract Process End Time: $prcEndTm")
      globalContext.spark.stop()
    }
  }
  def driverTableCreation(srcCd: String, patnrCd: String, ent: String, workingDir: String, eitRowKey: String, lastRunSts: String, drivingTable: DataFrame, columns:String): Unit ={
    Logger.log.info(s"Merging Schema for $ent from $workingDir/$ent")
    val mergeDF = sqlContext.read.option("mergeSchema", true).parquet(s"$workingDir/$ent").persist(org.apache.spark.api.java.StorageLevels.MEMORY_AND_DISK_SER)
    val snapRDD = Lib.getPkTs(patnrCd, srcCd, ent).cache()
    val columnNames=columns.split(',').toList
    if (!snapRDD.isEmpty()) {
      val cdc_ts = snapRDD.map(_._1).collect.mkString
      Logger.log.info(s"CDC_TS Column for $ent: $cdc_ts")
      val primaryKeys = snapRDD.map(_._2.split(";")).collect.flatten
      Logger.log.info(s"Primary Key Columns for $ent: ${primaryKeys.mkString}")
      snapRDD.unpersist()
      val joinDF=mergeDF.alias("df1").join(drivingTable.alias("df2"), mergeDF(columnNames(0))===drivingTable(columnNames(0)) &&
        mergeDF(columnNames(1))===drivingTable(columnNames(1)) &&
        mergeDF(columnNames(2))===drivingTable(columnNames(2)) &&
        mergeDF(columnNames(3))===drivingTable(columnNames(3)),"inner").select("df1.*")
      val userWindow = Window.partitionBy(concat_ws("-", primaryKeys.map(c => col(c)): _*), lit("")).orderBy(col(s"$cdc_ts").desc)
      val dedupDF = joinDF.withColumn("rank", row_number().over(userWindow)).where(col("rank") === 1).drop("rank").persist(org.apache.spark.api.java.StorageLevels.MEMORY_AND_DISK_SER)
      val dedupCnt = dedupDF.count()
      Logger.log.info(s"Number of Records Extracted for $ent from $lastRunSts to Current Date with Dedup Logic:" + dedupCnt)
      dedupDF.createOrReplaceTempView(s"$ent")
      Logger.log.info(s"Created Temp Table for $ent: ${ent} for Select Query")
      dedupDF.unpersist
      mergeDF.unpersist
    }
    else {
      Logger.log.info(s"Snapshot PrimaryKeys / CDC Timestamp not found for $ent, Please Check HBase Snapshot_config Table")
      Lib.hbaseEitPut(eitRowKey, "eri", "errCd", " Snapshot Primary / Timestamp")
      Lib.hbaseEitPut(eitRowKey, "eri", "errDesc", "Snapshot PrimaryKeys / CDC Timestamp not found, Please Check HBase Snapshot_config Table")
      Lib.hbaseEitPut(eitRowKey, "pi", "incPrcSts", "Failure")
      val prcEndTm = Lib.getCurrentTimeFormat
      Lib.hbaseEitPut(eitRowKey, "pi", "prcEndTm", prcEndTm)
      Logger.log.info(s"Incremental Extract Process End Time: $prcEndTm")
      globalContext.spark.stop()
    }
  }
}
