package com.optum.ihrcentri.LabGalaxyFiles

import java.text.SimpleDateFormat
import java.util.Calendar
import com.optum.ihrcentri.Common._
import scala.collection.parallel.ForkJoinTaskSupport


object GalaxyFiles {

  val format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
  val starTimeStamp=format.format(Calendar.getInstance().getTime)

  def main(args: Array[String]): Unit = {

    val globalContext = new GlobalContext
    val functions = new CommonFunctions
    val mainClass=new RunJob
    val reports=new ReportGeneration
    val numThreads: Int = globalContext.threads.toInt

    if (args.length != 1) {
      Logger.log.info("Please Pass RowKey \"PATNRCD-SRCCD-ENTITYNAME\"")
      Logger.log.info("===> Since No RowKey is Passed ending Galaxy Lab results extract <===")
      reports.HBaseAuditFailureReport("No-Row-key-LabResults","No-Row-key-LabResults", "2", "Since No RowKey is Passed ending Galaxy Lab results extract")
      globalContext.spark.stop()
    } else {
      val rowKey = args(0).toUpperCase().trim
      val Audit_RowKey = rowKey + "-" + s"${java.util.UUID.randomUUID.toString}"
      val entNm = rowKey.split('-')(2)
      try {
        Logger.log.info("=================> Lab Results Galaxy Files History load started <==========================")
        Logger.log.info("****************This job is inComplete check the script**********")
          var inboundPath=""
          if(entNm.equals("QUESTDIA")){
            inboundPath=globalContext.quest_InboundPath
          }else{
            inboundPath=globalContext.LabCorp_InboundPath
          }
        val partDate="test"
        val historyList = functions.historyList(inboundPath,partDate ).par

        historyList.tasksupport = new ForkJoinTaskSupport(new scala.concurrent.forkjoin.ForkJoinPool(numThreads))

        Logger.log.info(s"Total FileList: " + historyList.size)
        Logger.log.info(s"List of Files" + historyList)
        Logger.log.info("=================> Lab Results Aco_Member Match started <==========================")
        Logger.log.info("Process Start time: " + starTimeStamp)

        val stgOutpath = globalContext.stgdir + entNm + "/stgoutdir/"
        val stgLogDir = globalContext.stgdir + entNm + "/stglogdir/"

        val stgPath = stgOutpath.replace("/mapr/", "hdfs:///")
        val stgLogPath = stgLogDir.replace("/mapr/", "hdfs:///")

        val outRPath = globalContext.outpath.replace("/mapr/", "hdfs:///")
        val templogdir = globalContext.logDir.replace("/mapr/", "hdfs:///")

        functions.cleanOutputPath(globalContext.outputNodeAddress, stgPath)
        functions.cleanOutputPath(globalContext.outputNodeAddress, stgLogPath)

        val acoDf = functions.readAcomembers(globalContext.sparkS, globalContext.aco_table)

        for (file2 <- historyList){
          Logger.log.info("Current Processing file: " + file2)
          val inputfile = file2.replace("/mapr/", "hdfs:///")
          Thread.sleep(1000)
          mainClass.labExecution(globalContext.sparkS,acoDf,inputfile,stgPath,entNm,stgLogPath,globalContext.outputNodeAddress)
        }
        Logger.log.info("Moving files from stage outbound to Actual outbound path")
        functions.moveTxtFile(stgPath, outRPath + "/" + entNm + "/")

        Logger.log.info("Moving files from stage log dir to actual log dir")
        functions.moveCSVFile(stgLogPath, templogdir + "/" + entNm + "/")

        Logger.log.info("Generating the Success Audit Report")
        reports.HbaseAuditSuccessReport(rowKey,Audit_RowKey,mainClass.totalMatches.toString,mainClass.totalMissMatches.toString)
        Logger.log.info("Records with matches: " + mainClass.totalMatches)
        Logger.log.info("Records without matches: " + mainClass.totalMissMatches)
        Logger.log.info("==============> Lab Results Aco_member match completed successfully <===============")

      }catch {
        case e: Exception => Logger.log.info("Errored: " + e.getMessage)
          reports.HBaseAuditFailureReport(rowKey,Audit_RowKey,e.getLocalizedMessage,e.getMessage)
          globalContext.spark.stop()
          System.exit(1)
      }
    }
  }
}
