package com.optum.ihrcentri.LabGalaxyHistoryFile

import com.optum.ihrcentri.Common._
import java.text.SimpleDateFormat
import java.util.Calendar
import org.apache.spark.storage.StorageLevel

/**
  * Created by mmallam2 on May,2018
  *
  **/

object RunJob {
  def main(args: Array[String]): Unit = {

    val globalContext = new GlobalContext
    val functions = new CommonFunctions
    val transformations=new Transformations

    val format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
    val starTimeStamp = format.format(Calendar.getInstance().getTime())
    Logger.log.info("=============> Starting IHR Lab Results Framework <=============")
    if (args.length != 2) {
      Logger.log.info("Please Pass RowKey \"PATNRCD-SRCCD-ENTITYNAME\"  and Filter_File for IHR Incremental extract")
      Logger.log.info("===> Since No RowKey and Filter File not Passed ending Ihr LabResults extract <===")
      ReportGeneration.HBaseAuditFailureReport("No-Row-key-LabResults", "No-Row-key-LabResults", "2", "Since No RowKey is Passed ending IHR Incremental extract", "starTimeStamp")
      globalContext.spark.stop()
    } else {
      val rowKey = args(0).toUpperCase().trim
      val FilterFile=args(1)
      val auditRowKey = rowKey + "-" + s"${java.util.UUID.randomUUID.toString}"
      try {
        Logger.log.info("==============> Extracting the data from Lab Flatten tables with Filter on ACO_ROSTER and Creating the GALAXY OUTBOUND FILE <=============== ")
        val rptCfgScan = Lib.getEntityInfo(rowKey)
        rptCfgScan.foreach { case (patnrCd, srcCd, entNm, lastRunSts, outFileNm, outFileExt, isFilter) =>

          val stgOutpath = globalContext.stgdir + entNm + "/stgoutdir/"
          val stgPath = stgOutpath.replace("/mapr/", "hdfs:///")

          val stgLogDir = globalContext.stgdir + entNm + "/stglogdir/"
          val stgLogPath = stgLogDir.replace("/mapr/", "hdfs:///")

          functions.cleanOutputPath(globalContext.outputNodeAddress, stgLogPath)
          functions.cleanOutputPath(globalContext.outputNodeAddress, stgPath)

          val logdir = globalContext.logDir.replace("/mapr/", "hdfs:///")
          val outPath = globalContext.outpath.replace("/mapr/", "hdfs:///")

          val acofile = globalContext.aco_file
          val aco_members = "aco_roster"
          val msh_table = globalContext.msh_table
          val db = globalContext.dbName
          val spark = globalContext.sparkS
          val mshDF = spark.read.table(s"$db.$msh_table")
          val msh_pid_table = s"$db.$msh_table"
          val hl7_members = "hl7_member"

          var messagesCount=""
          if (entNm.equals("QUESTDIA")) {
            Logger.log.info("Filtering the Quest file for Service date : 2017-04-28")
            val questCount = spark.sql(s"""select * from $msh_pid_table where SOURCE_CODE="GALAXY" and domain="QUESTDIA" and cast(from_unixtime(unix_timestamp(split(HL7_MESSAGE,"\\\\|")[2], 'yyyy-MM-dd')) as Timestamp) < cast(from_unixtime(unix_timestamp('2017-04-29' , 'yyyy-MM-dd')) as Timestamp)""")
            messagesCount=questCount.count.toString
            Logger.log.info("No. of records received for QUESTDIA until 2017-04-28 : " + messagesCount)
            questCount.createOrReplaceTempView(s"$hl7_members")
          } else if (entNm.equals("LABCORPDIA")) {
            Logger.log.info("Filtering the LabCorp file for Service date : 2017-04-22")
            val labCount = spark.sql(s"""select * from $msh_pid_table where SOURCE_CODE="GALAXY" and domain="LABCORPDIA" and cast(from_unixtime(unix_timestamp(split(HL7_MESSAGE,"\\\\|")[2], 'yyyy-MM-dd')) as Timestamp) < cast(from_unixtime(unix_timestamp('2017-04-23' , 'yyyy-MM-dd')) as Timestamp)""")
            messagesCount=labCount.count().toString
            Logger.log.info("No. of records received for LabCorp until 2017-04-22 : " + messagesCount)
            labCount.createOrReplaceTempView(s"$hl7_members")
          }
          val messages = spark.sql(s"select * from $hl7_members")

          if(isFilter.equalsIgnoreCase("Yes")) {
            if(FilterFile.equalsIgnoreCase("ACO")) {
              Logger.log.info("Reading Aco Roster file")
              val acodf = transformations.readAcoFile(acofile, spark).cache()
              Logger.log.info("Member Count in Aco Roster file:" + acodf.count())
              acodf.createOrReplaceTempView(s"$aco_members")
            }else if(FilterFile.equalsIgnoreCase("EI")) {
              Logger.log.info("Reading the EI files")
              val dirPath = globalContext.spark.getConf.get("spark.eiDirectory")
              val UnionDF = transformations.unionDirectoryList(functions.ListDirFiles(dirPath), spark)
              val ei_members = transformations.GalaxyacoFields(UnionDF).cache()
              val memCount = ei_members.count()
              Logger.log.info("Member Count from EI Files:" + memCount)
              ei_members.createOrReplaceTempView(s"$aco_members")
            }
            Logger.log.info("Filtering against the Aco roster file")
            val matchedMembers = spark.sql(s"""select match.10_MESSAGE_CNTRL_ID_ST as 10_MESSAGE_CNTRL_ID_ST,match.5_2_PATIENT_NAME_XPN_GIVEN_NM_ST as 5_2_PATIENT_NAME_XPN_GIVEN_NM_ST,match.5_1_PATIENT_NAME_XPN_FAM_NM_FN as 5_1_PATIENT_NAME_XPN_FAM_NM_FN,match.7_DATE_OF_BIRTH_TS as 7_DATE_OF_BIRTH_TS,match.8_ADMINISTRATIVE_SEX_IS as 8_ADMINISTRATIVE_SEX_IS,match.HL7_MESSAGE as HL7_MESSAGE from (select hardmatch.* from (select h.* from $hl7_members h join $aco_members a on trim(lpad(h.GALAXY_CDB_SUBSCRIBER_ID,15,'0')) = trim(lpad(a.subscriber_id,15,'0')) union select h.* from $hl7_members h join $aco_members a on trim(lpad(h.GALAXY_CDB_MEMBER_ID,15,'0')) = trim(lpad(a.alt_id,15,'0')))hardmatch union select softmatch.* from (select h.* from $hl7_members h join $aco_members a on substr(h.5_2_PATIENT_NAME_XPN_GIVEN_NM_ST,1,3)=substr(a.member_first_name,1,3) and trim(substr(h.5_1_PATIENT_NAME_XPN_FAM_NM_FN,1,4))=trim(substr(a.member_last_name,1,4)) and h.7_DATE_OF_BIRTH_TS=a.member_birth_date and h.8_ADMINISTRATIVE_SEX_IS=a.member_gender union select h.* from $hl7_members h join $aco_members a on substr(h.5_2_PATIENT_NAME_XPN_GIVEN_NM_ST,1,3)=substr(a.member_first_name,1,3) and trim(substr(h.5_1_PATIENT_NAME_XPN_FAM_NM_FN,1,4))=trim(substr(a.member_last_name,1,4)) and 7_DATE_OF_BIRTH_TS=a.member_birth_date union select h.* from $hl7_members h join $aco_members a on trim(substr(h.5_1_PATIENT_NAME_XPN_FAM_NM_FN,1,4))=trim(substr(a.member_last_name,1,4)) and h.7_DATE_OF_BIRTH_TS=a.member_birth_date and h.8_ADMINISTRATIVE_SEX_IS=a.member_gender union select h.* from $hl7_members h join $aco_members a on substr(h.5_2_PATIENT_NAME_XPN_GIVEN_NM_ST,1,3)=substr(a.member_first_name,1,3) and h.7_DATE_OF_BIRTH_TS=a.member_birth_date and h.8_ADMINISTRATIVE_SEX_IS=a.member_gender union select h.* from $hl7_members h join $aco_members a on substr(h.5_2_PATIENT_NAME_XPN_GIVEN_NM_ST,1,3)=substr(a.member_first_name,1,3) and trim(substr(h.5_1_PATIENT_NAME_XPN_FAM_NM_FN,1,4))=trim(substr(a.member_last_name,1,4)) and h.8_ADMINISTRATIVE_SEX_IS=a.member_gender)softmatch)match""").persist(StorageLevel.MEMORY_AND_DISK_2)
            val matchedCount = matchedMembers.count.toString
            matchedMembers.createOrReplaceTempView("MatchedMembers")
            transformations.galaxyCreateOutBoundFile(spark, matchedMembers.select("HL7_Message"), stgPath + "/Temp")
            functions.fileRenameToTXT(globalContext.outputNodeAddress, stgPath, auditRowKey)
            Logger.log.info("Creating log File")
            val logdf = spark.sql(s"select h.GALAXY_CDB_SUBSCRIBER_ID,h.DERIVED_PATIENT_IDENTIFIER,to_date(cast(unix_timestamp(h.7_DATE_OF_BIRTH_TS,'yyyy-MM-dd') AS timestamp)) as 7_DATE_OF_BIRTH_TS,h.8_ADMINISTRATIVE_SEX_IS as 8_ADMINISTRATIVE_SEX_IS,h.5_2_PATIENT_NAME_XPN_GIVEN_NM_ST as 5_2_PATIENT_NAME_XPN_GIVEN_NM_ST,h.5_1_PATIENT_NAME_XPN_FAM_NM_FN as 5_1_PATIENT_NAME_XPN_FAM_NM_FN,case when match.HL7_MESSAGE is not null then 'TRUE' else 'FALSE' end as senttoIHR,from_unixtime(unix_timestamp()) as Messagetimestamp from $hl7_members h left outer join matchedmembers match on h.HL7_MESSAGE=match.HL7_MESSAGE").persist(StorageLevel.MEMORY_AND_DISK_SER)
            val misMatches = logdf.filter("senttoIHR='FALSE'").count
            matchedMembers.unpersist()
            functions.CreateCSVlogFile(logdf, stgLogPath + "/Temp")
            logdf.unpersist()
            functions.fileRenameToCSV(globalContext.outputNodeAddress, stgLogPath, auditRowKey)

            Logger.log.info("File Moving to actual log dir")
            functions.moveCSVFile(stgLogPath, logdir + entNm)

            Logger.log.info("File Moving to actual outpath")
            functions.moveTxtFile(stgPath, outPath + entNm)

            Logger.log.info("Generating the Success Audit Report")
            ReportGeneration.HbaseAuditSuccessReport(rowKey, auditRowKey, starTimeStamp, matchedCount, misMatches.toString, "0")

            Logger.log.info("Total Messages: " + matchedCount)
            Logger.log.info("Total unMatched Messages: " + misMatches)
            Logger.log.info("==============> Lab Results Consumption job completed successfully <===============")
          }else if(isFilter.equalsIgnoreCase("No")){
            Logger.log.info(s"Creating the $entNm extract")
            transformations.galaxyCreateOutBoundFile(spark, messages.select("HL7_Message"), stgPath + "/Temp")
            functions.fileRenameToTXT(globalContext.outputNodeAddress, stgPath, auditRowKey)
            Logger.log.info("File Moving to actual outpath")
            functions.moveTxtFile(stgPath, outPath + entNm)
            Logger.log.info("Generating the Success Audit Report")
            ReportGeneration.HbaseAuditSuccessReport(rowKey, auditRowKey, starTimeStamp, messagesCount,"0", "0")
            Logger.log.info("Total Messages: " + messagesCount)
            Logger.log.info("==============> Lab Results Consumption job completed successfully <===============")
          }
        }
      }catch {
        case e: Exception => Logger.log.info("Errored: " + e.getMessage)
          ReportGeneration.HBaseAuditFailureReport(rowKey,auditRowKey,e.getLocalizedMessage,e.getMessage,starTimeStamp)
          globalContext.spark.stop()
      }
    }
  }
}
