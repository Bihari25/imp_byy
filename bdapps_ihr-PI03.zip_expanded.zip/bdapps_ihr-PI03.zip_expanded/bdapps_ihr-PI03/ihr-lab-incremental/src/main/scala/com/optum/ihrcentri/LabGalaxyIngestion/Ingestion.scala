package com.optum.ihrcentri.LabGalaxyIngestion

import com.optum.ihrcentri.Common._
import org.apache.spark.sql.SparkSession

import scala.util.Random

import org.apache.spark.storage.StorageLevel

/**
  * Created by mmallam2 on May,2018
  *
  **/

class Ingestion {

  var totalMatches:Int= 0
  var totalMissMatches: Int= 0
  val functions = new CommonFunctions
  val transformations=new Transformations

  def runIngestion(spark: SparkSession,sourceFilePath: String,outbound_path: String,msh_table: String,obr_table: String,obx_table: String,daig_table: String,errorDir: String,entNm: String)={
    Logger.log.info("Reading the zipFile")
    val zipData=functions.readFile(spark.sparkContext,sourceFilePath)
    Logger.log.info("Mapping the Galaxy schema")
    val labDF=transformations.galaxyFileDF(spark,zipData)
    val GalaxyTable={Random.alphanumeric take 15 mkString}
    labDF.createOrReplaceTempView(GalaxyTable)

    Logger.log.info("Creating parquet file for: "+msh_table)
    val mshDF=Lib.createGalaxyMSHDF(spark,GalaxyTable,entNm,sourceFilePath).persist(StorageLevel.MEMORY_AND_DISK_2)
    val msgCount=mshDF.count()
    Logger.log.info("Ingested records: " + msgCount)
    transformations.saveDataFrame(mshDF,msh_table,outbound_path)

    Logger.log.info("Creating parquet file for: "+obr_table)
    val obrDF=Lib.createGalaxyOBRDF(spark,GalaxyTable)
    transformations.saveDataFrame(obrDF,obr_table,outbound_path)

    Logger.log.info("Creating parquet file for: "+obx_table)
    val obxDF=Lib.createGalaxyOBXDF(spark,GalaxyTable)
    transformations.saveDataFrame(obxDF,obx_table,outbound_path)

    Logger.log.info("Creating parquet file for: "+daig_table)
    val ft1DF=Lib.createGalaxyFITDF(spark,GalaxyTable)
    transformations.saveDataFrame(ft1DF,daig_table,outbound_path)

    totalMatches+=msgCount.toInt
  }
}
