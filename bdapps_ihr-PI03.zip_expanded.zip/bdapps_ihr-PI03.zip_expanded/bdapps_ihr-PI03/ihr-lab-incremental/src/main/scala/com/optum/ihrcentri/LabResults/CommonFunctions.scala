package com.optum.ihrcentri.LabResults

import org.apache.spark.sql.{DataFrame, SparkSession}
import java.io._
import java.util.zip.{ZipEntry, ZipFile, ZipInputStream}
import java.io.InputStream

import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.fs.FileSystem
import org.apache.hadoop.fs.Path
import org.apache.hadoop.fs.FileUtil
import java.text.SimpleDateFormat
import java.util.Calendar

import com.optum.ihrcentri.Common.ReportGeneration.{testdateFormat}
import org.apache.hadoop.hbase.client.Put


class CommonFunctions {

  val globalContext=new GlobalContext

  val format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
  var hl7FileName=""
  val parser=new HL7Parser

  def readAcomembers(spark:SparkSession,tableName:String):DataFrame={
    Logger.log.info("Reading the aco members")
    val acoDf=spark.read.table(s"$tableName").cache()
    Logger.log.info("Aco_member count: "+ acoDf.count)
    acoDf
  }

  def noFilterHl7(spark: SparkSession,hl7df:DataFrame):DataFrame={
    hl7df.select("msgblock")
  }
  def csvtoList(spark: SparkSession, csvdf:DataFrame):List[String]={
    csvdf.rdd.coalesce(1).map(x => x.mkString(",")).collect.toList
  }

  def buildH7File(hl7list: List[String],outPath:String): Unit ={
      val file = new File(outPath)
      Logger.log.info("Building file")
      val fwrite = new PrintWriter(new FileOutputStream(file, true))
      var count = 0
      fwrite.write("")
      for (hl7msg <- hl7list) {
        count += 1
        fwrite.write(hl7msg)
        fwrite.write("\n")
      }
      Logger.log.info("Created file with " + count + " messsages")
      fwrite.flush()
      fwrite.close()
  }

  def unzip(filePath: String):InputStream={
    Logger.log.info("Opening Zip file")
    var stream: InputStream = new FileInputStream(filePath)
    try {
      val zip = new ZipFile(filePath)
      val entries = zip.entries
      var entry = entries.nextElement()
      while (entries.hasMoreElements()) {
        if (entry.getName.endsWith(".hl7")) {
          hl7FileName = entry.getName
          Logger.log.info(s"Hl7 FileName inside source zip file: $filePath : " + hl7FileName)
          stream = zip.getInputStream(entry)
        }
        entry = entries.nextElement()
      }
      if(hl7FileName.isEmpty){
        Logger.log.info(s"========>No HL7 Files inside the source Zip file: ${filePath}<===============")
        HBaseAuditFailureReport(LabCorp.rowKey,LabCorp.auditRowKey,s"No HL7 Files inside the source Zip file: ${filePath}","Hl7 File missing")
        System.exit(1)
        globalContext.sparkS.stop()
      }
    }catch{
      case e: IOException => Logger.log.info("exception caught: " + e.getMessage)
    }
    stream
  }

  def fileRenameToCSV(outputNodeAddress: String, filepath: String,AuditName: String): Unit = {
    Logger.log.info("Renaming the outbound file")
    val sourcePath=filepath
    val targetPath=filepath+"/"+AuditName+".csv"
    val hadoopConf = new org.apache.hadoop.conf.Configuration()
    val hdfs = org.apache.hadoop.fs.FileSystem.get(new java.net.URI(outputNodeAddress), hadoopConf)
    val source = new org.apache.hadoop.fs.Path(sourcePath)
    val target = new org.apache.hadoop.fs.Path(targetPath)
    val sourceFiles = hdfs.listFiles(source, true)
    if (sourceFiles != null) {
      while (sourceFiles.hasNext()) {
        val spath = sourceFiles.next().getPath()
        if (spath.toString.endsWith(".csv")) {
          hdfs.rename(spath, target)
        }
      }
    }
  }

  def unZipIt(zipFile: String, outputFolder: String): Unit = {
    val buffer = new Array[Byte](1024)
    try {
      //output directory
      val folder = new File(outputFolder);
      if (!folder.exists()) {
        folder.mkdir();
      }
      //zip file content
      val zis: ZipInputStream = new ZipInputStream(new FileInputStream(zipFile));
      //get the zipped file list entry
      var ze: ZipEntry = zis.getNextEntry();
      while (ze != null) {
        val fileName = ze.getName();
        val newFile = new File(outputFolder + File.separator + fileName);
        System.out.println("file unzip : " + newFile.getAbsoluteFile());
        //create folders
        new File(newFile.getParent()).mkdirs();
        val fos = new FileOutputStream(newFile);
        var len: Int = zis.read(buffer);
        while (len > 0) {
          fos.write(buffer, 0, len)
          len = zis.read(buffer)
        }
        fos.close()
        ze = zis.getNextEntry()
      }
      zis.closeEntry()
      zis.close()
    } catch {
      case e: IOException => println("exception caught: " + e.getMessage)
    }
  }

  def toList(listDf: DataFrame):List[String]={
    listDf.rdd.map(r=>r(0).toString).collect.toList
  }


  def moveFile(srcFilePath: String,destFilePath: String): Unit= {
      val hadoopConf = new Configuration()
      val source = new Path(srcFilePath)
      val target = new Path(destFilePath)
      val fs: FileSystem = source.getFileSystem(hadoopConf)
      val sourceFiles = fs.listFiles(source, true)
      if (sourceFiles != null) {
        while (sourceFiles.hasNext()) {
          FileUtil.copy(fs, sourceFiles.next().getPath(), fs, target, true, hadoopConf)
        }
      }
  }

  def cleanOutputPath(outputNodeAddress: String, outputFilePath: String): Unit = {
    val hadoopConf = new org.apache.hadoop.conf.Configuration()
    val hdfs = org.apache.hadoop.fs.FileSystem.get(new java.net.URI(outputNodeAddress), hadoopConf)
    val path = new org.apache.hadoop.fs.Path(outputFilePath)
    if (hdfs.exists(path)) {
      Logger.log.info("Overwriting staging outbound directory : " + path)
      try { hdfs.delete(path, true) } catch { case _: Throwable => {} }
    } else { printf("output directory from path %s is empty.... Exiting clean", path) }
    hdfs.mkdirs(path)
  }

  def buildCsvFile(printDF: DataFrame,logPath: String): Unit={
    printDF.coalesce(1).write.csv(logPath)
  }


  def HBaseAuditFailureReport(row_key: String,eitRowKey:String,errorcode: String,errorDesc: String):Unit={
    Logger.log.info(s"${row_key} process got failed please check Audit table with this row_key: "+ eitRowKey)
    val prtnrCd=row_key.split('-')(0)
    val srcCd=row_key.split('-')(1)
    hbaseAuditPut(eitRowKey,"pi","prcNm",row_key)
    hbaseAuditPut(eitRowKey,"pi","incPrcSts","Failure")
    hbaseAuditPut(eitRowKey,"pi","prcEndTm",format.format(Calendar.getInstance().getTime()))
    hbaseAuditPut(eitRowKey,"pi","prcStTm",LabCorp.starTimeStamp)
    hbaseAuditPut(eitRowKey,"pi","prtnrCd",prtnrCd)
    hbaseAuditPut(eitRowKey,"eri","errCd",errorcode)
    hbaseAuditPut(eitRowKey,"eri","errDesc",errorDesc)
    hbaseAuditPut(eitRowKey,"pi","srcCd",srcCd)
    hbaseAuditPut(eitRowKey,"pi","prcdt",testdateFormat.format(Calendar.getInstance().getTime()))
  }
  def HbaseAuditSuccessReport(row_key: String,eitRowKey:String): Unit ={
    Logger.log.info("Audit table row_key: "+ eitRowKey)
    val prtnrCd=row_key.split('-')(0)
    val srcCd=row_key.split('-')(1)
    hbaseAuditPut(eitRowKey,"pi","prcNm",row_key)
    hbaseAuditPut(eitRowKey,"pi","incPrcSts","Success")
    hbaseAuditPut(eitRowKey,"pi","prcEndTm",format.format(Calendar.getInstance().getTime()))
    hbaseAuditPut(eitRowKey,"pi","prcStTm",LabCorp.starTimeStamp)
    hbaseAuditPut(eitRowKey,"pi","precessed-errreccnt",RunJob.totalErrorMSGS.toString)
    hbaseAuditPut(eitRowKey,"pi","prtnrCd",prtnrCd)
    hbaseAuditPut(eitRowKey,"pi","processed-reccnt",RunJob.totalMatches.toString)
    hbaseAuditPut(eitRowKey,"pi","unmatched/unprocessed-reccnt",RunJob.totalMissMatches.toString)
    hbaseAuditPut(eitRowKey,"pi","srcCd",srcCd)
    hbaseAuditPut(eitRowKey,"pi","prcdt",testdateFormat.format(Calendar.getInstance().getTime()))
  }

  def hbaseAuditPut(eitRowKey: String, colFm: String, colNm: String, value: String): Unit = {
    try {
      val p = new Put(s"$eitRowKey".getBytes())
      p.addColumn(s"$colFm".getBytes(), s"$colNm".getBytes(), s"$value".getBytes())
      globalContext.ihrEitTab.put(p)
    } catch {
      case e: Exception => Logger.log.info("Exception at HBase EIT Put Commands at IHR_entity_info IHR_ADT_DTL" :+ e.getStackTrace.mkString)
        throw e
    }
  }

   def getListOfFiles(dir: String):List[File] = {
      val d = new File(dir)
      if (d.exists && d.isDirectory) {
        d.listFiles.filter(_.isFile).toList
      } else {
        List[File]()
      }
   }

  var returnList=List[String]()
  def historyList(directory: String,partdate: String): List[String] ={
    val d = new File(directory)
    for(filelist <- d.listFiles()){
      if(filelist.isDirectory){
        if(filelist.getAbsolutePath.contains(partdate)){
          historyList(filelist.getAbsolutePath,partdate)
        }
      }else {
        returnList= filelist.getAbsolutePath :: returnList
      }
    }
    returnList
  }
}