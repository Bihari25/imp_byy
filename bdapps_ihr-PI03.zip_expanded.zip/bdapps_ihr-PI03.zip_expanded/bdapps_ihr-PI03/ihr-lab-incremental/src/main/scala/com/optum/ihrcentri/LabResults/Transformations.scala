package com.optum.ihrcentri.LabResults

import org.apache.spark.sql.{DataFrame, SparkSession}
import scala.util.Random
import com.optum.ihrcentri.Common.{GlobalContext,Logger}

class Transformations {
    def labresultsMapAcomembers(spark: SparkSession,hl7df:DataFrame,acodf:DataFrame):DataFrame={
        val hl7_members={Random.alphanumeric take 15 mkString}
        val aco_members={Random.alphanumeric take 15 mkString}

        Logger.log.info("Aco members filtering is initiated")
        hl7df.selectExpr("msgblock","lpad(pid,15,'0') as pid","substr(lastname,1,4) as lastname","substr(firstname,1,3) as firstname","dob as birthdate","gender","messageId").createOrReplaceTempView(hl7_members)
        acodf.selectExpr("substr(member_first_name,1,3) as member_first_name","substr(member_last_name,1,4) as member_last_name","lpad(subscriber_id,15,'0') as subscriber_id","member_birth_date as dob","member_gender","lpad(alt_id,15,'0') as alt_id","lpad(card_id,15,'0') as card_id").createOrReplaceTempView(aco_members)
        val acoFilter=spark.sql(s"""select filter.* from (
                    select i.* from
                    (select h.* from $hl7_members h join $aco_members a on trim(h.pid) = trim(a.subscriber_id) union
                    select h.* from $hl7_members h join $aco_members a on trim(h.pid) = trim(a.alt_id) union
                    select h.* from $hl7_members h join $aco_members a on trim(h.pid) = trim(a.card_id))i
                    union
                    select match.* from (
                    select h.* from $hl7_members h join $aco_members a on trim(h.firstname)=trim(a.member_first_name) and trim(h.lastname)=trim(a.member_last_name) and trim(a.dob)=trim(h.birthdate) and trim(h.gender)=trim(a.member_gender) union
                    select h.* from $hl7_members h join $aco_members a on trim(h.firstname)=trim(a.member_first_name) and trim(h.lastname)=trim(a.member_last_name) and trim(a.dob)=trim(h.birthdate) union
                    select h.* from $hl7_members h join $aco_members a on trim(h.lastname)=trim(a.member_last_name) and trim(a.dob)=trim(h.birthdate) and trim(h.gender)=trim(a.member_gender) union
                    select h.* from $hl7_members h join $aco_members a on trim(a.dob)=trim(h.birthdate) and trim(h.gender)=trim(a.member_gender) and trim(h.firstname)=trim(a.member_first_name) union
                    select h.* from $hl7_members h join $aco_members a on trim(h.lastname)=trim(a.member_last_name) and trim(h.gender)=trim(a.member_gender) and trim(h.firstname)=trim(a.member_first_name))match)filter""")
        acoFilter
    }

  def softMatch(spark: SparkSession,hl7df:DataFrame,acodf:DataFrame):List[String]={
      println("Aco members soft match is initiated")
      hl7df.createOrReplaceTempView("hl7_members")
      acodf.createOrReplaceTempView("aco_members")
      val acoFilter=spark.sql("select h.msgblock from hl7_members h join aco_members a on h.lastName =a.member_last_name and h.firstName=a.member_first_name and h.gender=a.member_gender")
      val memcount=acoFilter.count()
      println("Soft Match count"+ memcount)
      acoFilter.rdd.map(r=>r(0).toString).collect.toList
  }

  def misMatchedRecords(spark: SparkSession,matchedDf: DataFrame,hl7Df:DataFrame):DataFrame={
      val hl7_members={Random.alphanumeric take 15 mkString}
      val matched_members={Random.alphanumeric take 15 mkString}
      matchedDf.cache()
      hl7Df.createOrReplaceTempView(hl7_members)
      matchedDf.createOrReplaceTempView(matched_members)
      val misMatchedDf=spark.sql(s"""SELECT DISTINCT h.* from $hl7_members h WHERE NOT EXISTS( SELECT 1 FROM $matched_members m where m.msgblock=h.msgblock)""")
      misMatchedDf
  }

  /*def logCreation(spark: SparkSession,mismatchDF: DataFrame,matchDF: DataFrame): DataFrame ={
    val missedmembers={Random.alphanumeric take 15 mkString}
    val matchedmembers={Random.alphanumeric take 15 mkString}
    mismatchDF.createOrReplaceTempView(missedmembers)
    matchDF.createOrReplaceTempView(matchedmembers)
    val logdf=spark.sql(s"""select hl7.*,from_unixtime(unix_timestamp()) as timestamp from (select messageid,pid,to_date(cast(unix_timestamp(dob,'yyyyMMdd') AS timestamp)) as dob,gender,firstname,lastname,"FALSE" as sentToIHR from $missedmembers union
              select messageid,pid,birthdate,gender,firstname,lastname,"TRUE" as sentToIHR from $matchedmembers) hl7""")
    logdf
  }*/

  def globalViews(spark: SparkSession,acoDf: DataFrame,hl7df: DataFrame): Unit ={
    acoDf.createGlobalTempView("aco_members")
    hl7df.createGlobalTempView("hl7_members")
  }
  def SDRreadAcoFile(filePath: String,spark: SparkSession):DataFrame={
    spark.read.format("com.databricks.spark.csv").option("header", "true").option("inferSchema", "true").option("delimiter", "|").load(filePath).selectExpr("from_unixtime(unix_timestamp(member_birth_date,'yyy-MM-dd hh:mm:ss.S'),'yyyyMMdd') as  member_birth_date","member_first_name","member_last_name","member_gender","subscriber_id","ALT_ID","CARD_ID")
  }
  def logCreation(spark: SparkSession,pidDF: DataFrame,matchDF: DataFrame): DataFrame ={
    val hl7_members={Random.alphanumeric take 15 mkString}
    val matchedmembers={Random.alphanumeric take 15 mkString}
    pidDF.createOrReplaceTempView(hl7_members)
    matchDF.createOrReplaceTempView(matchedmembers)
    spark.sql(s"""select h.messageId,h.pid,to_date(cast(unix_timestamp(h.dob,'yyyyMMdd') AS timestamp)),h.gender,h.firstName,h.lastName,case when match.msgblock is not null then 'TRUE' else 'FALSE' end as senttoIHR,from_unixtime(unix_timestamp()) as timestamp from $hl7_members h left outer join $matchedmembers match on h.msgblock=match.msgblock""")
  }

  def CreateCSVlogFile(logDF:DataFrame,outpath:String): Unit ={
    logDF.coalesce(1).write.format("com.databricks.spark.csv").option("delimiter", "|").option("header", "false").save(outpath)
  }
}
