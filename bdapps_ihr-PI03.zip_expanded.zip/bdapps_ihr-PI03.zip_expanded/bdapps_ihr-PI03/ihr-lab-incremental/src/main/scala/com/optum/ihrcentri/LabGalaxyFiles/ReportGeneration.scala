package com.optum.ihrcentri.LabGalaxyFiles

import java.text.SimpleDateFormat
import java.util.Calendar

import com.optum.ihrcentri.Common._
import org.apache.hadoop.hbase.client.Put

class ReportGeneration {
  val globalContext=new GlobalContext
  val format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
  val mainClass=new RunJob

  def HBaseAuditFailureReport(row_key: String,eitRowKey: String, errorcode: String, errorDesc: String): Unit = {
    Logger.log.info("Audit table row_key: " + eitRowKey)
    val prtnrCd = row_key.split('-')(0)
    val srcCd = row_key.split('-')(1)
    hbaseAuditPut(eitRowKey, "pi", "prcNm", row_key)
    hbaseAuditPut(eitRowKey, "pi", "incPrcSts", "Failure")
    hbaseAuditPut(eitRowKey, "pi", "prcEndTm", format.format(Calendar.getInstance().getTime))
    hbaseAuditPut(eitRowKey, "pi", "prcStTm", GalaxyFiles.starTimeStamp)
    hbaseAuditPut(eitRowKey, "pi", "prtnrCd", prtnrCd)
    hbaseAuditPut(eitRowKey, "eri", "errCd", errorcode)
    hbaseAuditPut(eitRowKey, "eri", "errDesc", errorDesc)
    hbaseAuditPut(eitRowKey, "pi", "srcCd", srcCd)
  }

  def HbaseAuditSuccessReport(row_key: String,eitRowKey: String,proc_count: String,unprocessed_count: String): Unit = {
    Logger.log.info("Audit table row_key: " + eitRowKey)
    val prtnrCd = row_key.split('-')(0)
    val srcCd = row_key.split('-')(1)
    hbaseAuditPut(eitRowKey, "pi", "prcNm", row_key)
    hbaseAuditPut(eitRowKey, "pi", "incPrcSts", "Success")
    hbaseAuditPut(eitRowKey, "pi", "prcEndTm", format.format(Calendar.getInstance().getTime))
    hbaseAuditPut(eitRowKey, "pi", "prcStTm", GalaxyFiles.starTimeStamp)
    hbaseAuditPut(eitRowKey, "pi", "prtnrCd", prtnrCd)
    hbaseAuditPut(eitRowKey, "pi", "processed-reccnt", proc_count)
    hbaseAuditPut(eitRowKey, "pi", "unmatched/unprocessed-reccnt", unprocessed_count)
    hbaseAuditPut(eitRowKey, "pi", "srcCd", srcCd)
  }

  def hbaseAuditPut(eitRowKey: String, colFm: String, colNm: String, value: String): Unit = {
    try {
      val p = new Put(s"$eitRowKey".getBytes())
      p.addColumn(s"$colFm".getBytes(), s"$colNm".getBytes(), s"$value".getBytes())
      globalContext.ihrEitTab.put(p)
    } catch {
      case e: Exception => Logger.log.info("Exception at HBase EIT Put Commands at IHR_entity_info IHR_ADT_DTL" :+ e.getStackTrace.mkString)
        throw e
    }
  }

}