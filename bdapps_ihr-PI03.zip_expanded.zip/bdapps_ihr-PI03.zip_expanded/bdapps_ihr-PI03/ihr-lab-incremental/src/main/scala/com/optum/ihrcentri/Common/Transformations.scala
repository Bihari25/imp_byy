package com.optum.ihrcentri.Common

import java.sql.Date

import org.apache.spark.rdd.RDD
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SaveMode, SparkSession}

import scala.util.Random

case class labSchema(lab_utilization_gateway_lab_description: String,specimen_number: String,first_service_date: String,procedure_code: String,analyte_sequence_number: String,loinc_code: String,vendor_test_number: String,vendor_test_description: String,reference_range: String,result_value: String,result_units_name: String,result_abnormal_code: String,load_date: String,cd_input_file_id: String,member_sys_id: String,patient_date_of_birth: String,patient_gender_code: String,patient_first_name: String,patient_last_name: String,cdb_subscriber_id: String,entprs_clin_data_intk_fl_cd: String,claim_match_indicator: String,individual_id: String,lab_subscriber_number: String,cdb_member_id: String,mailing_address_line_1: String,mailing_address_line_2: String,mailing_city_name: String,mailing_state_abbreviation: String,mailing_zip_code: String,mailing_home_telephone_number: String,mailing_alternate_telephone_number_type_code: String,mailing_alternate_telephone_number: String,permanent_address_line_1: String,permanent_address_line_2: String,permanent_city_name: String,permanent_state_abbreviation: String,permanent_zip_code: String,permanent_home_telephone_number: String,permanent_alternate_telephone_number_type_code: String,permanent_alternate_telephone_number: String)
class Transformations {

  def galaxyLog(spark:SparkSession,labDF:DataFrame,matchedDF:DataFrame):DataFrame={
    val lab_members={Random.alphanumeric take 15 mkString}
    val matched_members={Random.alphanumeric take 15 mkString}

    labDF.createOrReplaceTempView(lab_members)
    matchedDF.createOrReplaceTempView(matched_members)
    spark.sql(s"""select lab.specimen_number,lab.cdb_subscriber_id,lab.patient_date_of_birth,lab.patient_gender_code,lab.patient_first_name,lab.patient_last_name,case when match.analyte_sequence_number is not null and match.specimen_number is not null and match.procedure_code is not null and match.claim_match_indicator is not null then 'TRUE' else 'FALSE' end as senttoIHR,from_unixtime(unix_timestamp()) as timestamp from $lab_members lab left outer join $matched_members match on lab.specimen_number=match.specimen_number and lab.analyte_sequence_number=match.analyte_sequence_number and lab.procedure_code=match.procedure_code and lab.claim_match_indicator=match.claim_match_indicator""")
  }

  def globalViews(spark: SparkSession,acoDf: DataFrame,hl7df: DataFrame): Unit ={
    acoDf.createGlobalTempView("aco_members")
    hl7df.createGlobalTempView("hl7_members")
  }

  def galaxyAcoMap(spark: SparkSession,labDF:DataFrame,acoDF: DataFrame): DataFrame ={
    val labdata={Random.alphanumeric take 15 mkString}
    val acodata={Random.alphanumeric take 15 mkString}

    labDF.createOrReplaceTempView(labdata)
    acoDF.createOrReplaceTempView(acodata)
    spark.sql(s"""select match.* from (
        select hardmatch.* from (select lab.* from $labdata lab join $acodata aco on lab.cdb_subscriber_id=aco.subscriber_id union select lab.* from $labdata lab join $acodata aco on lab.cdb_member_id=aco.alt_id) hardmatch union
        select softmatch.* from (
        select lab.* from $labdata lab join $acodata aco on substr(lab.patient_first_name,1,3)= substr(aco.member_first_name,1,3) and substr(lab.patient_last_name,1,4)=substr(aco.member_last_name,1,4) and trim(lab.patient_date_of_birth)=trim(aco.member_birth_date) and trim(lab.patient_gender_code)=trim(aco.member_gender) union
        select lab.* from $labdata lab join $acodata aco on substr(lab.patient_first_name,1,3)= substr(aco.member_first_name,1,3) and substr(lab.patient_last_name,1,4)=substr(aco.member_last_name,1,4) and trim(lab.patient_date_of_birth)=trim(aco.member_birth_date) union
        select lab.* from $labdata lab join $acodata aco on substr(lab.patient_last_name,1,4)=substr(aco.member_last_name,1,4) and trim(lab.patient_date_of_birth)=trim(aco.member_birth_date) and trim(lab.patient_gender_code)=trim(aco.member_gender) union
        select lab.* from $labdata lab join $acodata aco on substr(lab.patient_first_name,1,3)=substr(aco.member_first_name,1,3) and trim(lab.patient_date_of_birth)=trim(aco.member_birth_date) and trim(lab.patient_gender_code)=trim(aco.member_gender) union
        select lab.* from $labdata lab join $acodata aco on substr(lab.patient_first_name,1,3)= substr(aco.member_first_name,1,3) and substr(lab.patient_last_name,1,4)=substr(aco.member_last_name,1,4) and trim(lab.patient_gender_code)=trim(aco.member_gender))softmatch
        ) match""")
  }
  def galaxyFileDF(spark:SparkSession,galaxyData: RDD[String]): DataFrame ={
    val headerList=galaxyData.first
    val dataRDD=galaxyData.filter(x=>x!=headerList)
    import spark.implicits._
    dataRDD.map(x=>x.split('|').map(_.trim)).map(x=>labSchema(x(0),x(1),x(2),x(3),x(4),x(5),x(6),x(7),x(8),x(9),x(10),x(11),x(12),x(13),x(14),x(15),x(16),x(17),x(18),x(19),x(20),x(21),x(22),x(23),x(24),x(25),x(26),x(27),x(28),x(29),x(30),x(31),x(32),x(33),x(34),x(35),x(36),x(37),x(38),x(39),x(40))).toDF
  }
  def createOutBoundFile(outboundDF: DataFrame,outPath: String): Unit ={
    outboundDF.coalesce(1).write.format("com.databricks.spark.csv").option("delimiter", "|").option("header", "true").save(outPath)
  }
  def CreateCSVlogFile(logDF:DataFrame,outpath:String): Unit ={
    logDF.coalesce(1).write.format("com.databricks.spark.csv").option("delimiter", "|").option("header", "false").save(outpath)
  }
  def saveDataFrame(saveDf: DataFrame,tableName: String,Outpath: String): Unit ={
    val outloc=Outpath+"/"+tableName
    Logger.log.info("""saveDf.withColumn(\"partition_date\",current_date).write.mode(SaveMode.Append).partitionBy(\"partition_date\").parquet(outloc)""")
    saveDf.withColumn("partition_date",current_date).write.mode(SaveMode.Append).partitionBy("partition_date").parquet(outloc)
  }
  def readAcoFile(filePath: String,spark: SparkSession):DataFrame={
    spark.read.format("com.databricks.spark.csv").option("header", "true").option("inferSchema", "true").option("delimiter", "|").load(filePath).selectExpr("from_unixtime(unix_timestamp(member_birth_date,'yyy-MM-dd hh:mm:ss.S'),'yyyy-MM-dd') as  member_birth_date","member_first_name","member_last_name","member_gender","subscriber_id","ALT_ID","CARD_ID")
  }

  def SDRreadAcoFile(filePath: String,spark: SparkSession):DataFrame={
    Logger.log.info("Reading the Aco file from path:"+filePath)
    val testSchema=spark.read.format("com.databricks.spark.csv").option("header", "true").option("inferSchema", "true").option("delimiter", "|").load(filePath)
    Logger.log.info("Schema of Aco Roster file:"+testSchema.printSchema())
    testSchema.selectExpr("from_unixtime(unix_timestamp(member_birth_date,'yyy-MM-dd hh:mm:ss.S'),'yyyyMMdd') as  member_birth_date","member_first_name","member_last_name","member_gender","subscriber_id","ALT_ID","CARD_ID")
  }

  def galaxyCreateOutBoundFile(spark: SparkSession,outboundDF: DataFrame,outPath: String): Unit ={
    //outboundDF.coalesce(1).write.option("delimiter", "\u0001").csv(outPath)
    import spark.implicits._
    outboundDF.map(x=>x(0).toString).rdd.coalesce(1).saveAsTextFile(outPath)
  }
  def unionDirectoryList(dirList: List[String],spark: SparkSession):DataFrame={
    var unionDF=spark.read.format("com.databricks.spark.csv").option("header", "true").option("inferSchema", "true").option("delimiter", "|").load(dirList.head)
    val withOuthead=dirList.drop(1)
    withOuthead.map(x=>unionDF=unionDF.union(spark.read.format("com.databricks.spark.csv").option("header", "true").option("inferSchema", "true").option("delimiter", "|").load(x)))
    unionDF.distinct()
  }
  def SDRAcoFields(unionDF: DataFrame):DataFrame={
    unionDF.selectExpr("from_unixtime(unix_timestamp(BIRTH_DATE,'yyy-MM-dd hh:mm:ss'),'yyyyMMdd') as  member_birth_date","FIRST_NAME as member_first_name","LAST_NAME as member_last_name","GENDER_TYPE as member_gender","subscriber_id as subscriber_id","alt_member_id as ALT_ID","member_id as CARD_ID").distinct()
  }
  def GalaxyacoFields(unionDF:DataFrame):DataFrame={
    unionDF.selectExpr("from_unixtime(unix_timestamp(BIRTH_DATE,'yyy-MM-dd hh:mm:ss'),'yyyy-MM-dd') as  member_birth_date","FIRST_NAME as member_first_name","LAST_NAME as member_last_name","GENDER_TYPE as member_gender","subscriber_id as subscriber_id","alt_member_id as ALT_ID","member_id as CARD_ID").distinct()
  }
  def SDROutBoundFile(spark: SparkSession,outBoundDf: DataFrame,outPath: String):Unit ={
    //outBoundDf.coalesce(1).write.option("delimiter", "\u0001").csv(outPath)
    import spark.implicits._
    outBoundDf.map(x=>x(0).toString).rdd.coalesce(1).saveAsTextFile(outPath)
  }
  def distinctMembers(outboundDF: DataFrame,outPath: String): Unit ={
    outboundDF.coalesce(1).write.mode(SaveMode.Overwrite).format("com.databricks.spark.csv").option("delimiter", "|").option("header", "true").save(outPath)
  }
}
