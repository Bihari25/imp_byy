package com.optum.ihrcentri.LabFlatten

import java.text.SimpleDateFormat
import java.util.Calendar

import com.optum.ihrcentri.Common._
import org.joda.time.DateTime

import scala.collection.parallel.{ForkJoinTaskSupport, ParSeq}

/**
  * Created by mmallam2 on Apr,2018
  *
  **/

object Flatten {

  def main(args: Array[String]): Unit = {

    val globalContext = new GlobalContext
    val functions = new CommonFunctions
    val run=new Ingestion

    val format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
    val starTimeStamp = format.format(Calendar.getInstance().getTime())

    val numThreads: Int = globalContext.threads.toInt

    Logger.log.info("=============> Starting IHR Lab Results Framework <=============")
    if (args.length != 2) {
      Logger.log.info("Please Pass RowKey \"PATNRCD-SRCCD-ENTITYNAME\" and load type for IHR Incremental extract")
      Logger.log.info("===> Since No RowKey is Passed ending IHR Incremental extract <===")
      ReportGeneration.HBaseAuditFailureReport("No-Row-key-LabResults", "No-Row-key-LabResults", "2", "Since No RowKey is Passed ending IHR Incremental extract", starTimeStamp)
      globalContext.spark.stop()
    } else {
      val rowKey = args(0).toUpperCase().trim
      val history=args(1).toUpperCase().trim
      val entNm=rowKey.split('-')(2)
      val auditRowKey = rowKey + "-" + s"${java.util.UUID.randomUUID.toString}"
      var failedDate=""
      try {
        val stgOutpath = globalContext.stgdir + entNm + "/stgoutdir/"
        val stgErrorDir = globalContext.stgdir + entNm + "/stgerrordir/"

        val stgPath = stgOutpath.replace("/mapr/", "hdfs:///")
        val stgrrordir = stgErrorDir.replace("/mapr/", "hdfs:///")

        val errordir = globalContext.errorDir.replace("/mapr/", "hdfs:///")
        val out_path = globalContext.flatten_outPath.replace("/mapr/", "hdfs:///")

        val labDb=globalContext.dbName

        Logger.log.info(s"Creating database $labDb if not exists")
        globalContext.sparkS.sql(s"create database if not exists $labDb")
        Logger.log.info("Creating Table for: "+globalContext.msh_table+" if not exits")
        Lib.CreateMSHTable(globalContext.sparkS,globalContext.dbName,globalContext.msh_table,out_path)
        Logger.log.info("Creating Table for: "+globalContext.obr_table+" if not exits")
        Lib.createOBRTable(globalContext.sparkS,globalContext.dbName,globalContext.obr_table,out_path)
        Logger.log.info("Creating Table for: "+globalContext.diag_table+" if not exits")
        Lib.createDIAGTable(globalContext.sparkS,globalContext.dbName,globalContext.diag_table,out_path)
        Logger.log.info("Creating Table for: "+globalContext.obx_table+" if not exits")
        Lib.createOBXTable(globalContext.sparkS,globalContext.dbName,globalContext.obx_table,out_path)

        if (history.equalsIgnoreCase("history")) {
          Logger.log.info("===================> Extracting the History files and ingesting into flatten tables <==========================")
          var inboundPath = ""
          if(entNm.contains("QUESTDIA")){
            inboundPath=globalContext.quest_InboundPath
          }else if(entNm.contains("LABCORPDIA")){
            inboundPath=globalContext.LabCorp_InboundPath
          }else{
            Logger.log.info("Please pass Row key")
            Logger.log.info("===> Since No RowKey is Passed ending IHR LabResults Framework <===")
            ReportGeneration.HBaseAuditFailureReport("No-Row-key-LabResults", "No-Row-key-LabResults", "2", "Since No RowKey is Passed ending IHR LabResults extract", starTimeStamp)
            globalContext.spark.stop()
          }
          val currentDate=Calendar.getInstance().getTime
          val startDate = globalContext.startDate
          val endDate = Lib.getEndDate(rowKey)(0)
          var historyStartDate=""
          val format = new SimpleDateFormat("yyyy-MM-dd")

          if(endDate.split('-')(0).toInt != 0) {
            historyStartDate=endDate
            Logger.log.info(s"Starting date of the history files for $entNm:"+ historyStartDate)
          } else {
            historyStartDate=startDate
            Logger.log.info(s"Starting date of the history files for $entNm:"+ historyStartDate)
          }
          val dateList=functions.genDateRange(format.parse(historyStartDate),currentDate)
          for(folderDate <- dateList){
            val folderFormat = new java.text.SimpleDateFormat("yyyyMMdd")
            failedDate=format.format(folderDate.getTime)
           // Logger.log.info("date="+folderFormat.format(folderDate))
            val partitionDate="date="+folderFormat.format(folderDate)
            History.runHistory(globalContext.createSparkSession(s"LABRESULTS-$entNm"),inboundPath,partitionDate,entNm,rowKey)
          }
          Logger.log.info("Updating the HBase timestamp:" + format.format(Calendar.getInstance().getTime()))
          Lib.hbaseEitPut(rowKey, "is", "intEndDate","0000-00-00" )
          Logger.log.info("==============> Lab Results History files flatten ingestion process completed successfully <===============")
        } else if(history.equalsIgnoreCase("incremental")){
          Logger.log.info("=================> Extracting the Incremental files and ingesting into flatten tables <==========================")
          functions.cleanOutputPath(globalContext.outputNodeAddress, stgPath)
          functions.cleanOutputPath(globalContext.outputNodeAddress, stgrrordir)
          val rptCfgScan = Lib.getEntityInfo(rowKey)
          //Incremental End Timestamp
          val incEndTs = Lib.getCurrentTimeFormat
          //Extracted Configuration from HBase Table
          rptCfgScan.foreach { case (patnrCd, srcCd, entNm, lastRunSts, outFileNm, outFileExt, isFilter) =>

            val getFileList: ParSeq[String] = Lib.eitTabScan(patnrCd, srcCd, entNm, lastRunSts, incEndTs).par

            getFileList.tasksupport = new ForkJoinTaskSupport(new scala.concurrent.forkjoin.ForkJoinPool(numThreads))
            val listSize = getFileList.size
            Logger.log.info(s"Total FileList: " + listSize)
            Logger.log.info(s"List of Files from $lastRunSts to $incEndTs: " + getFileList)
            if (listSize != 0) {
              for (file2 <- getFileList) {
                Logger.log.info("Current Processing file: " + file2)
                val inputFile = file2.replace("maprfs://", "/mapr")
                run.runIngestion(globalContext.createSparkSession("LabResults"), inputFile, stgPath, globalContext.msh_table, globalContext.obr_table, globalContext.obx_table, globalContext.diag_table, stgErrorDir: String, entNm,rowKey,auditRowKey,starTimeStamp)
                Thread.sleep(1000)
              }
            }
          }

          val dateFormat = new SimpleDateFormat("yyyy-MM-dd")
          val currentDate = dateFormat.format(Calendar.getInstance().getTime())

          Logger.log.info(s"Loading data for: " + globalContext.msh_table + " table into partition: " + currentDate)
          functions.moveParquetFile(stgPath + "/" + globalContext.msh_table, globalContext.outputNodeAddress, globalContext.msh_table, out_path)
          Lib.msckRepairTable(globalContext.sparkS, globalContext.dbName, globalContext.msh_table)

          Logger.log.info(s"Loading data for: " + globalContext.obx_table + " table into partition: " + currentDate)
          functions.moveParquetFile(stgPath + "/" + globalContext.obx_table, globalContext.outputNodeAddress, globalContext.obx_table, out_path)
          Lib.msckRepairTable(globalContext.sparkS, globalContext.dbName, globalContext.obx_table)

          Logger.log.info(s"Loading data for: " + globalContext.obr_table + " table into partition: " + currentDate)
          functions.moveParquetFile(stgPath + "/" + globalContext.obr_table, globalContext.outputNodeAddress, globalContext.obr_table, out_path)
          Lib.msckRepairTable(globalContext.sparkS, globalContext.dbName, globalContext.obr_table)

          Logger.log.info(s"Loading data for: " + globalContext.diag_table + " table into partition: " + currentDate)
          functions.moveParquetFile(stgPath + "/" + globalContext.diag_table, globalContext.outputNodeAddress, globalContext.diag_table, out_path)
          Lib.msckRepairTable(globalContext.sparkS, globalContext.dbName, globalContext.diag_table)

          Logger.log.info("Moving files from stg error dir to actual error dir")
          functions.moveFile(stgrrordir, errordir + "/" + entNm + "/")

          Logger.log.info("Updating the HBase timestamp" + format.format(Calendar.getInstance().getTime()))
          Lib.hbaseEitPut(rowKey, "is", "lastRnTs", starTimeStamp)

          Logger.log.info("Generating the Success Audit Report")
          ReportGeneration.HbaseAuditSuccessReport(rowKey, auditRowKey, starTimeStamp, run.totalMessages.toString, "0", run.totalErrorMessages.toString)

          Logger.log.info("Total Ingested messages: " + run.totalMessages)
          Logger.log.info("Records Errored messages: " + run.totalErrorMessages)
          Logger.log.info("==============> Lab Results ingestion process completed successfully <===============")
          globalContext.sparkS.stop()
        }
        else{
          Logger.log.info("Generating the Error Audit Report")
          ReportGeneration.HBaseAuditFailureReport(rowKey,auditRowKey,"no load type","please pass load type",starTimeStamp)
          globalContext.spark.stop()
        }
      }catch {
        case e: Exception => Logger.log.info("Errored: " + e.getMessage)
          Logger.log.info("Generating the Error Audit Report")
          ReportGeneration.HBaseAuditFailureReport(rowKey,auditRowKey,e.getLocalizedMessage,e.getMessage,starTimeStamp)
          if (history.equalsIgnoreCase("History")) {
            Logger.log.info("Updating the HBase timestamp" + format.format(Calendar.getInstance().getTime()))
            Lib.hbaseEitPut(rowKey, "is", "intEndDate",failedDate )
          }
          globalContext.spark.stop()
      }
    }
  }
}
