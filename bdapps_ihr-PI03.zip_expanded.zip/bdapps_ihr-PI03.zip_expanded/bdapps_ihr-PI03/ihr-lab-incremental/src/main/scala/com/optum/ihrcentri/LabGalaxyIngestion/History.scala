package com.optum.ihrcentri.LabGalaxyIngestion

import java.text.SimpleDateFormat
import java.util.Calendar

import com.optum.ihrcentri.Common._
import org.apache.spark.sql.SparkSession

import scala.collection.parallel.ForkJoinTaskSupport

/**
  * Created by mmallam2 on Aug,2018
  *
  **/

object History {

  val globalContext = new GlobalContext
  val functions = new CommonFunctions
  val run=new Ingestion
  val format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
  val starTimeStamp = format.format(Calendar.getInstance().getTime())

  val numThreads: Int = globalContext.threads.toInt

  def runHistory(spark: SparkSession,inboundPath: String,partDate: String,entNm: String,rowKey: String):Unit= {

    run.totalMatches=0

    val Audit_RowKey = rowKey + "-" + s"${java.util.UUID.randomUUID.toString}"
    try {
      Logger.log.info(s"==============> Extracting the history files from the partition date: $partDate of $entNm <=================")
      val stgOutpath = globalContext.stgdir + entNm + "/stgoutdir/"
      val stgErrorDir = globalContext.stgdir + entNm + "/stgerrordir/"

      val stgPath = stgOutpath.replace("/mapr/", "hdfs:///")
      val stgrrordir = stgErrorDir.replace("/mapr/", "hdfs:///")

      val errordir = globalContext.errorDir.replace("/mapr/", "hdfs:///")
      val out_path = globalContext.flatten_outPath.replace("/mapr/", "hdfs:///")


      val historyList = functions.historyTestList(inboundPath, partDate).par
      historyList.tasksupport = new ForkJoinTaskSupport(new scala.concurrent.forkjoin.ForkJoinPool(numThreads))

      Logger.log.info(s"Total FileList: " + historyList.size)
      Logger.log.info(s"List of Files" + historyList)
      Logger.log.info("=================> Lab Results Aco_Member Match started <==========================")
      Logger.log.info("Process Start time: " + starTimeStamp)

      for (file2 <- historyList) {
        Logger.log.info("Current Processing file: " + file2)
        val inputFile = file2.replace("/mapr/", "hdfs:///")
        Thread.sleep(1000)
        run.runIngestion(globalContext.sparkS, inputFile, stgPath, globalContext.msh_table, globalContext.obr_table, globalContext.obx_table, globalContext.diag_table, stgErrorDir, entNm)
      }
      val dateFormat = new SimpleDateFormat("yyyy-MM-dd")
      val currentDate = dateFormat.format(Calendar.getInstance().getTime())

      if(historyList.size!=0) {
        Logger.log.info(s"Loading data for: " + globalContext.msh_table + " table into partition: " + currentDate)
        functions.moveParquetFile(stgPath + "/" + globalContext.msh_table, globalContext.outputNodeAddress, globalContext.msh_table, out_path)
        Lib.msckRepairTable(globalContext.sparkS, globalContext.dbName, globalContext.msh_table)

        Logger.log.info(s"Loading data for: " + globalContext.obx_table + " table into partition: " + currentDate)
        functions.moveParquetFile(stgPath + "/" + globalContext.obx_table, globalContext.outputNodeAddress, globalContext.obx_table, out_path)
        Lib.msckRepairTable(globalContext.sparkS, globalContext.dbName, globalContext.obx_table)

        Logger.log.info(s"Loading data for: " + globalContext.obr_table + " table into partition: " + currentDate)
        functions.moveParquetFile(stgPath + "/" + globalContext.obr_table, globalContext.outputNodeAddress, globalContext.obr_table, out_path)
        Lib.msckRepairTable(globalContext.sparkS, globalContext.dbName, globalContext.obr_table)

        Logger.log.info(s"Loading data for: " + globalContext.diag_table + " table into partition: " + currentDate)
        functions.moveParquetFile(stgPath + "/" + globalContext.diag_table, globalContext.outputNodeAddress, globalContext.diag_table, out_path)
        Lib.msckRepairTable(globalContext.sparkS, globalContext.dbName, globalContext.diag_table)

        Logger.log.info("Generating the Success Audit Report")
        ReportGeneration.HbaseAuditSuccessReport(rowKey, Audit_RowKey, starTimeStamp, run.totalMatches.toString, "0", "")

        Logger.log.info("Total Ingested messages: " + run.totalMatches)
        Logger.log.info("==============> Galaxy Lab Results ingestion process completed successfully <===============")
      }else{
        Logger.log.info("No Data Files in partition:"+partDate)
      }
    }catch {
      case e: Exception => Logger.log.info("Errored: " + e.getMessage)
        Logger.log.info("Generating the Error Audit Report")
        ReportGeneration.HBaseAuditFailureReport(rowKey,Audit_RowKey,e.getLocalizedMessage,e.getMessage,starTimeStamp)
        globalContext.spark.stop()
    }
  }
}
