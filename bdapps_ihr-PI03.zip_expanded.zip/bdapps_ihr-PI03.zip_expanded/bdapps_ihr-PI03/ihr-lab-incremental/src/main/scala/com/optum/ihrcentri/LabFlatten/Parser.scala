package com.optum.ihrcentri.LabFlatten

/**
  * Created by mmallam2 on May,2018
  *
  **/
import ca.uhn.hl7v2.{DefaultHapiContext, HL7Exception}
import ca.uhn.hl7v2.parser.CanonicalModelClassFactory
import ca.uhn.hl7v2.util.Hl7InputStreamMessageIterator
import ca.uhn.hl7v2.validation.impl.ValidationContextFactory
import com.optum.ihrcentri.Common._
import scala.collection.parallel.{ForkJoinTaskSupport, ParSeq}
import java.io._

class Parser {

  var segmentMSH = scala.collection.mutable.ListBuffer[String]()
  var segmentOBR = scala.collection.mutable.ListBuffer[String]()
  var segmentFTI = scala.collection.mutable.ListBuffer[String]()
  var segmentOBX = scala.collection.mutable.ListBuffer[String]()
  var errorMsgs = 0
  var errorList = List[String]()
  var msgCount = 0

  def hl7parser(messageStream: InputStream,fileName: String)={

    val iteration = new Hl7InputStreamMessageIterator(messageStream)
    val context = new DefaultHapiContext
    val version = new CanonicalModelClassFactory("2.5")
    context.setModelClassFactory(version)
    context.setValidationContext(ValidationContextFactory.defaultValidation)
    Logger.log.info("Hl7 File Parsing Initiated")

    val ts = System.currentTimeMillis()
    val parser: ca.uhn.hl7v2.parser.PipeParser = context.getPipeParser

    while (iteration.hasNext) {
      val next = iteration.next
      try {
        val message: ca.uhn.hl7v2.model.v25.message.ORU_R01 = parser.parse(next.toString).asInstanceOf[ca.uhn.hl7v2.model.v25.message.ORU_R01]
        val messageString=parser.encode(message)
        segmentMSH ++=Lib.segMSHFieldExtract(messageString,message,fileName)
        segmentOBR ++=Lib.segOBRFieldExtract(message)
        segmentFTI ++=Lib.segFT1FieldExtract(message)
        segmentOBX ++=Lib.segOBXFieldExtract(message)
      }
      catch {
        case e: HL7Exception =>
          Logger.log.info("Invalid Message Format: " + e.getMessage)
          Logger.log.info("Error Code " + e.getError)
          errorList = next.toString :: errorList
          errorMsgs += 1
      }
      msgCount += 1
    }
    Logger.log.info("Messages parsed: " + msgCount)
    Logger.log.info("ErrorMSGS:"+ errorMsgs)
  }
}
