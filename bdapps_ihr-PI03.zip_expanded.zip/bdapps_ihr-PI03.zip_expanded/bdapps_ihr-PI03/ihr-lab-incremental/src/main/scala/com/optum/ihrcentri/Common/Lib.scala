package com.optum.ihrcentri.Common

import java.text.SimpleDateFormat
import java.util.Calendar

import org.apache.hadoop.fs.Path
import org.apache.hadoop.hbase.TableName
import org.apache.hadoop.hbase.client.{Put, Scan}
import org.apache.hadoop.hbase.filter.CompareFilter.CompareOp
import org.apache.hadoop.hbase.filter._
import org.apache.hadoop.hbase.util.Bytes
import ca.uhn.hl7v2.model.v25.message.ORU_R01
import org.apache.spark.sql.types.{StringType, StructField, StructType}
import org.apache.spark.sql.{DataFrame, Row, SaveMode, SparkSession}
import org.apache.spark.sql.functions._


/**
  * Created by rkodur on 3/6/2018.
  */
object Lib {

  val globalContext = new GlobalContext

  def filterListAnd(filters: Filter*) = new FilterList(FilterList.Operator.MUST_PASS_ALL, filters: _*)

  def filterRawFileExist(filePath: String): Boolean = {
    globalContext.fs.exists(new Path(s"$filePath"))
  }

  def getCurrentTimeFormat: String = getCurrentDateTime("yyyy-MM-dd HH:mm:ss")

  def getCurrentDateTime(dateTimeFormat: String): String = {
    val dateFormat = new SimpleDateFormat(dateTimeFormat)
    val cal = Calendar.getInstance()
    dateFormat.format(cal.getTime)
  }

  def getTimestamp(DateFormat: String): Long = {
    try {
      val timestampformat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
      timestampformat.parse(DateFormat).getTime
    } catch {
      case e: Exception => Logger.log.info("Exception while getting current date/time" :+ e.getMessage)
        0
    }
  }

  def getEndDate(rowKey: String): Array[String] = {
    try {
      val ihrTab = globalContext.spark.getConf.get("spark.ihrCtlTab")
      Logger.log.info(s"ihrCtlTab ihr_ent_cfg: $ihrTab")
      val scanner = new Scan()
      scanner.setCaching(1000)
      scanner.setCacheBlocks(false)
      val filter1 = new RowFilter(CompareOp.EQUAL, new BinaryComparator(Bytes.toBytes(s"$rowKey")))
      scanner.setFilter(filter1)
      val ihrInfo = globalContext.hbaseContext.hbaseRDD(TableName.valueOf(ihrTab), scanner).cache()
      val ihrEntRDD = ihrInfo.map(tuple => {
        val result = tuple._2 ; Bytes.toString(result.getValue(Bytes.toBytes("is"), Bytes.toBytes("intEndDate")))
      })
      if (ihrEntRDD.isEmpty()) {
        Logger.log.info(s"Please Provide Appropriate RowKey / Check ihr_ent_cfg table Properties for $rowKey properly")
        ihrEntRDD.collect()
      }
      else {
        ihrEntRDD.collect()
      }
    } catch {
      case e: Exception => Logger.log.error(s"Exception while getting Configuration from ihr_entity_info Tab" :+ e.getMessage)
        throw e
    }
  }

  def createDataFrame(spark:SparkSession,tableName: String): DataFrame ={
    spark.read.table(tableName)
  }
//Get Configuration Info from Lab Configuration table
  def getEntityInfo(rowKey: String): Array[(String, String, String, String, String, String, String)] = {
    try {
      val ihrTab = globalContext.spark.getConf.get("spark.ihrCtlTab")
      Logger.log.info(s"ihrCtlTab ihr_ent_cfg: $ihrTab")
      val scanner = new Scan()
      scanner.setCaching(1000)
      scanner.setCacheBlocks(false)
      val filter1 = new RowFilter(CompareOp.EQUAL, new BinaryComparator(Bytes.toBytes(s"$rowKey")))
      scanner.setFilter(filter1)
      val ihrInfo = globalContext.hbaseContext.hbaseRDD(TableName.valueOf(ihrTab), scanner).cache()
      val ihrEntRDD = ihrInfo.map(tuple => {
        val result = tuple._2
        (Bytes.toString(result.getValue(Bytes.toBytes("ei"), Bytes.toBytes("prtnrCd"))),
          Bytes.toString(result.getValue(Bytes.toBytes("ei"), Bytes.toBytes("srcCd"))),
          Bytes.toString(result.getValue(Bytes.toBytes("ei"), Bytes.toBytes("entNm"))),
          Bytes.toString(result.getValue(Bytes.toBytes("is"), Bytes.toBytes("lastRnTs"))),
          Bytes.toString(result.getValue(Bytes.toBytes("ei"), Bytes.toBytes("outFileNm"))),
          Bytes.toString(result.getValue(Bytes.toBytes("ei"), Bytes.toBytes("outFileExt"))),
          Bytes.toString(result.getValue(Bytes.toBytes("ei"), Bytes.toBytes("isFilter"))))
      }
      )

      if (ihrEntRDD.isEmpty()) {
        Logger.log.info(s"Please Provide Appropriate RowKey / Check ihr_ent_cfg table Properties for $rowKey properly")
        ihrEntRDD.collect()
      }
      else {
        ihrEntRDD.collect()
      }
    } catch {
      case e: Exception => Logger.log.error(s"Exception while getting Configuration from ihr_entity_info Tab" :+ e.getMessage)
        throw e
    }
  }



//Extracting List of files from provided starttime to end time

  def eitTabScan(patnrCd: String, srcCd: String, entNm: String, incStTime: String, incEndTs: String): List[String] = {
    val eitTable = globalContext.spark.getConf.get("spark.eitTab")
    val ptnr = s"${patnrCd}".toUpperCase
    val src = s"${srcCd}".toUpperCase
    val mountPath = globalContext.spark.getConf.get("spark.mountPath")
    val raw_path = s"maprfs://$mountPath/${ptnr.toLowerCase}/raw/standard_access/${src.toLowerCase}/data/"
    val entName = s"${entNm}".toUpperCase
    Logger.log.info(s"Retrieving Files for $entName from Raw: $raw_path")
    Logger.log.info(s"Processing Entity:${entName} with patnrCd:${ptnr} srcCd:${src}")
    Logger.log.info(s"Scanning Eit HBase Table: $eitTable")
    val startTime = s"$incStTime"
    val endTime = s"$incEndTs"
    Logger.log.info(s"Capturing if any Changes reflected for $entName from $startTime to $endTime")
    val rowKey = s"${ptnr}-${src}-${entName}"
    Logger.log.info(s"Processing ${entName} Files")
    import org.apache.hadoop.hbase.client.Scan
    val scan = new Scan()
    val filter = new PrefixFilter(Bytes.toBytes(s"${ptnr}-${src}-${entName}-"))
    val filter1 = new SingleColumnValueFilter(Bytes.toBytes("exi"), Bytes.toBytes("ingProcLogSts"), CompareOp.EQUAL, Bytes.toBytes("Success"));
    scan.setCaching(10000)
    scan.setCacheBlocks(false)
    filter1.setFilterIfMissing(true)
    scan.setFilter(filterListAnd(filter1, filter))
    scan.setTimeRange(getTimestamp(startTime), getTimestamp(endTime))
    val eitVal = globalContext.hbaseContext.hbaseRDD(TableName.valueOf(eitTable), scan).cache
    val eitInfo = eitVal.map(tuple => {
      val result = tuple._2
      (Bytes.toString(result.getValue(Bytes.toBytes("fi"), Bytes.toBytes("schmVer"))),
        Bytes.toString(result.getValue(Bytes.toBytes("fi"), Bytes.toBytes("srcFileNm"))),
        Bytes.toString(result.getValue(Bytes.toBytes("fi"), Bytes.toBytes("entprtnfldr"))))
    })
    Logger.log.info(s"Number of Entries Captured for $entName from EIT SCAN b/w $startTime and $endTime :" + eitVal.count())
    if (!eitInfo.isEmpty) {
      //  val eitFileList: List[(String, String)] = eitInfo.collect.toList.map(x => (x, s"${raw_path}${entName}/${entName}.v${x}//*"))
      val eitFileList = eitInfo.map(x => (x._1, x._2, x._3)).collect.toList.map(x => (s"${raw_path}${entNm}/${entNm}.v${x._1}/${x._3}/${x._2}"))
      val eitRawFileList = eitFileList.filter(x => filterRawFileExist(x))
      eitVal.unpersist()
      eitRawFileList
    }
    else {
      Logger.log.info(s"Since, No Changes Captured for $entName from $startTime to $endTime, datasets will not be generated")
      List[String]()
    }
  }


  //Update IHR-audit_tracking table with Rowkey(Use JAVA UUID to get uniq ID) Column Family and values
  def hbaseEitPut(eitRowKey: String, colFm: String, colNm: String, value: String): Unit = {
    try {
      val p = new Put(s"$eitRowKey".getBytes())
      p.addColumn(s"$colFm".getBytes(), s"$colNm".getBytes(), s"$value".getBytes())
      globalContext.ihrCtlTab.put(p)
    } catch {
      case e: Exception => Logger.log.info("Exception at HBase EIT Put Commands at IHR_entity_info IHR_ADT_DTL" :+ e.getStackTrace.mkString)
        throw e
    }
  }
  def segFieldExtract(segName: String, msg: ORU_R01): scala.collection.mutable.ListBuffer[String] = {

    segName match {
      case "LAB_MSH_PID" => {
        //MSH Segment Columns
        var buf = scala.collection.mutable.ListBuffer[String]()
        val msh = msg.getMSH
        val Field_Separator_ST = msh.getFieldSeparator.encode()
        val Encoding_char_ST = msh.getEncodingCharacters.encode()
        val SENDING_APPLCTN_HD_NMSPCEID_IS = msh.getSendingApplication.getHd1_NamespaceID.encode()
        val SENDING_APPLCTN_HD_UNVRSL_ID_ST = msh.getSendingApplication.getHd2_UniversalID.encode
        val SENDING_APPLCTN_HD_UNVRSL_ID_TYP_ID = msh.getSendingApplication.getHd2_UniversalID.encode
        val SENDING_FACILITY_HD_NMSPCEID_IS = msh.getSendingFacility.getHd1_NamespaceID.encode
        val SENDING_FACILITY_HD_UNVRSL_ID_ST = msh.getSendingFacility.getHd2_UniversalID.encode
        val SENDING_FACILITY_HD_UNVRSL_ID_TYP_ID = msh.getSendingFacility.getHd3_UniversalIDType.encode
        val RECCVNG_FACILITY_HD_NMSPCEID_IS = msh.getReceivingFacility.getNamespaceID.encode
        val RECCVNG_FACILITY_HD_UNVRSL_ID_ST = msh.getReceivingFacility.getUniversalID.encode
        val RECCVNG_FACILITY_HD_UNVRSL_ID_TYP_ID = msh.getReceivingFacility.getHd3_UniversalIDType.encode
        val DATE_TIME_MESSAGE_TS = msh.getDateTimeOfMessage.getTime.encode()
        val DATE_TIME_MESSAGE_DEGREE_OF_PRECISION = msh.getDateTimeOfMessage.getDegreeOfPrecision.encode
        val SECURITY_ST = msh.getSecurity.encode
        val MESSAGE_TYP_MSG_MESSAGE_CODE_ID = msh.getMessageType.getMsg1_MessageCode.encode
        val MESSAGE_TYP_MSG_TRIGGER_EVNT_ID = msh.getMessageType.getTriggerEvent.encode
        val MESSAGE_TYP_MSG_MESSAGE_STRUCTURE_ID = msh.getMessageType.getMessageStructure.encode
        val MESSAGE_CNTRL_ID_ST = msh.getMessageControlID.encode
        val PROCESSING_ID_PT = msh.getProcessingID.getPt1_ProcessingID.encode
        val VERSION_ID_VID_ID = msh.getVersionID.getVid1_VersionID.encode
        val SEQ_NBR_NM = msh.getSequenceNumber.encode()
        val CONTINUATION_POINTER_ST = msh.getContinuationPointer.encode
        val ACCPT_ACKNLDGMNT_TYP_ID = msh.getAcceptAcknowledgmentType.encode
        val APPLCTN_ACKNLDGMNT_TYP_ID = msh.getApplicationAcknowledgmentType.encode
        val COUNTRY_CD = msh.getCountryCode.encode
        val CHARCTER_SET = msh.getCharacterSet().mkString
        val ALT_CHAR_SET_HNDLNG_SCHME_ID = msh.getAlternateCharacterSetHandlingScheme.encode


        //Patient Segment Columns
        val patientInfo = msg.getPATIENT_RESULT.getPATIENT.getPID

        val SET_ID_PID_SI = patientInfo.getSetIDPID.encode()
        val PATIENT_ID_CX_IDENTIFIER_NBR_ID = patientInfo.getPatientID.getCx1_IDNumber.encode
        val PATIENT_ID_LIST_CX_ID_NBR_ST = patientInfo.getPatientIdentifierList.map(x => x.getIDNumber.encode).mkString
        val PATIENT_ID_LIST_CX_CHK_DIGIT_ST = patientInfo.getPatientIdentifierList.map(x => x.getCheckDigit.encode).mkString
        val PATIENT_ID_LIST_CX_Check_Digit_Scheme_ID = patientInfo.getPatientIdentifierList.map(x => x.getCheckDigitScheme.encode).mkString
        val PATIENT_ID_LIST_CX_Assigning_Authority_ID = patientInfo.getPatientIdentifierList.map(x => x.getAssigningAuthority.encode()).mkString
        val PATIENT_ID_LIST_CX_Identifier_Typ_CD_ID = patientInfo.getPatientIdentifierList.map(x => x.getIdentifierTypeCode.encode).mkString
        val ALT_PATIENT_ID_CX_ID_NBR_ST = patientInfo.getAlternatePatientIDPID.map(x => x.getIDNumber.encode).mkString
        val ALT_PATIENT_ID_CX_Identifier_Typ_CD_ID = patientInfo.getAlternatePatientIDPID.map(x => x.getIdentifierTypeCode.encode).mkString
        val PATIENT_NAME_XPN_FAM_NM_FN = patientInfo.getPatientName.map(x => x.getFamilyName.getFn1_Surname.encode).mkString
        val PATIENT_NAME_XPN_GIVEN_NM_ST = patientInfo.getPatientName.map(x => x.getGivenName.encode).mkString
        val PATIENT_NAME_XPN_NAME_TYP_CD_ID = patientInfo.getPatientName.map(x => x.getNameTypeCode.encode).mkString
        val DATE_OF_BIRTH_TS = patientInfo.getDateTimeOfBirth.getTime.encode()
        val ADMINISTRATIVE_SEX_IS = patientInfo.getAdministrativeSex.encode
        val PATIENT_ALIAS_XPN = patientInfo.getPatientAlias.map(x => x.getFamilyName.getFn1_Surname.encode).mkString
        val PATIENT_RACE_CE_IDENTIFIER_ST = patientInfo.getRace.map(x => x.getIdentifier.encode).mkString
        val PATIENT_RACE_CE_TEXT_ST = patientInfo.getRace.map(x => x.getText.encode).mkString
        val PATIENT_RACE_CE_NAME_OF_CODING_SYS_ID = patientInfo.getRace.map(x => x.getNameOfCodingSystem.encode).mkString
        val PATIENT_ADDR_XAD_STREET_ADDR_ST = patientInfo.getPatientAddress.map(x => x.getStreetAddress.encode()).mkString
        val PATIENT_ADDR_XAD_OTHER_DESIGNATION_ST = patientInfo.getPatientAddress.map(x => x.getOtherDesignation.encode).mkString
        val PATIENT_ADDR_XAD_CITY_ST = patientInfo.getPatientAddress.map(x => x.getCity.encode).mkString
        val PATIENT_ADDR_XAD_ST_OR_PROVINCE_ST = patientInfo.getPatientAddress.map(x => x.getStateOrProvince.encode).mkString
        val PATIENT_ADDR_XAD_ST_POSTAL_CD_ST = patientInfo.getPatientAddress.map(x => x.getZipOrPostalCode.encode).mkString
        val PATIENT_ADDR_XAD_ST_ADDR_TYPE_ID = patientInfo.getPatientAddress.map(x => x.getAddressType.encode).mkString
        val HOME_PHN_NBR_TN = patientInfo.getPhoneNumberHome.map(x => x.getTelephoneNumber.encode).mkString
        val BUSINESS_PHN_NBR_TN = patientInfo.getPhoneNumberBusiness.map(x => x.getTelephoneNumber).mkString
        val Primary_LANG = patientInfo.getPid15_PrimaryLanguage.encode()
        val MARTIAL_STATUS = patientInfo.getMaritalStatus.encode()
        val RELIGION = patientInfo.getReligion.encode()
        val PATIENT_ACCOUNT_NBR_ST = patientInfo.getPatientAccountNumber.encode()
        val SSN_NBR_ST = patientInfo.getSSNNumberPatient.encode
        val DRIVER_LICEENSE_NBR_DLN = patientInfo.getDriverSLicenseNumberPatient.getLicenseNumber.encode
        val MOTHERS_IDENTIFIER_CX = patientInfo.getMotherSIdentifier.map(x => x.getIDNumber).mkString
        val ETHNIC_GRP_CE = patientInfo.getEthnicGroup.map(x => x.getIdentifier.encode).mkString
        val BIRTH_PLACE_ST = patientInfo.getBirthPlace.encode
        val MULTIPLE_BIRTH_INDICATOR_ID = patientInfo.getMultipleBirthIndicator.encode
        val BIRTH_ORDER_NM = patientInfo.getBirthOrder.encode()
        val CITIZENSHIP_CE = patientInfo.getCitizenship.map(x => x.getCe1_Identifier.encode).mkString
        val VETERANS_MILITARY_STATUS = patientInfo.getVeteransMilitaryStatus.encode()
        val NATIONALITY = patientInfo.getNationality.encode()
        val PATIENT_DEATH_DATE_AND_TIME_TS = patientInfo.getPatientDeathDateAndTime.getTime.encode()
        val PATIENT_DEATH_IND_ID = patientInfo.getPatientDeathIndicator.encode
        val IDENTIFY_UNKNOWN_INDICATOR_ID = patientInfo.getIdentityUnknownIndicator.encode
        val IDENTIFIER_RELIABILITY_CD_IS = patientInfo.getPid32_IdentityReliabilityCode.map(x => x.encode).mkString
        val LAST_UPDT_DATETIME_TS = patientInfo.getLastUpdateDateTime.getTime.encode()
        val LAST_UPDT_FACILITY_HD = patientInfo.getLastUpdateFacility.encode()
        val SPECIES_CD_CE = patientInfo.getSpeciesCode.encode()
        val BREED_CD_CE = patientInfo.getBreedCode.encode()
        val STRAIN_ST = patientInfo.getStrain.encode
        val PROD_CLASS_CD_CE = patientInfo.getProductionClassCode.encode()
        val TRIBAL_CITIZENSHIP_CD_CWE = patientInfo.getTribalCitizenship.mkString

        val mes = s"$Field_Separator_ST@$Encoding_char_ST@$SENDING_APPLCTN_HD_NMSPCEID_IS@$SENDING_APPLCTN_HD_UNVRSL_ID_ST@$SENDING_APPLCTN_HD_UNVRSL_ID_TYP_ID@$SENDING_FACILITY_HD_NMSPCEID_IS" +
          s"@$SENDING_FACILITY_HD_UNVRSL_ID_ST@$SENDING_FACILITY_HD_UNVRSL_ID_TYP_ID@$RECCVNG_FACILITY_HD_NMSPCEID_IS@$RECCVNG_FACILITY_HD_UNVRSL_ID_ST@$RECCVNG_FACILITY_HD_UNVRSL_ID_TYP_ID@$DATE_TIME_MESSAGE_TS" +
          s"@$DATE_TIME_MESSAGE_DEGREE_OF_PRECISION@$SECURITY_ST@$MESSAGE_TYP_MSG_MESSAGE_CODE_ID@$MESSAGE_TYP_MSG_TRIGGER_EVNT_ID@$MESSAGE_TYP_MSG_MESSAGE_STRUCTURE_ID@$MESSAGE_CNTRL_ID_ST" +
          s"@$PROCESSING_ID_PT@$VERSION_ID_VID_ID@$SEQ_NBR_NM@$CONTINUATION_POINTER_ST@$ACCPT_ACKNLDGMNT_TYP_ID@$APPLCTN_ACKNLDGMNT_TYP_ID" +
          s"@$COUNTRY_CD@$CHARCTER_SET@$ALT_CHAR_SET_HNDLNG_SCHME_ID@$SET_ID_PID_SI@$PATIENT_ID_CX_IDENTIFIER_NBR_ID@$PATIENT_ID_LIST_CX_ID_NBR_ST" +
          s"@$PATIENT_ID_LIST_CX_CHK_DIGIT_ST@$PATIENT_ID_LIST_CX_Check_Digit_Scheme_ID@$PATIENT_ID_LIST_CX_Assigning_Authority_ID@$PATIENT_ID_LIST_CX_Identifier_Typ_CD_ID@$ALT_PATIENT_ID_CX_ID_NBR_ST@$ALT_PATIENT_ID_CX_Identifier_Typ_CD_ID" +
          s"@$PATIENT_NAME_XPN_FAM_NM_FN@$PATIENT_NAME_XPN_GIVEN_NM_ST@$PATIENT_NAME_XPN_NAME_TYP_CD_ID@$DATE_OF_BIRTH_TS@$ADMINISTRATIVE_SEX_IS@$PATIENT_ALIAS_XPN" +
          s"@$PATIENT_RACE_CE_IDENTIFIER_ST@$PATIENT_RACE_CE_TEXT_ST@$PATIENT_RACE_CE_NAME_OF_CODING_SYS_ID@$PATIENT_ADDR_XAD_STREET_ADDR_ST@$PATIENT_ADDR_XAD_OTHER_DESIGNATION_ST@$PATIENT_ADDR_XAD_CITY_ST" +
          s"@$PATIENT_ADDR_XAD_ST_OR_PROVINCE_ST@$PATIENT_ADDR_XAD_ST_POSTAL_CD_ST@$PATIENT_ADDR_XAD_ST_ADDR_TYPE_ID@$HOME_PHN_NBR_TN@$BUSINESS_PHN_NBR_TN@$Primary_LANG" +
          s"@$MARTIAL_STATUS@$RELIGION@$PATIENT_ACCOUNT_NBR_ST@$SSN_NBR_ST@$DRIVER_LICEENSE_NBR_DLN@$MOTHERS_IDENTIFIER_CX" +
          s"@$ETHNIC_GRP_CE@$BIRTH_PLACE_ST@$MULTIPLE_BIRTH_INDICATOR_ID@$BIRTH_ORDER_NM@$CITIZENSHIP_CE@$VETERANS_MILITARY_STATUS" +
          s"@$NATIONALITY@$PATIENT_DEATH_DATE_AND_TIME_TS@$PATIENT_DEATH_IND_ID@$IDENTIFY_UNKNOWN_INDICATOR_ID@$IDENTIFIER_RELIABILITY_CD_IS@$LAST_UPDT_DATETIME_TS" +
          s"@$LAST_UPDT_FACILITY_HD@$SPECIES_CD_CE@$BREED_CD_CE@$STRAIN_ST@$PROD_CLASS_CD_CE@$TRIBAL_CITIZENSHIP_CD_CWE"
        buf += mes
        buf
      }
      case "LAB_OBR_FT1" => {
        var buf = scala.collection.mutable.ListBuffer[String]()

        val patientInfo = msg.getPATIENT_RESULT.getPATIENT.getPID

        val PATIENT_ID_LIST_CX_ID_NBR_ST = patientInfo.getPatientIdentifierList.map(x => x.getIDNumber.encode).mkString
        val PATIENT_ACCOUNT_NBR_ST = patientInfo.getPatientAccountNumber.encode()
        val MESSAGE_CNTRL_ID_ST = msg.getMSH.getMessageControlID.encode


        val obrList = msg.getPATIENT_RESULT.getORDER_OBSERVATIONAll
        val obrNum = obrList.size()

        for (x <- 0 until obrNum) {
          //OBR Columns
          val obrIndex = obrList.get(x).getOBR
          val OBR_SET_ID_SI = obrIndex.getSetIDOBR.encode()
          val PLACE_ORDER_NUMBER_EI_ENTITY_IDENTIFIER_ST = obrIndex.getPlacerOrderNumber.getEi1_EntityIdentifier.encode
          val PLACE_ORDER_NUMBER_EI_NAMESPACE_ID_IS = obrIndex.getPlacerOrderNumber.getEi2_NamespaceID.encode
          val PLACE_ORDER_NUMBER_EI_UNIVERSAL_ID_ST = obrIndex.getPlacerOrderNumber.getEi3_UniversalID.encode
          val PLACE_ORDER_NUMBER_EI_UNIVERSAL_ID_TYP_ID = obrIndex.getPlacerOrderNumber.getEi4_UniversalIDType.encode
          val FILLER_ORDER_NBR_EI_ENTITY_IDENTIFIER_ST = obrIndex.getFillerOrderNumber.getEi1_EntityIdentifier.encode
          val FILLER_ORDER_NBR_EI_ST_NAMESPACE_ID_IS = obrIndex.getFillerOrderNumber.getEi2_NamespaceID.encode
          val FILLER_ORDER_NBR_EI_ST_UNIVERSAL_ID_ST = obrIndex.getFillerOrderNumber.getEi3_UniversalID.encode
          val FILLER_ORDER_NBR_EI_ST_UNIVERSAL_ID_TYPE_ID = obrIndex.getFillerOrderNumber.getEi4_UniversalIDType.encode
          val UNIVERSAL_SERVICE_IDENTIFIER_CE_IDENTIFER_ST = obrIndex.getUniversalServiceIdentifier.getCe1_Identifier.encode
          val UNIVERSAL_SERVICE_IDENTIFIER_CE_TEXT_ST = obrIndex.getUniversalServiceIdentifier.getCe2_Text.encode
          val UNIVERSAL_SERVICE_IDENTIFIER_CE_NAME_OF_CODING_SYSTEM_ID = obrIndex.getUniversalServiceIdentifier.getCe3_NameOfCodingSystem.encode
          val UNIVERSAL_SERVICE_IDENTIFIER_CE_ALTERNATE_IDENTIFIER_ST = obrIndex.getUniversalServiceIdentifier.getCe4_AlternateIdentifier.encode
          val UNIVERSAL_SERVICE_IDENTIFIER_CE_ALTERNATE_TEXT_ST = obrIndex.getUniversalServiceIdentifier.getCe5_AlternateText.encode
          val UNIVERSAL_SERVICE_IDENTIFIER_CE_NAME_OF_ALTERNATE_CODING_SYSTEM_ID = obrIndex.getUniversalServiceIdentifier.getCe6_NameOfAlternateCodingSystem.encode
          val OBR_PRIOROTY_ID = obrIndex.getObr5_PriorityOBR.encode
          val REQUESTED_DATETIME_TS = obrIndex.getRequestedDateTime.getTime.encode()
          val OBSERVATION_DATETIME_TS = obrIndex.getObservationDateTime.getTime.encode()
          val OBSERVATION_END_DATETIME_TS = obrIndex.getObservationEndDateTime.getTime.encode()
          val COLLECTION_VOLUME_QUANTITY_NM = obrIndex.getObr9_CollectionVolume.getCq1_Quantity.encode()
          val COLLECTION_VOLUME_UNITS_CE = obrIndex.getObr9_CollectionVolume.getCq2_Units.encode()
          val COLLECTOR_IDENTFIER_XCN = obrIndex.getObr10_CollectorIdentifier.map(x => x.getIDNumber.encode).mkString
          val SPECIMEN_ACTION_CODE_ID = obrIndex.getObr11_SpecimenActionCode.encode
          val DANGER_CODE_CE = obrIndex.getObr12_DangerCode.encode()
          val RELEVANT_CLINICAL_INFORMATION_ST = obrIndex.getRelevantClinicalInformation.encode
          val SPECIMEN_RECEIVED_DATETIME_TS = obrIndex.getSpecimenReceivedDateTime.getTime.encode()
          val SPECIMEN_SOURCE_SPS = obrIndex.getSpecimenSource.encode()
          val ORDERING_PROVIDER_XCN_ID_NUMBER_ST = obrIndex.getOrderingProvider.map(x => x.getIDNumber.encode).mkString
          val ORDERING_PROVIDER_XCN_FAMILY_NAME_FN = obrIndex.getOrderingProvider.map(x => x.getFamilyName.getFn1_Surname.encode).mkString
          val ORDERING_PROVIDER_XCN_GIVEN_NAME_ST = obrIndex.getOrderingProvider.map(x => x.getGivenName.encode).mkString
          val ORDERING_PROVIDER_XCN_MIDDLE_INITIAL_OR_NAME_ST = obrIndex.getOrderingProvider.map(x => x.getXcn4_SecondAndFurtherGivenNamesOrInitialsThereof.encode).mkString
          val ORDERING_PROVIDER_XCN_SOURCE_TABLE_IS = obrIndex.getOrderingProvider.map(x => x.getSourceTable.encode).mkString
          val ORDERING_PROVIDER_XCN_ASSIGNING_AUTHORITY_HD = obrIndex.getOrderingProvider.map(x => x.getAssigningAuthority.encode()).mkString
          val ORDERING_PROVIDER_XCN_NAMESPACE_ID_IS = obrIndex.getOrderingProvider.map(x => x.getXcn10_NameTypeCode.encode).mkString
          val ORDER_CALLBACK_PHOBE_NUMBER_XTN_EMAIL_ADDR_ST = obrIndex.getOrderCallbackPhoneNumber.map(x => x.getEmailAddress.encode).mkString
          val ORDER_CALLBACK_PHOBE_NUMBER_XTN_AREA_CITY_CODE_NM = obrIndex.getOrderCallbackPhoneNumber.map(x => x.getXtn6_AreaCityCode.encode()).mkString
          val ORDER_CALLBACK_PHOBE_NUMBER_XTN_LOCAL_NUMBER_NM = obrIndex.getOrderCallbackPhoneNumber.map(x => x.getXtn7_LocalNumber.encode()).mkString
          val PLACER_FIELD_1_ST = obrIndex.getPlacerField1.encode
          val PLACER_FIELD_2_ST = obrIndex.getPlacerField2.encode
          val FILLER_FIELD_1_ST = obrIndex.getFillerField1.encode
          val FILLER_FIELD_2_ST = obrIndex.getFillerField2.encode
          val RESULTS_RPT_STATUS_CHANGE_DATETIME_TS = obrIndex.getResultsRptStatusChngDateTime.getTime.encode()
          val CHARGE_TO_PRACTICE_MOC = obrIndex.getChargeToPractice.encode()
          val DIAGNOSTIC_SERV_SECT_ID_ID = obrIndex.getDiagnosticServSectID.encode
          val RESULT_STATUS_ID = obrIndex.getResultStatus.encode
          val PARENT_RESULT_PRL = obrIndex.getParentResult.encode()
          val QUANTITY_TIMING_TQ_QUANTITY_CQ = obrIndex.getObr27_QuantityTiming.map(x => x.getTq1_Quantity.encode()).mkString
          val QUANTITY_TIMING_TQ_INTERVAL_RI = obrIndex.getObr27_QuantityTiming.map(x => x.getTq2_Interval.encode()).mkString
          val QUANTITY_TIMING_TQ_DURATION_ST = obrIndex.getObr27_QuantityTiming.map(x => x.getDuration.encode).mkString
          val QUANTITY_TIMING_TQ_START_DATETIME_TS = obrIndex.getObr27_QuantityTiming.map(x => x.getStartDateTime.getTime.encode()).mkString
          val QUANTITY_TIMING_TQ_END_DATETIME_TS = obrIndex.getObr27_QuantityTiming.map(x => x.getEndDateTime.getTime.encode()).mkString
          val RESULTS_COPIES_TO_XCN = obrIndex.getObr28_ResultCopiesTo.mkString
          val PARENT_EIP = obrIndex.getObr29_ParentNumber.encode()

          //FT1 Columns

          val ft1Index = obrList.get(x).getFT1

          val FT1_SET_ID_SI = ft1Index.getSetIDFT1.encode()
          val TRANSACTION_ID_ST = ft1Index.getTransactionID.encode
          val TRANSACTION_BATCH_ID_ST = ft1Index.getTransactionBatchID.encode
          val TRANSACTION_DATE_DR_RANGE_START_DATETIME_TS = ft1Index.getTransactionDate.getDr1_RangeStartDateTime.getTime.encode()
          val TRANSACTION_DATE_DR_RANGE_END_DATETIME_TS = ft1Index.getTransactionDate.getDr2_RangeEndDateTime.getTime.encode()
          val TRANSACTION_POSTING_DATE_TS = ft1Index.getTransactionPostingDate.getTime.encode()
          val TRANSACTION_TYP_IS = ft1Index.getTransactionType.encode
          val TRANSACTION_CD_CE_IDENTIFIER_ID = ft1Index.getTransactionCode.getCe1_Identifier.encode
          val TRANSACTION_CD_CE_TEXT_SE = ft1Index.getTransactionCode.getCe2_Text.encode
          val TRANSACTION_CD_CE_NAME_OF_CODING_SYS_ST = ft1Index.getTransactionCode.getCe3_NameOfCodingSystem.encode
          val TRANSACTION_CD_CE_ALT_IDENTIFIER_ID = ft1Index.getTransactionCode.getCe4_AlternateIdentifier.encode
          val TRANSACTION_CD_CE_ALT_TEXT_SE = ft1Index.getTransactionCode.getCe5_AlternateText.encode
          val TRANSACTION_CD_CE_ALT_NAME_OF_CODING_SYS_ST = ft1Index.getTransactionCode.getCe6_NameOfAlternateCodingSystem.encode
          val TRANSACTION_DESC_ST = ft1Index.getTransactionDescription.encode
          val ALT_TRANSACTION_DESC_ST = ft1Index.getFt19_TransactionDescriptionAlt.encode
          val TRANSACTION_QTY_NM = ft1Index.getFt110_TransactionQuantity.encode()
          val TRANSACTION_AMT_EXTNDED_CP = ft1Index.getFt111_TransactionAmountExtended.encode()
          val TRANSACTION_AMT_UNIT_CP = ft1Index.getFt112_TransactionAmountUnit.encode()
          val DEPT_CD_CE = ft1Index.getDepartmentCode.encode()
          val INSURANCE_PLAN_ID_CE_IDENTIFIER_ID = ft1Index.getFt114_InsurancePlanID.getCe1_Identifier.encode
          val INSURANCE_PLAN_ID_CE_TEXT_SE = ft1Index.getFt114_InsurancePlanID.getCe2_Text.encode
          val INSURANCE_PLAN_ID_CE_NAME_OF_CODING_SYS_ST = ft1Index.getFt114_InsurancePlanID.getNameOfCodingSystem.encode
          val INSURANCE_PLAN_ID_CE_ALT_IDENTIFIER_ID = ft1Index.getFt114_InsurancePlanID.getAlternateIdentifier.encode
          val INSURANCE_PLAN_ID_CE_ALT_TEXT_SE = ft1Index.getFt114_InsurancePlanID.getAlternateText.encode
          val INSURANCE_PLAN_ID_CE_ALT_NAME_OF_CODING_SYS_ST = ft1Index.getFt114_InsurancePlanID.getCe6_NameOfAlternateCodingSystem.encode
          val INSURANCE_AMT_CP = ft1Index.getFt115_InsuranceAmount.encode()
          val ASSGND_PTNT_LOCATION_PL = ft1Index.getFt116_AssignedPatientLocation.encode()
          val FEE_SCHDULE_IS = ft1Index.getFt117_FeeSchedule.encode
          val PATIENT_TYP_IS = ft1Index.getFt118_PatientType.encode
          val PERFORMED_BY_CODE_XCN = ft1Index.getPerformedByCode.mkString
          val ORDERED_BY_CODE_XCN = ft1Index.getOrderedByCode.mkString
          val UNIT_COST_CP = ft1Index.getUnitCost.encode()
          val FILLER_ORDER_NUMBER = ft1Index.getFillerOrderNumber.encode()
          val ENTERED_BY_CODE = ft1Index.getEnteredByCode.mkString
          val PROC_CD_CE_IDENTIFIER_ID = ft1Index.getProcedureCode.getCe1_Identifier.encode
          val PROC_CD_CE_TEXT_SE = ft1Index.getProcedureCode.getCe2_Text.encode
          val PROC_CD_CE_TEXT_SE_NAME_OF_CODING_SYS_ST = ft1Index.getProcedureCode.getCe3_NameOfCodingSystem.encode
          val PROC_CD_CE_ALT_IDENTIFIER_ID = ft1Index.getProcedureCode.getCe4_AlternateIdentifier.encode
          val PROC_CD_CE_ALT_TEXT_SE = ft1Index.getProcedureCode.getAlternateText.encode
          val PROC_CD_CE_TEXT_SE_ALT_NAME_OF_CODING_SYS_ST = ft1Index.getProcedureCode.getNameOfAlternateCodingSystem.encode
          val PROC_CD_MODIFIER_CE_IDENTIFIER_ID = ft1Index.getFt126_ProcedureCodeModifier.map(x => x.getCe1_Identifier.encode).mkString
          val PROC_CD_MODIFIER_CE_TEXT_SE = ft1Index.getFt126_ProcedureCodeModifier.map(x => x.getCe2_Text.encode).mkString
          val PROC_CD_MODIFIER_CE_NAME_OF_CODING_SYS_ST = ft1Index.getFt126_ProcedureCodeModifier.map(x => x.getCe3_NameOfCodingSystem.encode).mkString
          val PROC_CD_MODIFIER_CE_ALT_IDENTIFIER_ID = ft1Index.getFt126_ProcedureCodeModifier.map(x => x.getCe4_AlternateIdentifier.encode).mkString
          val PROC_CD_MODIFIER_CE_ALT_TEXT_SE = ft1Index.getFt126_ProcedureCodeModifier.map(x => x.getCe5_AlternateText.encode).mkString
          val PROC_CD_MODIFIER_CE_ALT_NAME_OF_CODING_SYS_ST = ft1Index.getFt126_ProcedureCodeModifier.map(x => x.getCe6_NameOfAlternateCodingSystem.encode).mkString

          val mess = s"$PATIENT_ID_LIST_CX_ID_NBR_ST@$PATIENT_ACCOUNT_NBR_ST@$MESSAGE_CNTRL_ID_ST" +
            s"@$OBR_SET_ID_SI@$PLACE_ORDER_NUMBER_EI_ENTITY_IDENTIFIER_ST@$PLACE_ORDER_NUMBER_EI_NAMESPACE_ID_IS@$PLACE_ORDER_NUMBER_EI_UNIVERSAL_ID_ST@$PLACE_ORDER_NUMBER_EI_UNIVERSAL_ID_TYP_ID@$FILLER_ORDER_NBR_EI_ENTITY_IDENTIFIER_ST" +
            s"@$FILLER_ORDER_NBR_EI_ST_NAMESPACE_ID_IS@$FILLER_ORDER_NBR_EI_ST_UNIVERSAL_ID_ST@$FILLER_ORDER_NBR_EI_ST_UNIVERSAL_ID_TYPE_ID@$UNIVERSAL_SERVICE_IDENTIFIER_CE_IDENTIFER_ST@$UNIVERSAL_SERVICE_IDENTIFIER_CE_TEXT_ST@$UNIVERSAL_SERVICE_IDENTIFIER_CE_NAME_OF_CODING_SYSTEM_ID" +
            s"@$UNIVERSAL_SERVICE_IDENTIFIER_CE_ALTERNATE_IDENTIFIER_ST@$UNIVERSAL_SERVICE_IDENTIFIER_CE_ALTERNATE_TEXT_ST@$UNIVERSAL_SERVICE_IDENTIFIER_CE_NAME_OF_ALTERNATE_CODING_SYSTEM_ID@$OBR_PRIOROTY_ID@$REQUESTED_DATETIME_TS@$OBSERVATION_DATETIME_TS" +
            s"@$OBSERVATION_END_DATETIME_TS@$COLLECTION_VOLUME_QUANTITY_NM@$COLLECTION_VOLUME_UNITS_CE@$COLLECTOR_IDENTFIER_XCN@$SPECIMEN_ACTION_CODE_ID@$DANGER_CODE_CE" +
            s"@$RELEVANT_CLINICAL_INFORMATION_ST@$SPECIMEN_RECEIVED_DATETIME_TS@$SPECIMEN_SOURCE_SPS@$ORDERING_PROVIDER_XCN_ID_NUMBER_ST@$ORDERING_PROVIDER_XCN_FAMILY_NAME_FN@$ORDERING_PROVIDER_XCN_GIVEN_NAME_ST" +
            s"@$ORDERING_PROVIDER_XCN_MIDDLE_INITIAL_OR_NAME_ST@$ORDERING_PROVIDER_XCN_SOURCE_TABLE_IS@$ORDERING_PROVIDER_XCN_ASSIGNING_AUTHORITY_HD@$ORDERING_PROVIDER_XCN_NAMESPACE_ID_IS@$ORDER_CALLBACK_PHOBE_NUMBER_XTN_EMAIL_ADDR_ST@$ORDER_CALLBACK_PHOBE_NUMBER_XTN_AREA_CITY_CODE_NM" +
            s"@$ORDER_CALLBACK_PHOBE_NUMBER_XTN_LOCAL_NUMBER_NM@$PLACER_FIELD_1_ST@$PLACER_FIELD_2_ST@$FILLER_FIELD_1_ST@$FILLER_FIELD_2_ST@$RESULTS_RPT_STATUS_CHANGE_DATETIME_TS" +
            s"@$CHARGE_TO_PRACTICE_MOC@$DIAGNOSTIC_SERV_SECT_ID_ID@$RESULT_STATUS_ID@$PARENT_RESULT_PRL@$QUANTITY_TIMING_TQ_QUANTITY_CQ@$QUANTITY_TIMING_TQ_INTERVAL_RI" +
            s"@$QUANTITY_TIMING_TQ_DURATION_ST@$QUANTITY_TIMING_TQ_START_DATETIME_TS@$QUANTITY_TIMING_TQ_END_DATETIME_TS@$RESULTS_COPIES_TO_XCN@$PARENT_EIP@$FT1_SET_ID_SI" +
            s"@$TRANSACTION_ID_ST@$TRANSACTION_BATCH_ID_ST@$TRANSACTION_DATE_DR_RANGE_START_DATETIME_TS@$TRANSACTION_DATE_DR_RANGE_END_DATETIME_TS@$TRANSACTION_POSTING_DATE_TS@$TRANSACTION_TYP_IS" +
            s"@$TRANSACTION_CD_CE_IDENTIFIER_ID@$TRANSACTION_CD_CE_TEXT_SE@$TRANSACTION_CD_CE_NAME_OF_CODING_SYS_ST@$TRANSACTION_CD_CE_ALT_IDENTIFIER_ID@$TRANSACTION_CD_CE_ALT_TEXT_SE@$TRANSACTION_CD_CE_ALT_NAME_OF_CODING_SYS_ST" +
            s"@$TRANSACTION_DESC_ST@$ALT_TRANSACTION_DESC_ST@$TRANSACTION_QTY_NM@$TRANSACTION_AMT_EXTNDED_CP@$TRANSACTION_AMT_UNIT_CP@$DEPT_CD_CE" +
            s"@$INSURANCE_PLAN_ID_CE_IDENTIFIER_ID@$INSURANCE_PLAN_ID_CE_TEXT_SE@$INSURANCE_PLAN_ID_CE_NAME_OF_CODING_SYS_ST@$INSURANCE_PLAN_ID_CE_ALT_IDENTIFIER_ID@$INSURANCE_PLAN_ID_CE_ALT_TEXT_SE@$INSURANCE_PLAN_ID_CE_ALT_NAME_OF_CODING_SYS_ST" +
            s"@$INSURANCE_AMT_CP@$ASSGND_PTNT_LOCATION_PL@$FEE_SCHDULE_IS@$PATIENT_TYP_IS@$PERFORMED_BY_CODE_XCN@$ORDERED_BY_CODE_XCN" +
            s"@$UNIT_COST_CP@$FILLER_ORDER_NUMBER@$ENTERED_BY_CODE@$PROC_CD_CE_IDENTIFIER_ID@$PROC_CD_CE_TEXT_SE@$PROC_CD_CE_TEXT_SE_NAME_OF_CODING_SYS_ST" +
            s"@$PROC_CD_CE_ALT_IDENTIFIER_ID@$PROC_CD_CE_ALT_TEXT_SE@$PROC_CD_CE_TEXT_SE_ALT_NAME_OF_CODING_SYS_ST@$PROC_CD_MODIFIER_CE_IDENTIFIER_ID@$PROC_CD_MODIFIER_CE_TEXT_SE@$PROC_CD_MODIFIER_CE_NAME_OF_CODING_SYS_ST" +
            s"@$PROC_CD_MODIFIER_CE_ALT_IDENTIFIER_ID@$PROC_CD_MODIFIER_CE_ALT_TEXT_SE@$PROC_CD_MODIFIER_CE_ALT_NAME_OF_CODING_SYS_ST"

          buf += mess
        }
        buf
      }
      case "LAB_FT1_DIAG_CD" => {
        var buf = scala.collection.mutable.ListBuffer[String]()

        val patientInfo = msg.getPATIENT_RESULT.getPATIENT.getPID
        val PATIENT_ID_LIST_CX_ID_NBR_ST = patientInfo.getPatientIdentifierList.map(x => x.getIDNumber.encode).mkString
        val PATIENT_ACCOUNT_NBR_ST = patientInfo.getPatientAccountNumber.encode()


        val obrList = msg.getPATIENT_RESULT.getORDER_OBSERVATIONAll
        val obrNum = obrList.size()

        for (x <- 0 until obrNum) {
          val obrIndex = obrList.get(x).getOBR
          val OBR_SET_ID_SI = obrIndex.getSetIDOBR.encode()
          val FILLER_ORDER_NBR_EI_ENTITY_IDENTIFIER_ST = obrIndex.getFillerOrderNumber.getEi1_EntityIdentifier.encode
          val ft1Index = obrList.get(x).getFT1
          val FT1_SET_ID_SI = ft1Index.getSetIDFT1.encode()

          val ft1diagSize = ft1Index.getDiagnosisCodeFT1.size

          if (ft1diagSize > 0) {
            for (z <- 0 until ft1diagSize) {
              val ft1DiagCdIndex = ft1Index.getDiagnosisCodeFT1(z)
              val DIAG_CD_CE_IDENTIFIER_ID = ft1DiagCdIndex.getCe1_Identifier.encode
              val DIAG_CD_CE_TEXT_SE = ft1DiagCdIndex.getCe2_Text.encode
              val DIAG_CD_CE_NAME_OF_CODING_SYS_IS = ft1DiagCdIndex.getCe3_NameOfCodingSystem.encode
              val DIAG_CD_CE_ALT_IDENTIFIER_ID = ft1DiagCdIndex.getCe4_AlternateIdentifier.encode
              val DIAG_CD_CE_ALT_TEXT_SE = ft1DiagCdIndex.getCe5_AlternateText.encode
              val DIAG_CD_CE_ALT_NAME_OF_CODING_SYS_IS = ft1DiagCdIndex.getCe6_NameOfAlternateCodingSystem.encode

              val mess = s"$PATIENT_ID_LIST_CX_ID_NBR_ST@$PATIENT_ACCOUNT_NBR_ST@$FILLER_ORDER_NBR_EI_ENTITY_IDENTIFIER_ST@$OBR_SET_ID_SI@$FT1_SET_ID_SI@$DIAG_CD_CE_IDENTIFIER_ID" +
                s"@$DIAG_CD_CE_TEXT_SE@$DIAG_CD_CE_NAME_OF_CODING_SYS_IS@$DIAG_CD_CE_ALT_IDENTIFIER_ID@$DIAG_CD_CE_ALT_TEXT_SE@$DIAG_CD_CE_ALT_NAME_OF_CODING_SYS_IS"
              buf += mess
            }
          }
          else {
            val mess = s"$PATIENT_ID_LIST_CX_ID_NBR_ST@$PATIENT_ACCOUNT_NBR_ST@$FILLER_ORDER_NBR_EI_ENTITY_IDENTIFIER_ST@$OBR_SET_ID_SI@$FT1_SET_ID_SI@@@@@@@"
            buf += mess
          }
        }
        buf
      }
      case "LAB_OBX_NTE" => {
        var buf = scala.collection.mutable.ListBuffer[String]()

        val patientInfo = msg.getPATIENT_RESULT.getPATIENT.getPID
        val PATIENT_ID_LIST_CX_ID_NBR_ST = patientInfo.getPatientIdentifierList.map(x => x.getIDNumber.encode).mkString
        val PATIENT_ACCOUNT_NBR_ST = patientInfo.getPatientAccountNumber.encode()


        val obrList = msg.getPATIENT_RESULT.getORDER_OBSERVATIONAll
        val obrNum = obrList.size()

        for (x <- 0 until obrNum) {
          val obrIndex = obrList.get(x).getOBR
          val OBR_SET_ID_SI = obrIndex.getSetIDOBR.encode()
          val FILLER_ORDER_NBR_EI_ENTITY_IDENTIFIER_ST = obrIndex.getFillerOrderNumber.getEi1_EntityIdentifier.encode
          val obxList = obrList.get(x).getOBSERVATIONAll
          val obxNum = obxList.size()

          for (y <- 0 until obxNum) {

            val obxIndex = obxList.get(y).getOBX
            val OBX_SET_ID_SI = obxIndex.getObx1_SetIDOBX.encode()
            val VALUE_TYP_ID = obxIndex.getObx2_ValueType.encode
            val OBSERVATION_IDENTIFIER_CE_IDENTIFIER_ST = obxIndex.getObx3_ObservationIdentifier.getCe1_Identifier.encode
            val OBSERVATION_IDENTIFIER_CE_TEXT_ST = obxIndex.getObx3_ObservationIdentifier.getCe2_Text.encode
            val OBSERVATION_IDENTIFIER_CE_NAME_OF_CODING_SYS_ID = obxIndex.getObx3_ObservationIdentifier.getCe3_NameOfCodingSystem.encode
            val OBSERVATION_IDENTIFIER_CE_ALT_IDENTIFIER_ST = obxIndex.getObx3_ObservationIdentifier.getCe4_AlternateIdentifier.encode
            val OBSERVATION_IDENTIFIER_CE_ALT_TEXT_ST = obxIndex.getObx3_ObservationIdentifier.getCe5_AlternateText.encode
            val OBSERVATION_IDENTIFIER_CE_ALT_NAME_OF_CODING_SYS_ID = obxIndex.getObx3_ObservationIdentifier.getCe6_NameOfAlternateCodingSystem.encode
            val OBSERVATION_SUB_ID_ST = obxIndex.getObx4_ObservationSubID.encode
            val OBSERVATION_VALUE = obxIndex.getObx5_ObservationValue(0).encode()
            val UNITS_CE_IDENTIFIER_ST = obxIndex.getObx6_Units.getCe1_Identifier.encode
            val UNITS_CE_TEXT_ST = obxIndex.getObx6_Units.getCe2_Text.encode
            val UNITS_CE_NAME_OF_CODING_SYS_ID = obxIndex.getObx6_Units.getCe3_NameOfCodingSystem.encode
            val UNITS_CE_ALT_IDENTIFIER_ST = obxIndex.getObx6_Units.getCe4_AlternateIdentifier.encode
            val UNITES_CE_ALT_TEXT_ST = obxIndex.getObx6_Units.getCe5_AlternateText.encode
            val REFERENCE_RANGE_ST = obxIndex.getObx7_ReferencesRange.encode
            val ABNORMAL_FLAGS_IS = obxIndex.getObx8_AbnormalFlags.map(x => x.encode).mkString
            val PROBABILITY_NM = obxIndex.getObx9_Probability.encode()
            val NATURE_OF_ABNORMAL_TEST_ID = obxIndex.getObx10_NatureOfAbnormalTest.map(x => x.encode).mkString
            val OBSERVATION_RESULT_STATUS_ID = obxIndex.getObx11_ObservationResultStatus.encode
            val EFFECTIVE_DATE_OF_REFERENCE_RANGE_TS = obxIndex.getObx12_EffectiveDateOfReferenceRange.getTime.encode()
            val USER_DEFINED_ACCESS_CHECKS_ST = obxIndex.getObx13_UserDefinedAccessChecks.encode
            val DATETIME_OF_OBSERVATION_TS = obxIndex.getObx14_DateTimeOfTheObservation.getTime.encode()
            val PRODUCERS_ID_CE = obxIndex.getObx15_ProducerSID.encode()
            val RESPONSIBLE_OBSERVER_XCN = obxIndex.getObx16_ResponsibleObserver.mkString
            val OBSERVATION_METHOD_CE = obxIndex.getObx17_ObservationMethod.mkString
            val EQUIPMENT_INSTANCE_IDENTIFIER_EI = obxIndex.getObx18_EquipmentInstanceIdentifier.mkString
            val DATETIME_OF_THE_ANALYSIS_TS = obxIndex.getObx19_DateTimeOfTheAnalysis.getTime.encode()

            val nteList = obxList.get(y).getNTEAll
            val nteSize = nteList.size()

            if (nteSize > 0) {
              for (z <- 0 until nteSize) {
                val NTE_SET_ID_SI = nteList.get(z).getNte1_SetIDNTE.encode()
                val SOURCE_OF_COMMENT_ID = nteList.get(z).getNte2_SourceOfComment.encode
                val COMMENT_FT = nteList.get(z).getNte3_Comment.mkString(" ")
                val COMMENT_TYPE_CE = nteList.get(z).getNte4_CommentType.encode()
                val mess = s"$PATIENT_ID_LIST_CX_ID_NBR_ST@$PATIENT_ACCOUNT_NBR_ST@$FILLER_ORDER_NBR_EI_ENTITY_IDENTIFIER_ST@$OBR_SET_ID_SI@$OBX_SET_ID_SI@$VALUE_TYP_ID" +
                  s"@$OBSERVATION_IDENTIFIER_CE_IDENTIFIER_ST@$OBSERVATION_IDENTIFIER_CE_TEXT_ST@$OBSERVATION_IDENTIFIER_CE_NAME_OF_CODING_SYS_ID@$OBSERVATION_IDENTIFIER_CE_ALT_IDENTIFIER_ST@$OBSERVATION_IDENTIFIER_CE_ALT_TEXT_ST@$OBSERVATION_IDENTIFIER_CE_ALT_NAME_OF_CODING_SYS_ID" +
                  s"@$OBSERVATION_SUB_ID_ST@$OBSERVATION_VALUE@$UNITS_CE_IDENTIFIER_ST@$UNITS_CE_TEXT_ST@$UNITS_CE_NAME_OF_CODING_SYS_ID@$UNITS_CE_ALT_IDENTIFIER_ST" +
                  s"@$UNITES_CE_ALT_TEXT_ST@$REFERENCE_RANGE_ST@$ABNORMAL_FLAGS_IS@$PROBABILITY_NM@$NATURE_OF_ABNORMAL_TEST_ID@$OBSERVATION_RESULT_STATUS_ID" +
                  s"@$EFFECTIVE_DATE_OF_REFERENCE_RANGE_TS@$USER_DEFINED_ACCESS_CHECKS_ST@$DATETIME_OF_OBSERVATION_TS@$PRODUCERS_ID_CE@$RESPONSIBLE_OBSERVER_XCN@$OBSERVATION_METHOD_CE" +
                  s"@$EQUIPMENT_INSTANCE_IDENTIFIER_EI@$DATETIME_OF_THE_ANALYSIS_TS@$NTE_SET_ID_SI@$SOURCE_OF_COMMENT_ID@$COMMENT_FT@$COMMENT_TYPE_CE"
                buf += mess
              }
            } else {
              val mess = s"$PATIENT_ID_LIST_CX_ID_NBR_ST@$PATIENT_ACCOUNT_NBR_ST@$FILLER_ORDER_NBR_EI_ENTITY_IDENTIFIER_ST@$OBR_SET_ID_SI@$OBX_SET_ID_SI@$VALUE_TYP_ID" +
                s"@$OBSERVATION_IDENTIFIER_CE_IDENTIFIER_ST@$OBSERVATION_IDENTIFIER_CE_TEXT_ST@$OBSERVATION_IDENTIFIER_CE_NAME_OF_CODING_SYS_ID@$OBSERVATION_IDENTIFIER_CE_ALT_IDENTIFIER_ST@$OBSERVATION_IDENTIFIER_CE_ALT_TEXT_ST@$OBSERVATION_IDENTIFIER_CE_ALT_NAME_OF_CODING_SYS_ID" +
                s"@$OBSERVATION_SUB_ID_ST@$OBSERVATION_VALUE@$UNITS_CE_IDENTIFIER_ST@$UNITS_CE_TEXT_ST@$UNITS_CE_NAME_OF_CODING_SYS_ID@$UNITS_CE_ALT_IDENTIFIER_ST" +
                s"@$UNITES_CE_ALT_TEXT_ST@$REFERENCE_RANGE_ST@$ABNORMAL_FLAGS_IS@$PROBABILITY_NM@$NATURE_OF_ABNORMAL_TEST_ID@$OBSERVATION_RESULT_STATUS_ID" +
                s"@$EFFECTIVE_DATE_OF_REFERENCE_RANGE_TS@$USER_DEFINED_ACCESS_CHECKS_ST@$DATETIME_OF_OBSERVATION_TS@$PRODUCERS_ID_CE@$RESPONSIBLE_OBSERVER_XCN@$OBSERVATION_METHOD_CE" +
                s"@$EQUIPMENT_INSTANCE_IDENTIFIER_EI@$DATETIME_OF_THE_ANALYSIS_TS@@@@"
              buf += mess
            }
          }
        }
        buf
      }
    }
  }

  def segMSHFieldExtract(messageString: String,msg: ORU_R01,fileName: String): scala.collection.mutable.ListBuffer[String] = {
    var buf = scala.collection.mutable.ListBuffer[String]()
    var DOMAIN=""

    val Message=messageString
    val msh = msg.getMSH
    val Field_Separator_ST = msh.getFieldSeparator.getValue
    val Encoding_char_ST = msh.getEncodingCharacters.getValue
    val SENDING_APPLCTN_HD_NMSPCEID_IS = msh.getSendingApplication.getHd1_NamespaceID.encode
    val SENDING_APPLCTN_HD_UNVRSL_ID_ST = msh.getSendingApplication.getHd2_UniversalID.encode
    val SENDING_APPLCTN_HD_UNVRSL_ID_TYP_ID = msh.getSendingApplication.getHd2_UniversalID.encode
    val SENDING_FACILITY_HD_NMSPCEID_IS = msh.getSendingFacility.getHd1_NamespaceID.encode
    val SENDING_FACILITY_HD_UNVRSL_ID_ST = msh.getSendingFacility.getHd2_UniversalID.encode
    val SENDING_FACILITY_HD_UNVRSL_ID_TYP_ID = msh.getSendingFacility.getHd3_UniversalIDType.encode
    val RECCVNG_FACILITY_HD_NMSPCEID_IS = msh.getReceivingFacility.getNamespaceID.encode
    val RECCVNG_FACILITY_HD_UNVRSL_ID_ST = msh.getReceivingFacility.getUniversalID.encode
    val RECCVNG_FACILITY_HD_UNVRSL_ID_TYP_ID = msh.getReceivingFacility.getHd3_UniversalIDType.encode
    val DATE_TIME_MESSAGE_TS = msh.getDateTimeOfMessage.getTime.encode()
    val DATE_TIME_MESSAGE_DEGREE_OF_PRECISION = msh.getDateTimeOfMessage.getDegreeOfPrecision.encode
    val SECURITY_ST = msh.getSecurity.encode
    val MESSAGE_TYP_MSG_MESSAGE_CODE_ID = msh.getMessageType.getMsg1_MessageCode.encode
    val MESSAGE_TYP_MSG_TRIGGER_EVNT_ID = msh.getMessageType.getTriggerEvent.encode
    val MESSAGE_TYP_MSG_MESSAGE_STRUCTURE_ID = msh.getMessageType.getMessageStructure.encode
    val MESSAGE_CNTRL_ID_ST = msh.getMessageControlID.encode
    val PROCESSING_ID_PT = msh.getProcessingID.getPt1_ProcessingID.encode
    val VERSION_ID_VID_ID = msh.getVersionID.getVid1_VersionID.encode
    val SEQ_NBR_NM = msh.getSequenceNumber.encode()
    val CONTINUATION_POINTER_ST = msh.getContinuationPointer.encode
    val ACCPT_ACKNLDGMNT_TYP_ID = msh.getAcceptAcknowledgmentType.encode
    val APPLCTN_ACKNLDGMNT_TYP_ID = msh.getApplicationAcknowledgmentType.encode
    val COUNTRY_CD = msh.getCountryCode.encode
    val CHARCTER_SET = msh.getCharacterSet().mkString
    val ALT_CHAR_SET_HNDLNG_SCHME_ID = msh.getAlternateCharacterSetHandlingScheme.encode


    //Patient Segment Columns
    val patientInfo = msg.getPATIENT_RESULT.getPATIENT.getPID

    var DERIVED_PATIENT_IDENTIFIER=""

    val SET_ID_PID_SI = patientInfo.getSetIDPID.encode()
    val PATIENT_ID_CX_IDENTIFIER_NBR_ID = patientInfo.getPatientID.getCx1_IDNumber.encode
    val PATIENT_ID_LIST_CX_ID_NBR_ST = patientInfo.getPatientIdentifierList.map(x => x.getIDNumber.encode).mkString
    val PATIENT_ID_LIST_CX_CHK_DIGIT_ST = patientInfo.getPatientIdentifierList.map(x => x.getCheckDigit.encode).mkString
    val PATIENT_ID_LIST_CX_Check_Digit_Scheme_ID = patientInfo.getPatientIdentifierList.map(x => x.getCheckDigitScheme.encode).mkString
    val PATIENT_ID_LIST_CX_Assigning_Authority_ID = patientInfo.getPatientIdentifierList.map(x => x.getAssigningAuthority.encode()).mkString
    val PATIENT_ID_LIST_CX_Identifier_Typ_CD_ID = patientInfo.getPatientIdentifierList.map(x => x.getIdentifierTypeCode.encode).mkString
    val ALT_PATIENT_ID_CX_ID_NBR_ST = patientInfo.getAlternatePatientIDPID.map(x => x.getIDNumber.encode).mkString
    val ALT_PATIENT_ID_CX_Identifier_Typ_CD_ID = patientInfo.getAlternatePatientIDPID.map(x => x.getIdentifierTypeCode.encode).mkString
    val PATIENT_NAME_XPN_FAM_NM_FN = patientInfo.getPatientName.map(x => x.getFamilyName.getFn1_Surname.encode).mkString
    val PATIENT_NAME_XPN_GIVEN_NM_ST = patientInfo.getPatientName.map(x => x.getGivenName.encode).mkString
    val PATIENT_NAME_XPN_NAME_TYP_CD_ID = patientInfo.getPatientName.map(x => x.getNameTypeCode.encode).mkString
    val DATE_OF_BIRTH_TS = patientInfo.getDateTimeOfBirth.getTime.encode()
    val ADMINISTRATIVE_SEX_IS = patientInfo.getAdministrativeSex.encode
    val PATIENT_ALIAS_XPN = patientInfo.getPatientAlias.map(x => x.getFamilyName.getFn1_Surname.encode).mkString
    val PATIENT_RACE_CE_IDENTIFIER_ST = patientInfo.getRace.map(x => x.getIdentifier.encode).mkString
    val PATIENT_RACE_CE_TEXT_ST = patientInfo.getRace.map(x => x.getText.encode).mkString
    val PATIENT_RACE_CE_NAME_OF_CODING_SYS_ID = patientInfo.getRace.map(x => x.getNameOfCodingSystem.encode).mkString
    val PATIENT_ADDR_XAD_STREET_ADDR_ST = patientInfo.getPatientAddress.map(x => x.getStreetAddress.encode()).mkString
    val PATIENT_ADDR_XAD_OTHER_DESIGNATION_ST = patientInfo.getPatientAddress.map(x => x.getOtherDesignation.encode).mkString
    val PATIENT_ADDR_XAD_CITY_ST = patientInfo.getPatientAddress.map(x => x.getCity.encode).mkString
    val PATIENT_ADDR_XAD_ST_OR_PROVINCE_ST = patientInfo.getPatientAddress.map(x => x.getStateOrProvince.encode).mkString
    val PATIENT_ADDR_XAD_ST_POSTAL_CD_ST = patientInfo.getPatientAddress.map(x => x.getZipOrPostalCode.encode).mkString
    val PATIENT_ADDR_XAD_ST_ADDR_TYPE_ID = patientInfo.getPatientAddress.map(x => x.getAddressType.encode).mkString
    val HOME_PHN_NBR_TN = patientInfo.getPhoneNumberHome.map(x => x.getTelephoneNumber.encode).mkString
    val BUSINESS_PHN_NBR_TN = patientInfo.getPhoneNumberBusiness.map(x => x.getTelephoneNumber).mkString
    val Primary_LANG = patientInfo.getPid15_PrimaryLanguage.encode()
    val MARTIAL_STATUS = patientInfo.getMaritalStatus.encode()
    val RELIGION = patientInfo.getReligion.encode()
    val PATIENT_ACCOUNT_NBR_ST = patientInfo.getPatientAccountNumber.encode()
    val SSN_NBR_ST = patientInfo.getSSNNumberPatient.encode
    val DRIVER_LICEENSE_NBR_DLN = patientInfo.getDriverSLicenseNumberPatient.getLicenseNumber.encode
    val MOTHERS_IDENTIFIER_CX = patientInfo.getMotherSIdentifier.map(x => x.getIDNumber).mkString
    val ETHNIC_GRP_CE = patientInfo.getEthnicGroup.map(x => x.getIdentifier.encode).mkString
    val BIRTH_PLACE_ST = patientInfo.getBirthPlace.encode
    val MULTIPLE_BIRTH_INDICATOR_ID = patientInfo.getMultipleBirthIndicator.encode
    val BIRTH_ORDER_NM = patientInfo.getBirthOrder.encode()
    val CITIZENSHIP_CE = patientInfo.getCitizenship.map(x => x.getCe1_Identifier.encode).mkString
    val VETERANS_MILITARY_STATUS = patientInfo.getVeteransMilitaryStatus.encode()
    val NATIONALITY = patientInfo.getNationality.encode()
    val PATIENT_DEATH_DATE_AND_TIME_TS = patientInfo.getPatientDeathDateAndTime.getTime.encode()
    val PATIENT_DEATH_IND_ID = patientInfo.getPatientDeathIndicator.encode
    val IDENTIFY_UNKNOWN_INDICATOR_ID = patientInfo.getIdentityUnknownIndicator.encode
    val IDENTIFIER_RELIABILITY_CD_IS = patientInfo.getPid32_IdentityReliabilityCode.map(x => x.encode).mkString
    val LAST_UPDT_DATETIME_TS = patientInfo.getLastUpdateDateTime.getTime.encode()
    val LAST_UPDT_FACILITY_HD = patientInfo.getLastUpdateFacility.encode()
    val SPECIES_CD_CE = patientInfo.getSpeciesCode.encode()
    val BREED_CD_CE = patientInfo.getBreedCode.encode()
    val STRAIN_ST = patientInfo.getStrain.encode
    val PROD_CLASS_CD_CE = patientInfo.getProductionClassCode.encode()
    val TRIBAL_CITIZENSHIP_CD_CWE = patientInfo.getTribalCitizenship.mkString

    if(PATIENT_ID_LIST_CX_ID_NBR_ST.equals("")){
      DERIVED_PATIENT_IDENTIFIER=ALT_PATIENT_ID_CX_ID_NBR_ST
    }else{
      DERIVED_PATIENT_IDENTIFIER=PATIENT_ID_LIST_CX_ID_NBR_ST
    }
    if(SENDING_FACILITY_HD_UNVRSL_ID_ST.equals("Quest Diagnostics")){
      DOMAIN="QUESTDIA"
    }else if(SENDING_FACILITY_HD_UNVRSL_ID_ST.equals("LC")){
      DOMAIN="LABCORPDIA"
    }
    val SOURCE_CODE="SDR"

    /*val mes = s"$DERIVED_PATIENT_IDENTIFIER@$Field_Separator_ST@$Encoding_char_ST@$SENDING_APPLCTN_HD_NMSPCEID_IS@$SENDING_APPLCTN_HD_UNVRSL_ID_ST@$SENDING_APPLCTN_HD_UNVRSL_ID_TYP_ID@$SENDING_FACILITY_HD_NMSPCEID_IS" +
      s"@$SENDING_FACILITY_HD_UNVRSL_ID_ST@$SENDING_FACILITY_HD_UNVRSL_ID_TYP_ID@$RECCVNG_FACILITY_HD_NMSPCEID_IS@$RECCVNG_FACILITY_HD_UNVRSL_ID_ST@$RECCVNG_FACILITY_HD_UNVRSL_ID_TYP_ID@$DATE_TIME_MESSAGE_TS" +
      s"@$DATE_TIME_MESSAGE_DEGREE_OF_PRECISION@$SECURITY_ST@$MESSAGE_TYP_MSG_MESSAGE_CODE_ID@$MESSAGE_TYP_MSG_TRIGGER_EVNT_ID@$MESSAGE_TYP_MSG_MESSAGE_STRUCTURE_ID@$MESSAGE_CNTRL_ID_ST" +
      s"@$PROCESSING_ID_PT@$VERSION_ID_VID_ID@$SEQ_NBR_NM@$CONTINUATION_POINTER_ST@$ACCPT_ACKNLDGMNT_TYP_ID@$APPLCTN_ACKNLDGMNT_TYP_ID" +
      s"@$COUNTRY_CD@$CHARCTER_SET@$ALT_CHAR_SET_HNDLNG_SCHME_ID@$SET_ID_PID_SI@$PATIENT_ID_CX_IDENTIFIER_NBR_ID@$PATIENT_ID_LIST_CX_ID_NBR_ST" +
      s"@$PATIENT_ID_LIST_CX_CHK_DIGIT_ST@$PATIENT_ID_LIST_CX_Check_Digit_Scheme_ID@$PATIENT_ID_LIST_CX_Assigning_Authority_ID@$PATIENT_ID_LIST_CX_Identifier_Typ_CD_ID@$ALT_PATIENT_ID_CX_ID_NBR_ST@$ALT_PATIENT_ID_CX_Identifier_Typ_CD_ID" +
      s"@$PATIENT_NAME_XPN_FAM_NM_FN@$PATIENT_NAME_XPN_GIVEN_NM_ST@$PATIENT_NAME_XPN_NAME_TYP_CD_ID@$DATE_OF_BIRTH_TS@$ADMINISTRATIVE_SEX_IS@$PATIENT_ALIAS_XPN" +
      s"@$PATIENT_RACE_CE_IDENTIFIER_ST@$PATIENT_RACE_CE_TEXT_ST@$PATIENT_RACE_CE_NAME_OF_CODING_SYS_ID@$PATIENT_ADDR_XAD_STREET_ADDR_ST@$PATIENT_ADDR_XAD_OTHER_DESIGNATION_ST@$PATIENT_ADDR_XAD_CITY_ST" +
      s"@$PATIENT_ADDR_XAD_ST_OR_PROVINCE_ST@$PATIENT_ADDR_XAD_ST_POSTAL_CD_ST@$PATIENT_ADDR_XAD_ST_ADDR_TYPE_ID@$HOME_PHN_NBR_TN@$BUSINESS_PHN_NBR_TN@$Primary_LANG" +
      s"@$MARTIAL_STATUS@$RELIGION@$PATIENT_ACCOUNT_NBR_ST@$SSN_NBR_ST@$DRIVER_LICEENSE_NBR_DLN@$MOTHERS_IDENTIFIER_CX" +
      s"@$ETHNIC_GRP_CE@$BIRTH_PLACE_ST@$MULTIPLE_BIRTH_INDICATOR_ID@$BIRTH_ORDER_NM@$CITIZENSHIP_CE@$VETERANS_MILITARY_STATUS" +
      s"@$NATIONALITY@$PATIENT_DEATH_DATE_AND_TIME_TS@$PATIENT_DEATH_IND_ID@$IDENTIFY_UNKNOWN_INDICATOR_ID@$IDENTIFIER_RELIABILITY_CD_IS@$LAST_UPDT_DATETIME_TS" +
      s"@$LAST_UPDT_FACILITY_HD@$SPECIES_CD_CE@$BREED_CD_CE@$STRAIN_ST@$PROD_CLASS_CD_CE@$TRIBAL_CITIZENSHIP_CD_CWE@$Message@@@@@@@@$SOURCE_CODE@$DOMAIN"*/

    val mes = s"$DERIVED_PATIENT_IDENTIFIER&&$Field_Separator_ST&&$Encoding_char_ST&&$SENDING_APPLCTN_HD_NMSPCEID_IS&&$SENDING_APPLCTN_HD_UNVRSL_ID_ST&&$SENDING_APPLCTN_HD_UNVRSL_ID_TYP_ID&&$SENDING_FACILITY_HD_NMSPCEID_IS" +
      s"&&$SENDING_FACILITY_HD_UNVRSL_ID_ST&&$SENDING_FACILITY_HD_UNVRSL_ID_TYP_ID&&$RECCVNG_FACILITY_HD_NMSPCEID_IS&&$RECCVNG_FACILITY_HD_UNVRSL_ID_ST&&$RECCVNG_FACILITY_HD_UNVRSL_ID_TYP_ID&&$DATE_TIME_MESSAGE_TS" +
      s"&&$DATE_TIME_MESSAGE_DEGREE_OF_PRECISION&&$SECURITY_ST&&$MESSAGE_TYP_MSG_MESSAGE_CODE_ID&&$MESSAGE_TYP_MSG_TRIGGER_EVNT_ID&&$MESSAGE_TYP_MSG_MESSAGE_STRUCTURE_ID&&$MESSAGE_CNTRL_ID_ST" +
      s"&&$PROCESSING_ID_PT&&$VERSION_ID_VID_ID&&$SEQ_NBR_NM&&$CONTINUATION_POINTER_ST&&$ACCPT_ACKNLDGMNT_TYP_ID&&$APPLCTN_ACKNLDGMNT_TYP_ID" +
      s"&&$COUNTRY_CD&&$CHARCTER_SET&&$ALT_CHAR_SET_HNDLNG_SCHME_ID&&$SET_ID_PID_SI&&$PATIENT_ID_CX_IDENTIFIER_NBR_ID&&$PATIENT_ID_LIST_CX_ID_NBR_ST" +
      s"&&$PATIENT_ID_LIST_CX_CHK_DIGIT_ST&&$PATIENT_ID_LIST_CX_Check_Digit_Scheme_ID&&$PATIENT_ID_LIST_CX_Assigning_Authority_ID&&$PATIENT_ID_LIST_CX_Identifier_Typ_CD_ID&&$ALT_PATIENT_ID_CX_ID_NBR_ST&&$ALT_PATIENT_ID_CX_Identifier_Typ_CD_ID" +
      s"&&$PATIENT_NAME_XPN_FAM_NM_FN&&$PATIENT_NAME_XPN_GIVEN_NM_ST&&$PATIENT_NAME_XPN_NAME_TYP_CD_ID&&$DATE_OF_BIRTH_TS&&$ADMINISTRATIVE_SEX_IS&&$PATIENT_ALIAS_XPN" +
      s"&&$PATIENT_RACE_CE_IDENTIFIER_ST&&$PATIENT_RACE_CE_TEXT_ST&&$PATIENT_RACE_CE_NAME_OF_CODING_SYS_ID&&$PATIENT_ADDR_XAD_STREET_ADDR_ST&&$PATIENT_ADDR_XAD_OTHER_DESIGNATION_ST&&$PATIENT_ADDR_XAD_CITY_ST" +
      s"&&$PATIENT_ADDR_XAD_ST_OR_PROVINCE_ST&&$PATIENT_ADDR_XAD_ST_POSTAL_CD_ST&&$PATIENT_ADDR_XAD_ST_ADDR_TYPE_ID&&$HOME_PHN_NBR_TN&&$BUSINESS_PHN_NBR_TN&&$Primary_LANG" +
      s"&&$MARTIAL_STATUS&&$RELIGION&&$PATIENT_ACCOUNT_NBR_ST&&$SSN_NBR_ST&&$DRIVER_LICEENSE_NBR_DLN&&$MOTHERS_IDENTIFIER_CX" +
      s"&&$ETHNIC_GRP_CE&&$BIRTH_PLACE_ST&&$MULTIPLE_BIRTH_INDICATOR_ID&&$BIRTH_ORDER_NM&&$CITIZENSHIP_CE&&$VETERANS_MILITARY_STATUS" +
      s"&&$NATIONALITY&&$PATIENT_DEATH_DATE_AND_TIME_TS&&$PATIENT_DEATH_IND_ID&&$IDENTIFY_UNKNOWN_INDICATOR_ID&&$IDENTIFIER_RELIABILITY_CD_IS&&$LAST_UPDT_DATETIME_TS" +
      s"&&$LAST_UPDT_FACILITY_HD&&$SPECIES_CD_CE&&$BREED_CD_CE&&$STRAIN_ST&&$PROD_CLASS_CD_CE&&$TRIBAL_CITIZENSHIP_CD_CWE&&$Message&&&&&&&&&&&&&&&&$SOURCE_CODE&&$DOMAIN&&$fileName&&&&&&&&&&&&&&&&&&&&&&"


    buf += mes
    buf
  }

  def segOBRFieldExtract(msg: ORU_R01): scala.collection.mutable.ListBuffer[String] = {
    var buf = scala.collection.mutable.ListBuffer[String]()

    val patientInfo = msg.getPATIENT_RESULT.getPATIENT.getPID

    val PATIENT_ID_LIST_CX_ID_NBR_ST = patientInfo.getPatientIdentifierList.map(x => x.getIDNumber.encode).mkString
    val PATIENT_ACCOUNT_NBR_ST = patientInfo.getPatientAccountNumber.encode()
    val MESSAGE_CNTRL_ID_ST = msg.getMSH.getMessageControlID.encode
    val ALT_PATIENT_ID_CX_ID_NBR_ST = patientInfo.getAlternatePatientIDPID.map(x => x.getIDNumber.encode).mkString


    val obrList = msg.getPATIENT_RESULT.getORDER_OBSERVATIONAll
    val obrNum = obrList.size()


    for (x <- 0 until obrNum) {
      //OBR Columns
      val obrIndex = obrList.get(x).getOBR
      val OBR_SET_ID_SI = obrIndex.getSetIDOBR.encode()
      val PLACE_ORDER_NUMBER_EI_ENTITY_IDENTIFIER_ST = obrIndex.getPlacerOrderNumber.getEi1_EntityIdentifier.encode
      val PLACE_ORDER_NUMBER_EI_NAMESPACE_ID_IS = obrIndex.getPlacerOrderNumber.getEi2_NamespaceID.encode
      val PLACE_ORDER_NUMBER_EI_UNIVERSAL_ID_ST = obrIndex.getPlacerOrderNumber.getEi3_UniversalID.encode
      val PLACE_ORDER_NUMBER_EI_UNIVERSAL_ID_TYP_ID = obrIndex.getPlacerOrderNumber.getEi4_UniversalIDType.encode
      val FILLER_ORDER_NBR_EI_ENTITY_IDENTIFIER_ST = obrIndex.getFillerOrderNumber.getEi1_EntityIdentifier.encode
      val FILLER_ORDER_NBR_EI_ST_NAMESPACE_ID_IS = obrIndex.getFillerOrderNumber.getEi2_NamespaceID.encode
      val FILLER_ORDER_NBR_EI_ST_UNIVERSAL_ID_ST = obrIndex.getFillerOrderNumber.getEi3_UniversalID.encode
      val FILLER_ORDER_NBR_EI_ST_UNIVERSAL_ID_TYPE_ID = obrIndex.getFillerOrderNumber.getEi4_UniversalIDType.encode
      val UNIVERSAL_SERVICE_IDENTIFIER_CE_IDENTIFER_ST = obrIndex.getUniversalServiceIdentifier.getCe1_Identifier.encode
      val UNIVERSAL_SERVICE_IDENTIFIER_CE_TEXT_ST = obrIndex.getUniversalServiceIdentifier.getCe2_Text.encode
      val UNIVERSAL_SERVICE_IDENTIFIER_CE_NAME_OF_CODING_SYSTEM_ID = obrIndex.getUniversalServiceIdentifier.getCe3_NameOfCodingSystem.encode
      val UNIVERSAL_SERVICE_IDENTIFIER_CE_ALTERNATE_IDENTIFIER_ST = obrIndex.getUniversalServiceIdentifier.getCe4_AlternateIdentifier.encode
      val UNIVERSAL_SERVICE_IDENTIFIER_CE_ALTERNATE_TEXT_ST = obrIndex.getUniversalServiceIdentifier.getCe5_AlternateText.encode
      val UNIVERSAL_SERVICE_IDENTIFIER_CE_NAME_OF_ALTERNATE_CODING_SYSTEM_ID = obrIndex.getUniversalServiceIdentifier.getCe6_NameOfAlternateCodingSystem.encode
      val OBR_PRIOROTY_ID = obrIndex.getObr5_PriorityOBR.encode
      val REQUESTED_DATETIME_TS = obrIndex.getRequestedDateTime.getTime.encode()
      val OBSERVATION_DATETIME_TS = obrIndex.getObservationDateTime.getTime.encode()
      val OBSERVATION_END_DATETIME_TS = obrIndex.getObservationEndDateTime.getTime.encode()
      val COLLECTION_VOLUME_QUANTITY_NM = obrIndex.getObr9_CollectionVolume.getCq1_Quantity.encode()
      val COLLECTION_VOLUME_UNITS_CE = obrIndex.getObr9_CollectionVolume.getCq2_Units.encode()
      val COLLECTOR_IDENTFIER_XCN = obrIndex.getObr10_CollectorIdentifier.map(x => x.getIDNumber.encode).mkString
      val SPECIMEN_ACTION_CODE_ID = obrIndex.getObr11_SpecimenActionCode.encode
      val DANGER_CODE_CE = obrIndex.getObr12_DangerCode.encode()
      val RELEVANT_CLINICAL_INFORMATION_ST = obrIndex.getRelevantClinicalInformation.encode
      val SPECIMEN_RECEIVED_DATETIME_TS = obrIndex.getSpecimenReceivedDateTime.getTime.encode()
      val SPECIMEN_SOURCE_SPS = obrIndex.getSpecimenSource.encode()
      val ORDERING_PROVIDER_XCN_ID_NUMBER_ST = obrIndex.getOrderingProvider.map(x => x.getIDNumber.encode).mkString
      val ORDERING_PROVIDER_XCN_FAMILY_NAME_FN = obrIndex.getOrderingProvider.map(x => x.getFamilyName.getFn1_Surname.encode).mkString
      val ORDERING_PROVIDER_XCN_GIVEN_NAME_ST = obrIndex.getOrderingProvider.map(x => x.getGivenName.encode).mkString
      val ORDERING_PROVIDER_XCN_MIDDLE_INITIAL_OR_NAME_ST = obrIndex.getOrderingProvider.map(x => x.getXcn4_SecondAndFurtherGivenNamesOrInitialsThereof.encode).mkString
      val ORDERING_PROVIDER_XCN_SOURCE_TABLE_IS = obrIndex.getOrderingProvider.map(x => x.getSourceTable.encode).mkString
      val ORDERING_PROVIDER_XCN_ASSIGNING_AUTHORITY_HD = obrIndex.getOrderingProvider.map(x => x.getAssigningAuthority.encode()).mkString
      val ORDERING_PROVIDER_XCN_NAMESPACE_ID_IS = obrIndex.getOrderingProvider.map(x => x.getXcn10_NameTypeCode.encode).mkString
      val ORDER_CALLBACK_PHOBE_NUMBER_XTN_EMAIL_ADDR_ST = obrIndex.getOrderCallbackPhoneNumber.map(x => x.getEmailAddress.encode).mkString
      val ORDER_CALLBACK_PHOBE_NUMBER_XTN_AREA_CITY_CODE_NM = obrIndex.getOrderCallbackPhoneNumber.map(x => x.getXtn6_AreaCityCode.encode()).mkString
      val ORDER_CALLBACK_PHOBE_NUMBER_XTN_LOCAL_NUMBER_NM = obrIndex.getOrderCallbackPhoneNumber.map(x => x.getXtn7_LocalNumber.encode()).mkString
      val PLACER_FIELD_1_ST = obrIndex.getPlacerField1.encode
      val PLACER_FIELD_2_ST = obrIndex.getPlacerField2.encode
      val FILLER_FIELD_1_ST = obrIndex.getFillerField1.encode
      val FILLER_FIELD_2_ST = obrIndex.getFillerField2.encode
      val RESULTS_RPT_STATUS_CHANGE_DATETIME_TS = obrIndex.getResultsRptStatusChngDateTime.getTime.encode()
      val CHARGE_TO_PRACTICE_MOC = obrIndex.getChargeToPractice.encode()
      val DIAGNOSTIC_SERV_SECT_ID_ID = obrIndex.getDiagnosticServSectID.encode
      val RESULT_STATUS_ID = obrIndex.getResultStatus.encode
      val PARENT_RESULT_PRL = obrIndex.getParentResult.encode()
      val QUANTITY_TIMING_TQ_QUANTITY_CQ = obrIndex.getObr27_QuantityTiming.map(x => x.getTq1_Quantity.encode()).mkString
      val QUANTITY_TIMING_TQ_INTERVAL_RI = obrIndex.getObr27_QuantityTiming.map(x => x.getTq2_Interval.encode()).mkString
      val QUANTITY_TIMING_TQ_DURATION_ST = obrIndex.getObr27_QuantityTiming.map(x => x.getDuration.encode).mkString
      val QUANTITY_TIMING_TQ_START_DATETIME_TS = obrIndex.getObr27_QuantityTiming.map(x => x.getStartDateTime.getTime.encode()).mkString
      val QUANTITY_TIMING_TQ_END_DATETIME_TS = obrIndex.getObr27_QuantityTiming.map(x => x.getEndDateTime.getTime.encode()).mkString
      val RESULTS_COPIES_TO_XCN = obrIndex.getObr28_ResultCopiesTo.mkString
      val PARENT_EIP = obrIndex.getObr29_ParentNumber.encode()
      var DERIVED_PATIENT_IDENTIFIER=""

      if(PATIENT_ID_LIST_CX_ID_NBR_ST.equals("")){
        DERIVED_PATIENT_IDENTIFIER=ALT_PATIENT_ID_CX_ID_NBR_ST
      }else{
        DERIVED_PATIENT_IDENTIFIER=PATIENT_ID_LIST_CX_ID_NBR_ST
      }

      //FT1 Columns

      val ft1Index = obrList.get(x).getFT1

      val FT1_SET_ID_SI = ft1Index.getSetIDFT1.encode()
      val TRANSACTION_ID_ST = ft1Index.getTransactionID.encode
      val TRANSACTION_BATCH_ID_ST = ft1Index.getTransactionBatchID.encode
      val TRANSACTION_DATE_DR_RANGE_START_DATETIME_TS = ft1Index.getTransactionDate.getDr1_RangeStartDateTime.getTime.encode()
      val TRANSACTION_DATE_DR_RANGE_END_DATETIME_TS = ft1Index.getTransactionDate.getDr2_RangeEndDateTime.getTime.encode()
      val TRANSACTION_POSTING_DATE_TS = ft1Index.getTransactionPostingDate.getTime.encode()
      val TRANSACTION_TYP_IS = ft1Index.getTransactionType.encode
      val TRANSACTION_CD_CE_IDENTIFIER_ID = ft1Index.getTransactionCode.getCe1_Identifier.encode
      val TRANSACTION_CD_CE_TEXT_SE = ft1Index.getTransactionCode.getCe2_Text.encode
      val TRANSACTION_CD_CE_NAME_OF_CODING_SYS_ST = ft1Index.getTransactionCode.getCe3_NameOfCodingSystem.encode
      val TRANSACTION_CD_CE_ALT_IDENTIFIER_ID = ft1Index.getTransactionCode.getCe4_AlternateIdentifier.encode
      val TRANSACTION_CD_CE_ALT_TEXT_SE = ft1Index.getTransactionCode.getCe5_AlternateText.encode
      val TRANSACTION_CD_CE_ALT_NAME_OF_CODING_SYS_ST = ft1Index.getTransactionCode.getCe6_NameOfAlternateCodingSystem.encode
      val TRANSACTION_DESC_ST = ft1Index.getTransactionDescription.encode
      val ALT_TRANSACTION_DESC_ST = ft1Index.getFt19_TransactionDescriptionAlt.encode
      val TRANSACTION_QTY_NM = ft1Index.getFt110_TransactionQuantity.encode()
      val TRANSACTION_AMT_EXTNDED_CP = ft1Index.getFt111_TransactionAmountExtended.encode()
      val TRANSACTION_AMT_UNIT_CP = ft1Index.getFt112_TransactionAmountUnit.encode()
      val DEPT_CD_CE = ft1Index.getDepartmentCode.encode()
      val INSURANCE_PLAN_ID_CE_IDENTIFIER_ID = ft1Index.getFt114_InsurancePlanID.getCe1_Identifier.encode
      val INSURANCE_PLAN_ID_CE_TEXT_SE = ft1Index.getFt114_InsurancePlanID.getCe2_Text.encode
      val INSURANCE_PLAN_ID_CE_NAME_OF_CODING_SYS_ST = ft1Index.getFt114_InsurancePlanID.getNameOfCodingSystem.encode
      val INSURANCE_PLAN_ID_CE_ALT_IDENTIFIER_ID = ft1Index.getFt114_InsurancePlanID.getAlternateIdentifier.encode
      val INSURANCE_PLAN_ID_CE_ALT_TEXT_SE = ft1Index.getFt114_InsurancePlanID.getAlternateText.encode
      val INSURANCE_PLAN_ID_CE_ALT_NAME_OF_CODING_SYS_ST = ft1Index.getFt114_InsurancePlanID.getCe6_NameOfAlternateCodingSystem.encode
      val INSURANCE_AMT_CP = ft1Index.getFt115_InsuranceAmount.encode()
      val ASSGND_PTNT_LOCATION_PL = ft1Index.getFt116_AssignedPatientLocation.encode()
      val FEE_SCHDULE_IS = ft1Index.getFt117_FeeSchedule.encode
      val PATIENT_TYP_IS = ft1Index.getFt118_PatientType.encode
      val PERFORMED_BY_CODE_XCN = ft1Index.getPerformedByCode.mkString
      val ORDERED_BY_CODE_XCN = ft1Index.getOrderedByCode.mkString
      val UNIT_COST_CP = ft1Index.getUnitCost.encode()
      val FILLER_ORDER_NUMBER = ft1Index.getFillerOrderNumber.encode()
      val ENTERED_BY_CODE = ft1Index.getEnteredByCode.mkString
      val PROC_CD_CE_IDENTIFIER_ID = ft1Index.getProcedureCode.getCe1_Identifier.encode
      val PROC_CD_CE_TEXT_SE = ft1Index.getProcedureCode.getCe2_Text.encode
      val PROC_CD_CE_TEXT_SE_NAME_OF_CODING_SYS_ST = ft1Index.getProcedureCode.getCe3_NameOfCodingSystem.encode
      val PROC_CD_CE_ALT_IDENTIFIER_ID = ft1Index.getProcedureCode.getCe4_AlternateIdentifier.encode
      val PROC_CD_CE_ALT_TEXT_SE = ft1Index.getProcedureCode.getAlternateText.encode
      val PROC_CD_CE_TEXT_SE_ALT_NAME_OF_CODING_SYS_ST = ft1Index.getProcedureCode.getNameOfAlternateCodingSystem.encode
      val PROC_CD_MODIFIER_CE_IDENTIFIER_ID = ft1Index.getFt126_ProcedureCodeModifier.map(x => x.getCe1_Identifier.encode).mkString
      val PROC_CD_MODIFIER_CE_TEXT_SE = ft1Index.getFt126_ProcedureCodeModifier.map(x => x.getCe2_Text.encode).mkString
      val PROC_CD_MODIFIER_CE_NAME_OF_CODING_SYS_ST = ft1Index.getFt126_ProcedureCodeModifier.map(x => x.getCe3_NameOfCodingSystem.encode).mkString
      val PROC_CD_MODIFIER_CE_ALT_IDENTIFIER_ID = ft1Index.getFt126_ProcedureCodeModifier.map(x => x.getCe4_AlternateIdentifier.encode).mkString
      val PROC_CD_MODIFIER_CE_ALT_TEXT_SE = ft1Index.getFt126_ProcedureCodeModifier.map(x => x.getCe5_AlternateText.encode).mkString
      val PROC_CD_MODIFIER_CE_ALT_NAME_OF_CODING_SYS_ST = ft1Index.getFt126_ProcedureCodeModifier.map(x => x.getCe6_NameOfAlternateCodingSystem.encode).mkString

      val mess = s"$DERIVED_PATIENT_IDENTIFIER@$PATIENT_ID_LIST_CX_ID_NBR_ST@$PATIENT_ACCOUNT_NBR_ST@$MESSAGE_CNTRL_ID_ST" +
        s"@$OBR_SET_ID_SI@$PLACE_ORDER_NUMBER_EI_ENTITY_IDENTIFIER_ST@$PLACE_ORDER_NUMBER_EI_NAMESPACE_ID_IS@$PLACE_ORDER_NUMBER_EI_UNIVERSAL_ID_ST@$PLACE_ORDER_NUMBER_EI_UNIVERSAL_ID_TYP_ID@$FILLER_ORDER_NBR_EI_ENTITY_IDENTIFIER_ST" +
        s"@$FILLER_ORDER_NBR_EI_ST_NAMESPACE_ID_IS@$FILLER_ORDER_NBR_EI_ST_UNIVERSAL_ID_ST@$FILLER_ORDER_NBR_EI_ST_UNIVERSAL_ID_TYPE_ID@$UNIVERSAL_SERVICE_IDENTIFIER_CE_IDENTIFER_ST@$UNIVERSAL_SERVICE_IDENTIFIER_CE_TEXT_ST@$UNIVERSAL_SERVICE_IDENTIFIER_CE_NAME_OF_CODING_SYSTEM_ID" +
        s"@$UNIVERSAL_SERVICE_IDENTIFIER_CE_ALTERNATE_IDENTIFIER_ST@$UNIVERSAL_SERVICE_IDENTIFIER_CE_ALTERNATE_TEXT_ST@$UNIVERSAL_SERVICE_IDENTIFIER_CE_NAME_OF_ALTERNATE_CODING_SYSTEM_ID@$OBR_PRIOROTY_ID@$REQUESTED_DATETIME_TS@$OBSERVATION_DATETIME_TS" +
        s"@$OBSERVATION_END_DATETIME_TS@$COLLECTION_VOLUME_QUANTITY_NM@$COLLECTION_VOLUME_UNITS_CE@$COLLECTOR_IDENTFIER_XCN@$SPECIMEN_ACTION_CODE_ID@$DANGER_CODE_CE" +
        s"@$RELEVANT_CLINICAL_INFORMATION_ST@$SPECIMEN_RECEIVED_DATETIME_TS@$SPECIMEN_SOURCE_SPS@$ORDERING_PROVIDER_XCN_ID_NUMBER_ST@$ORDERING_PROVIDER_XCN_FAMILY_NAME_FN@$ORDERING_PROVIDER_XCN_GIVEN_NAME_ST" +
        s"@$ORDERING_PROVIDER_XCN_MIDDLE_INITIAL_OR_NAME_ST@$ORDERING_PROVIDER_XCN_SOURCE_TABLE_IS@$ORDERING_PROVIDER_XCN_ASSIGNING_AUTHORITY_HD@$ORDERING_PROVIDER_XCN_NAMESPACE_ID_IS@$ORDER_CALLBACK_PHOBE_NUMBER_XTN_EMAIL_ADDR_ST@$ORDER_CALLBACK_PHOBE_NUMBER_XTN_AREA_CITY_CODE_NM" +
        s"@$ORDER_CALLBACK_PHOBE_NUMBER_XTN_LOCAL_NUMBER_NM@$PLACER_FIELD_1_ST@$PLACER_FIELD_2_ST@$FILLER_FIELD_1_ST@$FILLER_FIELD_2_ST@$RESULTS_RPT_STATUS_CHANGE_DATETIME_TS" +
        s"@$CHARGE_TO_PRACTICE_MOC@$DIAGNOSTIC_SERV_SECT_ID_ID@$RESULT_STATUS_ID@$PARENT_RESULT_PRL@$QUANTITY_TIMING_TQ_QUANTITY_CQ@$QUANTITY_TIMING_TQ_INTERVAL_RI" +
        s"@$QUANTITY_TIMING_TQ_DURATION_ST@$QUANTITY_TIMING_TQ_START_DATETIME_TS@$QUANTITY_TIMING_TQ_END_DATETIME_TS@$RESULTS_COPIES_TO_XCN@$PARENT_EIP@$FT1_SET_ID_SI" +
        s"@$TRANSACTION_ID_ST@$TRANSACTION_BATCH_ID_ST@$TRANSACTION_DATE_DR_RANGE_START_DATETIME_TS@$TRANSACTION_DATE_DR_RANGE_END_DATETIME_TS@$TRANSACTION_POSTING_DATE_TS@$TRANSACTION_TYP_IS" +
        s"@$TRANSACTION_CD_CE_IDENTIFIER_ID@$TRANSACTION_CD_CE_TEXT_SE@$TRANSACTION_CD_CE_NAME_OF_CODING_SYS_ST@$TRANSACTION_CD_CE_ALT_IDENTIFIER_ID@$TRANSACTION_CD_CE_ALT_TEXT_SE@$TRANSACTION_CD_CE_ALT_NAME_OF_CODING_SYS_ST" +
        s"@$TRANSACTION_DESC_ST@$ALT_TRANSACTION_DESC_ST@$TRANSACTION_QTY_NM@$TRANSACTION_AMT_EXTNDED_CP@$TRANSACTION_AMT_UNIT_CP@$DEPT_CD_CE" +
        s"@$INSURANCE_PLAN_ID_CE_IDENTIFIER_ID@$INSURANCE_PLAN_ID_CE_TEXT_SE@$INSURANCE_PLAN_ID_CE_NAME_OF_CODING_SYS_ST@$INSURANCE_PLAN_ID_CE_ALT_IDENTIFIER_ID@$INSURANCE_PLAN_ID_CE_ALT_TEXT_SE@$INSURANCE_PLAN_ID_CE_ALT_NAME_OF_CODING_SYS_ST" +
        s"@$INSURANCE_AMT_CP@$ASSGND_PTNT_LOCATION_PL@$FEE_SCHDULE_IS@$PATIENT_TYP_IS@$PERFORMED_BY_CODE_XCN@$ORDERED_BY_CODE_XCN" +
        s"@$UNIT_COST_CP@$FILLER_ORDER_NUMBER@$ENTERED_BY_CODE@$PROC_CD_CE_IDENTIFIER_ID@$PROC_CD_CE_TEXT_SE@$PROC_CD_CE_TEXT_SE_NAME_OF_CODING_SYS_ST" +
        s"@$PROC_CD_CE_ALT_IDENTIFIER_ID@$PROC_CD_CE_ALT_TEXT_SE@$PROC_CD_CE_TEXT_SE_ALT_NAME_OF_CODING_SYS_ST@$PROC_CD_MODIFIER_CE_IDENTIFIER_ID@$PROC_CD_MODIFIER_CE_TEXT_SE@$PROC_CD_MODIFIER_CE_NAME_OF_CODING_SYS_ST" +
        s"@$PROC_CD_MODIFIER_CE_ALT_IDENTIFIER_ID@$PROC_CD_MODIFIER_CE_ALT_TEXT_SE@$PROC_CD_MODIFIER_CE_ALT_NAME_OF_CODING_SYS_ST@$ALT_PATIENT_ID_CX_ID_NBR_ST"

      buf += mess
    }
    buf
  }

  def segFT1FieldExtract(msg: ORU_R01): scala.collection.mutable.ListBuffer[String] = {
    var buf = scala.collection.mutable.ListBuffer[String]()

    val patientInfo = msg.getPATIENT_RESULT.getPATIENT.getPID
    val PATIENT_ID_LIST_CX_ID_NBR_ST = patientInfo.getPatientIdentifierList.map(x => x.getIDNumber.encode).mkString
    val PATIENT_ACCOUNT_NBR_ST = patientInfo.getPatientAccountNumber.encode()


    val obrList = msg.getPATIENT_RESULT.getORDER_OBSERVATIONAll
    val obrNum = obrList.size()

    for (x <- 0 until obrNum) {
      val obrIndex = obrList.get(x).getOBR
      val OBR_SET_ID_SI = obrIndex.getSetIDOBR.encode()
      val FILLER_ORDER_NBR_EI_ENTITY_IDENTIFIER_ST = obrIndex.getFillerOrderNumber.getEi1_EntityIdentifier.encode
      val ft1Index = obrList.get(x).getFT1
      val FT1_SET_ID_SI = ft1Index.getSetIDFT1.encode()

      val ft1diagSize = ft1Index.getDiagnosisCodeFT1.size

      if (ft1diagSize > 0) {
        for (z <- 0 until ft1diagSize) {
          val ft1DiagCdIndex = ft1Index.getDiagnosisCodeFT1(z)
          val DIAG_CD_CE_IDENTIFIER_ID = ft1DiagCdIndex.getCe1_Identifier.encode
          val DIAG_CD_CE_TEXT_SE = ft1DiagCdIndex.getCe2_Text.encode
          val DIAG_CD_CE_NAME_OF_CODING_SYS_IS = ft1DiagCdIndex.getCe3_NameOfCodingSystem.encode
          val DIAG_CD_CE_ALT_IDENTIFIER_ID = ft1DiagCdIndex.getCe4_AlternateIdentifier.encode
          val DIAG_CD_CE_ALT_TEXT_SE = ft1DiagCdIndex.getCe5_AlternateText.encode
          val DIAG_CD_CE_ALT_NAME_OF_CODING_SYS_IS = ft1DiagCdIndex.getCe6_NameOfAlternateCodingSystem.encode

          val mess = s"$PATIENT_ID_LIST_CX_ID_NBR_ST@$PATIENT_ACCOUNT_NBR_ST@$FILLER_ORDER_NBR_EI_ENTITY_IDENTIFIER_ST@$OBR_SET_ID_SI@$FT1_SET_ID_SI@$DIAG_CD_CE_IDENTIFIER_ID" +
            s"@$DIAG_CD_CE_TEXT_SE@$DIAG_CD_CE_NAME_OF_CODING_SYS_IS@$DIAG_CD_CE_ALT_IDENTIFIER_ID@$DIAG_CD_CE_ALT_TEXT_SE@$DIAG_CD_CE_ALT_NAME_OF_CODING_SYS_IS"
          buf += mess
        }
      }
      else {
        val mess = s"$PATIENT_ID_LIST_CX_ID_NBR_ST@$PATIENT_ACCOUNT_NBR_ST@$FILLER_ORDER_NBR_EI_ENTITY_IDENTIFIER_ST@$OBR_SET_ID_SI@$FT1_SET_ID_SI@@@@@@@"
        buf += mess
      }
    }
    buf
  }

  def segOBXFieldExtract(msg: ORU_R01): scala.collection.mutable.ListBuffer[String]={
    var buf = scala.collection.mutable.ListBuffer[String]()

    val patientInfo = msg.getPATIENT_RESULT.getPATIENT.getPID
    val PATIENT_ID_LIST_CX_ID_NBR_ST = patientInfo.getPatientIdentifierList.map(x => x.getIDNumber.encode).mkString
    val PATIENT_ACCOUNT_NBR_ST = patientInfo.getPatientAccountNumber.encode()
    val ALT_PATIENT_ID_CX_ID_NBR_ST = patientInfo.getAlternatePatientIDPID.map(x => x.getIDNumber.encode).mkString


    val obrList = msg.getPATIENT_RESULT.getORDER_OBSERVATIONAll
    val obrNum = obrList.size()

    for (x <- 0 until obrNum) {
      val obrIndex = obrList.get(x).getOBR
      val OBR_SET_ID_SI = obrIndex.getSetIDOBR.encode()
      val FILLER_ORDER_NBR_EI_ENTITY_IDENTIFIER_ST = obrIndex.getFillerOrderNumber.getEi1_EntityIdentifier.encode
      val obxList = obrList.get(x).getOBSERVATIONAll
      val obxNum = obxList.size()

      for (y <- 0 until obxNum) {

        val obxIndex = obxList.get(y).getOBX
        val OBX_SET_ID_SI = obxIndex.getObx1_SetIDOBX.encode()
        val VALUE_TYP_ID = obxIndex.getObx2_ValueType.encode
        val OBSERVATION_IDENTIFIER_CE_IDENTIFIER_ST = obxIndex.getObx3_ObservationIdentifier.getCe1_Identifier.encode
        val OBSERVATION_IDENTIFIER_CE_TEXT_ST = obxIndex.getObx3_ObservationIdentifier.getCe2_Text.encode
        val OBSERVATION_IDENTIFIER_CE_NAME_OF_CODING_SYS_ID = obxIndex.getObx3_ObservationIdentifier.getCe3_NameOfCodingSystem.encode
        val OBSERVATION_IDENTIFIER_CE_ALT_IDENTIFIER_ST = obxIndex.getObx3_ObservationIdentifier.getCe4_AlternateIdentifier.encode
        val OBSERVATION_IDENTIFIER_CE_ALT_TEXT_ST = obxIndex.getObx3_ObservationIdentifier.getCe5_AlternateText.encode
        val OBSERVATION_IDENTIFIER_CE_ALT_NAME_OF_CODING_SYS_ID = obxIndex.getObx3_ObservationIdentifier.getCe6_NameOfAlternateCodingSystem.encode
        val OBSERVATION_SUB_ID_ST = obxIndex.getObx4_ObservationSubID.encode
        val OBSERVATION_VALUE = obxIndex.getObx5_ObservationValue(0).encode()
        val UNITS_CE_IDENTIFIER_ST = obxIndex.getObx6_Units.getCe1_Identifier.encode
        val UNITS_CE_TEXT_ST = obxIndex.getObx6_Units.getCe2_Text.encode
        val UNITS_CE_NAME_OF_CODING_SYS_ID = obxIndex.getObx6_Units.getCe3_NameOfCodingSystem.encode
        val UNITS_CE_ALT_IDENTIFIER_ST = obxIndex.getObx6_Units.getCe4_AlternateIdentifier.encode
        val UNITES_CE_ALT_TEXT_ST = obxIndex.getObx6_Units.getCe5_AlternateText.encode
        val REFERENCE_RANGE_ST = obxIndex.getObx7_ReferencesRange.encode
        val ABNORMAL_FLAGS_IS = obxIndex.getObx8_AbnormalFlags.map(x => x.encode).mkString
        val PROBABILITY_NM = obxIndex.getObx9_Probability.encode()
        val NATURE_OF_ABNORMAL_TEST_ID = obxIndex.getObx10_NatureOfAbnormalTest.map(x => x.encode).mkString
        val OBSERVATION_RESULT_STATUS_ID = obxIndex.getObx11_ObservationResultStatus.encode
        val EFFECTIVE_DATE_OF_REFERENCE_RANGE_TS = obxIndex.getObx12_EffectiveDateOfReferenceRange.getTime.encode()
        val USER_DEFINED_ACCESS_CHECKS_ST = obxIndex.getObx13_UserDefinedAccessChecks.encode
        val DATETIME_OF_OBSERVATION_TS = obxIndex.getObx14_DateTimeOfTheObservation.getTime.encode()
        val PRODUCERS_ID_CE = obxIndex.getObx15_ProducerSID.encode()
        val RESPONSIBLE_OBSERVER_XCN = obxIndex.getObx16_ResponsibleObserver.mkString
        val OBSERVATION_METHOD_CE = obxIndex.getObx17_ObservationMethod.mkString
        val EQUIPMENT_INSTANCE_IDENTIFIER_EI = obxIndex.getObx18_EquipmentInstanceIdentifier.mkString
        val DATETIME_OF_THE_ANALYSIS_TS = obxIndex.getObx19_DateTimeOfTheAnalysis.getTime.encode()

        var DERIVED_PATIENT_IDENTIFIER=""
        if(PATIENT_ID_LIST_CX_ID_NBR_ST.equals("")){
          DERIVED_PATIENT_IDENTIFIER=ALT_PATIENT_ID_CX_ID_NBR_ST
        }else{
          DERIVED_PATIENT_IDENTIFIER=PATIENT_ID_LIST_CX_ID_NBR_ST
        }

        val nteList = obxList.get(y).getNTEAll
        val nteSize = nteList.size()

        if (nteSize > 0) {
          for (z <- 0 until nteSize) {
            val NTE_SET_ID_SI = nteList.get(z).getNte1_SetIDNTE.encode()
            val SOURCE_OF_COMMENT_ID = nteList.get(z).getNte2_SourceOfComment.encode
            val COMMENT_FT = nteList.get(z).getNte3_Comment.mkString(" ")
            val COMMENT_TYPE_CE = nteList.get(z).getNte4_CommentType.encode()
            val mess = s"$DERIVED_PATIENT_IDENTIFIER@$PATIENT_ID_LIST_CX_ID_NBR_ST@$PATIENT_ACCOUNT_NBR_ST@$FILLER_ORDER_NBR_EI_ENTITY_IDENTIFIER_ST@$OBR_SET_ID_SI@$OBX_SET_ID_SI@$VALUE_TYP_ID" +
              s"@$OBSERVATION_IDENTIFIER_CE_IDENTIFIER_ST@$OBSERVATION_IDENTIFIER_CE_TEXT_ST@$OBSERVATION_IDENTIFIER_CE_NAME_OF_CODING_SYS_ID@$OBSERVATION_IDENTIFIER_CE_ALT_IDENTIFIER_ST@$OBSERVATION_IDENTIFIER_CE_ALT_TEXT_ST@$OBSERVATION_IDENTIFIER_CE_ALT_NAME_OF_CODING_SYS_ID" +
              s"@$OBSERVATION_SUB_ID_ST@$OBSERVATION_VALUE@$UNITS_CE_IDENTIFIER_ST@$UNITS_CE_TEXT_ST@$UNITS_CE_NAME_OF_CODING_SYS_ID@$UNITS_CE_ALT_IDENTIFIER_ST" +
              s"@$UNITES_CE_ALT_TEXT_ST@$REFERENCE_RANGE_ST@$ABNORMAL_FLAGS_IS@$PROBABILITY_NM@$NATURE_OF_ABNORMAL_TEST_ID@$OBSERVATION_RESULT_STATUS_ID" +
              s"@$EFFECTIVE_DATE_OF_REFERENCE_RANGE_TS@$USER_DEFINED_ACCESS_CHECKS_ST@$DATETIME_OF_OBSERVATION_TS@$PRODUCERS_ID_CE@$RESPONSIBLE_OBSERVER_XCN@$OBSERVATION_METHOD_CE" +
              s"@$EQUIPMENT_INSTANCE_IDENTIFIER_EI@$DATETIME_OF_THE_ANALYSIS_TS@$NTE_SET_ID_SI@$SOURCE_OF_COMMENT_ID@$COMMENT_FT@$COMMENT_TYPE_CE@$ALT_PATIENT_ID_CX_ID_NBR_ST"
            buf += mess
          }
        } else {
          val mess = s"$DERIVED_PATIENT_IDENTIFIER@$PATIENT_ID_LIST_CX_ID_NBR_ST@$PATIENT_ACCOUNT_NBR_ST@$FILLER_ORDER_NBR_EI_ENTITY_IDENTIFIER_ST@$OBR_SET_ID_SI@$OBX_SET_ID_SI@$VALUE_TYP_ID" +
            s"@$OBSERVATION_IDENTIFIER_CE_IDENTIFIER_ST@$OBSERVATION_IDENTIFIER_CE_TEXT_ST@$OBSERVATION_IDENTIFIER_CE_NAME_OF_CODING_SYS_ID@$OBSERVATION_IDENTIFIER_CE_ALT_IDENTIFIER_ST@$OBSERVATION_IDENTIFIER_CE_ALT_TEXT_ST@$OBSERVATION_IDENTIFIER_CE_ALT_NAME_OF_CODING_SYS_ID" +
            s"@$OBSERVATION_SUB_ID_ST@$OBSERVATION_VALUE@$UNITS_CE_IDENTIFIER_ST@$UNITS_CE_TEXT_ST@$UNITS_CE_NAME_OF_CODING_SYS_ID@$UNITS_CE_ALT_IDENTIFIER_ST" +
            s"@$UNITES_CE_ALT_TEXT_ST@$REFERENCE_RANGE_ST@$ABNORMAL_FLAGS_IS@$PROBABILITY_NM@$NATURE_OF_ABNORMAL_TEST_ID@$OBSERVATION_RESULT_STATUS_ID" +
            s"@$EFFECTIVE_DATE_OF_REFERENCE_RANGE_TS@$USER_DEFINED_ACCESS_CHECKS_ST@$DATETIME_OF_OBSERVATION_TS@$PRODUCERS_ID_CE@$RESPONSIBLE_OBSERVER_XCN@$OBSERVATION_METHOD_CE" +
            s"@$EQUIPMENT_INSTANCE_IDENTIFIER_EI@$DATETIME_OF_THE_ANALYSIS_TS@@@@@$ALT_PATIENT_ID_CX_ID_NBR_ST"
          buf += mess
        }
      }
    }
    buf
  }

  def CreateMSHTable(spark: SparkSession,dbName: String,tableName: String,outPath: String): Unit ={
    val subPath=outPath.replace("hdfs://","")
    spark.sql(s"""Create external table if not exists $dbName.$tableName(DERIVED_PATIENT_IDENTIFIER string,
 1_Field_Separator_ST string,
 2_Encoding_char_ST string,
 3_1_SENDING_APPLCTN_HD_NMSPCEID_IS string,
 3_2_SENDING_APPLCTN_HD_UNVRSL_ID_ST string,
 3_3_SENDING_APPLCTN_HD_UNVRSL_ID_TYP_ID string,
 4_1_SENDING_FACILITY_HD_NMSPCEID_IS string,
 4_2_SENDING_FACILITY_HD_UNVRSL_ID_ST string ,
 4_3_SENDING_FACILITY_HD_UNVRSL_ID_TYP_ID string,
 6_1_RECCVNG_FACILITY_HD_NMSPCEID_IS string,
 6_2_RECCVNG_FACILITY_HD_UNVRSL_ID_ST string,
 6_2_RECCVNG_FACILITY_HD_UNVRSL_ID_TYP_ID string,
 7_1_DATE_TIME_MESSAGE_TS string,
 7_2_DATE_TIME_MESSAGE_DEGREE_OF_PRECISION string,
 8_SECURITY_ST string,
 9_1_MESSAGE_TYP_MSG_MESSAGE_CODE_ID string ,
 9_2_MESSAGE_TYP_MSG_TRIGGER_EVNT_ID string ,
 9_3_MESSAGE_TYP_MSG_MESSAGE_STRUCTURE_ID string ,
 10_MESSAGE_CNTRL_ID_ST string ,
 11_PROCESSING_ID_PT string ,
 12_1_VERSION_ID_VID_ID string ,
 13_SEQ_NBR_NM string ,
 14_CONTINUATION_POINTER_ST string ,
 15_ACCPT_ACKNLDGMNT_TYP_ID string ,
 16_APPLCTN_ACKNLDGMNT_TYP_ID string ,
 17_COUNTRY_CD string ,
 18_CHARCTER_SET string ,
 20_ALT_CHAR_SET_HNDLNG_SCHME_ID string ,
 1_SET_ID_PID_SI string ,
 2_PATIENT_ID_CX_IDENTIFIER_NBR_ID string ,
 3_1_PATIENT_ID_LIST_CX_ID_NBR_ST string ,
 3_2_PATIENT_ID_LIST_CX_CHK_DIGIT_ST string ,
 3_3_PATIENT_ID_LIST_CX_Check_Digit_Scheme_ID string ,
 3_4_PATIENT_ID_LIST_CX_Assigning_Authority_ID string ,
 3_5_PATIENT_ID_LIST_CX_Identifier_Typ_CD_ID string ,
 4_1_ALT_PATIENT_ID_CX_ID_NBR_ST string ,
 4_5_ALT_PATIENT_ID_CX_Identifier_Typ_CD_ID string ,
 5_1_PATIENT_NAME_XPN_FAM_NM_FN string ,
 5_2_PATIENT_NAME_XPN_GIVEN_NM_ST string ,
 5_7_PATIENT_NAME_XPN_NAME_TYP_CD_ID string ,
 7_DATE_OF_BIRTH_TS string ,
 8_ADMINISTRATIVE_SEX_IS string ,
 9_PATIENT_ALIAS_XPN string ,
 10_1_PATIENT_RACE_CE_IDENTIFIER_ST string ,
 10_2_PATIENT_RACE_CE_TEXT_ST string ,
 10_3_PATIENT_RACE_CE_NAME_OF_CODING_SYS_ID string ,
 11_1_PATIENT_ADDR_XAD_STREET_ADDR_ST string ,
 11_2_PATIENT_ADDR_XAD_OTHER_DESIGNATION_ST string ,
 11_3_PATIENT_ADDR_XAD_CITY_ST string ,
 11_4_PATIENT_ADDR_XAD_ST_OR_PROVINCE_ST string ,
 11_5_PATIENT_ADDR_XAD_ST_POSTAL_CD_ST string ,
 11_7_PATIENT_ADDR_XAD_ST_ADDR_TYPE_ID string ,
 13_HOME_PHN_NBR_TN string ,
 14_BUSINESS_PHN_NBR_TN string ,
 15_Primary_LANG string ,
 16_MARTIAL_STATUS string ,
 17_RELIGION string ,
 18_PATIENT_ACCOUNT_NBR_ST string ,
 19_SSN_NBR_ST string ,
 20_DRIVER_LICEENSE_NBR_DLN string ,
 21_MOTHERS_IDENTIFIER_CX string ,
 22_ETHNIC_GRP_CE string,
 23_BIRTH_PLACE_ST string ,
 24_MULTIPLE_BIRTH_INDICATOR_ID string ,
 25_BIRTH_ORDER_NM string ,
 26_CITIZENSHIP_CE string ,
 27_VETERANS_MILITARY_STATUS string ,
 28_NATIONALITY string ,
 29_PATIENT_DEATH_DATE_AND_TIME_TS string ,
 30_PATIENT_DEATH_IND_ID string ,
 31_IDENTIFY_UNKNOWN_INDICATOR_ID string ,
 32_IDENTIFIER_RELIABILITY_CD_IS string ,
 33_LAST_UPDT_DATETIME_TS string ,
 34_LAST_UPDT_FACILITY_HD string ,
 35_SPECIES_CD_CE string ,
 36_BREED_CD_CE string ,
 37_STRAIN_ST string ,
 38_PROD_CLASS_CD_CE string ,
 39_TRIBAL_CITIZENSHIP_CD_CWE string ,
 HL7_MESSAGE string,
 GALAXY_LAB_UTILIZATION_GATEWAY_LAB_ID string,
 GALAXY_ENTPRS_CLIN_DATA_INTK_FL_CD string,
 GALAXY_CDB_SUBSCRIBER_ID string,
 GALAXY_CLAIM_MATCH_INDICATOR string,
 GALAXY_INDIVIDUAL_ID string,
 GALAXY_LAB_SUBSCRIBER_NUMBER string,
 GALAXY_CDB_MEMBER_ID string,
 SOURCE_CODE string,
 DOMAIN string,
 FILENAME string,
 GALAXY_MAILING_ALTERNATE_TELEPHONE_NUMBER_TYPE_CODE string,
 GALAXY_PERMANENT_ADDRESS_LINE_1 string,
 GALAXY_PERMANENT_ADDRESS_LINE_2 string,
 GALAXY_PERMANENT_CITY_NAME string,
 GALAXY_PERMANENT_STATE_ABBREVIATION string,
 GALAXY_PERMANENT_ZIP_CODE string,
 GALAXY_PERMANENT_HOME_TELEPHONE_NUMBER string,
 GALAXY_PERMANENT_ALTERNATE_TELEPHONE_NUMBER_TYPE_CODE string,
 GALAXY_PERMANENT_ALTERNATE_TELEPHONE_NUMBER string,
 GALAXY_MAILING_ADDRESS_LINE_2 string,
 GALAXY_CD_INPUT_FILE_ID string)
 PARTITIONED BY (partition_date date)
  ROW FORMAT SERDE
  'org.apache.hadoop.hive.ql.io.parquet.serde.ParquetHiveSerDe'
STORED AS INPUTFORMAT
  'org.apache.hadoop.hive.ql.io.parquet.MapredParquetInputFormat'
OUTPUTFORMAT
  'org.apache.hadoop.hive.ql.io.parquet.MapredParquetOutputFormat'
 Location 'maprfs:$subPath/$tableName'""")
  }
  def createDIAGTable(spark: SparkSession,dbName: String,tableName: String,outPath: String): Unit ={
    val subPath=outPath.replace("hdfs://","")
    spark.sql(s"""Create External table if not exists $dbName.$tableName(3_1_PATIENT_ID_LIST_CX_ID_NBR_ST string,
 18_PATIENT_ACCOUNT_NBR_ST string,
 3_1_FILLER_ORDER_NBR_EI_ENTITY_IDENTIFIER_ST string,
 1_OBR_SET_ID_SI string,
 1_FT1_SET_ID_SI string,
 19_1_DIAG_CD_CE_IDENTIFIER_ID string,
 19_2_DIAG_CD_CE_TEXT_SE string,
 19_3_DIAG_CD_CE_NAME_OF_CODING_SYS_IS string,
 19_4_DIAG_CD_CE_ALT_IDENTIFIER_ID string,
 19_5_DIAG_CD_CE_ALT_TEXT_SE string,
 19_6_DIAG_CD_CE_ALT_NAME_OF_CODING_SYS_IS string)
PARTITIONED BY (partition_date date)
ROW FORMAT SERDE
  'org.apache.hadoop.hive.ql.io.parquet.serde.ParquetHiveSerDe'
STORED AS INPUTFORMAT
'org.apache.hadoop.hive.ql.io.parquet.MapredParquetInputFormat'
OUTPUTFORMAT
'org.apache.hadoop.hive.ql.io.parquet.MapredParquetOutputFormat'
Location 'maprfs:$subPath/$tableName'""")
  }
  def createOBRTable(spark: SparkSession,dbName: String,tableName: String,outPath: String):Unit={
    val subPath=outPath.replace("hdfs://","")
    spark.sql(s"""Create External table if not exists $dbName.$tableName (DERIVED_PATIENT_IDENTIFIER string,
 3_1_PATIENT_ID_LIST_CX_ID_NBR_ST string,
 18_PATIENT_ACCOUNT_NBR_ST string,
 10_MESSAGE_CNTRL_ID_ST string,
 1_OBR_SET_ID_SI string,
 2_1_PLACE_ORDER_NUMBER_EI_ENTITY_IDENTIFIER_ST string,
 2_2_PLACE_ORDER_NUMBER_EI_NAMESPACE_ID_IS string,
 2_3_PLACE_ORDER_NUMBER_EI_UNIVERSAL_ID_ST string,
 2_4_PLACE_ORDER_NUMBER_EI_UNIVERSAL_ID_TYP_ID string,
 3_1_FILLER_ORDER_NBR_EI_ENTITY_IDENTIFIER_ST string,
 3_2_FILLER_ORDER_NBR_EI_ST_NAMESPACE_ID_IS string,
 3_3_FILLER_ORDER_NBR_EI_ST_UNIVERSAL_ID_ST string,
 3_4_FILLER_ORDER_NBR_EI_ST_UNIVERSAL_ID_TYPE_ID string,
 4_1_UNIVERSAL_SERVICE_IDENTIFIER_CE_IDENTIFER_ST string,
 4_2_UNIVERSAL_SERVICE_IDENTIFIER_CE_TEXT_ST string,
 4_3_UNIVERSAL_SERVICE_IDENTIFIER_CE_NAME_OF_CODING_SYSTEM_ID string,
 4_4_UNIVERSAL_SERVICE_IDENTIFIER_CE_ALTERNATE_IDENTIFIER_ST string,
 4_5_UNIVERSAL_SERVICE_IDENTIFIER_CE_ALTERNATE_TEXT_ST string,
 4_6_UNIVERSAL_SERVICE_IDENTIFIER_CE_NAME_OF_ALTERNATE_CODING_SYSTEM_ID string,
 5_OBR_PRIOROTY_ID string,
 6_REQUESTED_DATETIME_TS string,
 7_OBSERVATION_DATETIME_TS string,
 8_OBSERVATION_END_DATETIME_TS string,
 9_1_COLLECTION_VOLUME_QUANTITY_NM string,
 9_2_COLLECTION_VOLUME_UNITS_CE string,
 10_COLLECTOR_IDENTFIER_XCN string,
 11_SPECIMEN_ACTION_CODE_ID string,
 12_DANGER_CODE_CE string,
 13_RELEVANT_CLINICAL_INFORMATION_ST string,
 14_SPECIMEN_RECEIVED_DATETIME_TS string,
 15_SPECIMEN_SOURCE_SPS string,
 16_1_ORDERING_PROVIDER_XCN_ID_NUMBER_ST string,
 16_2_ORDERING_PROVIDER_XCN_FAMILY_NAME_FN string,
 16_3_ORDERING_PROVIDER_XCN_GIVEN_NAME_ST string,
 16_4_ORDERING_PROVIDER_XCN_MIDDLE_INITIAL_OR_NAME_ST string,
 16_8_ORDERING_PROVIDER_XCN_SOURCE_TABLE_IS string,
 16_9_ORDERING_PROVIDER_XCN_ASSIGNING_AUTHORITY_HD string,
 16_10_ORDERING_PROVIDER_XCN_NAMESPACE_ID_IS string,
 17_4_ORDER_CALLBACK_PHOBE_NUMBER_XTN_EMAIL_ADDR_ST string,
 17_6_ORDER_CALLBACK_PHOBE_NUMBER_XTN_AREA_CITY_CODE_NM string,
 17_7_ORDER_CALLBACK_PHOBE_NUMBER_XTN_LOCAL_NUMBER_NM string,
 18_PLACER_FIELD_1_ST string,
 19_PLACER_FIELD_2_ST string,
 20_FILLER_FIELD_1_ST string,
 21_FILLER_FIELD_2_ST string,
 22_RESULTS_RPT_STATUS_CHANGE_DATETIME_TS string,
 23_CHARGE_TO_PRACTICE_MOC string,
 24_DIAGNOSTIC_SERV_SECT_ID_ID string,
 25_RESULT_STATUS_ID string,
 26_PARENT_RESULT_PRL string,
 27_1_QUANTITY_TIMING_TQ_QUANTITY_CQ string,
 27_2_QUANTITY_TIMING_TQ_INTERVAL_RI string,
 27_3_QUANTITY_TIMING_TQ_DURATION_ST string,
 27_4_QUANTITY_TIMING_TQ_START_DATETIME_TS string,
 27_5_QUANTITY_TIMING_TQ_END_DATETIME_TS string,
 28_RESULTS_COPIES_TO_XCN string,
 29_PARENT_EIP string,
 1_FT1_SET_ID_SI string,
 2_TRANSACTION_ID_ST string,
 3_TRANSACTION_BATCH_ID_ST string,
 4_1_TRANSACTION_DATE_DR_RANGE_START_DATETIME_TS string,
 4_2_TRANSACTION_DATE_DR_RANGE_END_DATETIME_TS string,
 5_TRANSACTION_POSTING_DATE_TS string,
 6_TRANSACTION_TYP_IS string,
 7_1_TRANSACTION_CD_CE_IDENTIFIER_ID string,
 7_2_TRANSACTION_CD_CE_TEXT_SE string,
 7_3_TRANSACTION_CD_CE_NAME_OF_CODING_SYS_ST string,
 7_4_TRANSACTION_CD_CE_ALT_IDENTIFIER_ID string,
 7_5_TRANSACTION_CD_CE_ALT_TEXT_SE string,
 7_6_TRANSACTION_CD_CE_ALT_NAME_OF_CODING_SYS_ST string,
 8_TRANSACTION_DESC_ST string,
 9_ALT_TRANSACTION_DESC_ST string,
 10_TRANSACTION_QTY_NM string,
 11_TRANSACTION_AMT_EXTNDED_CP string,
 12_TRANSACTION_AMT_UNIT_CP string,
 13_DEPT_CD_CE string,
 14_1_INSURANCE_PLAN_ID_CE_IDENTIFIER_ID string,
 14_2_INSURANCE_PLAN_ID_CE_TEXT_SE string,
 14_3_INSURANCE_PLAN_ID_CE_NAME_OF_CODING_SYS_ST string,
 14_4_INSURANCE_PLAN_ID_CE_ALT_IDENTIFIER_ID string,
 14_5_INSURANCE_PLAN_ID_CE_ALT_TEXT_SE string,
 14_6_INSURANCE_PLAN_ID_CE_ALT_NAME_OF_CODING_SYS_ST string,
 15_INSURANCE_AMT_CP string,
 16_ASSGND_PTNT_LOCATION_PL string,
 17_FEE_SCHDULE_IS string,
 18_PATIENT_TYP_IS string,
 20_PERFORMED_BY_CODE_XCN string,
 21_ORDERED_BY_CODE_XCN string,
 22_UNIT_COST_CP string,
 23_FILLER_ORDER_NUMBER string,
 24_ENTERED_BY_CODE string,
 25_1_PROC_CD_CE_IDENTIFIER_ID string,
 25_2_PROC_CD_CE_TEXT_SE string,
 25_3_PROC_CD_CE_TEXT_SE_NAME_OF_CODING_SYS_ST string,
 25_4_PROC_CD_CE_ALT_IDENTIFIER_ID string,
 25_5_PROC_CD_CE_ALT_TEXT_SE string,
 25_6_PROC_CD_CE_TEXT_SE_ALT_NAME_OF_CODING_SYS_ST string,
 26_1_PROC_CD_MODIFIER_CE_IDENTIFIER_ID string,
 26_2_PROC_CD_MODIFIER_CE_TEXT_SE string,
 26_3_PROC_CD_MODIFIER_CE_NAME_OF_CODING_SYS_ST string,
 26_4_PROC_CD_MODIFIER_CE_ALT_IDENTIFIER_ID string,
 26_5_PROC_CD_MODIFIER_CE_ALT_TEXT_SE string,
 26_6_PROC_CD_MODIFIER_CE_ALT_NAME_OF_CODING_SYS_ST string,
 4_1_ALT_PATIENT_ID_CX_ID_NBR_ST string)
 PARTITIONED BY (partition_date date)
  ROW FORMAT SERDE
  'org.apache.hadoop.hive.ql.io.parquet.serde.ParquetHiveSerDe'
STORED AS INPUTFORMAT
  'org.apache.hadoop.hive.ql.io.parquet.MapredParquetInputFormat'
OUTPUTFORMAT
  'org.apache.hadoop.hive.ql.io.parquet.MapredParquetOutputFormat'
 Location 'maprfs:$subPath/$tableName'""")
  }
  def createOBXTable(spark: SparkSession,dbName: String,tableName: String,outPath: String):Unit={
    val subPath=outPath.replace("hdfs://","")
    spark.sql(s"""Create External table if not exists $dbName.$tableName(DERIVED_PATIENT_IDENTIFIER string,
 3_1_PATIENT_ID_LIST_CX_ID_NBR_ST string,
 18_PATIENT_ACCOUNT_NBR_ST string,
 3_1_FILLER_ORDER_NBR_EI_ENTITY_IDENTIFIER_ST string,
 1_OBR_SET_ID_SI string,
 1_OBX_SET_ID_SI string,
 2_VALUE_TYP_ID string,
 3_1_OBSERVATION_IDENTIFIER_CE_IDENTIFIER_ST string,
 3_2_OBSERVATION_IDENTIFIER_CE_TEXT_ST string,
 3_3_OBSERVATION_IDENTIFIER_CE_NAME_OF_CODING_SYS_ID string,
 3_4_OBSERVATION_IDENTIFIER_CE_ALT_IDENTIFIER_ST string,
 3_5_OBSERVATION_IDENTIFIER_CE_ALT_TEXT_ST string,
 3_6_OBSERVATION_IDENTIFIER_CE_ALT_NAME_OF_CODING_SYS_ID string,
 4_OBSERVATION_SUB_ID_ST string,
 5_OBSERVATION_VALUE string,
 6_1_UNITS_CE_IDENTIFIER_ST string,
 6_2_UNITS_CE_TEXT_ST string,
 6_3_UNITS_CE_NAME_OF_CODING_SYS_ID string,
 6_4_UNITS_CE_ALT_IDENTIFIER_ST string,
 6_5_UNITS_CE_ALT_TEXT_ST string,
 7_REFERENCE_RANGE_ST string,
 8_ABNORMAL_FLAGS_IS string,
 9_PROBABILITY_NM string,
 10_NATURE_OF_ABNORMAL_TEST_ID string,
 11_OBSERVATION_RESULT_STATUS_ID string,
 12_EFFECTIVE_DATE_OF_REFERENCE_RANGE_TS string,
 13_USER_DEFINED_ACCESS_CHECKS_ST string,
 14_DATETIME_OF_OBSERVATION_TS string,
 15_PRODUCERS_ID_CE string,
 16_RESPONSIBLE_OBSERVER_XCN string,
 17_OBSERVATION_METHOD_CE string,
 18_EQUIPMENT_INSTANCE_IDENTIFIER_EI string,
 19_DATETIME_OF_THE_ANALYSIS_TS string,
 1_NTE_SET_ID_SI string,
 2_SOURCE_OF_COMMENT_ID string,
 3_COMMENT_FT string,
 4_COMMENT_TYPE_CE string,
 4_1_ALT_PATIENT_ID_CX_ID_NBR_ST string)
 PARTITIONED BY (partition_date date)
ROW FORMAT SERDE
  'org.apache.hadoop.hive.ql.io.parquet.serde.ParquetHiveSerDe'
STORED AS INPUTFORMAT
'org.apache.hadoop.hive.ql.io.parquet.MapredParquetInputFormat'
OUTPUTFORMAT
'org.apache.hadoop.hive.ql.io.parquet.MapredParquetOutputFormat'
Location 'maprfs:$subPath/$tableName'""")
  }
  def msckRepairTable(spark: SparkSession,dbName: String,tableName: String): Unit ={
    Logger.log.info("Adding current_date partition to:"+tableName+" table ")
    spark.sql(s"msck repair table $dbName.$tableName")
  }
  def createGalaxyMSHDF(spark:SparkSession,tableName: String,entNM: String,filePath: String):DataFrame={
    spark.sql(s"""SELECT member_sys_id AS DERIVED_PATIENT_IDENTIFIER,
    '' AS 1_Field_Separator_ST,
    '' AS 2_Encoding_char_ST,
    '' AS 3_1_SENDING_APPLCTN_HD_NMSPCEID_IS,
    '' AS 3_2_SENDING_APPLCTN_HD_UNVRSL_ID_ST,
    '' AS 3_3_SENDING_APPLCTN_HD_UNVRSL_ID_TYP_ID,
    '' AS 4_1_SENDING_FACILITY_HD_NMSPCEID_IS,
    '' AS 4_2_SENDING_FACILITY_HD_UNVRSL_ID_ST,
    '' AS 4_3_SENDING_FACILITY_HD_UNVRSL_ID_TYP_ID,
    '' AS 6_1_RECCVNG_FACILITY_HD_NMSPCEID_IS,
    '' AS 6_2_RECCVNG_FACILITY_HD_UNVRSL_ID_ST,
    '' AS 6_2_RECCVNG_FACILITY_HD_UNVRSL_ID_TYP_ID,
    '' AS 7_1_DATE_TIME_MESSAGE_TS,
    '' AS 7_2_DATE_TIME_MESSAGE_DEGREE_OF_PRECISION,
    '' AS 8_SECURITY_ST,
    '' AS 9_1_MESSAGE_TYP_MSG_MESSAGE_CODE_ID,
    '' AS 9_2_MESSAGE_TYP_MSG_TRIGGER_EVNT_ID,
    '' AS 9_3_MESSAGE_TYP_MSG_MESSAGE_STRUCTURE_ID,
    '' AS 10_MESSAGE_CNTRL_ID_ST,
    '' AS 11_PROCESSING_ID_PT,
    '' AS 12_1_VERSION_ID_VID_ID,
    '' AS 13_SEQ_NBR_NM,
    '' AS 14_CONTINUATION_POINTER_ST,
    '' AS 15_ACCPT_ACKNLDGMNT_TYP_ID,
    '' AS 16_APPLCTN_ACKNLDGMNT_TYP_ID,
    '' AS 17_COUNTRY_CD,
    '' AS 18_CHARCTER_SET,
    '' AS 20_ALT_CHAR_SET_HNDLNG_SCHME_ID,
    '' AS 1_SET_ID_PID_SI,
    '' AS 2_PATIENT_ID_CX_IDENTIFIER_NBR_ID,
    '' AS 3_1_PATIENT_ID_LIST_CX_ID_NBR_ST,
    '' AS 3_2_PATIENT_ID_LIST_CX_CHK_DIGIT_ST,
    '' AS 3_3_PATIENT_ID_LIST_CX_Check_Digit_Scheme_ID,
    '' AS 3_4_PATIENT_ID_LIST_CX_Assigning_Authority_ID,
    '' AS 3_5_PATIENT_ID_LIST_CX_Identifier_Typ_CD_ID,
    '' AS 4_1_ALT_PATIENT_ID_CX_ID_NBR_ST,
    '' AS 4_5_ALT_PATIENT_ID_CX_Identifier_Typ_CD_ID,
    PATIENT_LAST_NAME AS 5_1_PATIENT_NAME_XPN_FAM_NM_FN,
    PATIENT_FIRST_NAME AS 5_2_PATIENT_NAME_XPN_GIVEN_NM_ST,
    '' AS 5_7_PATIENT_NAME_XPN_NAME_TYP_CD_ID,
    PATIENT_DATE_OF_BIRTH AS 7_DATE_OF_BIRTH_TS,
    PATIENT_GENDER_CODE AS 8_ADMINISTRATIVE_SEX_IS,
    '' AS 9_PATIENT_ALIAS_XPN,
    '' AS 10_1_PATIENT_RACE_CE_IDENTIFIER_ST,
    '' AS 10_2_PATIENT_RACE_CE_TEXT_ST,
    '' AS 10_3_PATIENT_RACE_CE_NAME_OF_CODING_SYS_ID,
    MAILING_ADDRESS_LINE_1 AS 11_1_PATIENT_ADDR_XAD_STREET_ADDR_ST,
    '' AS 11_2_PATIENT_ADDR_XAD_OTHER_DESIGNATION_ST,
    MAILING_CITY_NAME AS 11_3_PATIENT_ADDR_XAD_CITY_ST,
    MAILING_STATE_ABBREVIATION AS 11_4_PATIENT_ADDR_XAD_ST_OR_PROVINCE_ST,
    '' AS 11_5_PATIENT_ADDR_XAD_ST_POSTAL_CD_ST,
    MAILING_ZIP_CODE AS 11_7_PATIENT_ADDR_XAD_ST_ADDR_TYPE_ID,
    MAILING_HOME_TELEPHONE_NUMBER AS 13_HOME_PHN_NBR_TN,
    MAILING_ALTERNATE_TELEPHONE_NUMBER_TYPE_CODE AS 14_BUSINESS_PHN_NBR_TN,
    '' AS 15_Primary_LANG,
    '' AS 16_MARTIAL_STATUS,
    '' AS 17_RELIGION,
    '' AS 18_PATIENT_ACCOUNT_NBR_ST,
    '' AS 19_SSN_NBR_ST,
    '' AS 20_DRIVER_LICEENSE_NBR_DLN,
    '' AS 21_MOTHERS_IDENTIFIER_CX,
    '' AS 22_ETHNIC_GRP_CE,
    '' AS 23_BIRTH_PLACE_ST,
    '' AS 24_MULTIPLE_BIRTH_INDICATOR_ID,
    '' AS 25_BIRTH_ORDER_NM,
    '' AS 26_CITIZENSHIP_CE,
    '' AS 27_VETERANS_MILITARY_STATUS,
    '' AS 28_NATIONALITY,
    '' AS 29_PATIENT_DEATH_DATE_AND_TIME_TS,
    '' AS 30_PATIENT_DEATH_IND_ID,
    '' AS 31_IDENTIFY_UNKNOWN_INDICATOR_ID,
    '' AS 32_IDENTIFIER_RELIABILITY_CD_IS,
    '' AS 33_LAST_UPDT_DATETIME_TS,
    '' AS 34_LAST_UPDT_FACILITY_HD,
    '' AS 35_SPECIES_CD_CE,
    '' AS 36_BREED_CD_CE,
    '' AS 37_STRAIN_ST,
    '' AS 38_PROD_CLASS_CD_CE,
    '' AS 39_TRIBAL_CITIZENSHIP_CD_CWE,
    concat(lab_utilization_gateway_lab_description,'|',specimen_number,'|',first_service_date,'|',procedure_code,'|',analyte_sequence_number,'|',loinc_code,'|',vendor_test_number,'|',vendor_test_description,'|',reference_range,'|',result_value,'|',result_units_name,'|',result_abnormal_code,'|',load_date,'|',cd_input_file_id,'|',member_sys_id,'|',patient_date_of_birth,'|',patient_gender_code,'|',patient_first_name,'|',patient_last_name,'|',cdb_subscriber_id,'|',entprs_clin_data_intk_fl_cd,'|',claim_match_indicator,'|',individual_id,'|',lab_subscriber_number,'|',cdb_member_id,'|',mailing_address_line_1,'|',mailing_address_line_2,'|',mailing_city_name,'|',mailing_state_abbreviation,'|',mailing_zip_code,'|',mailing_home_telephone_number,'|',mailing_alternate_telephone_number_type_code,'|',mailing_alternate_telephone_number,'|',permanent_address_line_1,'|',permanent_address_line_2,'|',permanent_city_name,'|',permanent_state_abbreviation,'|',permanent_zip_code,'|',permanent_home_telephone_number,'|',permanent_alternate_telephone_number_type_code,'|',permanent_alternate_telephone_number) AS HL7_MESSAGE,
    LAB_UTILIZATION_GATEWAY_LAB_DESCRIPTION AS GALAXY_LAB_UTILIZATION_GATEWAY_LAB_ID,
    ENTPRS_CLIN_DATA_INTK_FL_CD AS GALAXY_ENTPRS_CLIN_DATA_INTK_FL_CD,
    CDB_SUBSCRIBER_ID AS GALAXY_CDB_SUBSCRIBER_ID,
    CLAIM_MATCH_INDICATOR AS GALAXY_CLAIM_MATCH_INDICATOR,
    INDIVIDUAL_ID AS GALAXY_INDIVIDUAL_ID,
    LAB_SUBSCRIBER_NUMBER AS GALAXY_LAB_SUBSCRIBER_NUMBER,
    CDB_MEMBER_ID AS GALAXY_CDB_MEMBER_ID,
    'GALAXY'  AS SOURCE_CODE,
    '$entNM' AS DOMAIN,
    '$filePath' AS FILENAME,
    mailing_alternate_telephone_number_type_code as GALAXY_MAILING_ALTERNATE_TELEPHONE_NUMBER_TYPE_CODE,
    permanent_address_line_1 as GALAXY_PERMANENT_ADDRESS_LINE_1,
    permanent_address_line_2 as GALAXY_PERMANENT_ADDRESS_LINE_2,
    permanent_city_name as GALAXY_PERMANENT_CITY_NAME,
    permanent_state_abbreviation as GALAXY_PERMANENT_STATE_ABBREVIATION,
    permanent_zip_code as GALAXY_PERMANENT_ZIP_CODE,
    permanent_home_telephone_number as GALAXY_PERMANENT_HOME_TELEPHONE_NUMBER,
    permanent_alternate_telephone_number_type_code as GALAXY_PERMANENT_ALTERNATE_TELEPHONE_NUMBER_TYPE_CODE,
    permanent_alternate_telephone_number as GALAXY_PERMANENT_ALTERNATE_TELEPHONE_NUMBER,
    mailing_address_line_2 as GALAXY_MAILING_ADDRESS_LINE_2,
    cd_input_file_id as GALAXY_CD_INPUT_FILE_ID FROM  $tableName""")
  }

  def createGalaxyOBRDF(spark:SparkSession,tableName: String):DataFrame={
    spark.sql(s"""SELECT member_sys_id AS DERIVED_PATIENT_IDENTIFIER,
      '' AS 3_1_PATIENT_ID_LIST_CX_ID_NBR_ST,
      '' AS 18_PATIENT_ACCOUNT_NBR_ST,
      '' AS 10_MESSAGE_CNTRL_ID_ST,
      '' AS 1_OBR_SET_ID_SI,
      '' AS 2_1_PLACE_ORDER_NUMBER_EI_ENTITY_IDENTIFIER_ST,
      '' AS 2_2_PLACE_ORDER_NUMBER_EI_NAMESPACE_ID_IS,
      '' AS 2_3_PLACE_ORDER_NUMBER_EI_UNIVERSAL_ID_ST,
      '' AS 2_4_PLACE_ORDER_NUMBER_EI_UNIVERSAL_ID_TYP_ID,
      specimen_number AS 3_1_FILLER_ORDER_NBR_EI_ENTITY_IDENTIFIER_ST,
      '' AS 3_2_FILLER_ORDER_NBR_EI_ST_NAMESPACE_ID_IS,
      '' AS 3_3_FILLER_ORDER_NBR_EI_ST_UNIVERSAL_ID_ST,
      '' AS 3_4_FILLER_ORDER_NBR_EI_ST_UNIVERSAL_ID_TYPE_ID,
      '' AS 4_1_UNIVERSAL_SERVICE_IDENTIFIER_CE_IDENTIFER_ST,
      '' AS 4_2_UNIVERSAL_SERVICE_IDENTIFIER_CE_TEXT_ST,
      '' AS 4_3_UNIVERSAL_SERVICE_IDENTIFIER_CE_NAME_OF_CODING_SYSTEM_ID,
      '' AS 4_4_UNIVERSAL_SERVICE_IDENTIFIER_CE_ALTERNATE_IDENTIFIER_ST,
      '' AS 4_5_UNIVERSAL_SERVICE_IDENTIFIER_CE_ALTERNATE_TEXT_ST,
      '' AS 4_6_UNIVERSAL_SERVICE_IDENTIFIER_CE_NAME_OF_ALTERNATE_CODING_SYSTEM_ID,
      '' AS 5_OBR_PRIOROTY_ID,
      '' AS 6_REQUESTED_DATETIME_TS,
      first_service_date AS 7_OBSERVATION_DATETIME_TS,
      '' AS 8_OBSERVATION_END_DATETIME_TS,
      '' AS 9_1_COLLECTION_VOLUME_QUANTITY_NM,
      '' AS 9_2_COLLECTION_VOLUME_UNITS_CE,
      '' AS 10_COLLECTOR_IDENTFIER_XCN,
      '' AS 11_SPECIMEN_ACTION_CODE_ID,
      '' AS 12_DANGER_CODE_CE,
      '' AS 13_RELEVANT_CLINICAL_INFORMATION_ST,
      '' AS 14_SPECIMEN_RECEIVED_DATETIME_TS,
      '' AS 15_SPECIMEN_SOURCE_SPS,
      '' AS 16_1_ORDERING_PROVIDER_XCN_ID_NUMBER_ST,
      '' AS 16_2_ORDERING_PROVIDER_XCN_FAMILY_NAME_FN,
      '' AS 16_3_ORDERING_PROVIDER_XCN_GIVEN_NAME_ST,
      '' AS 16_4_ORDERING_PROVIDER_XCN_MIDDLE_INITIAL_OR_NAME_ST,
      '' AS 16_8_ORDERING_PROVIDER_XCN_SOURCE_TABLE_IS,
      '' AS 16_9_ORDERING_PROVIDER_XCN_ASSIGNING_AUTHORITY_HD,
      '' AS 16_10_ORDERING_PROVIDER_XCN_NAMESPACE_ID_IS,
      '' AS 17_4_ORDER_CALLBACK_PHOBE_NUMBER_XTN_EMAIL_ADDR_ST,
      '' AS 17_6_ORDER_CALLBACK_PHOBE_NUMBER_XTN_AREA_CITY_CODE_NM,
      '' AS 17_7_ORDER_CALLBACK_PHOBE_NUMBER_XTN_LOCAL_NUMBER_NM,
      '' AS 18_PLACER_FIELD_1_ST,
      '' AS 19_PLACER_FIELD_2_ST,
      '' AS 20_FILLER_FIELD_1_ST,
      '' AS 21_FILLER_FIELD_2_ST,
      '' AS 22_RESULTS_RPT_STATUS_CHANGE_DATETIME_TS,
      '' AS 23_CHARGE_TO_PRACTICE_MOC,
      '' AS 24_DIAGNOSTIC_SERV_SECT_ID_ID,
      '' AS 25_RESULT_STATUS_ID,
      '' AS 26_PARENT_RESULT_PRL,
      '' AS 27_1_QUANTITY_TIMING_TQ_QUANTITY_CQ,
      '' AS 27_2_QUANTITY_TIMING_TQ_INTERVAL_RI,
      '' AS 27_3_QUANTITY_TIMING_TQ_DURATION_ST,
      '' AS 27_4_QUANTITY_TIMING_TQ_START_DATETIME_TS,
      '' AS 27_5_QUANTITY_TIMING_TQ_END_DATETIME_TS,
      '' AS 28_RESULTS_COPIES_TO_XCN,
      '' AS 29_PARENT_EIP,
      '' AS 1_FT1_SET_ID_SI,
      '' AS 2_TRANSACTION_ID_ST,
      '' AS 3_TRANSACTION_BATCH_ID_ST,
      '' AS 4_1_TRANSACTION_DATE_DR_RANGE_START_DATETIME_TS,
      '' AS 4_2_TRANSACTION_DATE_DR_RANGE_END_DATETIME_TS,
      '' AS 5_TRANSACTION_POSTING_DATE_TS,
      '' AS 6_TRANSACTION_TYP_IS,
      '' AS 7_1_TRANSACTION_CD_CE_IDENTIFIER_ID,
      '' AS 7_2_TRANSACTION_CD_CE_TEXT_SE,
      '' AS 7_3_TRANSACTION_CD_CE_NAME_OF_CODING_SYS_ST,
      '' AS 7_4_TRANSACTION_CD_CE_ALT_IDENTIFIER_ID,
      '' AS 7_5_TRANSACTION_CD_CE_ALT_TEXT_SE,
      '' AS 7_6_TRANSACTION_CD_CE_ALT_NAME_OF_CODING_SYS_ST,
      '' AS 8_TRANSACTION_DESC_ST,
      '' AS 9_ALT_TRANSACTION_DESC_ST,
      '' AS 10_TRANSACTION_QTY_NM,
      '' AS 11_TRANSACTION_AMT_EXTNDED_CP,
      '' AS 12_TRANSACTION_AMT_UNIT_CP,
      '' AS 13_DEPT_CD_CE,
      '' AS 14_1_INSURANCE_PLAN_ID_CE_IDENTIFIER_ID,
      '' AS 14_2_INSURANCE_PLAN_ID_CE_TEXT_SE,
      '' AS 14_3_INSURANCE_PLAN_ID_CE_NAME_OF_CODING_SYS_ST,
      '' AS 14_4_INSURANCE_PLAN_ID_CE_ALT_IDENTIFIER_ID,
      '' AS 14_5_INSURANCE_PLAN_ID_CE_ALT_TEXT_SE,
      '' AS 14_6_INSURANCE_PLAN_ID_CE_ALT_NAME_OF_CODING_SYS_ST,
      '' AS 15_INSURANCE_AMT_CP,
      '' AS 16_ASSGND_PTNT_LOCATION_PL,
      '' AS 17_FEE_SCHDULE_IS,
      '' AS 18_PATIENT_TYP_IS,
      '' AS 20_PERFORMED_BY_CODE_XCN,
      '' AS 21_ORDERED_BY_CODE_XCN,
      '' AS 22_UNIT_COST_CP,
      '' AS 23_FILLER_ORDER_NUMBER,
      '' AS 24_ENTERED_BY_CODE,
      '' AS 25_1_PROC_CD_CE_IDENTIFIER_ID,
      '' AS 25_2_PROC_CD_CE_TEXT_SE,
      '' AS 25_3_PROC_CD_CE_TEXT_SE_NAME_OF_CODING_SYS_ST,
      '' AS 25_4_PROC_CD_CE_ALT_IDENTIFIER_ID,
      '' AS 25_5_PROC_CD_CE_ALT_TEXT_SE,
      '' AS 25_6_PROC_CD_CE_TEXT_SE_ALT_NAME_OF_CODING_SYS_ST,
      '' AS 26_1_PROC_CD_MODIFIER_CE_IDENTIFIER_ID,
      '' AS 26_2_PROC_CD_MODIFIER_CE_TEXT_SE,
      '' AS 26_3_PROC_CD_MODIFIER_CE_NAME_OF_CODING_SYS_ST,
      '' AS 26_4_PROC_CD_MODIFIER_CE_ALT_IDENTIFIER_ID,
      '' AS 26_5_PROC_CD_MODIFIER_CE_ALT_TEXT_SE,
      '' AS 26_6_PROC_CD_MODIFIER_CE_ALT_NAME_OF_CODING_SYS_ST,
      '' AS 4_1_ALT_PATIENT_ID_CX_ID_NBR_ST From $tableName""")
  }

  def createGalaxyOBXDF(spark: SparkSession,tableName: String):DataFrame={
    spark.sql(s"""SELECT member_sys_id AS DERIVED_PATIENT_IDENTIFIER,
    '' AS 3_1_PATIENT_ID_LIST_CX_ID_NBR_ST,
    '' AS 18_PATIENT_ACCOUNT_NBR_ST,
    specimen_number AS 3_1_FILLER_ORDER_NBR_EI_ENTITY_IDENTIFIER_ST,
    analyte_sequence_number AS 1_OBR_SET_ID_SI,
    analyte_sequence_number AS 1_OBX_SET_ID_SI,
    '' AS 2_VALUE_TYP_ID,
    loinc_code AS 3_1_OBSERVATION_IDENTIFIER_CE_IDENTIFIER_ST,
    '' AS 3_2_OBSERVATION_IDENTIFIER_CE_TEXT_ST,
    '' AS 3_3_OBSERVATION_IDENTIFIER_CE_NAME_OF_CODING_SYS_ID,
    vendor_test_number AS 3_4_OBSERVATION_IDENTIFIER_CE_ALT_IDENTIFIER_ST,
    vendor_test_description AS 3_5_OBSERVATION_IDENTIFIER_CE_ALT_TEXT_ST,
    '' AS 3_6_OBSERVATION_IDENTIFIER_CE_ALT_NAME_OF_CODING_SYS_ID,
    '' AS 4_OBSERVATION_SUB_ID_ST,
    '' AS 5_OBSERVATION_VALUE,
    result_units_name AS 6_1_UNITS_CE_IDENTIFIER_ST,
    '' AS 6_2_UNITS_CE_TEXT_ST,
    '' AS 6_3_UNITS_CE_NAME_OF_CODING_SYS_ID,
    '' AS 6_4_UNITS_CE_ALT_IDENTIFIER_ST,
    '' AS 6_5_UNITS_CE_ALT_TEXT_ST,
    reference_range AS 7_REFERENCE_RANGE_ST,
    '' AS 8_ABNORMAL_FLAGS_IS,
    '' AS 9_PROBABILITY_NM,
    result_abnormal_code AS 10_NATURE_OF_ABNORMAL_TEST_ID,
    result_value AS 11_OBSERVATION_RESULT_STATUS_ID,
    '' AS 12_EFFECTIVE_DATE_OF_REFERENCE_RANGE_TS,
    '' AS 13_USER_DEFINED_ACCESS_CHECKS_ST,
    '' AS 14_DATETIME_OF_OBSERVATION_TS,
    '' AS 15_PRODUCERS_ID_CE,
    '' AS 16_RESPONSIBLE_OBSERVER_XCN,
    '' AS 17_OBSERVATION_METHOD_CE,
    '' AS 18_EQUIPMENT_INSTANCE_IDENTIFIER_EI,
    '' AS 19_DATETIME_OF_THE_ANALYSIS_TS,
    '' AS 1_NTE_SET_ID_SI,
    '' AS 2_SOURCE_OF_COMMENT_ID,
    '' AS 3_COMMENT_FT,
    '' AS 4_COMMENT_TYPE_CE,
    '' AS 4_1_ALT_PATIENT_ID_CX_ID_NBR_ST FROM $tableName""")
  }

  def createGalaxyFITDF(spark:SparkSession,table:String): DataFrame={
    spark.sql(s"""SELECT member_sys_id AS 3_1_PATIENT_ID_LIST_CX_ID_NBR_ST,
    '' AS 18_PATIENT_ACCOUNT_NBR_ST,
    specimen_number AS 3_1_FILLER_ORDER_NBR_EI_ENTITY_IDENTIFIER_ST,
    analyte_sequence_number AS 1_OBR_SET_ID_SI,
    '' AS 1_FT1_SET_ID_SI,
    procedure_code AS 19_1_DIAG_CD_CE_IDENTIFIER_ID,
    '' AS 19_2_DIAG_CD_CE_TEXT_SE,
    '' AS 19_3_DIAG_CD_CE_NAME_OF_CODING_SYS_IS,
    '' AS 19_4_DIAG_CD_CE_ALT_IDENTIFIER_ID,
    '' AS 19_5_DIAG_CD_CE_ALT_TEXT_SE,
    '' AS 19_6_DIAG_CD_CE_ALT_NAME_OF_CODING_SYS_IS FROM $table""")
  }
}
