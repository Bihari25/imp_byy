package com.optum.ihrcentri.LabGalaxyFiles

import java.text.SimpleDateFormat
import java.util.Calendar
import com.optum.ihrcentri.Common._
import org.apache.spark.sql.{DataFrame, SparkSession}

class RunJob {
  var totalMatches:Int= 0
  var totalMissMatches: Int= 0
  val functions = new CommonFunctions
  val transformations=new Transformations

  def labExecution(spark: SparkSession,aco_members: DataFrame, SourceFilePath: String, outputfilepath: String, entnm: String, logDir: String,outputNodeAddress: String): Unit ={

    val format = new SimpleDateFormat("MMddyyyyHHmmssSS")
    val filename=s"$entnm"+"_"+format.format(Calendar.getInstance().getTime)
    Logger.log.info("Reading zip file")
    val zipdata=functions.readFile(spark.sparkContext,SourceFilePath)
    val labDF=transformations.galaxyFileDF(spark,zipdata)
    val joinDF=transformations.galaxyAcoMap(spark,labDF,aco_members)
    val matches=joinDF.count
    Logger.log.info("Matched members:"+matches)
    Logger.log.info("Creating the outbound file")
    transformations.createOutBoundFile(joinDF,outputfilepath+s"$filename")
    functions.fileRenameToTXT(outputNodeAddress,outputfilepath+s"$filename",entnm)

    val logDF=transformations.galaxyLog(spark,labDF,joinDF)
    Logger.log.info("Creating the log file")
    transformations.CreateCSVlogFile(logDF,logDir+s"$filename")
    functions.fileRenameToCSV(outputNodeAddress,logDir+s"$filename",entnm)

    totalMatches += matches.toInt
    totalMissMatches += logDF.filter("senttoIHR='FALSE'").count.toInt
  }
}
