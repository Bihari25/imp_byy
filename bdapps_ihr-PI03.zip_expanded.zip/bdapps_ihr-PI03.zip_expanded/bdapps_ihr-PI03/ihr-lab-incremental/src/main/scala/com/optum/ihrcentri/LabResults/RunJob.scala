package com.optum.ihrcentri.LabResults


import java.text.SimpleDateFormat
import java.util.Calendar
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel


object RunJob {

  var totalMatches:Int= 0
  var totalMissMatches: Int= 0
  var totalErrorMSGS: Int= 0
  val globalContext=new GlobalContext

  def labExecution(spark: SparkSession, Aco_members: DataFrame, filepath: String, outputfilepath: String, isFilter: String, entnm: String, logDir: String, errorDir: String,fileName:String): Unit ={

    val parser=new HL7Parser()
    val transformations=new Transformations()
    val functions=new CommonFunctions()

    var finalOutpath=""
    val format = new SimpleDateFormat("MMddyyyyHHmmssSS")

    if(isFilter.toUpperCase.equals("YES")){

      val hl7stream = functions.unzip(filepath)

      finalOutpath=outputfilepath.concat(fileName)
      val finallogDir=logDir.concat(fileName)
      val finalerrorDir=errorDir.concat(fileName)

      val pidData=parser.Hl7Reader(spark,hl7stream)
      pidData.persist(StorageLevel.MEMORY_AND_DISK_2)

      val hl7Df=transformations.labresultsMapAcomembers(spark,pidData,Aco_members)
      val matchCount=hl7Df.count()
      hl7Df.persist(StorageLevel.MEMORY_AND_DISK_2)
      Logger.log.info("Aco_Member Match count "+ matchCount)
      val hardhl7list: List[String]=functions.toList(hl7Df.select("msgblock"))
      functions.buildH7File(hardhl7list,finalOutpath+".hl7")

      Logger.log.info("Creating log file")
      val logDF=transformations.logCreation(spark,pidData,hl7Df)
      val misMatches=logDF.filter("senttoIHR='FALSE'").count
      transformations.CreateCSVlogFile(logDF,finallogDir)
      functions.fileRenameToCSV(globalContext.outputNodeAddress,finallogDir,fileName)

      //functions.buildH7File(logList,finallogDir+".csv")

      if(parser.errorMsgs!=0){
        Logger.log.info("Creating error messages hl7 file")
        functions.buildH7File(parser.errorList,finalerrorDir+".hl7")
      }
      totalMatches += matchCount.toInt
      totalMissMatches += misMatches.toInt
      totalErrorMSGS += parser.errorMsgs

    }else if(isFilter.toUpperCase.equals("NO")){

      val datestring=entnm+"_"+format.format(Calendar.getInstance().getTime())
      finalOutpath=outputfilepath.concat(fileName)

      val hl7stream=functions.unzip(filepath)
      val Piddata=parser.Hl7Reader(spark,hl7stream)
      val hl7df=functions.noFilterHl7(spark,Piddata)
      val matchCount=hl7df.count()
      val hl7List=functions.toList(hl7df)
      functions.buildH7File(hl7List,finalOutpath+".hl7")
      totalMatches += matchCount.toInt
    }
  }
}
