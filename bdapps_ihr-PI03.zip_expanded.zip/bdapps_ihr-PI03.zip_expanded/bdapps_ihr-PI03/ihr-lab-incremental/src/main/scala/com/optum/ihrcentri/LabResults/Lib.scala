package com.optum.ihrcentri.LabResults

import java.text.SimpleDateFormat
import java.util.Calendar

import org.apache.hadoop.fs.Path
import org.apache.hadoop.hbase.TableName
import org.apache.hadoop.hbase.client.{Put, Scan}
import org.apache.hadoop.hbase.filter.CompareFilter.CompareOp
import org.apache.hadoop.hbase.filter._
import org.apache.hadoop.hbase.util.Bytes
import com.optum.ihrcentri.Common.{GlobalContext,Logger}

/**
  * Created by rkodur on 3/6/2018.
  */
object Lib {

  val globalContext = new GlobalContext

  def filterListAnd(filters: Filter*) = new FilterList(FilterList.Operator.MUST_PASS_ALL, filters: _*)

  def filterRawFileExist(filePath: String): Boolean = {
    globalContext.fs.exists(new Path(s"$filePath"))
  }

  def getCurrentTimeFormat: String = getCurrentDateTime("yyyy-MM-dd HH:mm:ss")

  def getCurrentDateTime(dateTimeFormat: String): String = {
    val dateFormat = new SimpleDateFormat(dateTimeFormat)
    val cal = Calendar.getInstance()
    dateFormat.format(cal.getTime)
  }

  def getTimestamp(DateFormat: String): Long = {
    try {
      val timestampformat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
      timestampformat.parse(DateFormat).getTime
    } catch {
      case e: Exception => Logger.log.info("Exception while getting current date/time" :+ e.getMessage)
        0
    }
  }

  def getEntityInfo(rowKey: String): Array[(String, String, String, String, String, String, String)] = {
    try {
      val ihrTab = globalContext.spark.getConf.get("spark.ihrCtlTab")
      Logger.log.info(s"ihrCtlTab ihr_ent_cfg: $ihrTab")
      val scanner = new Scan()
      scanner.setCaching(1000)
      scanner.setCacheBlocks(false)
      val filter1 = new RowFilter(CompareOp.EQUAL, new BinaryComparator(Bytes.toBytes(s"$rowKey")))
      scanner.setFilter(filter1)
      val ihrInfo = globalContext.hbaseContext.hbaseRDD(TableName.valueOf(ihrTab), scanner).cache()
      val ihrEntRDD = ihrInfo.map(tuple => {
        val result = tuple._2
        (Bytes.toString(result.getValue(Bytes.toBytes("ei"), Bytes.toBytes("prtnrCd"))),
          Bytes.toString(result.getValue(Bytes.toBytes("ei"), Bytes.toBytes("srcCd"))),
          Bytes.toString(result.getValue(Bytes.toBytes("ei"), Bytes.toBytes("entNm"))),
          Bytes.toString(result.getValue(Bytes.toBytes("is"), Bytes.toBytes("lastRnTs"))),
          Bytes.toString(result.getValue(Bytes.toBytes("ei"), Bytes.toBytes("outFileNm"))),
          Bytes.toString(result.getValue(Bytes.toBytes("ei"), Bytes.toBytes("outFileExt"))),
          Bytes.toString(result.getValue(Bytes.toBytes("ei"), Bytes.toBytes("isFilter"))))
      })

      if (ihrEntRDD.isEmpty()) {
        Logger.log.info(s"Please Provide Appropriate RowKey / Check ihr_ent_cfg table Properties for $rowKey properly")
        ihrEntRDD.collect()
      }
      else {
        ihrEntRDD.collect()
      }
    } catch {
      case e: Exception => Logger.log.error(s"Exception while getting Configuration from ihr_entity_info Tab" :+ e.getMessage)
        throw e
    }
  }

//Extracting List of files from provided starttime to end time

  def eitTabScan(patnrCd: String, srcCd: String, entNm: String, incStTime: String, incEndTs: String): List[String] = {
    val eitTable = globalContext.spark.getConf.get("spark.eitTab")
    val ptnr = s"${patnrCd}".toUpperCase
    val src = s"${srcCd}".toUpperCase
    val mountPath = globalContext.spark.getConf.get("spark.mountPath")
    val raw_path = s"maprfs://$mountPath/${ptnr.toLowerCase}/raw/standard_access/${src.toLowerCase}/data/"
    val entName = s"${entNm}".toUpperCase
    Logger.log.info(s"Retrieving Files for $entName from Raw: $raw_path")
    Logger.log.info(s"Processing Entity:${entName} with patnrCd:${ptnr} srcCd:${src}")
    Logger.log.info(s"Scanning Eit HBase Table: $eitTable")
    val startTime = s"$incStTime"
    val endTime = s"$incEndTs"
    Logger.log.info(s"Capturing if any Changes reflected for $entName from $startTime to $endTime")
    val rowKey = s"${ptnr}-${src}-${entName}"
    Logger.log.info(s"Processing ${entName} Files")
    import org.apache.hadoop.hbase.client.Scan
    val scan = new Scan()
    val filter = new PrefixFilter(Bytes.toBytes(s"${ptnr}-${src}-${entName}-"))
    val filter1 = new SingleColumnValueFilter(Bytes.toBytes("exi"), Bytes.toBytes("ingProcLogSts"), CompareOp.EQUAL, Bytes.toBytes("Success"));
    scan.setCaching(10000)
    scan.setCacheBlocks(false)
    filter1.setFilterIfMissing(true)
    scan.setFilter(filterListAnd(filter1, filter))
    scan.setTimeRange(getTimestamp(startTime), getTimestamp(endTime))
    val eitVal = globalContext.hbaseContext.hbaseRDD(TableName.valueOf(eitTable), scan).cache
    val eitInfo = eitVal.map(tuple => {
      val result = tuple._2
      (Bytes.toString(result.getValue(Bytes.toBytes("fi"), Bytes.toBytes("schmVer"))),
        Bytes.toString(result.getValue(Bytes.toBytes("fi"), Bytes.toBytes("srcFileNm"))),
        Bytes.toString(result.getValue(Bytes.toBytes("fi"), Bytes.toBytes("entprtnfldr"))))
    })
    Logger.log.info(s"Number of Entries Captured for $entName from EIT SCAN b/w $startTime and $endTime :" + eitVal.count())
    if (!eitInfo.isEmpty) {
      //  val eitFileList: List[(String, String)] = eitInfo.collect.toList.map(x => (x, s"${raw_path}${entName}/${entName}.v${x}//*"))
      val eitFileList = eitInfo.map(x => (x._1, x._2, x._3)).collect.toList.map(x => (s"${raw_path}${entNm}/${entNm}.v${x._1}/${x._3}/${x._2}"))
      val eitRawFileList = eitFileList.filter(x => filterRawFileExist(x))
      eitVal.unpersist()
      eitRawFileList
    }
    else {
      Logger.log.info(s"Since, No Changes Captured for $entName from $startTime to $endTime, datasets will not be generated")
      List[String]()
    }
  }


  //Update IHR-audit_tracking table with Rowkey(Use JAVA UUID to get uniq ID) Column Family and values
  def hbaseEitPut(eitRowKey: String, colFm: String, colNm: String, value: String): Unit = {
    try {
      val p = new Put(s"$eitRowKey".getBytes())
      p.addColumn(s"$colFm".getBytes(), s"$colNm".getBytes(), s"$value".getBytes())
      globalContext.ihrCtlTab.put(p)
    } catch {
      case e: Exception => Logger.log.info("Exception at HBase EIT Put Commands at IHR_entity_info IHR_ADT_DTL" :+ e.getStackTrace.mkString)
        throw e
    }
  }
}
