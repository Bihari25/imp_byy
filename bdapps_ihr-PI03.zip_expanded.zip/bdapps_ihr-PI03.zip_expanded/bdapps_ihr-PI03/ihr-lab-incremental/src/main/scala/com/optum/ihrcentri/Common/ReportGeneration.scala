package com.optum.ihrcentri.Common

import java.text.SimpleDateFormat
import java.util.Calendar

import org.apache.hadoop.hbase.client.Put

/**
  * Created by mmallam2 on Apr,2018
  *
  **/


object ReportGeneration {

  val globalContext=new GlobalContext

  val format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
  val testdateFormat=new SimpleDateFormat("yyyy-MM-dd")

  def HBaseAuditFailureReport(row_key: String,eitRowKey:String,errorcode: String,errorDesc: String,startTime: String):Unit={
    Logger.log.info(s"${row_key} process got failed please check Audit table with this row_key: "+ eitRowKey)
    val prtnrCd=row_key.split('-')(0)
    val srcCd=row_key.split('-')(1)
    hbaseAuditPut(eitRowKey,"pi","prcNm",row_key)
    hbaseAuditPut(eitRowKey,"pi","incPrcSts","Failure")
    hbaseAuditPut(eitRowKey,"pi","prcEndTm",format.format(Calendar.getInstance().getTime()))
    hbaseAuditPut(eitRowKey,"pi","prcStTm",startTime)
    hbaseAuditPut(eitRowKey,"pi","prtnrCd",prtnrCd)
    hbaseAuditPut(eitRowKey,"eri","errCd",errorcode)
    hbaseAuditPut(eitRowKey,"eri","errDesc",errorDesc)
    hbaseAuditPut(eitRowKey,"pi","srcCd",srcCd)
    hbaseAuditPut(eitRowKey,"pi","prcdt",testdateFormat.format(Calendar.getInstance().getTime()))
  }
  def HbaseAuditSuccessReport(row_key: String,eitRowKey:String,startTime: String,processed_count: String,unproc_count: String,error_recCount: String): Unit ={
    Logger.log.info("Audit table row_key: "+ eitRowKey)
    val prtnrCd=row_key.split('-')(0)
    val srcCd=row_key.split('-')(1)
    hbaseAuditPut(eitRowKey,"pi","prcNm",row_key)
    hbaseAuditPut(eitRowKey,"pi","incPrcSts","Success")
    hbaseAuditPut(eitRowKey,"pi","prcEndTm",format.format(Calendar.getInstance().getTime()))
    hbaseAuditPut(eitRowKey,"pi","prcStTm",startTime)
    hbaseAuditPut(eitRowKey,"pi","precessed-errreccnt",error_recCount)
    hbaseAuditPut(eitRowKey,"pi","prtnrCd",prtnrCd)
    hbaseAuditPut(eitRowKey,"pi","processed-reccnt",processed_count)
    hbaseAuditPut(eitRowKey,"pi","unmatched/unprocessed-reccnt",unproc_count)
    hbaseAuditPut(eitRowKey,"pi","srcCd",srcCd)
    hbaseAuditPut(eitRowKey,"pi","prcdt",testdateFormat.format(Calendar.getInstance().getTime()))
  }
  def hbaseAuditPut(eitRowKey: String, colFm: String, colNm: String, value: String): Unit = {
    try {
      val p = new Put(s"$eitRowKey".getBytes())
      p.addColumn(s"$colFm".getBytes(), s"$colNm".getBytes(), s"$value".getBytes())
      globalContext.ihrEitTab.put(p)
    } catch {
      case e: Exception => Logger.log.info("Exception at HBase EIT Put Commands at IHR_entity_info IHR_ADT_DTL" :+ e.getStackTrace.mkString)
        throw e
    }
  }
}
