package com.optum.ihrcentri.LabResults

import org.apache.log4j.Level

/**
  * Created by rkodur on 3/6/2018.
  */
object Logger {
  @transient lazy val log: org.apache.log4j.Logger = org.apache.log4j.LogManager.getLogger(getClass.getName)
  log.setLevel(Level.ALL)
}
