package com.optum.ihrcentri.LabResults


import java.text.SimpleDateFormat
import java.util.Calendar
import com.optum.ihrcentri.Common.{GlobalContext,Logger}
import org.apache.spark.storage.StorageLevel
import scala.collection.parallel._


/**
  * Created by rkodur on 3/6/2018.
  */
object LabCorp {

  val format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
  val starTimeStamp=format.format(Calendar.getInstance().getTime())
  var rowKey:String=""
  var auditRowKey:String=""

  def main(args: Array[String]): Unit = {

    val globalContext = new GlobalContext
    val functions=new CommonFunctions
    val transformations=new Transformations

    val numThreads:Int = globalContext.threads.toInt

    Logger.log.info("=============> Starting IHR Lab Incremental WorkFlow <=============")
    if (args.length != 1) {
      Logger.log.info("Please Pass RowKey \"PATNRCD-SRCCD-ENTITYNAME\" for IHR Incremental extract")
      Logger.log.info("===> Since No RowKey is Passed ending IHR Incremental extract <===")
      functions.HBaseAuditFailureReport("No-Row-key-LabResults","No-Row-key-LabResults","2","Since No RowKey is Passed ending IHR Incremental extract")
      globalContext.spark.stop()
    }
    else {
      rowKey = args(0).toUpperCase().trim
      auditRowKey = rowKey+"-"+s"${java.util.UUID.randomUUID.toString}"
      try {
          val rptCfgScan = Lib.getEntityInfo(rowKey)
          val incEndTs = Lib.getCurrentTimeFormat

          rptCfgScan.foreach { case (patnrCd, srcCd, entNm, lastRunSts, outFileNm, outFileExt, isFilter) =>
            val getFileList: ParSeq[String] = Lib.eitTabScan(patnrCd, srcCd, entNm, lastRunSts, incEndTs).par

            getFileList.tasksupport = new ForkJoinTaskSupport(new scala.concurrent.forkjoin.ForkJoinPool(numThreads))

            val listSize = getFileList.size
            Logger.log.info(s"Total FileList: " + listSize)
            Logger.log.info(s"List of Files from $lastRunSts to $incEndTs: " + getFileList)
            if (listSize != 0) {

              Logger.log.info(s"=================> Lab Results Incremental Aco Roster filter started for $entNm <==========================")
              Logger.log.info("Process Start time: " + starTimeStamp)

              val stgOutpath= globalContext.stgdir+entNm+"/stgoutdir/"
              val stgLogDir=  globalContext.stgdir+entNm+"/stglogdir/"
              val stgErrorDir= globalContext.stgdir+entNm+"/stgerrordir/"

              val stgPath = stgOutpath.replace("/mapr/", "hdfs:///")
              val stgLogPath = stgLogDir.replace("/mapr/", "hdfs:///")
              val stgrrordir = stgErrorDir.replace("/mapr/", "hdfs:///")

              val errordir = globalContext.errorDir.replace("/mapr/", "hdfs:///")
              val outRPath = globalContext.outpath.replace("/mapr/", "hdfs:///")
              val templogdir = globalContext.logDir.replace("/mapr/", "hdfs:///")

              functions.cleanOutputPath(globalContext.outputNodeAddress, stgPath)
              functions.cleanOutputPath(globalContext.outputNodeAddress, stgLogPath)
              functions.cleanOutputPath(globalContext.outputNodeAddress, stgrrordir)

              val acoDf=transformations.SDRreadAcoFile(globalContext.aco_file,globalContext.sparkS).cache()

              for (file2 <- getFileList) {
                Logger.log.info("Current Processing file: " + file2)
                val inputfile = file2.replace("maprfs://", "/mapr")
                RunJob.labExecution(globalContext.sparkS, acoDf, inputfile, stgOutpath, isFilter, entNm, stgLogPath, stgErrorDir,auditRowKey)
                Thread.sleep(1000)
              }

              Logger.log.info("Moving files from stage outbound to Actual outbound path")
              functions.moveFile(stgPath, outRPath + "/" + entNm + "/")

              Logger.log.info("Moving files from stage log dir to actual log dir")
              functions.moveFile(stgLogPath, templogdir + "/" + entNm + "/")

              Logger.log.info("Moving files from stg error dir to actual error dir")
              functions.moveFile(stgrrordir, errordir + "/" + entNm + "/")

              Logger.log.info("Updating the HBase timestamp" + format.format(Calendar.getInstance().getTime()))
              Lib.hbaseEitPut(rowKey, globalContext.RuntimColFm, globalContext.RuntimColNm, format.format(Calendar.getInstance().getTime()))

              Logger.log.info("Generating the Success Audit Report")
              functions.HbaseAuditSuccessReport(rowKey,auditRowKey)
              Logger.log.info("Records with matches: " + RunJob.totalMatches)
              Logger.log.info("Records without matches: " + RunJob.totalMissMatches)
              Logger.log.info(s"==============> Incremental Aco Roster filter for ${entNm} Completed successfully <===============")
            } else {
              Logger.log.info("No input files")
              Logger.log.info("Creating Hbase failure scenerio")
              functions.HBaseAuditFailureReport(rowKey,auditRowKey, "No input files", "No input files")
              globalContext.sparkS.stop()
            }
          }
        }
    catch {
          case e: Exception => Logger.log.info("Errored: " + e.getMessage)
          functions.HBaseAuditFailureReport(rowKey,auditRowKey,e.getLocalizedMessage,e.getMessage)
          globalContext.sparkS.stop()
      }
    }
  }
}
