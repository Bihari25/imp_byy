package com.optum.centriihr.common

import java.text.SimpleDateFormat
import java.util.{Calendar, Date}

import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.fs.{FileSystem, FileUtil, Path}
import org.apache.log4j.{Level, LogManager}
import org.apache.spark.sql.SparkSession

object IHRUtils {

  @transient lazy val log = LogManager.getLogger(getClass.getName)
  log.setLevel(Level.INFO)

  val dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")

  val dateFormat2 = new SimpleDateFormat("yyyy-MM-dd")



  def getProperty(sparkSession: SparkSession, propertyName: String ): String = {
    sparkSession.sparkContext.getConf.get(propertyName)
  }

  def getProperty(sparkSession: SparkSession, propertyName: String, defaultValue: String ): String = {
    sparkSession.sparkContext.getConf.get(propertyName, defaultValue)
  }

  def getCurrentTime(): String = {
    dateFormat.format(Calendar.getInstance().getTime())
  }

  def getDate(): String = {
    dateFormat2.format(Calendar.getInstance().getTime())
  }


  def getCurrentTimeInLong(dateString : String): Long = {
    dateFormat.parse(dateString).getTime
  }

  def moveFile(srcFilePath: String,destFilePath: String): Unit= {
    val hadoopConf = new Configuration()
    val source = new Path(srcFilePath)
    val target = new Path(destFilePath)
    val fs: FileSystem = source.getFileSystem(hadoopConf)
    val sourceFiles = fs.listFiles(source, true)
    if (sourceFiles != null) {
      while (sourceFiles.hasNext()) {
        FileUtil.copy(fs, sourceFiles.next().getPath(), fs, target, true, hadoopConf)
      }
    }
  }
}
