package com.optum.centriihr.domain

import com.optum.centriihr.common.IHRUtils
import org.apache.hadoop.hbase.client.Result
import org.apache.hadoop.hbase.util.Bytes

case class IHRAuditTracking(id: String, prcName: String, incPrcSts: String, prcDate: String, prcEndTm: String, prcStTm: String, prtnrCd: String, srcCd: String, reccnt: String, errCd: String, errDesc: String)
  extends Serializable {
  override def toString: String = return s"id:$id, prcName:$prcName, incPrcSts:$incPrcSts, prcDate:$prcDate, prcEndTm:$prcEndTm, prcStTm:$prcStTm, prtnrCd:$prtnrCd, srcCd:$srcCd, reccnt:$reccnt, errCd:$errCd, errDesc:$errDesc"
}

object IHRAuditTracking extends Serializable {

  def returnObject(id: String, prcName: String, incPrcSts: String, prcDate: String, prcEndTm: String, prcStTm: String, prtnrCd: String, srcCd: String, reccnt: String, errCd: String, errDesc: String) : IHRAuditTracking =
  { new IHRAuditTracking(id, prcName, incPrcSts, prcDate, prcEndTm, prcStTm, prtnrCd, srcCd, reccnt, errCd, errDesc) }

  val piCF = Bytes.toBytes("po");

  val eriCF = Bytes.toBytes("eri");

  def parseHbaseIHRRow(result: Result): Any = {

    val rowkey = Bytes.toString(result.getRow())

    val prcNm = Bytes.toString(result.getValue(piCF, Bytes.toBytes("entNm")))
    val incPrcSts = Bytes.toString(result.getValue(piCF, Bytes.toBytes("incPrcSts")))

    val prcDate = Bytes.toString(result.getValue(piCF, Bytes.toBytes("prcDate")))
    val prcEndTm = Bytes.toString(result.getValue(piCF, Bytes.toBytes("prcEndTm")))
    val prcStTm = Bytes.toString(result.getValue(piCF, Bytes.toBytes("prcStTm")))



    val prtnrCd = Bytes.toString(result.getValue(piCF, Bytes.toBytes("prtnrCd")))
    val srcCd = Bytes.toString(result.getValue(piCF, Bytes.toBytes("srcCd")))
    val reccnt = Bytes.toString(result.getValue(piCF, Bytes.toBytes("reccnt")))

    val errCd = Bytes.toString(result.getValue(eriCF, Bytes.toBytes("errCd")))
    val errDesc = Bytes.toString(result.getValue(eriCF, Bytes.toBytes("errDesc")))

    IHRUtils.log.info("rowkey=" + rowkey)
    IHRAuditTracking(rowkey, prcNm, incPrcSts, prcDate, prcEndTm, prcStTm, prtnrCd, srcCd, reccnt, errCd, errDesc)
  }
}
