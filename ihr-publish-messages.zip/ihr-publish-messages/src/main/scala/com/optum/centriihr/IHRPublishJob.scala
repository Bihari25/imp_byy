package com.optum.centriihr

import java.io.{File, FileInputStream,StringWriter, PrintWriter}
import java.net.URI
import java.text.{ParseException, SimpleDateFormat}
import java.util.{Base64, Calendar, Date, Properties}

import com.optum.centriihr.common.IHRUtils._
import com.optum.centriihr.common.HBaseUtil
import com.optum.centriihr.domain.IHRAuditTracking
import com.rabbitmq.client._
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession


import org.apache.hadoop.fs.permission.{FsAction, FsPermission}
import org.apache.hadoop.fs.{FSDataOutputStream, FileSystem, Path}
import org.apache.spark.SparkContext
import org.apache.spark.util.LongAccumulator

import scala.tools.cmd.Spec.Accumulator


object IHRPublishJob {


  def main(args: Array[String]) {

    //val sparkSession = SparkSession.builder().appName("ihrPublish").enableHiveSupport().getOrCreate()
    val sparkSession = SparkSession.builder().appName("ihrPublish").getOrCreate()
    val sparkContext = sparkSession.sparkContext
    val sparkConf = sparkContext.getConf
    sparkConf.set("spark.serializer", "org.apache.spark.serializer.KryoSerializer")
    sparkConf.set("spark.eventLog.enabled","true")
    //sparkConf.set("hive.metastore.uris", "thrift://dbsls0324.uhc.com:11015")
    //sparkConf.set("spark.sql.warehouse.dir", "./spark-warehouse")

    val rowCounter = sparkContext.longAccumulator("rowCounter")

    val prop : Properties = new Properties()
    val processStartTime = getCurrentTime
    var processEndTime = ""
    var processDate = getDate
    val propsFile = new File(sparkConf.get("spark.myapp.properties"))
    if (propsFile.exists()) {
      prop.load(new FileInputStream(propsFile))
    }
    val domain = sparkConf.get("spark.ihr.domain")
    prop.setProperty("domain", domain);
    val batchId = sparkConf.get("spark.ihr.batchId")
    prop.setProperty("batchId", batchId);
    val hbaseAuditTable = prop.getProperty("spark.ihr.audit.table")

    val output = prop.getProperty("ihr_archive").replaceAll("/mapr", "")+"/"+domain+"/"
    val processMetrics = prop.getProperty("ihr_home").replaceAll("/mapr", "")+"/d_hdfs/"+domain+"-spark.process"

    var hbaseRowKey = sparkConf.get("spark.ihr.rowkey")

    hbaseRowKey = if(!hbaseRowKey.contains("-") || hbaseRowKey.split("-").length <2) s"NO-ROWKEY-DEFINED_$hbaseRowKey" else hbaseRowKey


    var processName = hbaseRowKey.split("-")(2)//prop.getProperty(domain+"_rowkey")
    var outputProperties = new Properties();
    //var outputValues = new StringBuilder()
    var outputHTML = new StringBuilder()
    outputProperties.put("domain", domain)
    outputProperties.put("hbaseAuditTable", hbaseAuditTable)
    outputProperties.put("hbaseRowKey", hbaseRowKey)
    outputHTML.append("<table border=1> <tr> <td> Domain </td> <td> "+domain+"</td> </tr> ")
    var count = 0l
    var inputFileRecords = 0l
      try {
      val input = prop.getProperty("ihr_landing").replaceAll("/mapr", "")+"/"+domain+"/"
      //val hbaseRowKey = sparkSession.read.text(input).select(input_file_name, $"value").select(col("input_file_name()")).first.getString(0).reverse.split("/")(0).reverse.split("\\.")(0)



      //val hbaseRowKey = processName+"-"+(batchId.reverse.substring(0, batchId.reverse.indexOf("_")).reverse)//+"-"+s"${java.util.UUID.randomUUID.toString}"

      val inputFile = sparkContext.textFile(input)
      inputFileRecords = inputFile.count()
      log.info("IHRPublishJob partitions.length="+inputFile.partitions.length+" inputFile.count="+inputFileRecords)
      val result : RDD[(String)] = inputFile.mapPartitions(dataMapper(_, prop, rowCounter))
      //result.saveAsTextFile(output+"temp_output/"+getCurrentTimeInLong(processStartTime))
      count = result.count()
      // 10 10
      // need to check whether rowCounter is always == inputFileRecords for success use case
      log.info("IHRPublishJob inputFileRecords="+inputFileRecords+", rowCounter="+rowCounter.value)
      processEndTime = getCurrentTime

      // # of rec, domain, host, duration
      outputProperties.put("count",rowCounter.value+"")
      outputProperties.put("rabbitMQHost", prop.getProperty("host"))
      val duration = (getCurrentTimeInLong(processEndTime) - getCurrentTimeInLong(processStartTime))/1000
      outputProperties.put("duration", ""+duration)
      outputProperties.put("errorCode", "0")
      outputHTML.append("<tr> <td> Count </td> <td> "+count +"</td> </tr>")
      outputHTML.append("<tr> <td> Rabbit MQ Host </td> <td> "+prop.getProperty("host") +"</td> </tr>")
      outputHTML.append("<tr> <td> Duration (in seconds) </td> <td> "+duration +"</td> </tr>")
      outputHTML.append("</table>")
      outputProperties.put("outputHTML",outputHTML.toString)
      writeProcessInfo(outputProperties, processMetrics, sparkContext)

      val iHRAuditTracking = new IHRAuditTracking(hbaseRowKey, processName, "Success", processDate, processEndTime, processStartTime, hbaseRowKey.split("-")(0), hbaseRowKey.split("-")(1), ""+count, "","")
      updateAudit(sparkSession, hbaseAuditTable, iHRAuditTracking)
      //moveFile(input, output)
    } catch {

      case ex: Exception => {

        val stringWriter = new StringWriter
        ex.printStackTrace(new PrintWriter(stringWriter))
        log.info("in exception blobk, inputFileRecords="+inputFileRecords+", rowCounter="+rowCounter.value+", count="+count)
        log.info("got exception and stackTrace: " + ex.getMessage)
        processEndTime = getCurrentTime
        // # of rec, domain, host, duration


        //outputProperties.put("count", sparkContext.longAccumulator("rowCounter").value+"")
        var soFarProcessed = ex.getMessage.split("~~==~~==")(1)+""
        outputProperties.put("count", soFarProcessed)


        outputProperties.put("rabbitMQHost",prop.getProperty("host"))
        val duration = (getCurrentTimeInLong(processEndTime) - getCurrentTimeInLong(processStartTime))/1000
        outputProperties.put("duration",duration+"")
        outputProperties.put("errorCode","1")
        outputHTML.append("<tr> <td> Count </td> <td> "+soFarProcessed+" </td> </tr>")
        outputHTML.append("<tr> <td> Rabbit MQ Host </td> <td> "+prop.getProperty("host") +"</td> </tr>")
        outputHTML.append("<tr> <td> Duration (in seconds) </td> <td> "+duration +"</td> </tr>")
        outputHTML.append("</table>")
        outputProperties.put("outputHTML",outputHTML+"\n")
        writeProcessInfo(outputProperties, processMetrics, sparkContext)
        val iHRAuditTracking = new IHRAuditTracking(hbaseRowKey, processName, "Failure", processDate, processEndTime, processStartTime, hbaseRowKey.split("-")(0), hbaseRowKey.split("-")(1), soFarProcessed, ex.getMessage, stringWriter.toString)
        updateAudit(sparkSession, hbaseAuditTable, iHRAuditTracking)
      }

    }
    sparkContext.stop()
  }

  @throws(classOf[Exception])
  def dataMapper(iter: Iterator[(String)], prop: Properties, rowCounter: LongAccumulator) : Iterator[String] = {
    log.info("IHRPublishJob dataMapper")
    var domain = prop.getProperty("domain")
    val queueName = prop.getProperty(domain+"_queue")
    val factory = new ConnectionFactory
    factory.setHost(prop.getProperty("host"))
    factory.setPort(Integer.parseInt(prop.getProperty("port")))
    factory.setUsername(prop.getProperty("rabbitmq_user_name"))
    factory.setPassword(prop.getProperty("rabbitmq_password"))
    factory.setVirtualHost(prop.getProperty("virtualhost"))
    val connection = factory.newConnection
    log.info("connection=" + connection)
    val channel = connection.createChannel
    channel.queueDeclare(queueName, true, false, false, null)
    val obj = iter.map(publishMessage(_, channel, prop, rowCounter))
    log.info("IHRPublishJob, obj="+obj)
    return obj
  }

  @throws(classOf[Exception])
  def publishMessage(line : String, channel : Channel, prop: Properties, rowCounter: LongAccumulator) : String = {

    try {
      rowCounter.add(1)
      var domain = prop.getProperty("domain")
      val queueName = prop.getProperty(domain+"_queue")
      val translatorId = prop.getProperty(domain+"_translator")
      var batchId = prop.getProperty("batchId")
      var msgLine = line.replaceAll("\f","\r")

      var encodedMessage = Base64.getEncoder.encodeToString(msgLine.getBytes)
      encodedMessage = encodedMessage+"^"+translatorId+"^"+batchId+"_"+rowCounter.value+"^"+batchId
      channel.basicPublish("", queueName, MessageProperties.PERSISTENT_TEXT_PLAIN, encodedMessage.getBytes("UTF-8"))
      //log.info(" [x] Sent '" + msgLine + "'")

//      if(rowCounter.value == 500) {
//        throw new Exception("afreen test limit reached")
//      }
      return msgLine
    } catch {
      case ex: Exception => {
        throw new Exception(ex.getMessage+"~~==~~=="+rowCounter.value+"~~==~~==", ex)
      }

    }

  }

  def updateAudit(sparkSession: SparkSession, hbaseTableName : String, ihrAuditTracking : IHRAuditTracking): Unit = {
    val hbaseUtil = new HBaseUtil(sparkSession)
    hbaseUtil.writeToHBase(hbaseTableName, ihrAuditTracking )
  }

  def writeProcessInfo(outputProperties: Properties, processMetrics: String, sparkContext: SparkContext): Unit = {
    val processMetricsFile = new Path(processMetrics)
    val fs = FileSystem.get(new URI(processMetrics), sparkContext.hadoopConfiguration)
    if (fs.exists(processMetricsFile)) fs.delete(processMetricsFile,true) // isRecusrive= true
    val fos : FSDataOutputStream = fs.create(processMetricsFile, true)
    outputProperties.store(fos, "ihr spark process file")
    //fos.writeUTF(outputValues.toString())
    fs.setPermission(processMetricsFile, new FsPermission(FsAction.READ_WRITE, FsAction.READ_WRITE, FsAction.NONE))
    fos.close()

  }

}

