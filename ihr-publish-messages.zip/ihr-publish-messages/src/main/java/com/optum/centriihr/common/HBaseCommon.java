package com.optum.centriihr.common;

import com.optum.centriihr.domain.IHRAuditTrackingDTO;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.hbase.TableName;
import org.apache.hadoop.hbase.client.Connection;
import org.apache.hadoop.hbase.client.ConnectionFactory;
import org.apache.hadoop.hbase.client.Put;
import org.apache.hadoop.hbase.client.Table;
import org.apache.hadoop.hbase.util.Bytes;

public class HBaseCommon {

    public static void writeToHBase(String tableName, IHRAuditTrackingDTO ihrAuditTrackingDTO) throws Exception{

        Configuration conf  = HBaseConfiguration.create();
        Connection conn  = ConnectionFactory.createConnection(conf);

        //IHRAuditTracking obj1 = new IHRAuditTracking();

        TableName hbaseTableName = TableName.valueOf(tableName);
        Table hbaseTable = conn.getTable(hbaseTableName);

        Put put = new Put(Bytes.toBytes(ihrAuditTrackingDTO.getId()));
        //put.addColumn(Bytes.toBytes("pi"), Bytes.toBytes("prtnrCd"), Bytes.toBytes(ihrAuditTrackingDTO.getPrtnrCd()));
        //put.addColumn(Bytes.toBytes("pi"), Bytes.toBytes("srcCd"), Bytes.toBytes(ihrAuditTrackingDTO.getSrcCd()));
        //put.addColumn(Bytes.toBytes("pi"), Bytes.toBytes("prcNm"), Bytes.toBytes(ihrAuditTrackingDTO.getPrcName()));
        //put.addColumn(Bytes.toBytes("pi"), Bytes.toBytes("incPrcSts"), Bytes.toBytes(ihrAuditTrackingDTO.getIncPrcSts()));
        //put.addColumn(Bytes.toBytes("pi"), Bytes.toBytes("prcStTm"), Bytes.toBytes(ihrAuditTrackingDTO.getPrcStTm()));
        //put.addColumn(Bytes.toBytes("pi"), Bytes.toBytes("prcEndTm"), Bytes.toBytes(ihrAuditTrackingDTO.getPrcEndTm()));
        //if(ihrAuditTrackingDTO.getReccnt() != null) {
        //    put.addColumn(Bytes.toBytes("pi"), Bytes.toBytes("recCount"), Bytes.toBytes(ihrAuditTrackingDTO.getReccnt()));
        //}

        if(ihrAuditTrackingDTO.getErrCd() != null && ihrAuditTrackingDTO.getErrCd().length()>0) {
            put.addColumn(Bytes.toBytes("eri"), Bytes.toBytes("errCd"), Bytes.toBytes(ihrAuditTrackingDTO.getErrCd()));
            put.addColumn(Bytes.toBytes("eri"), Bytes.toBytes("errDesc"), Bytes.toBytes(ihrAuditTrackingDTO.getErrDesc()));
        }
        hbaseTable.put(put);
    }
}
