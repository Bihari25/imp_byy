package com.optum.centriihr.domain;


public class IHRAuditTrackingDTO  {


    String id;
    String prcName;
    String incPrcSts;
    String prcEndTm;
    String prcStTm;
    String prtnrCd;
    String srcCd;
    String reccnt;
    String errCd;
    String errDesc;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getPrcName() {
        return prcName;
    }

    public void setPrcName(String prcName) {
        this.prcName = prcName;
    }

    public String getIncPrcSts() {
        return incPrcSts;
    }

    public void setIncPrcSts(String incPrcSts) {
        this.incPrcSts = incPrcSts;
    }

    public String getPrcEndTm() {
        return prcEndTm;
    }

    public void setPrcEndTm(String prcEndTm) {
        this.prcEndTm = prcEndTm;
    }

    public String getPrcStTm() {
        return prcStTm;
    }

    public void setPrcStTm(String prcStTm) {
        this.prcStTm = prcStTm;
    }

    public String getPrtnrCd() {
        return prtnrCd;
    }

    public void setPrtnrCd(String prtnrCd) {
        this.prtnrCd = prtnrCd;
    }

    public String getSrcCd() {
        return srcCd;
    }

    public void setSrcCd(String srcCd) {
        this.srcCd = srcCd;
    }

    public String getReccnt() {
        return reccnt;
    }

    public void setReccnt(String reccnt) {
        this.reccnt = reccnt;
    }

    public String getErrCd() {
        return errCd;
    }

    public void setErrCd(String errCd) {
        this.errCd = errCd;
    }

    public String getErrDesc() {
        return errDesc;
    }

    public void setErrDesc(String errDesc) {
        this.errDesc = errDesc;
    }



/*
     IHRAuditTracking(id:String, prcName:String, incPrcSts:String, prcEndTm:String, prcStTm:String, prtnrCd:String, srcCd:String, reccnt:String, errCd:String, errDesc:String) {
     }
     */


}
