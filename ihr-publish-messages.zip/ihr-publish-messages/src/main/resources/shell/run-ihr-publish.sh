#!/bin/sh

# leagcy script, just keeping for reference

if [ "$#" -ne 2 ];
then
  echo "Usage: $0 <dev/prd> <member_mr/member_cs/member_mr_cov/member_cs_cov/labresult>"
  exit 1
fi

ENV=$1
domain=$2

. ./ihr-${ENV}.properties 1>/dev/null 2>&1
#echo ${IHR_HOME}


sed -i 's/^M//g' ${ihr_landing}/*/*.hl7


spark-submit --conf spark.myapp.properties=${ihr_shell}/ihr-${ENV}.properties --conf spark.ihr.domain=${domain} --jars ${ihr_home}/jars/amqp-client-3.6.5.jar --class com.optum.centriihr.IHRPublishJob --master yarn --queue ${mapr_queue_name} ${ihr_home}/jars/ihr-publish-messages-1.0.0-SNAPSHOT.jar