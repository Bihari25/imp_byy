from airflow import DAG
from airflow.models import Variable
from big_query_fast_copy_operator import BigQueryFastCopyOperator
from airflow.contrib.operators.bigquery_operator import BigQueryOperator
from airflow.operators.bash_operator import BashOperator
from airflow.operators.python_operator import PythonOperator
from datetime import date, datetime, timedelta
from platform_engineering.utilities.email import *
from platform_engineering.utilities.utils import *


args = {
    'owner': 'Platform Engineering',
    'depends_on_past': False,
    'start_date': datetime(2021, 1, 27),
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 0,
    'use_legacy_sql': False
}

base_data_dir = Variable.get('base_data_dir')

uld_dim_loinc_code_dir = Variable.get('uld_dim_loinc_code_dir') + '/'
uld_dim_loinc_code_filename = Variable.get('uld_dim_loinc_code_filename')

metadata_table = Variable.get('uld_metadata_table')


def uld_dim_loinc_code(dag_name):
    with DAG(dag_id=dag_name, default_args=args, schedule_interval=None, catchup=False, template_searchpath=base_data_dir) as dag:

        notify_start = start_notification(dag, dag_name)

        log = BashOperator(
            task_id='log',
            bash_command='''
            bq query --use_legacy_sql=false "insert into research-01-217611.df_uld_stage.logging (job, message_datetime) select \'about to start a run...\' as job, current_datetime as message_datetime";
             '''
        )

        # Archival step
        archive = 'uld_dim_loinc_code_archive'

        get_archive_list = PythonOperator(task_id='get_archive_list',
                                          provide_context=True,
                                          python_callable=push_table_list_xcom,
                                          op_kwargs={'interface': archive,
                                                     'metadata_table': metadata_table
                                                     }
                                          )

        archive_tables = BigQueryFastCopyOperator(
            task_id='archive_tables',
            archive=True,
            use_xcom=True,
            xcom_sources_key='source_list_' + archive,
            xcom_sources_task_id='get_archive_list'
        )

        dim_loinc_code = BigQueryOperator(
            task_id=uld_dim_loinc_code_filename.split('.')[0],
            sql=uld_dim_loinc_code_dir + uld_dim_loinc_code_filename
        )

        notify_success = success_notification(dag, dag_name)

        notify_start >> log >> get_archive_list >> archive_tables >> dim_loinc_code >> notify_success

    return dag


uld_dim_loinc_code = uld_dim_loinc_code('ULD_dimLoincCode_load')
