from airflow import DAG
from airflow.models import Variable
from big_query_fast_copy_operator import BigQueryFastCopyOperator
from airflow.contrib.operators.bigquery_operator import BigQueryOperator
from airflow.operators.bash_operator import BashOperator
from airflow.operators.python_operator import PythonOperator
from datetime import date, datetime, timedelta
from platform_engineering.utilities.email import *
from platform_engineering.utilities.utils import *


args = {
    'owner': 'Platform Engineering',
    'depends_on_past': False,
    'start_date': datetime(2021, 1, 27),
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 0,
    'use_legacy_sql': False
}

base_data_dir = Variable.get('base_data_dir')

ihr_lab_dir = Variable.get('uld_ihr_lab_dir') + '/'
ihr_lab_wkg_dir = ihr_lab_dir + 'working_ihr_lab'
ihr_lab_wkg_filenames = Variable.get('uld_ihr_lab_wkg_filenames').split(',')

ihr_lab_final_wkg_filename = Variable.get('uld_ihr_lab_final_wkg_filename')
ihr_lab_stage_filename = Variable.get('uld_ihr_lab_stage_filename')

metadata_table = Variable.get('uld_metadata_table')

def uld_ihr_lab(dag_name):
    with DAG(dag_id=dag_name, default_args=args, schedule_interval=None, catchup=False, template_searchpath=base_data_dir) as dag:

        notify_start = start_notification(dag, dag_name)

        log = BashOperator(
            task_id='log',
            bash_command='''
            bq query --use_legacy_sql=false "insert into research-01-217611.df_uld_stage.logging (job, message_datetime) select \'about to start a run...\' as job, current_datetime as message_datetime";
             '''
        )

        # Archival step
        archive = 'uld_ihr_lab_archive'

        get_archive_list = PythonOperator(task_id='get_archive_list',
                                          provide_context=True,
                                          python_callable=push_table_list_xcom,
                                          op_kwargs={'interface': archive,
                                                     'metadata_table': metadata_table
                                                     }
                                          )

        archive_tables = BigQueryFastCopyOperator(
            task_id='archive_tables',
            archive=True,
            use_xcom=True,
            xcom_sources_key='source_list_' + archive,
            xcom_sources_task_id='get_archive_list'
        )

        working_tables_step1 = create_dags(
            ihr_lab_wkg_filenames, ihr_lab_wkg_dir)

        working_tables_step2 = BigQueryOperator(
            task_id=ihr_lab_final_wkg_filename.split('.')[0],
            sql=ihr_lab_dir + ihr_lab_final_wkg_filename
        )

        # Copy templates
        template = 'uld_ihr_lab_template'

        get_copy_templates_list = PythonOperator(task_id='get_copy_templates_list',
                                                 provide_context=True,
                                                 python_callable=push_table_list_xcom,
                                                 op_kwargs={'interface': template,
                                                            'metadata_table': metadata_table
                                                            }
                                                 )

        create_tables_from_templates = BigQueryFastCopyOperator(
            task_id='create_tables_from_templates',
            use_xcom=True,
            xcom_sources_key='source_list_' + template,
            xcom_sources_task_id='get_copy_templates_list',
            xcom_destinations_key='destination_list_' + template,
            xcom_destinations_task_id='get_copy_templates_list'
        )

        working_tables_step3 = BigQueryOperator(
            task_id=ihr_lab_stage_filename.split('.')[0],
            sql=ihr_lab_dir + ihr_lab_stage_filename
        )

        # Final copy
        final = 'uld_ihr_lab_final'

        get_final_list = PythonOperator(task_id='get_final_list',
                                        provide_context=True,
                                        python_callable=push_table_list_xcom,
                                        op_kwargs={'interface': final,
                                                   'metadata_table': metadata_table
                                                   }
                                        )

        copy_from_stg_to_final = BigQueryFastCopyOperator(
            task_id='copy_from_stg_to_final',
            use_xcom=True,
            xcom_sources_key='source_list_' + final,
            xcom_sources_task_id='get_final_list',
            xcom_destinations_key='destination_list_' + final,
            xcom_destinations_task_id='get_final_list'
        )

        notify_success = success_notification(dag, dag_name)

        notify_start >> log >> get_archive_list >> archive_tables >> working_tables_step1 >> working_tables_step2 >> get_copy_templates_list >> create_tables_from_templates >> working_tables_step3 >> get_final_list >> copy_from_stg_to_final >> notify_success

    return dag


uld_ihr_labs_dag = uld_ihr_lab('ULD_labIHR_load')
