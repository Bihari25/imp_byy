from airflow import DAG
from airflow.utils.email import send_email
from airflow.operators.email_operator import EmailOperator
from datetime import datetime, timedelta
from airflow.models import Variable

to_email = Variable.get("notify_to")
airflow_url = Variable.get("airflow_base_url")


def notify_email(contextDict, **kwargs):
    dict = {
        'dag_id': str(contextDict['task_instance'].dag_id),
        'task_id': str(contextDict['task_instance'].task_id),
        'execution_date': str(contextDict['execution_date']).replace(':', '%3A').replace('+', '%2B'),
        'formatted_ts': datetime.fromtimestamp(int(datetime.now().timestamp())).strftime("%m/%d/%Y %H:%M:%S"),
        'airflow_url' : airflow_url
    }

    # email title
    title = '''{dag_id} : processing has encountered a failure at {task_id} - {formatted_ts}'''.format(**dict)
    # email contents
    body = '''
    <br>
    <br>
    <p><font size="3"> Platform Engineering Data Load failed at {dag_id} - {task_id} - {formatted_ts}.</font></p>
    For more details <a href="{airflow_url}/admin/airflow/log?task_id={task_id}&dag_id={dag_id}&execution_date={execution_date}"> Click here</a>
    <br><br>
    -Thanks<br><br>'''.format(**dict)
    send_email(to_email, title, body)


def start_notification(dag_obj, batch_name):
    formatted_ts = curr_ts()
    body = '''
    <br><br>
    Platform Engineering Data loads has been successfully started at {0} <br><br>
    For more details  {1}/admin/airflow/graph?dag_id={2}<br>
    <br>
    -Thanks<br><br>
    '''.format(formatted_ts, airflow_url, batch_name)

    return EmailOperator(
        task_id='start_notification',
        to=to_email,
        subject=batch_name + ' - Data load starts - ' + formatted_ts,
        html_content=body,
        dag=dag_obj)


def success_notification(dag_obj, batch_name):
    formatted_ts = curr_ts()
    body = '''
    <br><br>
    Platform Engineering Data load is successful for {0}<br><br>
    For more details at {1}<br>
    <br>
    -Thanks<br><br>
    '''.format(batch_name, airflow_url)

    return EmailOperator(
        task_id='success_notification',
        to=to_email,
        subject='{0} :  completed at {1}'.format(batch_name, formatted_ts),
        html_content=body,
        dag=dag_obj)

def curr_ts():
    return datetime.fromtimestamp(int(datetime.now().timestamp())).strftime("%m/%d/%Y %H:%M:%S")