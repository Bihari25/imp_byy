from airflow.models import Variable
from airflow.contrib.hooks.bigquery_hook import BigQueryHook
from airflow.contrib.operators.bigquery_operator import BigQueryOperator
from big_query_fast_copy_operator import BigQueryFastCopyOperator
import os
import logging

base_data_dir = Variable.get('base_data_dir')

def push_table_list_xcom(**kwargs):
    task_instance = kwargs['task_instance']
    interface = kwargs['interface']
    metadata_table = kwargs ['metadata_table']
    hook = BigQueryHook(
        bigquery_conn_id="bigquery_default",
        use_legacy_sql=False,
        delegate_to=None)
    conn = hook.get_conn()
    bq_cursor = conn.cursor()
    bq_cursor.execute(
        "SELECT SOURCE, DESTINATION FROM " + metadata_table + " WHERE INTERFACE = '" + interface + "';")
    source_list = []
    destination_list = []
    result = bq_cursor.fetchall()
    for entry in result:
        source_list.append(entry[0])
        destination_list.append(entry[1])
    task_instance.xcom_push(key="source_list_" + interface, value=source_list)
    task_instance.xcom_push(key="destination_list_" +
                                interface, value=destination_list)


def create_dags(filenames=[], directory=""):
    dag_list = []
    for filename in filenames:
        run_enriched_transformation = BigQueryOperator(
            task_id=filename.split('.')[0],
            sql=directory+"/"+filename
        )
        dag_list.append(run_enriched_transformation)
    return dag_list


def query_metadata(sql="", run_id="", archive_filters="", **context):
    task_instance = context['task_instance']
    tables_summary = []
    for filt in archive_filters:
        hook = BigQueryHook(
            bigquery_conn_id="bigquery_default",
            use_legacy_sql=False,
            delegate_to=None)
        conn = hook.get_conn()
        bq_cursor = conn.cursor()
        where = " WHERE table_id LIKE '%"
        filts = filt.split("|")
        i = 0
        while i < len(filts):
            if i == 0:
                where += filts[i]+"%'"
            else:
                where += " OR table_id LIKE '%" + filts[i] + "%'"
            i += 1
        query = sql + where
        logging.info(query)
        bq_cursor.execute(query)
       ## path = '/home/airflow/gcs/data/de_pe/' +run_id\
        tables = []
        result = bq_cursor.fetchall()
        for entry in result:
            p_ds_table = "{}.{}.{}".format(entry[0], entry[1], entry[2])
            if entry[2].find("summary") == -1 and entry[2].find("scores") == -1:
                tables.append(p_ds_table)
            else:
                tables_summary.append(p_ds_table)
        filt = filt.replace("|", "_")
        task_instance.xcom_push(key=filt, value=tables)
    task_instance.xcom_push(key="summary", value=tables_summary)


def group_big_query_copy(task_id, xcom_key, xcom_task_id, dag, **kwargs):
    # load the values if needed in the command you plan to execute
    return BigQueryFastCopyOperator(
        task_id=task_id,
        archive=True,
        use_xcom=True,
        xcom_sources_key=xcom_key,
        xcom_sources_task_id=xcom_task_id,
        dag=dag,
        trigger_rule="all_success",
    )


def generate_bq_list_from_files(filenames=[], bqlist=[], directory=""):
    for file in filenames:
        transform = BigQueryOperator(
            task_id=file.split('.')[0],
            sql=directory + "/" + file
        )
        bqlist.append(transform)
    return bqlist


def create_sequential_dependencies(op_list, previous_op, next_op):
    i = 0
    while i < len(op_list):
        if i not in [0]:
            op_list[i-1] >> op_list[i]
        else:
            if previous_op is not None:
                previous_op >> op_list[i]
        i += 1
    if next_op is not None:
        op_list[len(op_list)-1] >> next_op
     
