from airflow import DAG
from airflow.models import Variable
from big_query_fast_copy_operator import BigQueryFastCopyOperator
from airflow.contrib.operators.bigquery_operator import BigQueryOperator
from airflow.operators.bash_operator import BashOperator
from airflow.operators.subdag_operator import SubDagOperator
from airflow.operators.python_operator import PythonOperator
from datetime import date, datetime, timedelta
from platform_engineering.utilities.email import *
from platform_engineering.utilities.utils import *


base_data_dir = Variable.get('base_data_dir')

meta_table = Variable.get("safeGraph_metadata")

interface_dir = Variable.get('safeGraph_dir')
interface_filenames = Variable.get('safeGraph_filenames_monthly').split(",")

skipFlag = Variable.get('safeGraph_monthly_finalLoadFlag')

interface = 'safegraph'

args = {
    'owner': 'Platform Engineering',
    'depends_on_past': False,
    'start_date': datetime(2021, 1, 27),
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 0,
    'use_legacy_sql': False
}


def safeGraph_monthlyRefresh_load(dag_name):
    with DAG(dag_id=dag_name, default_args=args, schedule_interval=None, catchup=False, template_searchpath=base_data_dir) as dag:

        notify_start = start_notification(dag, dag_name)

        # Job Exeuction State
        log = BashOperator(
            task_id='log',
            bash_command='''
        bq query --use_legacy_sql=false "insert into research-01-217611.df_safegraph_stage.logging (job, message_datetime) select \'about to start a run...\' as job, current_datetime as message_datetime";
         '''
        )

        # get copy templates
        archive = 'safeGraph_monthly_archive'

        # Only Final Tables
        get_archive_list = PythonOperator(task_id='get_archive_list',
                                          provide_context=True,
                                          python_callable=push_table_list_xcom,
                                          op_kwargs={'interface': archive,
                                                     'metadata_table': meta_table})

        # apply copy templates
        archive_tables = BigQueryFastCopyOperator(
            task_id='archive_tables',
            archive=True,
            use_xcom=True,
            xcom_sources_key='source_list_' + archive,
            xcom_sources_task_id='get_final_list'
        )

        # Interface SQL Execution
        interface_sql = create_dags(interface_filenames, interface_dir)

        # copy from staging to stage final and df_uld
        copyFinal = 'safeGraph_monthly_final'

        get_final_list = PythonOperator(task_id='get_final_list',
                                        provide_context=True,
                                        python_callable=push_table_list_xcom,
                                        op_kwargs={'interface': copyFinal,
                                                   'metadata_table': meta_table})

        # apply copy templates
        if skipFlag == 'true' :
            copy_from_stg_to_final = BigQueryFastCopyOperator(
                task_id='copy_from_stg_to_final',
                use_xcom=True,
                xcom_sources_key='source_list_' + copyFinal,
                xcom_sources_task_id='get_final_list',
                xcom_destinations_key='destination_list_' + copyFinal,
                xcom_destinations_task_id='get_final_list'
            )

        notify_success = success_notification(dag, dag_name)

        if skipFlag == 'false' :
            notify_start >> log >> get_archive_list >> archive_tables >> interface_sql >> get_final_list >> notify_success
        else :
            notify_start >> log >> get_archive_list >> archive_tables >> interface_sql >> get_final_list >> copy_from_stg_to_final >> notify_success

    return dag


safeGraph_monthlyRefresh_dag = safeGraph_monthlyRefresh_load('safeGraph_monthlyRefresh')
