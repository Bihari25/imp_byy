from airflow import DAG
from airflow.models import Variable
from big_query_fast_copy_operator import BigQueryFastCopyOperator
from airflow.contrib.operators.bigquery_operator import BigQueryOperator
from airflow.operators.python_operator import PythonOperator
from airflow.operators.bash_operator import BashOperator
from platform_engineering.utilities.utils import *
from datetime import datetime, timedelta

base_data_dir = Variable.get('base_data_dir')


args = {
    'owner': 'Platform Engineering',
    'depends_on_past': False,
    'start_date': datetime(2021, 1, 27),
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 0,
    'use_legacy_sql': False
}
metadata_table = Variable.get('ucd_metadata_table')


# application arguments
membership_dir = Variable.get('ucd_membership_dir')
membership_filenames = Variable.get('ucd_membership_filenames').split(',')
membership = 'mem'


def membership_claims(dag_name):
    with DAG(dag_id=dag_name, default_args=args, schedule_interval=None, catchup=False, template_searchpath=base_data_dir) as dag:

        get_member_list = PythonOperator(task_id='get_member_list',
                                         provide_context=True,
                                         python_callable=push_table_list_xcom,
                                         op_kwargs={
                                             'interface': membership,
                                             'metadata': metadata_table
                                             }
                                         )

        copy_member = BigQueryFastCopyOperator(
            task_id='copy_member',
            use_xcom=True,
            xcom_sources_key='source_list_' + membership,
            xcom_sources_task_id='get_member_list',
            xcom_destinations_key='destination_list_' + membership,
            xcom_destinations_task_id='get_member_list'
        )

        get_member_list >> copy_member

        membership_sql = []
        for sql in membership_filenames:
            run_transformation = BigQueryOperator(
                task_id=sql.split('.')[0],
                sql=membership_dir + "/" + sql
            )
            membership_sql.append(run_transformation)
            create_sequential_dependencies(membership_sql, copy_member, None)

    return dag


membership_claims_dag = membership_claims('UCD_membership_load')
