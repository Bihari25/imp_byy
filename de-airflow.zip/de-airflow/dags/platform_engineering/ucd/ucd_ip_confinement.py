from airflow import DAG
from airflow.models import Variable
from big_query_fast_copy_operator import BigQueryFastCopyOperator
from airflow.contrib.operators.bigquery_operator import BigQueryOperator
from airflow.operators.python_operator import PythonOperator
from platform_engineering.utilities.utils import *
from datetime import date, datetime, timedelta

base_data_dir = Variable.get('base_data_dir')

args = {
    'owner': 'Platform Engineering',
    'depends_on_past': False,
    'start_date': datetime(2021, 1, 27),
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 0,
    'use_legacy_sql': False
}

enrich_ip_dir = Variable.get('ucd_enriched_ip_dir')
enrich_ip_filenames = Variable.get('ucd_enriched_ip_filenames').split(',')
metadata_table = Variable.get('ucd_metadata_table')


# list_of_en_mem_sql = Variable.get('enriched_member_sql').split(',')
# list_of_enriched_sql = Variable.get('enriched_sql').split(',')

enriched = 'enrich'


def ip_confinement(dag_name):
    with DAG(dag_id=dag_name, default_args=args, schedule_interval=None, catchup=False, template_searchpath=base_data_dir) as dag:
        ip_sqls = generate_bq_list_from_files(enrich_ip_filenames, [], enrich_ip_dir)
        create_sequential_dependencies(ip_sqls, None, None)

    return dag


ip_confinement_dag = ip_confinement('UCD_ipConfinement_enrich')
