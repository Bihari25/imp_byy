from airflow import DAG
from airflow.models import Variable
from big_query_fast_copy_operator import BigQueryFastCopyOperator
from airflow.contrib.operators.bigquery_operator import BigQueryOperator
from airflow.operators.bash_operator import BashOperator
from airflow.operators.subdag_operator import SubDagOperator
from airflow.operators.python_operator import PythonOperator
from datetime import date, datetime, timedelta
from platform_engineering.ucd.ucd_membership_claim import membership_claims
from platform_engineering.ucd.ucd_ip_confinement import ip_confinement
from platform_engineering.ucd.ucd_medical_galaxy_claim import medical_galaxy_claims
from platform_engineering.utilities.email import *
from platform_engineering.utilities.utils import *
import logging


base_data_dir = Variable.get('base_data_dir')

archive_filters= Variable.get("ucd_archive_filters").split(",")
archive_meta_table = Variable.get("ucd_archive_meta_table")

enrich_med_pha_dir = Variable.get('ucd_enriched_med_pha_dir')
enrich_med_pha_filenames = Variable.get('ucd_enriched_med_pha_filenames').split(",")

enrich_diag_dir = Variable.get('ucd_enriched_diag_dir')
enrich_diag_filenames = Variable.get('ucd_enriched_diag_filenames').split(",")

enrich_mem_cont_detail_dir = Variable.get('ucd_enriched_mem_cont_detail_dir')
enrich_mem_cont_detail_filenames = Variable.get('ucd_enriched_mem_cont_detail_filenames').split(",")

enrich_mem_sum_dir = Variable.get('ucd_enriched_mem_sum_dir')
enrich_mem_sum_filenames = Variable.get('ucd_enriched_mem_sum_filenames').split(",")

enriched = 'enrich'

medical_dir = Variable.get('ucd_medical_dir')
medical_filenames = Variable.get('ucd_medical_filenames').split(",")

medical_consolidated_dir = Variable.get('ucd_medical_consolidated_dir')
medical_consolidated_filenames = Variable.get('ucd_medical_consolidated_filenames').split(",")

medical = 'med'

pharmacy_dir = Variable.get('ucd_pharmacy_dir')
pharmacy_filenames = Variable.get('ucd_pharmacy_filenames').split(",")

pharmacy_consolidated_dir = Variable.get('ucd_pharmacy_consolidated_dir')
pharmacy_consolidated_filenames = Variable.get('ucd_pharmacy_consolidated_filenames').split(",")

pharmacy = 'rx'

summary_dir = Variable.get('ucd_summary_dir')
summary_filenames = Variable.get('ucd_summary_filenames').split(",")

summary_helper_dir = Variable.get('ucd_summary_helper_dir')
summary_helper_filenames = Variable.get('ucd_summary_helper_filenames').split(",")

metadata_table = Variable.get('ucd_metadata_table')


summary = 'summary'


args = {
    'owner': 'Platform Engineering',
    'depends_on_past': False,
    'start_date': datetime(2021, 1, 27),
    'email_on_failure': True,
    'email_on_retry': False,
    'retries': 0,
    'on_failure_callback': notify_email,
    'use_legacy_sql': False
}

dag_name = 'UCD_fullRefresh_demo'
enrich_copy = 'enrich_copy'
final_template = 'final_template'
final_table = 'final'


with DAG(dag_id=dag_name, default_args=args, schedule_interval=None, catchup=False, template_searchpath=base_data_dir) as dag:
    notify_start = start_notification(dag, dag_name)

    log = BashOperator(
        task_id='log',
        bash_command='''
        bq query --use_legacy_sql=false "insert into research-01-217611.df_ucd_stage.logging (job, message_datetime) select \'about to start a run...\' as job, current_datetime as message_datetime";
         '''
    )

    query = PythonOperator(
        task_id="fetch_metadata",
        python_callable=query_metadata,
        op_kwargs={"sql": "SELECT project_id, dataset_id, table_id from "+  archive_meta_table, "archive_filters": archive_filters,  "run_id": "{{run_id}}"},
        provide_context=True,
        dag=dag,
    )

    summary_archive = BigQueryFastCopyOperator(
                task_id="consolidate_archive",
                archive= True,
                use_xcom=True,
                xcom_sources_key="summary",
                xcom_sources_task_id="fetch_metadata",
                dag=dag,
                trigger_rule = "all_success",
            )
    

    source_audit = BigQueryOperator(
        task_id='source_audit',
        sql='ucd/base/run_source_data_audit.sql'
    )

    create_dimension_table = BigQueryOperator(
        task_id='create_dimension_table',
        sql='ucd/base/create_dimension_tables.sql'
    )

    get_enrichment_list = PythonOperator(task_id='get_enrichment_list',
                                provide_context=True,
                                python_callable=push_table_list_xcom,
                                op_kwargs={
                                'interface': enrich_copy,
                                'metadata': metadata_table
                                }
                            )

    copy_enrichment = BigQueryFastCopyOperator(
        task_id='copy_enrichment',
        use_xcom=True,
        xcom_sources_key='source_list_' + enrich_copy,
        xcom_sources_task_id='get_enrichment_list',
        xcom_destinations_key='destination_list_' + enrich_copy,
        xcom_destinations_task_id='get_enrichment_list'
    )

    ucd_membership_claim = SubDagOperator(
        task_id='mem_detail_load_stage',
        subdag=membership_claims(
            '{}.mem_detail_load_stage'.format(dag_name))
    )


    get_med_list = PythonOperator(
                        task_id='get_med_list',
                        provide_context=True,
                        python_callable=push_table_list_xcom,
                        op_kwargs={
                            'interface': medical,
                            'metadata': metadata_table
                        }
                    )

    copy_med = BigQueryFastCopyOperator(
        task_id='copy_med',
        use_xcom=True,
        xcom_sources_key='source_list_' + medical,
        xcom_sources_task_id='get_med_list',
        xcom_destinations_key='destination_list_' + medical,
        xcom_destinations_task_id='get_med_list'
    )
    ucd_medical_galaxy_claims = SubDagOperator(
        task_id='medical_galaxy_claims',
        subdag=medical_galaxy_claims(
            '{}.medical_galaxy_claims'.format(dag_name))
    )

    medical_sql = create_dags(medical_filenames,medical_dir)
    med_consolidate = create_dags(medical_consolidated_filenames,medical_consolidated_dir)


    get_pharmay_list = PythonOperator(task_id='get_pharmay_list',
                                          provide_context=True,
                                          python_callable=push_table_list_xcom,
                                          op_kwargs={
                                              'interface': pharmacy,
                                              'metadata': metadata_table
                                            }
                                          )

    copy_pharmacy = BigQueryFastCopyOperator(
        task_id='copy_pharmacy',
        use_xcom=True,
        xcom_sources_key='source_list_' + pharmacy,
        xcom_sources_task_id='get_pharmay_list',
        xcom_destinations_key='destination_list_' + pharmacy,
        xcom_destinations_task_id='get_pharmay_list'
    )
        
    pharmacy_sql = create_dags(pharmacy_filenames,pharmacy_dir)

    pharmacy_consolidate = create_dags(pharmacy_consolidated_filenames,pharmacy_consolidated_dir)


    get_enriched_list = PythonOperator(
        task_id='get_enriched_list',
        provide_context=True,
        python_callable=push_table_list_xcom,
        op_kwargs={
            'interface': enriched,
            'metadata': metadata_table
            }
        )

    copy_enriched = BigQueryFastCopyOperator(
            task_id='copy_enriched',
            use_xcom=True,
            xcom_sources_key='source_list_' + enriched,
            xcom_sources_task_id='get_enriched_list',
            xcom_destinations_key='destination_list_' + enriched,
            xcom_destinations_task_id='get_enriched_list'
    )

    enriched_member_cont_detail_sql = create_dags(enrich_mem_cont_detail_filenames,enrich_mem_cont_detail_dir)
    enriched_member_sum_sql = create_dags(enrich_mem_sum_filenames,enrich_mem_sum_dir)

    ip_confinement = SubDagOperator(
        task_id='ip_confinement',
        subdag=ip_confinement(
            '{}.ip_confinement'.format(dag_name))
    )


    enriched_med_pha_sql = create_dags(enrich_med_pha_filenames,enrich_med_pha_dir)
    enriched_diag_sql = create_dags(enrich_diag_filenames,enrich_diag_dir)


    get_summary_list = PythonOperator(task_id='get_summary_list',
                                          provide_context=True,
                                          python_callable=push_table_list_xcom,
                                          op_kwargs={
                                              'interface': summary,
                                              'metadata': metadata_table
                                            }
                                          )

    copy_summary = BigQueryFastCopyOperator(
        task_id='copy_summary',
        use_xcom=True,
        xcom_sources_key='source_list_' + summary,
        xcom_sources_task_id='get_summary_list',
        xcom_destinations_key='destination_list_' + summary,
        xcom_destinations_task_id='get_summary_list'
    )
    summary_sql = create_dags(summary_filenames,summary_dir)
    summary_helper = create_dags(summary_helper_filenames,summary_helper_dir)

    notify_success = success_notification(dag, dag_name)

# Dependencies :
notify_start >> log >> [query, source_audit]

for filt in archive_filters:
    filt = filt.replace("|","_")
    query >> group_big_query_copy(filt+"_archive",filt, "fetch_metadata", dag) >> create_dimension_table

query >> summary_archive >> create_dimension_table

source_audit >> create_dimension_table >> get_enrichment_list >> copy_enrichment >> ucd_membership_claim

ucd_membership_claim >> get_pharmay_list >> copy_pharmacy >> pharmacy_sql 

for ps in pharmacy_sql:
    ps >> pharmacy_consolidate

ucd_membership_claim >> get_med_list >> copy_med >> medical_sql 

copy_med >> ucd_medical_galaxy_claims >> med_consolidate

for ms in medical_sql:
    ms >> med_consolidate


[med_consolidate[len(med_consolidate)-1], pharmacy_consolidate[len(pharmacy_consolidate)-1]] >> get_enriched_list >> copy_enriched >> enriched_member_cont_detail_sql

for d in enriched_member_cont_detail_sql:
    d >> enriched_member_sum_sql

enriched_member_sum_sql >> ip_confinement

for dd in enriched_med_pha_sql:
    ip_confinement >> dd >> enriched_diag_sql

enriched_diag_sql >> get_summary_list >> copy_summary >> summary_helper

for sh in summary_helper:
    sh >> summary_sql

summary_sql >> notify_success