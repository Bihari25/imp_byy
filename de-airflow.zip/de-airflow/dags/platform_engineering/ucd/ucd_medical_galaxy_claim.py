from airflow import DAG
from airflow.models import Variable
from big_query_fast_copy_operator import BigQueryFastCopyOperator
from airflow.contrib.operators.bigquery_operator import BigQueryOperator
from airflow.operators.python_operator import PythonOperator
from airflow.operators.bash_operator import BashOperator
from platform_engineering.utilities.utils import *
from datetime import date, datetime, timedelta

base_data_dir = Variable.get('base_data_dir')

args = {
    'owner': 'Platform Engineering',
    'depends_on_past': False,
    'start_date': datetime(2021, 1, 27),
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 0,
    'use_legacy_sql': False
}

# application arguments
medical_galaxy_dir = Variable.get('ucd_medical_galaxy_dir')
medical_galaxy_filenames = Variable.get('ucd_medical_galaxy_filenames').split(',')


def medical_galaxy_claims(dag_name):
    with DAG(dag_id=dag_name, default_args=args, schedule_interval=None, catchup=False, template_searchpath=base_data_dir ) as dag:
        medical_galaxy_sql = generate_bq_list_from_files(medical_galaxy_filenames, [], medical_galaxy_dir)
        create_sequential_dependencies(medical_galaxy_sql, None, None)
    return dag


medical_galaxy_claims_dag = medical_galaxy_claims('UCD_medicalGalaxy_load')
