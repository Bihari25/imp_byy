from airflow import DAG
from airflow.operators.python_operator import PythonOperator
from airflow.utils.dates import days_ago
from big_query_fast_copy_operator import BigQueryFastCopyOperator
from datetime import timedelta
import os
import sys

DAG_ID = os.path.basename(__file__).replace(".pyc", "").replace(".py", "")

default_args = {
    "owner": "airflow",
    "depends_on_past": False,
    "start_date": days_ago(1),
    "email_on_failure": True,
    "email_on_retry": False,
    "email": ["brian.rieger@optum.com"],
    "retries": 1,
    "retry_delay": timedelta(minutes=5),
    "execution_timeout": timedelta(seconds=14700),
}

dag = DAG(
    DAG_ID,
    schedule_interval=None,
    default_args=default_args,
    tags=["example"],
    description="Data Enrichment pipeline for Big Query Fast Copy Example",
    )

table_task = BigQueryFastCopyOperator(
    task_id='fast_copy_example',
    sources=["research-01-217611.df_ucd.diagnosis_claim_ihr"],
    destinations=["research-01-217611.df_ucd.diagnosis_claim_ihr_de_test"],
    dag=dag  
)
table_task
