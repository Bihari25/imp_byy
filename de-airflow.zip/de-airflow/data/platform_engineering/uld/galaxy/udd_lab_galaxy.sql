/*
--Purpose: Create Galaxy Lab data in ULD standard format
--Total run time:  1 min 16 sec
--Input table/s:  df_uld_stage.wkg_galaxy_lab
--Output table/s: df_uld_stage.udd_lab_galaxy
*/

BEGIN

insert into  `research-01-217611.df_uld_stage.udd_lab_galaxy`


/* -----------------------------------------Finally, combining everything to create the final file------------------------------------------------- */

SELECT GENERATE_UUID() AS uuid
            , savvy_pid
            , savvy_did
            , is_restricted
            , src_type
            , where_lab_performed

            , max(uuid) as source_uuid

            , lab_date
            , cast(null as time) lab_time

            , lab_result_description
            , cast(null as string) lab_order_description

            , numeric_result_value
            , result_value
            , results_units

            , ref_range
            , lower_ref_range
            , upper_ref_range
            , delimiter

            , abnormal_cd
            , abnormal_desc

            , cast(null as string) result_status

            , prov_npi
            , prov_mpin

            , proc_cd
            , proc_desc

            , loinc_cd
            , cmpnt_nm
            , loinc_cd_desc
            , prop_msr_cd
            , rec_sts_cd
            , repl_loinc_cd
            , samp_typ_nm
            , scl_typ_cd
            , tm_nm
            , tst_meth_nm
            , ver_lst_chg

            , cast(null as string) as note

            , current_datetime() as create_datetime
            , current_datetime() as update_datetime

FROM `research-01-217611.df_uld_stage.wkg_galaxy_lab`
where is_restricted=0
group by savvy_pid, savvy_did, is_restricted, src_type, where_lab_performed, lab_date, lab_time, lab_result_description, lab_order_description, numeric_result_value, result_value, results_units
      , ref_range, lower_ref_range, upper_ref_range, delimiter, abnormal_cd, abnormal_desc, result_status, prov_npi, prov_mpin, proc_cd, proc_desc, loinc_cd, cmpnt_nm, loinc_cd_desc, prop_msr_cd, rec_sts_cd, repl_loinc_cd, samp_typ_nm
      , scl_typ_cd, tm_nm, tst_meth_nm, ver_lst_chg, note

;


/* ---------------------------------------------------------- End of code --------------------------------------------------------------------- */

  --if successful, we'll get here!
insert into `research-01-217611.df_uld_stage.logging`(
     success_flag, job,tbl, message_datetime)
   select
     1 as success_flag
     , 'create udd_lab_galaxy tables' as job
     , 'udd_lab_galaxy' as tbl
     ,current_datetime as message_datetime
   ;

   EXCEPTION WHEN ERROR THEN
     insert into `research-01-217611.df_uld_stage.logging`(
       success_flag, job,tbl, error_message, statement_text, formatted_stack_trace, message_datetime)
     select
       0 as success_flag
       , 'create udd_lab_galaxy tables' as job
       , 'udd_lab_galaxy' as tbl
       , @@error.message as error_message
       , @@error.statement_text as statement_text
       , @@error.formatted_stack_trace as formatted_stack_trace
       , current_datetime as message_datetime
     ;

END
;