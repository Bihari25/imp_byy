/* ------------------------------ Finally creating the combined form of galaxy lab ---------------------------------------------------------- */

--5 min 12 sec


BEGIN

create or replace table `research-01-217611.df_uld_stage.wkg_galaxy_lab`
as
SELECT GENERATE_UUID() as uuid
    , ar.savvy_pid
    , ar.savvy_did
    , ar.is_restricted
    , fst_srvc_dt as lab_date
    , ar.mbr_sys_id
    , 'galaxy_labs' as event_name
    , 'galaxy' as src_type
    , lower(trim(ar.analyte_seq_nbr)) as analyte_seq_nbr

    --Lab claim header
    , lch.lab_clm_head_sys_id
    , lch.fst_srvc_dt
    , lower(trim(lch.src_sys_cd)) as src_sys_cd
    , lower(trim(lch.specimen_nbr)) as specimen_nbr
    , lower(trim(lch.ptnt_race_cd)) as ptnt_race_cd
    , lower(trim(lch.lab_vend_src_id )) as lab_vend_src_id

    --Site cd
    , sc.site_cd
    , sc.site_grp_cd
    , sc.site_grp_nm
    , sc.site_nm

     --Analyte results
    , lower(trim(ar.rslt_units_nm)) as results_units
    , ar.rslt_val_nbr as numeric_result_value
    , lower(trim(ar.rslt_val_txt)) as result_value
    , lower(trim(ar.vend_tst_desc)) as lab_result_description
    , lower(trim(ar.vend_tst_nbr)) as vend_tst_nbr
    , ar.hi_nrml_val_nbr as upper_ref_range
    , ar.low_nrml_val_nbr as lower_ref_range
    , concat(ar.low_nrml_val_nbr, ' - ', ar.hi_nrml_val_nbr) as ref_range
    , case when concat(ar.low_nrml_val_nbr, ' - ', ar.hi_nrml_val_nbr) is not null then 'dash' end as delimiter

    -- Result_abnormal_code
    , rac.rslt_abnl_cd as abnormal_cd
    , rac.rslt_abnl_desc as abnormal_desc

    -- provider
    , pr.srvc_prov_row_eff_dt
    , pr.srvc_prov_sys_id
    , pr.prov_id
    , pr.prov_fst_nm
    , pr.prov_lst_nm
    , pr.dea_nbr
    , pr.dea_alph_nbr
    , pr.cos_prov_spcl_cd
    , pr.tin
    , pr.prov_site_cd
    , pr.prov_site_nm
    , pr.nat_assoc_bd_phrm_nbr
    , pr.prov_npi
    , pr.prov_mpin
    , pr.prov_zip_cd
    --, pr.uniq_prov_sys_id

     -- proc_cd
    , pc.proc_cd
    --, pc.srvc_catgy_desc
    --, pc.srvc_catgy_cd
    --, pc.proc_end_dt
    , pc.proc_desc
    --, pc.proc_decm_cd
    --, pc.gdr_lmt_cd
    --, pc.asg_grp_cd
    , pc.ahrq_proc_genl_catgy_desc
    , pc.ahrq_proc_genl_catgy_cd
    , pc.ahrq_proc_dtl_catgy_desc
    , pc.ahrq_proc_dtl_catgy_cd
    --, pc.vst_cd
    , pc.proc_typ_cd

    -- loinc code
    , lc.loinc_cd
    , lc.cmpnt_nm
    , lc.loinc_cd_desc
    , lc.prop_msr_cd
    , lc.rec_sts_cd
    , lc.repl_loinc_cd
    , lc.samp_typ_nm
    , lc.scl_typ_cd
    , lc.tm_nm
    , lc.tst_meth_nm
    , lc.ver_lst_chg

    --Lab utilization gateway
    , lg.lab_utlz_gtwy_lab_id_nbr
    , lg.lab_utlz_gtwy_lab_desc as where_lab_performed
    , lg.lab_utlz_src_sys_cd

    -- dim_date
    , dt.full_dt
    --, dt.month_nm
    --, dt.month_abbr_cd
    --, dt.month_nbr
    --, dt.week_day_nm
    --, dt.day_wk
    --, dt.day_abbr_cd
    --, dt.lst_day_mo_ind
    --, dt.day_nbr
    --, dt.quarter_nm
    --, dt.quarter_nbr
    , dt.year_nbr
    --, dt.seq_nbr
    --, dt.week_day_ind
    --, dt.week_nbr_yr
    , dt.year_mo

    , current_datetime() as create_datetime
    , current_datetime() as update_datetime


from `ds-00-191017.galaxy_final.analyte_result`                ar

join (select distinct savvy_pid, mbr_sys_id, lch.lab_utlz_gtwy_lab_id_nbr
                 , lch.fst_srvc_dt, lch.srvc_prov_sys_id, lch.srvc_prov_row_eff_dt
                 , lch.lab_clm_head_sys_id, site_cd, src_sys_cd, specimen_nbr
                 , ptnt_race_cd, lab_vend_src_id
      from `ds-00-191017.galaxy_final.lab_claim_header` lch
      )

                                                                lch      on ar.lab_clm_head_sys_id          = lch.lab_clm_head_sys_id
                                                                         and ar.mbr_sys_id                  = lch.mbr_sys_id
                                                                     ---and ar.savvy_pid                   = lch.savvy_pid
inner join (select distinct savvy_pid, mbr_sys_id
            from `ds-00-191017.galaxy_final.member`
            where mbr_sys_id>0)                                 mem      on ar.mbr_sys_id                  = mem.mbr_sys_id
                                                                     --and ar.savvy_pid                    = mem.savvy_pid

left join `research-01-217611.df_uld_stage.wkg_galaxy_lch_provider`                  pr       on lch.srvc_prov_sys_id            = pr.srvc_prov_sys_id
                                                                         and lch.srvc_prov_row_eff_dt       = pr.srvc_prov_row_eff_dt
left join `research-01-217611.df_uld_stage.wkg_galaxy_ar_procedure_code`             pc       on ar.proc_cd                      = pc.orig_ar_proc_cd
left join `research-01-217611.df_uld_stage.wkg_galaxy_ar_loinc_code`                 lc       on ar.loinc_cd                     = lc.orig_ar_loinc_cd
left join `research-01-217611.df_uld_stage.wkg_galaxy_lch_lab_utilization_gateway`   lg       on lch.lab_utlz_gtwy_lab_id_nbr    = lg.orig_lch_lab_utlz_gtwy_lab_id_nbr
left join `research-01-217611.df_uld_stage.wkg_galaxy_date`                          dt       on lch.fst_srvc_dt                 = dt.full_dt
left join `research-01-217611.df_uld_stage.wkg_galaxy_ar_result_abnormal_code`       rac      on ar.rslt_abnl_cd                 = rac.orig_ar_rslt_abnl_cd
left join `research-01-217611.df_uld_stage.wkg_galaxy_lch_site_code`                 sc       on lch.site_cd                     = sc.orig_lch_site_cd
where ar.savvy_pid<>-1;

/* ---------------------------------------------------DROP Temporary Tables ------------------------------------------------------------------ */

drop table `research-01-217611.df_uld_stage.wkg_galaxy_ar_loinc_code`;
drop table `research-01-217611.df_uld_stage.wkg_galaxy_ar_procedure_code`;
drop table `research-01-217611.df_uld_stage.wkg_galaxy_ar_result_abnormal_code`;
drop table `research-01-217611.df_uld_stage.wkg_galaxy_date`;
drop table `research-01-217611.df_uld_stage.wkg_galaxy_lch_lab_utilization_gateway`;
drop table `research-01-217611.df_uld_stage.wkg_galaxy_lch_provider`;
drop table `research-01-217611.df_uld_stage.wkg_galaxy_lch_site_code`;


/* ---------------------------------------------------------- End of code --------------------------------------------------------------------- */

  --if successful, we'll get here!
 insert into `research-01-217611.df_uld_stage.logging`(
      success_flag, job,tbl, message_datetime)
    select
      1 as success_flag
      , 'create wkg_galaxy_lab tables' as job
      , 'wkg_galaxy_lab' as tbl
      ,current_datetime as message_datetime
    ;

    EXCEPTION WHEN ERROR THEN
      insert into `research-01-217611.df_uld_stage.logging`(
        success_flag, job,tbl, error_message, statement_text, formatted_stack_trace, message_datetime)
      select
        0 as success_flag
        , 'create wkg_galaxy_lab tables' as job
        , 'wkg_galaxy_lab' as tbl
        , @@error.message as error_message
        , @@error.statement_text as statement_text
        , @@error.formatted_stack_trace as formatted_stack_trace
        , current_datetime as message_datetime
      ;

END
;
