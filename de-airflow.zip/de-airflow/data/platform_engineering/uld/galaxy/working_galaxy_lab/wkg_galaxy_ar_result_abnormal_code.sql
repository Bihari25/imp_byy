/* -------------------------------------------------------RESULT ABNORMAL CODE---------------------------------------------------------------- */
BEGIN

create or replace table `research-01-217611.df_uld_stage.wkg_galaxy_ar_result_abnormal_code` as
    (select distinct ar.rslt_abnl_cd as orig_ar_rslt_abnl_cd
            , lower(trim(ar.rslt_abnl_cd)) as rslt_abnl_cd
            , max(lower(trim(rac.rslt_abnl_desc))) as rslt_abnl_desc
    from  (select distinct rslt_abnl_cd
          from `ds-00-191017.galaxy_final.analyte_result`
          )  ar
    left join `ds-00-191017.galaxy_final.dim_result_abnormal_code`  rac on lower(trim(ar.rslt_abnl_cd)) = lower(trim(rac.rslt_abnl_cd))
    group by ar.rslt_abnl_cd
    );

--259 rows
--2 min 11 sec
/* ---------------------------------------------------------- End of code --------------------------------------------------------------------- */

  --if successful, we'll get here!
insert into `research-01-217611.df_uld_stage.logging`(
     success_flag, job,tbl, message_datetime)
   select
     1 as success_flag
     , 'create wkg_galaxy_ar_result_abnormal_code tables' as job
     , 'wkg_galaxy_ar_result_abnormal_code' as tbl
     ,current_datetime as message_datetime
   ;

   EXCEPTION WHEN ERROR THEN
     insert into `research-01-217611.df_uld_stage.logging`(
       success_flag, job,tbl, error_message, statement_text, formatted_stack_trace, message_datetime)
     select
       0 as success_flag
       , 'create wkg_galaxy_ar_result_abnormal_code tables' as job
       , 'wkg_galaxy_ar_result_abnormal_code' as tbl
       , @@error.message as error_message
       , @@error.statement_text as statement_text
       , @@error.formatted_stack_trace as formatted_stack_trace
       , current_datetime as message_datetime
     ;

END
;