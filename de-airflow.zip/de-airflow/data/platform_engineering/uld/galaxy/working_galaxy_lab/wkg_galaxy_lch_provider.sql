/* ----------------------------------------------------------PROVIDER------------------------------------------------------------------------- */

BEGIN

create or replace table `research-01-217611.df_uld_stage.wkg_galaxy_lch_provider` as
      (select distinct
              lch.srvc_prov_sys_id, lch.srvc_prov_row_eff_dt
            , max(lower(trim(pr.prov_id))) as prov_id
            , max(lower(trim(pr.fst_nm))) as prov_fst_nm
            , max(lower(trim(pr.lst_nm))) as prov_lst_nm
            , max(lower(trim(pr.dea_nbr))) as dea_nbr
            , max(lower(trim(pr.dea_alph_nbr))) as dea_alph_nbr
            , max(pr.cos_prov_spcl_cd) as cos_prov_spcl_cd
            , max(lower(trim(pr.tin))) as tin
            , max(lower(trim(pr.site_cd))) as prov_site_cd
            , max(lower(trim(sc.site_nm))) as prov_site_nm
            , max(lower(trim(pr.nat_assoc_bd_phrm_nbr))) as nat_assoc_bd_phrm_nbr
            , max(pr.mpin) as prov_mpin
            , max(pr2.npi) as prov_npi
            , max(lower(trim(pr.zip_cd))) as prov_zip_cd
            , max(pr.prov_sys_id) as uniq_prov_sys_id
       from (select distinct srvc_prov_sys_id, srvc_prov_row_eff_dt
             from `ds-00-191017.galaxy_final.lab_claim_header`
             )  lch
       left join `ds-00-191017.galaxy_final.dim_provider`  pr   on  lch.srvc_prov_sys_id           = pr.prov_sys_id
                                                                and lch.srvc_prov_row_eff_dt       = pr.prov_row_eff_dt
       left join `ds-00-191017.galaxy_final.dim_site_code` sc   on  lower(trim(pr.site_cd))        = lower(trim(sc.site_cd))
       left join `research-01-217611.df_ucd_stage.dim_provider`  pr2  on  pr.mpin                        = pr2.mpin
       group by 1,2);
       --21 sec, single row for prov_sys_id and prov_row_eff_dt combination join condition
/* ---------------------------------------------------------- End of code --------------------------------------------------------------------- */

  --if successful, we'll get here!
insert into `research-01-217611.df_uld_stage.logging`(
     success_flag, job,tbl, message_datetime)
   select
     1 as success_flag
     , 'create wkg_galaxy_lch_provider tables' as job
     , 'wkg_galaxy_lch_provider' as tbl
     ,current_datetime as message_datetime
   ;

   EXCEPTION WHEN ERROR THEN
     insert into `research-01-217611.df_uld_stage.logging`(
       success_flag, job,tbl, error_message, statement_text, formatted_stack_trace, message_datetime)
     select
       0 as success_flag
       , 'create wkg_galaxy_lch_provider tables' as job
       , 'wkg_galaxy_lch_provider' as tbl
       , @@error.message as error_message
       , @@error.statement_text as statement_text
       , @@error.formatted_stack_trace as formatted_stack_trace
       , current_datetime as message_datetime
     ;

END
;