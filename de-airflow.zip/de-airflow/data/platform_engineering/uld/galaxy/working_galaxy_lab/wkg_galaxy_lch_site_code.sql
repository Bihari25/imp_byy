/* ----------------------------------------------------------SITE CODE------------------------------------------------------------------------ */

BEGIN

create or replace table `research-01-217611.df_uld_stage.wkg_galaxy_lch_site_code` as
      (select distinct lch.site_cd as orig_lch_site_cd
             , max(lower(trim(lch.site_cd))) as site_cd
             , max(lower(trim(sc.site_grp_cd))) as site_grp_cd
             , max(lower(trim(sc.site_grp_nm))) as site_grp_nm
             , max(lower(trim(sc.site_nm))) as site_nm
       from (select distinct site_cd
             from `ds-00-191017.galaxy_final.lab_claim_header`
             )  lch
       left join  `ds-00-191017.galaxy_final.dim_site_code`  sc on lower(trim(lch.site_cd)) = lower(trim(sc.site_cd))
       group by 1);
       --2.2 sec, single row on join condition
/* ---------------------------------------------------------- End of code --------------------------------------------------------------------- */

insert into `research-01-217611.df_uld_stage.logging`(
     success_flag, job,tbl, message_datetime)
   select
     1 as success_flag
     , 'create wkg_galaxy_lch_site_code tables' as job
     , 'wkg_galaxy_lch_site_code' as tbl
     ,current_datetime as message_datetime
   ;

   EXCEPTION WHEN ERROR THEN
     insert into `research-01-217611.df_uld_stage.logging`(
       success_flag, job,tbl, error_message, statement_text, formatted_stack_trace, message_datetime)
     select
       0 as success_flag
       , 'create wkg_galaxy_lch_site_code tables' as job
       , 'wkg_galaxy_lch_site_code' as tbl
       , @@error.message as error_message
       , @@error.statement_text as statement_text
       , @@error.formatted_stack_trace as formatted_stack_trace
       , current_datetime as message_datetime
     ;

END
;