
BEGIN

create or replace table `research-01-217611.df_uld_stage.wkg_galaxy_date` as
    (select dt.full_dt
            , lower(trim(dt.day_abbr_cd)) as day_abbr_cd
            , lower(trim(dt.month_nm)) as month_nm
            , dt.day_wk
            , lower(trim(dt.week_day_nm)) as week_day_nm
            , dt.month_nbr
            , lower(trim(dt.lst_day_mo_ind)) as lst_day_mo_ind
            , dt.day_nbr
            , lower(trim(dt.month_abbr_cd)) as month_abbr_cd
            , lower(trim(dt.quarter_nm)) as quarter_nm
            , dt.quarter_nbr as quarter_nbr
            , dt.year_nbr
            , dt.same_week_day_yr_ago_dt
            , dt.seq_nbr
            , dt.week_begn_dt
            , lower(trim(dt.week_day_ind)) as week_day_ind
            , dt.week_nbr_yr
            , dt.year_mo
    from `ds-00-191017.galaxy_final.dim_date`   dt
    );
--1.9 sec
/* ---------------------------------------------------------- End of code --------------------------------------------------------------------- */

  --if successful, we'll get here!
insert into `research-01-217611.df_uld_stage.logging`(
     success_flag, job,tbl, message_datetime)
   select
     1 as success_flag
     , 'create wkg_galaxy_date tables' as job
     , 'wkg_galaxy_date' as tbl
     ,current_datetime as message_datetime
   ;

   EXCEPTION WHEN ERROR THEN
     insert into `research-01-217611.df_uld_stage.logging`(
       success_flag, job,tbl, error_message, statement_text, formatted_stack_trace, message_datetime)
     select
       0 as success_flag
       , 'create wkg_galaxy_date tables' as job
       , 'wkg_galaxy_date' as tbl
       , @@error.message as error_message
       , @@error.statement_text as statement_text
       , @@error.formatted_stack_trace as formatted_stack_trace
       , current_datetime as message_datetime
     ;

END
;