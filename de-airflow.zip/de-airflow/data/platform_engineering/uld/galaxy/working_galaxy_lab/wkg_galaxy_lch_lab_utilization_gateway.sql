/* ---------------------------------------------------LAB UTILIZATION GATEWAY----------------------------------------------------------------- */

BEGIN

create or replace table `research-01-217611.df_uld_stage.wkg_galaxy_lch_lab_utilization_gateway` as
    (select distinct lch.lab_utlz_gtwy_lab_id_nbr as orig_lch_lab_utlz_gtwy_lab_id_nbr
            , cast(lch.lab_utlz_gtwy_lab_id_nbr as int64) as lab_utlz_gtwy_lab_id_nbr
            , max(lower(trim(lg.lab_utlz_gtwy_lab_desc))) as lab_utlz_gtwy_lab_desc
            , max(lower(trim(lg.src_sys_cd))) as lab_utlz_src_sys_cd
     from (select distinct lab_utlz_gtwy_lab_id_nbr
           from `ds-00-191017.galaxy_final.lab_claim_header`
           )  lch
     left join `ds-00-191017.galaxy_final.lab_utlz_gtwy_lab_id`  lg on cast(lch.lab_utlz_gtwy_lab_id_nbr as int64)  = lg.lab_utlz_gtwy_lab_id_nbr
                                                                    and lower(trim(lg.lab_utlz_gtwy_lab_desc)) not like '%do not use%'
     group by lch.lab_utlz_gtwy_lab_id_nbr);
     --423 rows, (single row after using  do not use condition)
--2.2 sec

/* ---------------------------------------------------------- End of code --------------------------------------------------------------------- */

  --if successful, we'll get here!
insert into `research-01-217611.df_uld_stage.logging`(
     success_flag, job,tbl, message_datetime)
   select
     1 as success_flag
     , 'create wkg_galaxy_lch_lab_utilization_gateway tables' as job
     , 'wkg_galaxy_lch_lab_utilization_gateway' as tbl
     ,current_datetime as message_datetime
   ;

   EXCEPTION WHEN ERROR THEN
     insert into `research-01-217611.df_uld_stage.logging`(
       success_flag, job,tbl, error_message, statement_text, formatted_stack_trace, message_datetime)
     select
       0 as success_flag
       , 'create wkg_galaxy_lch_lab_utilization_gateway tables' as job
       , 'wkg_galaxy_lch_lab_utilization_gateway' as tbl
       , @@error.message as error_message
       , @@error.statement_text as statement_text
       , @@error.formatted_stack_trace as formatted_stack_trace
       , current_datetime as message_datetime
     ;

END
;