/* -----------------------------------------------------------PROCEDURE CODE------------------------------------------------------------------ */

-- Used df_ucd_stage.dim_procedure code since it has 1 row per procedure code (Galaxy's dim_procedure_code can have multiple row per proc_cd so need to modify this table before using)

BEGIN

create or replace table `research-01-217611.df_uld_stage.wkg_galaxy_ar_procedure_code` as
      (select distinct ar.proc_cd as orig_ar_proc_cd  --included this for easy join to ar table
            , lower(trim(ar.proc_cd)) as proc_cd
            , lower(trim(pc.srvc_catgy_desc)) as srvc_catgy_desc
            , lower(trim(pc.srvc_catgy_cd)) as srvc_catgy_cd
            , pc.proc_end_dt as proc_end_dt
            , lower(trim(pc.proc_desc)) as proc_desc
            , lower(trim(pc.proc_decm_cd)) as proc_decm_cd
            , lower(trim(pc.gdr_lmt_cd)) as gdr_lmt_cd
            , lower(trim(pc.asg_grp_cd)) as asg_grp_cd
            , lower(trim(pc.ahrq_proc_genl_catgy_desc)) as ahrq_proc_genl_catgy_desc
            , pc.ahrq_proc_genl_catgy_cd
            , lower(trim(pc.ahrq_proc_dtl_catgy_desc)) as ahrq_proc_dtl_catgy_desc
            , pc.ahrq_proc_dtl_catgy_cd
            , lower(trim(pc.vst_cd)) as vst_cd
            , lower(trim(pc.proc_typ_cd)) as proc_typ_cd
       from      (select distinct proc_cd
                  from `ds-00-191017.galaxy_final.analyte_result`
                  )  ar

       left join `research-01-217611.df_ucd_stage.dim_procedure_code` pc  on lower(trim(ar.proc_cd)) = lower(trim(pc.proc_cd))

      );
      --4.7 sec, used dim_procedure_code in df_ucd_stage since multiple rows for proc_cd in dim_procedure_code of galaxy (so need to modify this table before using)
/* ---------------------------------------------------------- End of code --------------------------------------------------------------------- */

  --if successful, we'll get here!
 insert into `research-01-217611.df_uld_stage.logging`(
     success_flag, job,tbl, message_datetime)
   select
     1 as success_flag
     , 'create wkg_galaxy_ar_procedure_code tables' as job
     , 'wkg_galaxy_ar_procedure_code' as tbl
     ,current_datetime as message_datetime
   ;

   EXCEPTION WHEN ERROR THEN
     insert into `research-01-217611.df_uld_stage.logging`(
       success_flag, job,tbl, error_message, statement_text, formatted_stack_trace, message_datetime)
     select
       0 as success_flag
       , 'create wkg_galaxy_ar_procedure_code tables' as job
       , 'wkg_galaxy_ar_procedure_code' as tbl
       , @@error.message as error_message
       , @@error.statement_text as statement_text
       , @@error.formatted_stack_trace as formatted_stack_trace
       , current_datetime as message_datetime
     ;

END
;