/* --------------------------------------------------------LOINC CODE------------------------------------------------------------------------- */
BEGIN

create or replace table `research-01-217611.df_uld_stage.wkg_galaxy_ar_loinc_code` as
     (select distinct ar.loinc_cd as orig_ar_loinc_cd
            , lower(trim(ar.loinc_cd)) as loinc_cd
            , max(lower(trim(lc.cmpnt_nm))) as cmpnt_nm
            , max(lower(trim(lc.loinc_cd_desc))) as loinc_cd_desc
            , max(lower(trim(lc.prop_msr_cd))) as prop_msr_cd
            , max(lower(trim(lc.rec_sts_cd))) as rec_sts_cd
            , max(lower(trim(lc.repl_loinc_cd))) as repl_loinc_cd
            , max(lower(trim(lc.samp_typ_nm))) as samp_typ_nm
            , max(lower(trim(lc.scl_typ_cd))) as scl_typ_cd
            , max(lower(trim(lc.tm_nm))) as tm_nm
            , max(lower(trim(lc.tst_meth_nm))) as tst_meth_nm
            , max(lower(trim(lc.ver_lst_chg))) as ver_lst_chg
      from (select distinct loinc_cd
            from `ds-00-191017.galaxy_final.analyte_result`
            )  ar
      left join `ds-00-191017.galaxy_final.loinc_code`  lc  on lower(trim(ar.loinc_cd)) = lower(trim(lc.loinc_cd))
     group by ar.loinc_cd
     );
     --4.5 sec, single row on join condition
/* ---------------------------------------------------------- End of code --------------------------------------------------------------------- */

  --if successful, we'll get here!
insert into `research-01-217611.df_uld_stage.logging`(
    success_flag, job,tbl, message_datetime)
  select
    1 as success_flag
    , 'create wkg_galaxy_ar_loinc_code tables' as job
    , 'wkg_galaxy_ar_loinc_code' as tbl
    ,current_datetime as message_datetime
  ;

  EXCEPTION WHEN ERROR THEN
    insert into `research-01-217611.df_uld_stage.logging`(
      success_flag, job,tbl, error_message, statement_text, formatted_stack_trace, message_datetime)
    select
      0 as success_flag
      , 'create wkg_galaxy_ar_loinc_code tables' as job
      , 'wkg_galaxy_ar_loinc_code' as tbl
      , @@error.message as error_message
      , @@error.statement_text as statement_text
      , @@error.formatted_stack_trace as formatted_stack_trace
      , current_datetime as message_datetime
    ;

END
;