BEGIN

create or replace table `research-01-217611.df_uld_stage.cte_tw_person_phone` as
          (SELECT
            ph.ID,
            MAX(ph.home_phone) AS home_phone,
            MAX(ph.work_phone) AS work_phone,
            MAX(ph.cell_phone) AS cell_phone,
            MAX(ph.fax_phone) AS fax_phone
           FROM (SELECT ID
                  , CASE WHEN PhoneType = 'Home' THEN CASE WHEN LENGTH(REPLACE(PhoneInternational,'0',''))>0 THEN PhoneInternational
                                                      ELSE LOWER(TRIM(CONCAT(PhoneArea,'-',PhoneExchange,'-',PhoneLast4)))
                                                      END
                    ELSE ''
                    END AS home_phone,
                    CASE WHEN PhoneType = 'Work' THEN CASE WHEN LENGTH(REPLACE(PhoneInternational,'0',''))>0 THEN PhoneInternational
                                                      ELSE LOWER(TRIM(CONCAT(PhoneArea,'-',PhoneExchange,'-',PhoneLast4)))
                                                      END
                    ELSE ''
                    END AS work_phone
                  , CASE WHEN PhoneType = 'Cell' THEN CASE WHEN LENGTH(REPLACE(PhoneInternational,'0',''))>0 THEN PhoneInternational
                                                      ELSE LOWER(TRIM(CONCAT(PhoneArea,'-',PhoneExchange,'-',PhoneLast4)))
                                                      END
                    ELSE ''
                    END AS cell_phone
                  , CASE WHEN PhoneType = 'Fax' THEN CASE WHEN LENGTH(REPLACE(PhoneInternational,'0',''))>0 THEN PhoneInternational
                                                     ELSE LOWER(TRIM(CONCAT(PhoneArea,'-',PhoneExchange,'-',PhoneLast4)))
                                                     END
                    ELSE ''
                    END AS fax_phone
                  FROM `ds-00-191017.smalv_tw_final.person_phone`
                ) ph
          GROUP BY
            ph.ID)
        ;
/* ---------------------------------------------------------- End of code --------------------------------------------------------------------- */

  --if successful, we'll get here!
insert into `research-01-217611.df_uld_stage.logging`(
     success_flag, job,tbl, message_datetime)
   select
     1 as success_flag
     , 'create cte_tw_person_phone tables' as job
     , 'cte_tw_person_phone' as tbl
     ,current_datetime as message_datetime
   ;

   EXCEPTION WHEN ERROR THEN
     insert into `research-01-217611.df_uld_stage.logging`(
       success_flag, job,tbl, error_message, statement_text, formatted_stack_trace, message_datetime)
     select
       0 as success_flag
       , 'create cte_tw_person_phone tables' as job
       , 'cte_tw_person_phone' as tbl
       , @@error.message as error_message
       , @@error.statement_text as statement_text
       , @@error.formatted_stack_trace as formatted_stack_trace
       , current_datetime as message_datetime
     ;

END
;