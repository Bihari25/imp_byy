/* -------------------------------------------------GETTING DESCRIPTIONS FROM QO TABLES----------------------------------------------------------- */

BEGIN

create or replace table `research-01-217611.df_uld_stage.cte_ir_qo_tables_desc` as
    (select ir.qode, ir.qoclassificationde, ir.lab_result_description, ir.lab_order_description
          , ir.loinc_cd, lc.* except(loinc_cd)
          , ir.cpt4code as proc_cd, proc.proc_desc
     from (select distinct ir.qode, ir.qoclassificationde
                      , lower(trim(qo.entryname)) as lab_result_description, lower(trim(qoc.entryname)) as lab_order_description
                      , qoc.loinccode, qo.loinclabcode
                      , case when LOWER(TRIM(qoc.loinccode)) = '' then LOWER(TRIM(qo.loinclabcode)) else LOWER(TRIM(qoc.loinccode)) end AS loinc_cd
                      , lower(trim(substr(qoc.cpt4code,1,5))) as cpt4code
           from (select distinct qode, qoclassificationde
                 from `ds-00-191017.smalv_tw_final.item_result`)              ir
           LEFT JOIN  `ds-00-191017.smalv_tw_final.qo_de`                     qo    ON qo.id                  = cast(ir.qode AS INT64)
           LEFT JOIN  `ds-00-191017.smalv_tw_final.qo_classification_de`      qoc   ON qoc.id                 = cast(ir.qoclassificationde AS INT64)
           ) ir
     LEFT JOIN `research-01-217611.df_ucd_stage.dim_procedure_code`    proc  ON proc.proc_cd = lower(trim(ir.cpt4code))
     LEFT JOIN `research-01-217611.df_uld_stage.dim_loinc_code`        lc    ON lc.loinc_cd  = lower(trim(ir.loinc_cd))
     )
     ;

/* ---------------------------------------------------------- End of code --------------------------------------------------------------------- */

  --if successful, we'll get here!
 insert into `research-01-217611.df_uld_stage.logging`(
      success_flag, job,tbl, message_datetime)
    select
      1 as success_flag
      , 'create cte_ir_qo_tables_desc tables' as job
      , 'cte_ir_qo_tables_desc' as tbl
      ,current_datetime as message_datetime
    ;

    EXCEPTION WHEN ERROR THEN
      insert into `research-01-217611.df_uld_stage.logging`(
        success_flag, job,tbl, error_message, statement_text, formatted_stack_trace, message_datetime)
      select
        0 as success_flag
        , 'create cte_ir_qo_tables_desc tables' as job
        , 'cte_ir_qo_tables_desc' as tbl
        , @@error.message as error_message
        , @@error.statement_text as statement_text
        , @@error.formatted_stack_trace as formatted_stack_trace
        , current_datetime as message_datetime
      ;

END
;