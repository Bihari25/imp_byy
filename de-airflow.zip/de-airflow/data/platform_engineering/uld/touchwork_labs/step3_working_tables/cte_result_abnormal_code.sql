/* --------------------------------------------------RESULT ABNORMAL CODE FROM GALAXY----------------------------------------------------------- */
BEGIN

create or replace table `research-01-217611.df_uld_stage.cte_result_abnormal_code` as
    (select distinct r.abnormalflagtype as orig_r_abnormalflagtype
          , lower(trim(r.abnormalflagtype)) as abnormalflagtype
          , max(lower(trim(rslt_abnl_desc))) as rslt_abnl_desc
      from (select distinct abnormalflagtype
            from `ds-00-191017.smalv_tw_final.result`)             r
      left join `ds-00-191017.galaxy_final.dim_result_abnormal_code`    rac  on  lower(trim(r.abnormalflagtype)) = lower(trim(rac.rslt_abnl_cd))
    group by 1)
    ;
/* ---------------------------------------------------------- End of code --------------------------------------------------------------------- */

  --if successful, we'll get here!
insert into `research-01-217611.df_uld_stage.logging`(
     success_flag, job,tbl, message_datetime)
   select
     1 as success_flag
     , 'create cte_result_abnormal_code tables' as job
     , 'cte_result_abnormal_code' as tbl
     ,current_datetime as message_datetime
   ;

   EXCEPTION WHEN ERROR THEN
     insert into `research-01-217611.df_uld_stage.logging`(
       success_flag, job,tbl, error_message, statement_text, formatted_stack_trace, message_datetime)
     select
       0 as success_flag
       , 'create cte_result_abnormal_code tables' as job
       , 'cte_result_abnormal_code' as tbl
       , @@error.message as error_message
       , @@error.statement_text as statement_text
       , @@error.formatted_stack_trace as formatted_stack_trace
       , current_datetime as message_datetime
     ;

END
;