/* ----------------------------------------- Creating the summary file for touchworks lab ---------------------------------------------------- */

BEGIN

create or replace table `research-01-217611.df_uld_stage.wkg_touchworks_lab`

   (  uuid string options (description='Unique record identifier')
    , savvy_pid int64 options (description = 'Unique (persistent) member identifier')
    , savvy_did int64 OPTIONS(description = 'Unique (periodically updated) member identifier')
    , is_restricted int64 OPTIONS(description = '1 if member is restricted (i.e., has ever been a UHG employee) and needs to be reported separately; 0 otherwise')
    , src_type string options (description='Name of the data mart type or source')
    , where_lab_performed string options(description='Facility where lab was performed')

    , lab_item_id int64 options (description='Unique key generated in Touchworks system for lab item. Links to "item_result" table')
    , lab_result_id int64 options (description='Unique key generated in Touchworks system for lab result. Links to "result" table')
    , patientid int64 options (description='Unique ID that points to the patient that this document belongs to')

    , lab_performed_date date options (description='Lab date - date test was performed')
    , lab_performed_time time options (description='Lab time - Time test was performed')

    , lab_item_created_date date options (description='Date lab item was created')
    , lab_item_created_time time options (description='Time lab item was created')

    , lab_item_entryname string options (description='Lab item ordered (ex. "ecg report", "pap smear. 1005")')
    , accession_number string options (description='Order number of the item. If the order came from within Touchworks, it is prefaced with "TW"; or, it may be from an external source and can sometimes be unpopulated. The accessionnumber ties items to an order/flowchart for a patient.')
    , is_error_flag string options (description='Flag for whether lab item had error(s)')
    , decoded_lab_item_value string options (description='Decoded values for the results; dependent on the test (ex. "6.5mg/dl","29 sec")')

    , lab_result_description string options (description='Lab result entryname.')
    , lab_order_description string options (description='Lab order entryname.')

    , lab_order_modifier_1 string options (description='Order modifier, can contain supplemental descriptions for the order')
    , lab_order_modifier_2 string options (description='Order modifier, can contain supplemental descriptions for the order')
    , lab_order_modifier_3 string options (description='Order modifier, can contain supplemental descriptions for the order')

     --Analyte results
    , numeric_result_value float64 options (description='Contains a numeric value if such is applicable for a particular test result. Please note that numeric results may also be in the Result Value field.')
    , result_value string options (description='Result value of test. Please note that numeric results may also be in the Numeric Result Value field.')
    , result_units string options (description='Contains the units upon which the result is based (milliliters, deciliters, percentage, et al).')

    --Reference range
    , ref_range string options(description='Reference Range for a specific test or analyte')
    , lower_ref_range float64 options (description='Numeric value for low-end of the normal range for a specific test or analyte.')
    , upper_ref_range float64 options (description='Numeric value for high-end of the normal range for a specific test or analyte')
    , delimiter string options (description='Delimiter used to separate lower and upper reference range from reference range. Since <30 and <=30 reference range will have same upper_ref_range (30), and >50 and >=50 will have same lower_ref_range (50), so, please use this delimiter field to make distinction between gt/ge (greater than/greater than or equal to) and lt/le (lesser than/lesser than or equal to).')

    , normalized_result_value float64 options (description='Normalized result value')
    , normalized_result_units string options (description='Units for normalized result')
    , source string options (description='Biological source of the lab sample (e.g. "blood")')

    -- Result_abnormal_code
    , abnormal_cd string options (description='Code to signify if the result was abnormal or outside of the standard ranges for the test.')
    , abnormal_desc string options (description='The Result Abnormal Description describes the result which is abnormal or outside the standard range for the test performed.')

    , result_status string options (description='Lab result status')
    , lab_completion_status string options (description='Status for whether the lab is imcomplete or was completed')
    , is_result_unverified_flag string options (description='Flag for whether lab was verified or not')

    --Procedure code
    , proc_cd string options (description='Procedure Code describes the type of procedure performed or service provided. This procedure code is usually a CPT-4 OR HCPCS Code.')
    , proc_desc string options (description='Describes a specific procedure performed or service provided. A procedure code can be an ICD10, ICD9, CPT4, or HCPC code.')

    --Loinc code
    , loinc_cd string  options (description='A universal identification number for a particular test or analyte, based on Logical Oberservation Identifiers Names and Codes (LOINC); a registered trademark of the Regenstrief Institute.')
    , cmpnt_nm string options (description='The biological component being measured by the laboratory test or analyte; e.g., potassium, glucose.')
    , loinc_cd_desc string options (description='Describes the universal identification number for a particular test or analyte, based on Logical Oberservation Identifiers Names and Codes (LOINC); a registered trademark of the Regenstrief Institute.')
    , prop_msr_cd string options (description='The property of the element that is being measured and reported upon (mass concentration, enzyme activity, etc.). Data Placement: left justified, space filled.')
    , rec_sts_cd string options (description='Identifies if the LOINC Code is still active or if it has been deleted. When a LOINC Code has been deleted, there may be a value in the Replacement LOINC Code field identifying the LOINC Code that should now be used. VALID VALUES: DEL=Delete spaces=Active')
    , repl_loinc_cd string options (description='When a LOINC Code has been replaced, this field will identify the new LOINC Code that should be used instead. Data Placement: left justified, space filled.')
    , samp_typ_nm string options (description='The type of sample upon which the test is performed; e.g., urine, blood, tissue.')
    , scl_typ_cd string options (description='The type of scale used to measure the result; e.g., whether the measurement is quantitative (a true measurement), ordinal (a ranked set of options), nominal (e.g., E. coli; Staphylococcus), or narrative (e.g., dictation results from x-rays). Data Placement: left justified, space filled. If you receive the following warning message when joining this code table to any Galaxy Fact tables please disregard: WARNING: Multiple lengths were specified for the BY variable (field name) by input data sets. This may cause unexpected results. The data in the code on the Galaxy Fact table will join to the data in the Galaxy Code Table. For Valid Values, see table SCALE_TYPE_CODE in Galaxy.')
    , tm_nm string options (description='Timing Name: The timeframe in which the biological componet is observed and measured; i.e., point in time, following a challenge (e.g., 2 hr post prandial), or an observation integrated over an extended duration of time (e.g., 24-hour urine)')
    , tst_meth_nm string options (description='Where relevant, the method used to produce the result or other observation.')
    , ver_lst_chg string options (description='The Version Last Changed is the LOINC version number in which the record has last changed. For new records, this field contains the same value as the LOINC First Published Release field')

    , dx1_diagnosis_free_text string options (description='Diagnosis free text for encounter diagnosis display order of 1')  --dx1 based on display order of 1
    , dx1_icd9_diagnosis_code string options (description='ICD9 diagnosis code for encounter diagnosis display order of 1')
    , dx1_icd10_diagnosis_code string options (description='ICD10 diagnosis code for encounter diagnosis display order of 1')
    , dx1_diagnosis_type string options (description='Diagnosis type for encounter diagnosis display order of 1.  Possible values: problem, icd9, icd10')
    , encounter_type string options (description='Type of encounter; an encounter is defined as a healthcare-related interaction between a patient and provider/service. For example, the encounter type fo this event would be "appointment"')
    , default_billing_location string options (description='Billing location')
    , billing_area string options (description='Billing area')
    , insurance_class string options (description='The patient registration insurance organization')
    , division string options (description='Division')
    , secondary_insurance string options (description='Secondary insurance')
    , tertiary_insurance string options (description='Tertiary insurance')

    , prov_upin_number string options(description='UPIN number')
    , prov_is_pcp_flag string options(description='Primary Care Provider? Y/N')
    , prov_dea_number string options(description='DEA number')
    , prov_npi int64 options(description='Provider National Provider Identifier')
    , prov_epa_enabled string options(description='Is Electronic Prior Authorization enabled (Y/N)?')
    , prov_specialty string options(description='Specialty')
    , prov_secondary_specialty string options(description='Secondary Specialty')

    --Ordering provider
    , ordering_prov_upin_number string options(description='Ordering Provider UPIN number')
    , ordering_prov_is_pcp_flag string options(description='Primary Care Provider? Y/N')
    , ordering_prov_dea_number string options(description='DEA number')
    , ordering_prov_npi int64 options(description='Provider National Provider Identifier')
    , ordering_prov_epa_enabled string options(description='Is Electronic Prior Authorization enabled (Y/N)?')
    , ordering_prov_specialty string options(description='Specialty')
    , ordering_prov_secondary_specialty string options(description='Secondary Specialty')

    , person_id int64 options(description='Unique key linking to "person" table')
    , encounter_id int64 options(description='Unique key linking to "encounter" table')
    , encounter_diagnosis_id int64 options(description='Unique key linking to "encounter_diagnosis" table')
    , activity_labs_id int64 options(description='Unique key linking to "act_result" table')
    , activity_header_labs_id int64 options(description='Unique key linking to "act_header_result" table')
    , provider_id int64 options(description='Unique key linking to "provider" table')
    , ordering_provider_id int64 options(description='Unique key linking to "provider" table')
    , person_other_id int64 options(description='Unique key linking to "person_other" table')
    , person_address_id int64 options(description='Unique key linking to "person_address" table')
    , person_phone_id int64 options(description='Unique key linking to "person_phone" table')

    , create_datetime datetime options (description='Datetime when the record was created')
    , update_datetime datetime options (description='Datetime when the record was updated')
   )

  --Table Metadata

  options (description='Touchworks Lab data detail')

as

SELECT GENERATE_UUID() AS uuid
      , pm.savvy_pid
      , pm.savvy_did
      , pm.is_restricted
      , 'touchworks lab' as src_type
      , LOWER(TRIM(wp.entryname)) AS where_lab_performed

      , ir.id AS lab_item_id
      , r.id as lab_result_id
      , CAST(ir.patientid as int64) AS patient_id

      , DATE(CAST(SUBSTR(ir.performeddttm,1,19) AS TIMESTAMP)) as lab_performed_date
      , TIME(CAST(SUBSTR(ir.performeddttm,1,19) AS TIMESTAMP)) as lab_performed_time

      , DATE(CAST(SUBSTR(ir.createdttm,1,19) AS TIMESTAMP)) as lab_item_created_date
      , TIME(CAST(SUBSTR(ir.createdttm,1,19) AS TIMESTAMP)) as lab_item_created_time

      , LOWER(TRIM(ir.entryname)) AS lab_item_entryname
      , LOWER(TRIM(r.accessionnumber)) AS accession_number  --not present in findings(vitals) table
      , LOWER(TRIM(ir.iserrorflag)) AS is_error_flag
      , LOWER(TRIM(ir.decodedvalue)) AS decoded_lab_item_value  --not present in findings(vitals) table

      , qo.lab_result_description
      , qo.lab_order_description

      --Lab order modifier
      , LOWER(TRIM(qom1.entryname)) AS lab_order_modifier_1
      , LOWER(TRIM(qom2.entryname)) AS lab_order_modifier_2
      , LOWER(TRIM(qom3.entryname)) AS lab_order_modifier_3

      --Results
      , CAST(r.numericresult as FLOAT64) AS numeric_result_value
      , LOWER(TRIM(r.answerdet)) AS result_value
      , hl.result_units

      --Reference range
      , LOWER(TRIM(r.shortrefrange)) AS ref_range
      , hl.lower_ref_range
      , hl.upper_ref_range
      , hl.delim as delimiter

      --Normalized results
      , cast(r.normalizedvalue as float64) AS normalized_result_value
      , LOWER(TRIM(nru.entryname)) AS normalized_result_units

      , LOWER(TRIM(s.entryname)) AS source

      --Abnormal values
      , rac.abnormalflagtype AS abnormal_cd
      , rac.rslt_abnl_desc AS abnormal_desc

      , LOWER(TRIM(rs.entryname)) as result_status
      , LOWER(TRIM(ahr.completionstatus)) AS lab_completion_status
      , LOWER(TRIM(r.isunverifiedflag)) AS is_result_unverified_flag

      --Procedure code
      , qo.proc_cd
      , qo.proc_desc

      --Loinc code
      , qo.loinc_cd
      , qo.cmpnt_nm
      , qo.loinc_cd_desc
      , qo.prop_msr_cd
      , qo.rec_sts_cd
      , qo.repl_loinc_cd
      , qo.samp_typ_nm
      , qo.scl_typ_cd
      , qo.tm_nm
      , qo.tst_meth_nm
      , qo.ver_lst_chg

      , LOWER(TRIM(REGEXP_REPLACE(ed.freetextdiag, "000", ""))) AS dx1_diagnosis_free_text  --dx1 based on display order of 1
      , LOWER(TRIM(ed.ICD9DiagnosisCode)) AS dx1_icd9_diagnosis_code
      , LOWER(TRIM(ed.ICD10DiagnosisCode)) AS dx1_icd10_diagnosis_code
      , LOWER(TRIM(ed.DiagnosisType)) AS dx1_diagnosis_type
      , LOWER(TRIM(et.entryname)) AS encounter_type
      , LOWER(TRIM(bl.entryname)) AS default_billing_location
      , LOWER(TRIM(ba.entryname)) AS billing_area
      , LOWER(TRIM(ic.entryname)) AS insurance_class
      , LOWER(TRIM(d.entryname)) AS division
      , LOWER(TRIM(sic.entryname)) AS secondary_insurance
      , LOWER(TRIM(tic.entryname)) AS tertiary_insurance

      , LOWER(TRIM(pr.upinnumber)) AS prov_upin_number
      , LOWER(TRIM(pr.ispcpflag)) AS prov_is_pcp_flag
      , LOWER(TRIM(pr.deanumber)) AS prov_dea_number
      , safe_cast(pr.npi as int64) AS prov_npi
      , LOWER(TRIM(pr.epa_enabled)) AS prov_epa_enabled
      , LOWER(TRIM(sp.entryname)) AS prov_specialty
      , LOWER(TRIM(ssp.entryname)) AS prov_secondary_specialty

      --Ordering provider
      , LOWER(TRIM(opr.upinnumber)) AS ordering_prov_upin_number
      , LOWER(TRIM(opr.ispcpflag)) AS ordering_prov_is_pcp_flag
      , LOWER(TRIM(opr.deanumber)) AS ordering_prov_dea_number
      , safe_cast(opr.npi as int64) AS ordering_prov_npi
      , LOWER(TRIM(opr.epa_enabled)) AS ordering_prov_epa_enabled
      , LOWER(TRIM(osp.entryname)) AS ordering_prov_specialty
      , LOWER(TRIM(ossp.entryname)) AS ordering_prov_secondary_specialty

      , pe.ID AS person_id
      , e.ID AS encounter_id
      , ed.ID AS encounter_diagnosis_id
      , ar.ID AS activity_labs_id
      , ahr.ID AS activity_header_labs_id
      , pr.ID AS provider_id
      , opr.ID as ordering_provider_id
      , po.ID AS person_other_id
      , pa.ID AS person_address_id
      , pp.ID AS person_phone_id

      , current_datetime() as create_datetime
      , current_datetime() as update_datetime

FROM
--Item Result
           `ds-00-191017.smalv_tw_final.item_result`               ir
LEFT JOIN  cte_ir_qo_tables_desc                                   qo    ON ir.qode                = qo.qode
                                                                         AND ir.qoclassificationde  = qo.qoclassificationde
LEFT JOIN  `ds-00-191017.smalv_tw_final.qo_mod_de`                 qom1  ON qom1.id                = cast(ir.qomod1de AS INT64)
LEFT JOIN  `ds-00-191017.smalv_tw_final.qo_mod_de`                 qom2  ON qom2.id                = cast(ir.qomod2de AS INT64)
LEFT JOIN  `ds-00-191017.smalv_tw_final.qo_mod_de`                 qom3  ON qom3.id                = cast(ir.qomod3de AS INT64)

--Activity
LEFT JOIN  `ds-00-191017.smalv_tw_final.act_hdr_result`            ahr   ON ahr.id                 = cast(ir.ActivityHeaderID AS INT64)
LEFT JOIN  `ds-00-191017.smalv_tw_final.act_result`                ar    ON ahr.ID                 = ar.ActivityHeaderID
                                                                         and ahr.currentID         = ar.id
--Result
INNER JOIN  `ds-00-191017.smalv_tw_final.result`                   r     ON ir.id                  = cast(r.itemid as int64)
                                                                         AND r.id                  = cast(ir.currentid  as int64)
LEFT JOIN  `ds-00-191017.smalv_tw_final.result_status_de`          rs    ON rs.id                  = cast(r.resultstatusde as int64)
LEFT JOIN cte_hi_low_from_ref_range                                hl    ON r.shortrefrange        = hl.orig_r_shortrefrange
                                                                         AND r.unitsde             = hl.unitsde
LEFT JOIN  `ds-00-191017.smalv_tw_final.unit_code_de`              nru   ON nru.id                 = cast(r.normalizedunitsde as int64)
LEFT JOIN  `ds-00-191017.smalv_tw_final.source_de`                 s     ON s.id                   = cast(r.sourcede as int64)
LEFT JOIN  `ds-00-191017.smalv_tw_final.where_performed_de`        wp    ON wp.id                  = cast(r.whereperformedde as int64)
LEFT JOIN   cte_result_abnormal_code                               rac   ON r.abnormalflagtype     = rac.orig_r_abnormalflagtype

--Encounter
LEFT JOIN  `ds-00-191017.smalv_tw_final.encounter`                 e     ON ahr.EncounterID        = e.ID
LEFT JOIN `ds-00-191017.smalv_tw_final.encounter_type_de`          et    ON et.id                  = cast(e.encountertypede as int64)
LEFT JOIN `ds-00-191017.smalv_tw_final.billing_area_de`            ba    ON ba.id                  = cast(e.billingareade as int64)
LEFT JOIN `ds-00-191017.smalv_tw_final.billing_location_de`        bl    ON bl.id                  = cast(e.defaultbillinglocationde as int64)
LEFT JOIN `ds-00-191017.smalv_tw_final.insurance_class_de`         ic    ON ic.id                  = cast(e.insuranceclassde as int64)
LEFT JOIN `ds-00-191017.smalv_tw_final.division_de`                d     ON d.id                   = cast(e.divisionde as int64)
LEFT JOIN `ds-00-191017.smalv_tw_final.insurance_class_de`         sic   ON sic.id                 = cast(e.secondaryinsurancede as int64)
LEFT JOIN `ds-00-191017.smalv_tw_final.insurance_class_de`         tic   ON tic.id                 = cast(e.tertiaryinsurancede as int64)

--Encounter diagnosis
LEFT JOIN `ds-00-191017.smalv_tw_final.encounter_diagnosis`        ed    ON ed.EncounterID         = e.ID
                                                                         and ed.DisplayOrder       = 1
                                                                         and ed.SubmittedFLAG      is true
--Provider
LEFT JOIN `ds-00-191017.smalv_tw_final.provider`                   pr    ON pr.id                  = cast(r.whoforid as int64)
LEFT JOIN `ds-00-191017.smalv_tw_final.specialty_de`               sp    ON sp.id                  = cast(pr.specialtyde as int64)
LEFT JOIN `ds-00-191017.smalv_tw_final.specialty_de`               ssp   ON ssp.id                 = safe_cast(pr.specialty2de as int64)
--Ordering Provider
LEFT JOIN `ds-00-191017.smalv_tw_final.provider`                   opr   ON opr.id                 = cast(ar.orderingproviderid as int64)
LEFT JOIN `ds-00-191017.smalv_tw_final.specialty_de`               osp   ON osp.id                 = cast(opr.specialtyde as int64)
LEFT JOIN `ds-00-191017.smalv_tw_final.specialty_de`               ossp  ON ossp.id                = safe_cast(opr.specialty2de as int64)
--Person
INNER JOIN `ds-00-191017.smalv_tw_final.person`                    pe    ON pe.id                  = cast(ir.patientid as int64)
INNER JOIN `ds-00-191017.smalv_tw_final.patient_member`            pm    ON pe.id                  = pm.ID
LEFT JOIN cte_tw_person_phone                                      pp    ON pe.id                  = pp.id
LEFT JOIN `ds-00-191017.smalv_tw_final.person_address`             pa    ON pe.id                  = pa.id
LEFT JOIN `ds-00-191017.smalv_tw_final.person_other`               po    ON pe.id                  = po.id
WHERE trim(lower(pm.isinactiveflag)) = 'n'
and pm.savvy_pid <> -1
   ;

/* ---------------------------------------------------------- End of code --------------------------------------------------------------------- */

  --if successful, we'll get here!
insert into `research-01-217611.df_uld_stage.logging`(
     success_flag, job,tbl, message_datetime)
   select
     1 as success_flag
     , 'create wkg_touchworks_lab tables' as job
     , 'wkg_touchworks_lab' as tbl
     ,current_datetime as message_datetime
   ;

   EXCEPTION WHEN ERROR THEN
     insert into `research-01-217611.df_uld_stage.logging`(
       success_flag, job,tbl, error_message, statement_text, formatted_stack_trace, message_datetime)
     select
       0 as success_flag
       , 'create wkg_touchworks_lab tables' as job
       , 'wkg_touchworks_lab' as tbl
       , @@error.message as error_message
       , @@error.statement_text as statement_text
       , @@error.formatted_stack_trace as formatted_stack_trace
       , current_datetime as message_datetime
     ;

END
;