BEGIN

create or replace table `research-01-217611.df_uld_stage.cte_assign_delimiter` as

    (Select distinct orig_r_shortrefrange, curated_shortrefrange, result_units, unitsde
               , CASE WHEN ( LEFT(REGEXP_REPLACE(curated_shortrefrange,' |than',''),1) = '<'
                             AND SAFE_CAST(SUBSTR(REGEXP_REPLACE(curated_shortrefrange,' |than',''),2) AS FLOAT64) IS NOT NULL ----default 3rd argument for substring is length of 1st argument
                            ) --first byte is <. second byte is numeric is float needed (handles values such as '<10', '< than 10')
                      OR ( curated_shortrefrange like '%less%than%'
                           AND SAFE_CAST(REGEXP_REPLACE(curated_shortrefrange,' |less|than','') AS FLOAT64) IS NOT NULL
                           ) --handles values such as 'less than 10'
                     THEN 'lt'

                      WHEN LEFT(REGEXP_REPLACE(curated_shortrefrange,' |than',''),1) = '>'
                      AND SAFE_CAST(SUBSTR(REGEXP_REPLACE(curated_shortrefrange,' |than',''),2) AS FLOAT64) IS NOT NULL --first byte is >, second byte is numeric (handles values such as '>10', '> than 10')
                      THEN 'gt'

                      WHEN INSTR(curated_shortrefrange,'-',2)>1 --'-'  (starts search from 2nd position) after the first position which indicates a numeric range. for e.g. '-10 - +11'
                      AND SAFE_CAST(SUBSTR(curated_shortrefrange, 1, INSTR(curated_shortrefrange, '-',2) -1) AS FLOAT64) IS NOT NULL --numeric before dash
                      AND SAFE_CAST(SUBSTR(curated_shortrefrange, INSTR(curated_shortrefrange,'-',2) + 1) AS FLOAT64) IS NOT NULL --numeric after dash
                      --handles values such as '10-11',
                      THEN 'dash'

                      WHEN INSTR(curated_shortrefrange,'to',2)>1
                      AND SAFE_CAST(SUBSTR(curated_shortrefrange, 1, INSTR(curated_shortrefrange, 'to',2) -1) AS FLOAT64) IS NOT NULL --numeric before to
                      AND SAFE_CAST(SUBSTR(curated_shortrefrange, INSTR(curated_shortrefrange,'to',2) + 2) AS FLOAT64) IS NOT NULL --numeric after to
                      --handles values such as '10 to 11'
                      THEN 'to'

                      WHEN REGEXP_REPLACE(curated_shortrefrange,'[0-9]','')= curated_shortrefrange THEN 'alpha'      --no numbers

                      WHEN ( LEFT(REGEXP_REPLACE(curated_shortrefrange,' |or',''),2) = '<='
                            AND SAFE_CAST(SUBSTR(REGEXP_REPLACE(curated_shortrefrange,' |or',''),3) AS FLOAT64) IS NOT NULL
                            ) -- Remove spaces and 'or' check for <= ( Handles values such as "<=10", "< or = 10")
                        OR ( curated_shortrefrange like '%or%less%'
                           AND SAFE_CAST(REGEXP_REPLACE(curated_shortrefrange,' |or|less','') AS FLOAT64) IS NOT NULL
                           ) --Handles values such as '0.2 or less'
                      THEN 'le'

                      WHEN LEFT(REGEXP_REPLACE(curated_shortrefrange,' |or',''),2) = '>=' AND SAFE_CAST(SUBSTR(REGEXP_REPLACE(curated_shortrefrange,' |or',''),3) AS FLOAT64) IS NOT NULL
                      -- Remove spaces and 'or' check for >=
                      THEN 'ge'


                  END AS DELIM
      from cte_ref_range_curation
      )
   ;
/* ---------------------------------------------------------- End of code --------------------------------------------------------------------- */

  --if successful, we'll get here!
insert into `research-01-217611.df_uld_stage.logging`(
      success_flag, job,tbl, message_datetime)
    select
      1 as success_flag
      , 'create cte_assign_delimiter tables' as job
      , 'cte_assign_delimiter' as tbl
      ,current_datetime as message_datetime
    ;

    EXCEPTION WHEN ERROR THEN
      insert into `research-01-217611.df_uld_stage.logging`(
        success_flag, job,tbl, error_message, statement_text, formatted_stack_trace, message_datetime)
      select
        0 as success_flag
        , 'create cte_assign_delimiter tables' as job
        , 'cte_assign_delimiter' as tbl
        , @@error.message as error_message
        , @@error.statement_text as statement_text
        , @@error.formatted_stack_trace as formatted_stack_trace
        , current_datetime as message_datetime
      ;

END
;