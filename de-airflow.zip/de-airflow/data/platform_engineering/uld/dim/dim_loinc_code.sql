create or replace table `research-01-217611.df_uld_stage.dim_loinc_code`

(     loinc_cd string  options (description='A universal identification number for a particular test or analyte, based on Logical Oberservation Identifiers Names and Codes (LOINC); a registered trademark of the Regenstrief Institute.')
    , cmpnt_nm string options (description='The biological component being measured by the laboratory test or analyte; e.g., potassium, glucose.')
    , loinc_cd_desc string options (description='Describes the universal identification number for a particular test or analyte, based on Logical Oberservation Identifiers Names and Codes (LOINC); a registered trademark of the Regenstrief Institute.')
    , prop_msr_cd string options (description='The property of the element that is being measured and reported upon (mass concentration, enzyme activity, etc.). Data Placement: left justified, space filled.')
    , rec_sts_cd string options (description='Identifies if the LOINC Code is still active or if it has been deleted. When a LOINC Code has been deleted, there may be a value in the Replacement LOINC Code field identifying the LOINC Code that should now be used. VALID VALUES: DEL=Delete spaces=Active')
    , repl_loinc_cd string options (description='When a LOINC Code has been replaced, this field will identify the new LOINC Code that should be used instead. Data Placement: left justified, space filled. ')
    , samp_typ_nm string options (description='The type of sample upon which the test is performed; e.g., urine, blood, tissue.')
    , scl_typ_cd string options (description='The type of scale used to measure the result; e.g., whether the measurement is quantitative (a true measurement), ordinal (a ranked set of options), nominal (e.g., E. coli; Staphylococcus), or narrative (e.g., dictation results from x-rays). Data Placement: left justified, space filled. If you receive the following warning message when joining this code table to any Galaxy Fact tables please disregard: WARNING: Multiple lengths were specified for the BY variable (field name) by input data sets. This may cause unexpected results. The data in the code on the Galaxy Fact table will join to the data in the Galaxy Code Table. For Valid Values, see table SCALE_TYPE_CODE in Galaxy.')
    , tm_nm string options (description='Timing Name: The timeframe in which the biological componet is observed and measured; i.e., point in time, following a challenge (e.g., 2 hr post prandial), or an observation integrated over an extended duration of time (e.g., 24-hour urine)')
    , tst_meth_nm string options (description='Where relevant, the method used to produce the result or other observation.')
    , ver_lst_chg string options (description='The Version Last Changed is the LOINC version number in which the record has last changed. For new records, this field contains the same value as the LOINC First Published Release field')

    , create_datetime datetime options (description='Datetime when the record was created')

 )

 --Table Metadata
 options (description='Dimension table for loinc code. Contains 1 row per loinc code. Source: Galaxy')

 as


select  lower(trim(loinc_cd)) as loinc_cd
      , max(lower(trim(cmpnt_nm))) as cmpnt_nm
      , max(lower(trim(loinc_cd_desc))) as loinc_cd_desc
      , max(lower(trim(prop_msr_cd))) as prop_msr_cd
      , max(lower(trim(rec_sts_cd))) as rec_sts_cd
      , max(lower(trim(repl_loinc_cd))) as repl_loinc_cd
      , max(lower(trim(samp_typ_nm))) as samp_typ_nm
      , max(lower(trim(scl_typ_cd))) as scl_typ_cd
      , max(lower(trim(tm_nm))) as tm_nm
      , max(lower(trim(tst_meth_nm))) as tst_meth_nm
      , max(lower(trim(ver_lst_chg))) as ver_lst_chg
      , current_datetime() as create_datetime
from `ds-00-191017.galaxy_final.loinc_code`
group by loinc_cd
