--DIM_LOINC

insert into `research-01-217611.df_uld_stage.copy_metadata`(interface, source, destination ) values
('uld_dim_loinc_code_archive','research-01-217611.df_uld_stage.dim_loinc_code','');



--ULD-GALAXY-LABS

insert into `research-01-217611.df_uld_stage.copy_metadata`(interface, source, destination ) values
('uld_galaxy_archive','research-01-217611.df_uld_stage.final_udd_lab_galaxy',''),
('uld_galaxy_archive','research-01-217611.df_uld.udd_lab_galaxy','');


insert into `research-01-217611.df_uld_stage.copy_metadata`(interface, source, destination ) values
('uld_galaxy_template','research-01-217611.df_uld_stage.galaxy_lab_template','research-01-217611.df_uld_stage.udd_lab_galaxy'),
('uld_galaxy_template','research-01-217611.df_uld_stage.galaxy_lab_template','research-01-217611.df_uld_stage.final_udd_lab_galaxy'),
('uld_galaxy_template','research-01-217611.df_uld_stage.galaxy_lab_template','research-01-217611.df_uld.udd_lab_galaxy');

insert into `research-01-217611.df_uld_stage.copy_metadata`(interface, source, destination ) values
('uld_galaxy_final','research-01-217611.df_uld_stage.udd_lab_galaxy','research-01-217611.df_uld_stage.final_udd_lab_galaxy'),
('uld_galaxy_final','research-01-217611.df_uld_stage.udd_lab_galaxy','research-01-217611.df_uld.udd_lab_galaxy');


--ULD-IHR-LABS

insert into `research-01-217611.df_uld_stage.copy_metadata`(interface, source, destination ) values
('uld_ihr_lab_archive','research-01-217611.df_uld_stage.final_udd_lab_ihr',''),
('uld_ihr_lab_archive','research-01-217611.df_uld.udd_lab_ihr','');


insert into `research-01-217611.df_uld_stage.copy_metadata`(interface, source, destination ) values
('uld_ihr_lab_template','research-01-217611.df_uld_stage.lab_ihr_template','research-01-217611.df_uld_stage.udd_lab_ihr'),
('uld_ihr_lab_template','research-01-217611.df_uld_stage.lab_ihr_template','research-01-217611.df_uld_stage.final_udd_lab_ihr'),
('uld_ihr_lab_template','research-01-217611.df_uld_stage.lab_ihr_template','research-01-217611.df_uld.udd_lab_ihr');

insert into `research-01-217611.df_uld_stage.copy_metadata`(interface, source, destination ) values
('uld_ihr_lab_final','research-01-217611.df_uld_stage.udd_lab_ihr','research-01-217611.df_uld_stage.final_udd_lab_ihr'),
('uld_ihr_lab_final','research-01-217611.df_uld_stage.udd_lab_ihr','research-01-217611.df_uld.udd_lab_ihr');


--ULD-TOUCHWORKS-LABS

insert into `research-01-217611.df_uld_stage.copy_metadata`(interface, source, destination ) values
('uld_touchwork_lab_archive','research-01-217611.df_uld_stage.final_udd_lab_touchworks',''),
('uld_touchwork_lab_archive','research-01-217611.df_uld.udd_lab_touchworks','');


insert into `research-01-217611.df_uld_stage.copy_metadata`(interface, source, destination ) values
('uld_touchwork_lab_template','research-01-217611.df_uld_stage.touchworks_lab_template','research-01-217611.df_uld_stage.udd_lab_touchworks'),
('uld_touchwork_lab_template','research-01-217611.df_uld_stage.touchworks_lab_template','research-01-217611.df_uld_stage.final_udd_lab_touchworks'),
('uld_touchwork_lab_template','research-01-217611.df_uld_stage.touchworks_lab_template','research-01-217611.df_uld.udd_lab_touchworks');

insert into `research-01-217611.df_uld_stage.copy_metadata`(interface, source, destination ) values
('uld_touchwork_lab_final','research-01-217611.df_uld_stage.udd_lab_touchworks','research-01-217611.df_uld_stage.final_udd_lab_touchworks'),
('uld_touchwork_lab_final','research-01-217611.df_uld_stage.udd_lab_touchworks','research-01-217611.df_uld.udd_lab_touchworks');


--ULD-TOUCHWORKS-VITALS

insert into `research-01-217611.df_uld_stage.copy_metadata`(interface, source, destination ) values
('uld_touchwork_vital_archive','research-01-217611.df_uld_stage.final_udd_vitals_touchworks',''),
('uld_touchwork_vital_archive','research-01-217611.df_uld.udd_vitals_touchworks','');


insert into `research-01-217611.df_uld_stage.copy_metadata`(interface, source, destination ) values
('uld_touchwork_vital_template','research-01-217611.df_uld_stage.touchworks_vitals_template','research-01-217611.df_uld_stage.udd_vitals_touchworks'),
('uld_touchwork_vital_template','research-01-217611.df_uld_stage.touchworks_vitals_template','research-01-217611.df_uld_stage.final_udd_vitals_touchworks'),
('uld_touchwork_vital_template','research-01-217611.df_uld_stage.touchworks_vitals_template','research-01-217611.df_uld.udd_vitals_touchworks');

insert into `research-01-217611.df_uld_stage.copy_metadata`(interface, source, destination ) values
('uld_touchwork_vital_final','research-01-217611.df_uld_stage.udd_vitals_touchworks','research-01-217611.df_uld_stage.final_udd_vitals_touchworks'),
('uld_touchwork_vital_final','research-01-217611.df_uld_stage.udd_vitals_touchworks','research-01-217611.df_uld.udd_vitals_touchworks');
