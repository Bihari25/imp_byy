create or replace table `research-01-217611.df_uld_stage.touchworks_lab_template`

   (  uuid                     string      OPTIONS(description="Unique record identifier")
    , savvy_pid                int64       OPTIONS(description="Unique (persistent) member identifier")
    , savvy_did                int64       OPTIONS(description="Unique (periodically updated) member identifier")
    , is_restricted            int64       OPTIONS(description="1 if member is restricted (i.e., has ever been a UHG employee) and needs to be reported separately; 0 otherwise")

    , src_type                 string      OPTIONS(description="Data mart type or source")
    , where_lab_performed      string      OPTIONS(description="Facility where lab was performed")
    , src_uuid                 string      OPTIONS(description="uuid from source table")

    , lab_date                 date        OPTIONS(description="Lab Date - date lab test was performed")
    , lab_time                 time        OPTIONS(description="Lab Time - time lab test was performed")

    , lab_result_description   string      OPTIONS(description="Description of lab result")
    , lab_order_description    string      OPTIONS(description="Description of lab order")

    , numeric_result_value     float64     OPTIONS(description="Numeric lab result value")
    , result_value             string      OPTIONS(description="Lab result value")
    , result_units             string      OPTIONS(description="Lab result units")

    , ref_range                string      OPTIONS(description="Reference Range for lab test")
    , lower_ref_range          float64     OPTIONS(description="Lower value of reference range")
    , upper_ref_range          float64     OPTIONS(description="Upper value of reference range")
    , delimiter                string      OPTIONS(description="Delimiter used to separate lower and upper reference range from reference range. Since <30 and <=30 reference range will have same upper_ref_range (30), and >50 and >=50 will have same lower_ref_range (50), so, please use this delimiter field to make distinction between gt/ge (greater than/greater than or equal to) and lt/le (lesser than/lesser than or equal to).")

    , abnormal_cd              string      OPTIONS(description="Code to signify if the result was abnormal or outside the standard ranges for the test")
    , abnormal_desc            string      OPTIONS(description="Description of abnormal code")
    , result_status            string      OPTIONS(description="lab result status")

    , prov_npi                 int64       OPTIONS(description="Provider National provider indentifier")
    , prov_mpin                int64       OPTIONS(description="Provider MPIN")

    , proc_cd                  string      OPTIONS(description="Procedure code")
    , proc_desc                string      OPTIONS(description="Procedure code description")

    , loinc_cd                 string      OPTIONS(description="A universal identification number for a particular test or analyte, based on Logical Oberservation Identifiers Names and Codes (LOINC); a registered trademark of the Regenstrief Institute")
    , cmpnt_nm                 string      OPTIONS(description="The biological component being measured by the laboratory test or analyte; e.g., potassium, glucose.")
    , loinc_cd_desc            string      OPTIONS(description="Describes the universal identification number for a particular test or analyte, based on Logical Oberservation Identifiers Names and Codes (LOINC); a registered trademark of the Regenstrief Institute.")
    , prop_msr_cd              string      OPTIONS(description="The property of the element that is being measured and reported upon (mass concentration, enzyme activity, etc.). Data Placement: left justified, space filled.")
    , rec_sts_cd               string      OPTIONS(description="Identifies if the LOINC Code is still active or if it has been deleted. When a LOINC Code has been deleted, there may be a value in the Replacement LOINC Code field identifying the LOINC Code that should now be used. VALID VALUES: DEL=Delete spaces=Active")
    , repl_loinc_cd            string      OPTIONS(description="When a LOINC Code has been replaced, this field will identify the new LOINC Code that should be used instead. Data Placement: left justified, space filled.")
    , samp_typ_nm              string      OPTIONS(description="The type of sample upon which the test is performed; e.g., urine, blood, tissue.")
    , scl_typ_cd               string      OPTIONS(description="The type of scale used to measure the result; e.g., whether the measurement is quantitative (a true measurement), ordinal (a ranked set of options), nominal (e.g., E. coli; Staphylococcus), or narrative (e.g., dictation results from x-rays). Data Placement: left justified, space filled. If you receive the following warning message when joining this code table to any Galaxy Fact tables please disregard: WARNING: Multiple lengths were specified for the BY variable (field name) by input data sets. This may cause unexpected results. The data in the code on the Galaxy Fact table will join to the data in the Galaxy Code Table. For Valid Values, see table SCALE_TYPE_CODE in Galaxy.")
    , tm_nm                    string      OPTIONS(description="Timing Name: The timeframe in which the biological componet is observed and measured; i.e., point in time, following a challenge (e.g., 2 hr post prandia,l), or an observation integrated over an extended duration of time (e.g., 24-hour urine)")
    , tst_meth_nm              string      OPTIONS(description="Where relevant, the method used to produce the result or other observation.")
    , ver_lst_chg              string      OPTIONS(description="The Version Last Changed is the LOINC version number in which the record has last changed. For new records, this field contains the same value as the LOINC First Published Release field")

    , note                     string      OPTIONS(description= "Note (includes all rows)")
    , create_datetime          datetime    OPTIONS(description= "datetime record created")
    , update_datetime          datetime    OPTIONS(description= "datetime record updated")

  );
