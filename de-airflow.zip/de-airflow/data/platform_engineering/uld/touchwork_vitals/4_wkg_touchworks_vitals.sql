BEGIN

/* ----------------------------------------- Creating the summary file for touchworks lab ---------------------------------------------------- */

create or replace table `research-01-217611.df_uld_stage.wkg_touchworks_vitals`

   (  uuid string options (description='Unique record identifier')
    , savvy_pid int64 options (description = 'Unique (persistent) member identifier')
    , savvy_did int64 OPTIONS(description = 'Unique (periodically updated) member identifier')
    , is_restricted int64 OPTIONS(description = '1 if member is restricted (i.e., has ever been a UHG employee) and needs to be reported separately; 0 otherwise')
    , src_type string options (description='Name of the data mart type or source')
    , where_vitals_performed string options(description='Clinical location where vitals were taken')

    , vitals_item_id int64 options (description='Unique key generated in Touchworks system for vitals item. Links to "item_finding" table')
    , vitals_result_id int64 options (description='Unique key generated in Touchworks system for lab result. Links to "finding" table')
    , patientid int64 options (description='Unique ID that points to the patient that this document belongs to')

    , vitals_performed_date date options (description='Vitals date - date test was performed')
    , vitals_performed_time time options (description='Vitals time - Time test was performed')

    , vitals_item_created_date date options (description='Date vitals item was created')
    , vitals_item_created_time time options (description='Time vitals item was created')

    , vitals_item_entryname string options (description='Vitals item ordered. The entry name of the item. Contains the vital measured in the test (ex. "respiratory rate", "temperature")')
    , is_error_flag string options (description='Flag for whether vitals item had error(s)')
    , decoded_vitals_item_value string options (description='Vitals value. Depending on the diagnostic performed, may represent %, a measurable amount, an observation (ex. "irregular bleeding"), etc.')

    , vitals_result_description string options (description='Vitals result entryname.')
    , vitals_order_description string options (description='Vitals order entryname. The type of diagnostic performed, often similar or the same as vitals_result_description')

    , vitals_order_modifier_1 string options (description='Order modifier, can contain supplemental descriptions for the order')
    , vitals_order_modifier_2 string options (description='Order modifier, can contain supplemental descriptions for the order')
    , vitals_order_modifier_3 string options (description='Order modifier, can contain supplemental descriptions for the order')

     --Analyte results
    , numeric_vitals_value float64 options (description='Contains a numeric value if such is applicable for a particular test result. Please note that numeric results may also be in the Vitals Value field.')
    , vitals_value string options (description='Vitals result value. Please note that numeric results may also be in the Numeric Vitals Value field.')
    , vitals_units string options (description='Units of vitals value.')

    --Reference range
    , ref_range string options(description='Reference Range for a specific test or analyte')
    , lower_ref_range float64 options (description='Numeric value for low-end of the normal range for a specific test or analyte.')
    , upper_ref_range float64 options (description='Numeric value for high-end of the normal range for a specific test or analyte')
    , delimiter string options (description='Delimiter used to separate lower and upper reference range from reference range. Since <30 and <=30 reference range will have same upper_ref_range (30), and >50 and >=50 will have same lower_ref_range (50), so, please use this delimiter field to make distinction between gt/ge (greater than/greater than or equal to) and lt/le (lesser than/lesser than or equal to).')

    , normalized_vitals_value float64 options (description='Normalized vitals value')
    , normalized_vitals_units string options (description='Units for normalized vitals value')
    , source string options (description='Biological source of the vitals')

    -- Result_abnormal_code
    , abnormal_cd string options (description='Code to signify if the result was abnormal or outside of the standard ranges for the test.')
    , abnormal_desc string options (description='The Result Abnormal Description describes the result which is abnormal or outside the standard range for the test performed.')

    , vitals_status string options (description='Vitals result status')
    , vitals_completion_status string options (description='Status for whether the vitals is imcomplete or was completed')
    , is_vitals_unverified_flag string options (description='Flag for whether vitals was verified or not')

    --Procedure code
    , proc_cd string options (description='Procedure Code describes the type of procedure performed or service provided. This procedure code is usually a CPT-4 OR HCPCS Code.')
    , proc_desc string options (description='Describes a specific procedure performed or service provided. A procedure code can be an ICD10, ICD9, CPT4, or HCPC code.')

    --Loinc code
    , loinc_cd string  options (description='A universal identification number for a particular test or analyte, based on Logical Oberservation Identifiers Names and Codes (LOINC); a registered trademark of the Regenstrief Institute.')
    , cmpnt_nm string options (description='The biological component being measured by the laboratory test or analyte; e.g., potassium, glucose.')
    , loinc_cd_desc string options (description='Describes the universal identification number for a particular test or analyte, based on Logical Oberservation Identifiers Names and Codes (LOINC); a registered trademark of the Regenstrief Institute.')
    , prop_msr_cd string options (description='The property of the element that is being measured and reported upon (mass concentration, enzyme activity, etc.). Data Placement: left justified, space filled.')
    , rec_sts_cd string options (description='Identifies if the LOINC Code is still active or if it has been deleted. When a LOINC Code has been deleted, there may be a value in the Replacement LOINC Code field identifying the LOINC Code that should now be used. VALID VALUES: DEL=Delete spaces=Active')
    , repl_loinc_cd string options (description='When a LOINC Code has been replaced, this field will identify the new LOINC Code that should be used instead. Data Placement: left justified, space filled.')
    , samp_typ_nm string options (description='The type of sample upon which the test is performed; e.g., urine, blood, tissue.')
    , scl_typ_cd string options (description='The type of scale used to measure the result; e.g., whether the measurement is quantitative (a true measurement), ordinal (a ranked set of options), nominal (e.g., E. coli; Staphylococcus), or narrative (e.g., dictation results from x-rays). Data Placement: left justified, space filled. If you receive the following warning message when joining this code table to any Galaxy Fact tables please disregard: WARNING: Multiple lengths were specified for the BY variable (field name) by input data sets. This may cause unexpected results. The data in the code on the Galaxy Fact table will join to the data in the Galaxy Code Table. For Valid Values, see table SCALE_TYPE_CODE in Galaxy.')
    , tm_nm string options (description='Timing Name: The timeframe in which the biological componet is observed and measured; i.e., point in time, following a challenge (e.g., 2 hr post prandial), or an observation integrated over an extended duration of time (e.g., 24-hour urine)')
    , tst_meth_nm string options (description='Where relevant, the method used to produce the result or other observation.')
    , ver_lst_chg string options (description='The Version Last Changed is the LOINC version number in which the record has last changed. For new records, this field contains the same value as the LOINC First Published Release field')

    , dx1_diagnosis_free_text string options (description='Diagnosis free text for encounter diagnosis display order of 1')  --dx1 based on display order of 1
    , dx1_icd9_diagnosis_code string options (description='ICD9 diagnosis code for encounter diagnosis display order of 1')
    , dx1_icd10_diagnosis_code string options (description='ICD10 diagnosis code for encounter diagnosis display order of 1')
    , dx1_diagnosis_type string options (description='Diagnosis type for encounter diagnosis display order of 1.  Possible values: problem, icd9, icd10')
    , encounter_type string options (description='Type of encounter; an encounter is defined as a healthcare-related interaction between a patient and provider/service. For example, the encounter type fo this event would be "appointment"')
    , default_billing_location string options (description='Billing location')
    , billing_area string options (description='Billing area')
    , insurance_class string options (description='The patient registration insurance organization')
    , division string options (description='Division')
    , secondary_insurance string options (description='Secondary insurance')
    , tertiary_insurance string options (description='Tertiary insurance')

    , prov_upin_number string options(description='UPIN number')
    , prov_is_pcp_flag string options(description='Primary Care Provider? Y/N')
    , prov_dea_number string options(description='DEA number')
    , prov_npi int64 options(description='Provider National Provider Identifier')
    , prov_epa_enabled string options(description='Is Electronic Prior Authorization enabled (Y/N)?')
    , prov_specialty string options(description='Specialty')
    , prov_secondary_specialty string options(description='Secondary Specialty')

    , person_id int64 options(description='Unique key linking to "person" table')
    , encounter_id int64 options(description='Unique key linking to "encounter" table')
    , encounter_diagnosis_id int64 options(description='Unique key linking to "encounter_diagnosis" table')
    , activity_header_other_id int64 options(description='Unique key linking to "act_hdr_other" table')
    , provider_id int64 options(description='Unique key linking to "provider" table')
    , person_other_id int64 options(description='Unique key linking to "person_other" table')
    , person_address_id int64 options(description='Unique key linking to "person_address" table')
    , person_phone_id int64 options(description='Unique key linking to "person_phone" table')

    , create_datetime datetime options (description='Datetime when the record was created')
    , update_datetime datetime options (description='Datetime when the record was updated')
   )

  --Table Metadata

  options (description='Touchworks Vitals detail')

as

SELECT distinct GENERATE_UUID() AS uuid
      , pm.savvy_pid
      , pm.savvy_did
      , pm.is_restricted
      , 'touchworks vitals' as src_type
      , LOWER(TRIM(wp.entryname)) AS where_vitals_performed

      , i_f.id AS vitals_item_id
      , f.id as vitals_result_id
      , cast(i_f.patientid as int64) as patient_id

      , DATE(i_f.performeddttm) as vitals_performed_date
      , TIME(i_f.performeddttm) as vitals_performed_time

      , DATE(i_f.createdttm) as vitals_item_created_date
      , TIME(i_f.createdttm) as vitals_item_created_time

      , LOWER(TRIM(i_f.entryname)) AS vitals_item_entryname
      , CAST(i_f.iserrorflag as string) as is_error_flag
      , LOWER(TRIM(i_f.decodedvalue)) AS decoded_lab_item_value

      , qo.vitals_result_description
      , qo.vitals_order_description

      , LOWER(TRIM(qom1.entryname)) AS vitals_order_modifier_1
      , LOWER(TRIM(qom2.entryname)) AS vitals_order_modifier_2
      , LOWER(TRIM(qom3.entryname)) AS vitals_order_modifier_3

      , f.numericfinding AS numeric_vitals_value
      , LOWER(TRIM(f.answerdet)) AS vitals_value
      , LOWER(TRIM(fu.entryname)) AS vitals_units

      , LOWER(TRIM(f.shortrefrange)) AS ref_range
      , hl.lower_ref_range
      , hl.upper_ref_range
      , hl.delim as delimiter

      , f.normalizedvalue AS normalized_vitals_value
      , LOWER(TRIM(nfu.entryname)) AS normalized_vitals_units

      , LOWER(TRIM(s.entryname)) AS source

      , LOWER(TRIM(f.abnormalflagtype)) AS abnormal_cd
      , vac.rslt_abnl_desc as abnormal_desc

      , LOWER(TRIM(fs.entryname)) as vitals_status
      , LOWER(TRIM(aho.completionstatus)) AS vitals_completion_status
      , CAST(f.isunverifiedflag as string) AS is_vitals_unverified_flag

      , qo.proc_cd
      , qo.proc_desc

      --Loinc code
      , qo.loinc_cd
      , qo.cmpnt_nm
      , qo.loinc_cd_desc
      , qo.prop_msr_cd
      , qo.rec_sts_cd
      , qo.repl_loinc_cd
      , qo.samp_typ_nm
      , qo.scl_typ_cd
      , qo.tm_nm
      , qo.tst_meth_nm
      , qo.ver_lst_chg

      , LOWER(TRIM(REGEXP_REPLACE(ed.freetextdiag, "000", ""))) AS dx1_diagnosis_free_text  --dx1 based on display order
      , LOWER(TRIM(ed.ICD9DiagnosisCode)) AS dx1_icd9_diagnosis_code
      , LOWER(TRIM(ed.ICD10DiagnosisCode)) AS dx1_icd10_diagnosis_code
      , LOWER(TRIM(ed.DiagnosisType)) AS dx1_diagnosis_type
      --LOWER(TRIM(ed.ICD9_Diagnosis)) AS icd9_diagnosis
      --LOWER(TRIM(ed.Diagnosis)) AS diagnosis
      , LOWER(TRIM(et.entryname)) AS encounter_type
      , LOWER(TRIM(bl.entryname)) AS default_billing_location
      , LOWER(TRIM(ba.entryname)) AS billing_area
      , LOWER(TRIM(ic.entryname)) AS insurance_class
      , LOWER(TRIM(d.entryname)) AS division
      , LOWER(TRIM(sic.entryname)) AS secondary_insurance
      , LOWER(TRIM(tic.entryname)) AS tertiary_insurance

      , LOWER(TRIM(pr.upinnumber)) AS provider_upin_number
      , LOWER(TRIM(pr.ispcpflag)) AS provider_is_pcp_flag
      , LOWER(TRIM(pr.deanumber)) AS provider_dea_number
      , SAFE_CAST(pr.npi as int64) AS provider_npi
      , LOWER(TRIM(pr.epa_enabled)) AS provider_epa_enabled
      , LOWER(TRIM(sp.entryname)) AS provider_specialty
      , LOWER(TRIM(ssp.entryname)) AS provider_secondary_specialty

      , pe.ID AS person_id
      , e.ID AS encounter_id
      , ed.ID AS encounter_diagnosis_id
      --, ar.ID AS activity_other_id
      , aho.ID AS activity_header_other_id
      , pr.ID AS provider_id
      --, opr.id as ordering_provider_id
      , po.ID AS person_other_id
      , pa.ID AS person_address_id
      , pp.ID AS person_phone_id

      , current_datetime() as create_datetime
      , current_datetime() as update_datetime
FROM
--Item Finding
           `ds-00-191017.smalv_tw_final.item_finding`              i_f
LEFT JOIN  cte_if_qo_tables_desc                                   qo    ON i_f.qode                = qo.qode
                                                                         AND i_f.qoclassificationde = qo.qoclassificationde
LEFT JOIN  `ds-00-191017.smalv_tw_final.qo_mod_de`                 qom1  ON qom1.id                = cast(i_f.qomod1de AS INT64)
LEFT JOIN  `ds-00-191017.smalv_tw_final.qo_mod_de`                 qom2  ON qom2.id                = cast(i_f.qomod2de AS INT64)
LEFT JOIN  `ds-00-191017.smalv_tw_final.qo_mod_de`                 qom3  ON qom3.id                = cast(i_f.qomod3de AS INT64)
 --Activity
LEFT JOIN  `ds-00-191017.smalv_tw_final.act_hdr_other`             aho   ON aho.id                 = cast(i_f.ActivityHeaderID AS INT64)
--LEFT JOIN  `ds-00-191017.smalv_tw_final.act_other`                ao    ON aho.ID                 = ao.ActivityHeaderID
                                                                         --and aho.currentID         = ao.id
--Finding
LEFT JOIN  `ds-00-191017.smalv_tw_final.finding`                   f     ON i_f.id                  = cast(f.itemid as int64)
                                                                         AND f.id                  = cast(i_f.currentid  as int64) --??
LEFT JOIN  `ds-00-191017.smalv_tw_final.finding_status_de`         fs    ON fs.id                  = cast(f.findingstatusde as int64)
LEFT JOIN  `ds-00-191017.smalv_tw_final.unit_code_de`              fu    ON fu.id                  = cast(f.unitsde as int64)
LEFT JOIN cte_hi_low_from_ref_range                                hl    ON f.shortrefrange        = hl.orig_f_shortrefrange
LEFT JOIN  `ds-00-191017.smalv_tw_final.unit_code_de`              nfu   ON nfu.id                 = cast(f.normalizedunitsde as int64)
LEFT JOIN  `ds-00-191017.smalv_tw_final.source_de`                 s     ON s.id                   = cast(f.sourcede as int64)
LEFT JOIN  `ds-00-191017.smalv_tw_final.where_performed_de`        wp    ON wp.id                  = cast(f.whereperformedde as int64)
LEFT JOIN   cte_vitals_abnormal_code                               vac   ON f.abnormalflagtype     = vac.orig_f_abnormalflagtype

--Encounter
LEFT JOIN  `ds-00-191017.smalv_tw_final.encounter`                 e     ON aho.EncounterID        = e.ID
LEFT JOIN `ds-00-191017.smalv_tw_final.encounter_type_de`          et    ON et.id                  = cast(e.encountertypede as int64)
LEFT JOIN `ds-00-191017.smalv_tw_final.billing_area_de`            ba    ON ba.id                  = cast(e.billingareade as int64)
LEFT JOIN `ds-00-191017.smalv_tw_final.billing_location_de`        bl    ON bl.id                  = cast(e.defaultbillinglocationde as int64)
LEFT JOIN `ds-00-191017.smalv_tw_final.insurance_class_de`         ic    ON ic.id                  = cast(e.insuranceclassde as int64)
LEFT JOIN `ds-00-191017.smalv_tw_final.division_de`                d     ON d.id                   = cast(e.divisionde as int64)
LEFT JOIN `ds-00-191017.smalv_tw_final.insurance_class_de`         sic   ON sic.id                 = cast(e.secondaryinsurancede as int64)
LEFT JOIN `ds-00-191017.smalv_tw_final.insurance_class_de`         tic   ON tic.id                 = cast(e.tertiaryinsurancede as int64)
--Encounter diagnosis
LEFT JOIN `ds-00-191017.smalv_tw_final.encounter_diagnosis`        ed    ON ed.EncounterID         = e.ID
                                                                         and ed.DisplayOrder       = 1
                                                                         and ed.SubmittedFLAG      is true
--Provider
LEFT JOIN `ds-00-191017.smalv_tw_final.provider`                   pr    ON pr.id                  = cast(f.whoforid as int64)
LEFT JOIN `ds-00-191017.smalv_tw_final.specialty_de`               sp    ON sp.id                  = cast(pr.specialtyde as int64)
LEFT JOIN `ds-00-191017.smalv_tw_final.specialty_de`               ssp   ON ssp.id                 = safe_cast(pr.specialty2de as int64)

--Person
INNER JOIN `ds-00-191017.smalv_tw_final.person`                    pe    ON pe.id                  = cast(i_f.patientid as int64)
INNER JOIN `ds-00-191017.smalv_tw_final.patient_member`            pm    ON pe.id                  = pm.ID
LEFT JOIN cte_tw_person_phone                                      pp    ON pe.id                  = pp.id
LEFT JOIN `ds-00-191017.smalv_tw_final.person_address`             pa    ON pe.id                  = pa.id
LEFT JOIN `ds-00-191017.smalv_tw_final.person_other`               po    ON pe.id                  = po.id
WHERE trim(lower(pm.isinactiveflag)) = 'n'
and pm.savvy_pid <>-1
;

/* ---------------------------------------------------------- End of code --------------------------------------------------------------------- */

  --if successful, we'll get here!
insert into `research-01-217611.df_uld_stage.logging`(
     success_flag, job,tbl, message_datetime)
   select
     1 as success_flag
     , 'create wkg_touchworks_vitals tables' as job
     , 'wkg_touchworks_vitals' as tbl
     ,current_datetime as message_datetime
   ;

   EXCEPTION WHEN ERROR THEN
     insert into `research-01-217611.df_uld_stage.logging`(
       success_flag, job,tbl, error_message, statement_text, formatted_stack_trace, message_datetime)
     select
       0 as success_flag
       , 'create wkg_touchworks_vitals tables' as job
       , 'wkg_touchworks_vitals' as tbl
       , @@error.message as error_message
       , @@error.statement_text as statement_text
       , @@error.formatted_stack_trace as formatted_stack_trace
       , current_datetime as message_datetime
     ;

END
;