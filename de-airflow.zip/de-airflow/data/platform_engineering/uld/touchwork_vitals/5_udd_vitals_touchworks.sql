/*
--Purpose: Create Touchworks vitals data in ULD standard format
--Total run time:  55 sec
--Input table/s:  df_uld_stage.wkg_touchworks_vitals_detail
--Output table/s: df_uld_stage.udd_vitals_touchworks
*/

BEGIN

insert into  `research-01-217611.df_uld_stage.udd_vitals_touchworks`

SELECT GENERATE_UUID() AS uuid
            , savvy_pid
            , savvy_did
            , is_restricted

            , src_type
            , where_vitals_performed

            , max(uuid) as source_uuid

            , vitals_performed_date as vitals_date
            , vitals_performed_time as vitals_time

            , vitals_result_description
            , vitals_order_description

            , numeric_vitals_value
            , vitals_value
            , vitals_units

            , ref_range
            , lower_ref_range
            , upper_ref_range
            , delimiter

            , abnormal_cd
            , abnormal_desc

            , vitals_status

            , prov_npi
            , -1 as prov_mpin

            , proc_cd
            , proc_desc

            , loinc_cd
            , cmpnt_nm
            , loinc_cd_desc
            , prop_msr_cd
            , rec_sts_cd
            , repl_loinc_cd
            , samp_typ_nm
            , scl_typ_cd
            , tm_nm
            , tst_meth_nm
            , ver_lst_chg

            , cast(null as string) as note

            , current_datetime() as create_datetime
            , current_datetime() as update_datetime

FROM `research-01-217611.df_uld_stage.wkg_touchworks_vitals`
where is_restricted=0
group by savvy_pid, savvy_did, is_restricted, src_type, where_vitals_performed, vitals_date, vitals_time, vitals_result_description, vitals_order_description, numeric_vitals_value, vitals_value, vitals_units
      , ref_range, lower_ref_range, upper_ref_range, delimiter, abnormal_cd, abnormal_desc, vitals_status, prov_npi, prov_mpin, proc_cd, proc_desc, loinc_cd, cmpnt_nm, loinc_cd_desc, prop_msr_cd, rec_sts_cd, repl_loinc_cd, samp_typ_nm
      , scl_typ_cd, tm_nm, tst_meth_nm, ver_lst_chg, note
   ;
/* ---------------------------------------------------------- End of code --------------------------------------------------------------------- */

  --if successful, we'll get here!
insert into `research-01-217611.df_uld_stage.logging`(
     success_flag, job,tbl, message_datetime)
   select
     1 as success_flag
     , 'create udd_vitals_touchworks tables' as job
     , 'udd_vitals_touchworks' as tbl
     ,current_datetime as message_datetime
   ;

   EXCEPTION WHEN ERROR THEN
     insert into `research-01-217611.df_uld_stage.logging`(
       success_flag, job,tbl, error_message, statement_text, formatted_stack_trace, message_datetime)
     select
       0 as success_flag
       , 'create udd_vitals_touchworks tables' as job
       , 'udd_vitals_touchworks' as tbl
       , @@error.message as error_message
       , @@error.statement_text as statement_text
       , @@error.formatted_stack_trace as formatted_stack_trace
       , current_datetime as message_datetime
     ;

END
;