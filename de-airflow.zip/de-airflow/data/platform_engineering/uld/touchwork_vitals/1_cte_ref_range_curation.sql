/* -----------------------------------------CONVERTING REF RANGE TO HIGH AND LOW NUMERIC VALUES------------------------------------------------- */
--direct copy of code used for touchworks labs


BEGIN

create or replace table `research-01-217611.df_uld_stage.cte_ref_range_curation` as
    (select distinct f.shortrefrange as orig_f_shortrefrange  --for easy join to finding table in the final step
          , trim(REGEXP_REPLACE(replace(lower(trim(f.shortrefrange)), lower(trim(fu.entryname)), ''), 'ref|range|x|adult:|adults:|am:','')) as curated_shortrefrange
          --Removing units i.e. from the reference range (in situation such as 10.0-14.0 mg/dl) where the unit present in reference range matches result units
          --Also removing different words and letters from the reference range (for reference values such as "Adult: 10-14", "10-14 x meq/l")
          --Removing this will help in conversion of reference range to high and low values.
          , lower(trim(fu.entryname)) as result_units
    from `ds-00-191017.smalv_tw_final.finding`              f
    left join  `ds-00-191017.smalv_tw_final.unit_code_de`   fu    ON fu.id = cast(f.unitsde as int64)
    group by 1,2,3
    )
    ;
/* ---------------------------------------------------------- End of code --------------------------------------------------------------------- */

  --if successful, we'll get here!
insert into `research-01-217611.df_uld_stage.logging`(
     success_flag, job,tbl, message_datetime)
   select
     1 as success_flag
     , 'create cte_ref_range_curation tables' as job
     , 'cte_ref_range_curation' as tbl
     ,current_datetime as message_datetime
   ;

   EXCEPTION WHEN ERROR THEN
     insert into `research-01-217611.df_uld_stage.logging`(
       success_flag, job,tbl, error_message, statement_text, formatted_stack_trace, message_datetime)
     select
       0 as success_flag
       , 'create cte_ref_range_curation tables' as job
       , 'cte_ref_range_curation' as tbl
       , @@error.message as error_message
       , @@error.statement_text as statement_text
       , @@error.formatted_stack_trace as formatted_stack_trace
       , current_datetime as message_datetime
     ;

END
;