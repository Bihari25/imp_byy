
BEGIN

create or replace table `research-01-217611.df_uld_stage.cte_hi_low_from_ref_range` as

      (select distinct orig_f_shortrefrange, curated_shortrefrange, delim
        ,CASE WHEN DELIM='alpha' THEN NULL
             WHEN DELIM='dash'  THEN SAFE_CAST(SUBSTR(curated_shortrefrange,1,INSTR(curated_shortrefrange,'-',2) -1) AS FLOAT64) --trim reference range if not already trimmed
             WHEN DELIM='to'    THEN SAFE_CAST(SUBSTR(curated_shortrefrange,1,INSTR(curated_shortrefrange,'to',2) -1) AS FLOAT64) --trim reference range if not already trimmed
             WHEN DELIM='gt'    THEN SAFE_CAST(SUBSTR(REGEXP_REPLACE(curated_shortrefrange,' |than',''),2) AS FLOAT64)
             WHEN DELIM='ge'    THEN SAFE_CAST(SUBSTR(REGEXP_REPLACE(curated_shortrefrange,' |or',''),3) AS FLOAT64)
             WHEN DELIM='lt'    THEN null
             WHEN DELIM='le'    THEN null

        END  AS lower_ref_range

        ,CASE WHEN DELIM='alpha' THEN NULL
             WHEN DELIM='dash'  THEN SAFE_CAST(SUBSTR(curated_shortrefrange,INSTR(curated_shortrefrange,'-',2)+1) AS FLOAT64) --default 3rd argument for substring is length of 1st argument
             WHEN DELIM='to'    THEN SAFE_CAST(SUBSTR(curated_shortrefrange,INSTR(curated_shortrefrange,'to',2)+2) AS FLOAT64)
             WHEN DELIM='gt'    THEN null
             WHEN DELIM='ge'    THEN null
             WHEN DELIM='lt'    THEN SAFE_CAST(REGEXP_REPLACE(curated_shortrefrange,' |less|than|<','') AS FLOAT64)
             WHEN DELIM='le'    THEN SAFE_CAST(REGEXP_REPLACE(curated_shortrefrange,' |or|less|<|=','') AS FLOAT64)
        END as upper_ref_range

      from cte_assign_delimiter
      )
      ;
/* ---------------------------------------------------------- End of code --------------------------------------------------------------------- */

  --if successful, we'll get here!
 insert into `research-01-217611.df_uld_stage.logging`(
      success_flag, job,tbl, message_datetime)
    select
      1 as success_flag
      , 'create cte_hi_low_from_ref_range tables' as job
      , 'cte_hi_low_from_ref_range' as tbl
      ,current_datetime as message_datetime
    ;

    EXCEPTION WHEN ERROR THEN
      insert into `research-01-217611.df_uld_stage.logging`(
        success_flag, job,tbl, error_message, statement_text, formatted_stack_trace, message_datetime)
      select
        0 as success_flag
        , 'create cte_hi_low_from_ref_range tables' as job
        , 'cte_hi_low_from_ref_range' as tbl
        , @@error.message as error_message
        , @@error.statement_text as statement_text
        , @@error.formatted_stack_trace as formatted_stack_trace
        , current_datetime as message_datetime
      ;

END
;