/* Project: Universal Lab Database (ULD)

   Business Partner: Matt Holst

   Input: `research-01-217611`.`df_uld_stage`.`ihr_labs`,  `research-01-217611`.`df_ucd_stage`.`udw_member_summary`,  `research-01-217611`.`df_ucd_stage`.`dim_date`

   Created By: Dave

   Created Date: 11/4/2020

   Modified By: Dave Corban

   Modified Date: 

   Initial creation-filter out Medicaid and add business_line to lab detail

  
   Granularity:  Lab Result detail                                    */

BEGIN

insert into `research-01-217611.df_uld_stage.udd_lab_ihr`
(
uuid, savvy_pid, savvy_did,is_restricted, src_type, where_lab_performed, src_uuid, lab_date, lab_time, lab_result_description, lab_order_description, numeric_result_value, result_value, result_units, ref_range, lower_ref_range ,upper_ref_range, delimiter
,abnormal_cd, abnormal_desc, result_status, prov_npi, prov_mpin, proc_cd, proc_desc, loinc_cd, cmpnt_nm, loinc_cd_desc, prop_msr_cd, rec_sts_cd, repl_loinc_cd, samp_typ_nm, scl_typ_cd, tm_nm, tst_meth_nm,ver_lst_chg, note
,create_datetime, update_datetime
)

WITH LABS

AS

(
SELECT

savvy_pid
,savvy_did
,is_restricted
,data_source_name AS where_lab_perfomred 
,MAX(uuid) AS src_uuid  
,CAST(observation_date_time as date) AS lab_date
,CAST(observation_date_time as time) AS lab_time
,observation_loinc_description AS lab_result_description
,universal_service_identifier_text AS lab_order_decription
,safe_cast(observation_value AS float64) AS numeric_result_value
,observation_value AS result_value
,observation_units AS result_units
,reference_range AS ref_range
,CASE WHEN delimiter='alpha' THEN NULL
     WHEN delimiter='dash'  THEN SAFE_CAST(SUBSTR(reference_range,1,INSTR(reference_range,'-') -1) AS FLOAT64)
     WHEN delimiter='gt'    THEN SAFE_CAST(SUBSTR(REGEXP_REPLACE(reference_range,' |or',''),2,LENGTH(REGEXP_REPLACE(reference_range,' |or','')) -1) AS FLOAT64)
     WHEN delimiter='ge'    THEN SAFE_CAST(SUBSTR(REGEXP_REPLACE(reference_range,' |or',''),3,LENGTH(REGEXP_REPLACE(reference_range,' |or','')) -2) AS FLOAT64)
     WHEN delimiter='lt'    THEN null
     WHEN delimiter='le'    THEN null
     
END  AS lower_ref_range

,CASE WHEN delimiter='alpha' THEN NULL
     WHEN delimiter='dash'  THEN SAFE_CAST(SUBSTR(reference_range,INSTR(reference_range,'-')+1,LENGTH(reference_range)-INSTR(reference_range,'-')) AS FLOAT64)
     WHEN delimiter='gt'    THEN null
     WHEN delimiter='ge'    THEN null
     WHEN delimiter='lt'    THEN SAFE_CAST(SUBSTR(REGEXP_REPLACE(reference_range,' |or',''),2,LENGTH(REGEXP_REPLACE(reference_range,' |or','')) -1) AS FLOAT64)
     WHEN delimiter='le'    THEN SAFE_CAST(SUBSTR(REGEXP_REPLACE(reference_range,' |or',''),3,LENGTH(REGEXP_REPLACE(reference_range,' |or','')) -2) AS FLOAT64)
     
END  AS upper_ref_range
,delimiter
,interpretation_code AS abnormal_cd
,'tbd' AS abnormal_desc
,result_status
,SAFE_CAST(ordering_provider_npi AS INT64) AS prov_npi
,-1 AS prov_mpin
,billing_procedure_code AS proc_cd
,billing_procedure_text AS proc_desc
,observation_loinc_number AS loinc_cd
,note


FROM  `research-01-217611`.`df_uld_stage`.`wkg_ihr_lab`

Group by
savvy_pid,savvy_did,is_restricted
,where_lab_perfomred ,lab_date,lab_time,lab_result_description,lab_order_decription,numeric_result_value,result_value,result_units,ref_range,lower_ref_range,upper_ref_range,delimiter
,abnormal_cd,abnormal_desc,result_status,prov_npi,prov_mpin,proc_cd,proc_desc,loinc_cd,note
)



(
SELECT
GENERATE_UUID() as uuid
,LABS.savvy_pid
,LABS.savvy_did
,LABS.is_restricted
,lower(CONCAT('ihr - ',cast(MEMBER.commercial_flag as string), cast(MEMBER.medicare_flag as string), cast(MEMBER.medicaid_flag as string), cast(MEMBER.dual_flag as string))) as src_type
,where_lab_perfomred 
,src_uuid  
,lab_date
,lab_time
,lab_result_description
,lab_order_decription
,numeric_result_value
,result_value
,result_units
,ref_range
,lower_ref_range
,upper_ref_range
,delimiter
,abnormal_cd
,abnormal_desc
,result_status
,prov_npi
,prov_mpin
,proc_cd
,proc_desc
,LABS.loinc_cd

,LOINC.cmpnt_nm 
,LOINC.loinc_cd_desc
,LOINC.prop_msr_cd  
,LOINC.rec_sts_cd   
,LOINC.repl_loinc_cd
,LOINC.samp_typ_nm  
,LOINC.scl_typ_cd   
,LOINC.tm_nm        
,LOINC.tst_meth_nm  
,LOINC.ver_lst_chg 

,note

,current_datetime() as create_datetime
,current_datetime() as update_datetime


FROM LABS

INNER JOIN `research-01-217611.df_ucd_stage.dim_date` dd
    on LABS.lab_date = dd.full_dt
    
LEFT JOIN `research-01-217611.df_ucd_stage.udw_member_month` MEMBER
    on LABS.savvy_pid=MEMBER.savvy_pid and dd.year_mo= MEMBER.year_mo

LEFT JOIN `research-01-217611`.`df_uld_stage`.`dim_loinc_code` LOINC
    ON LABS.loinc_cd = LOINC.loinc_cd
    
WHERE (substr(lower(CONCAT('ihr - ',cast(MEMBER.commercial_flag as string), cast(MEMBER.medicare_flag as string), cast(MEMBER.medicaid_flag as string), cast(MEMBER.dual_flag as string))),9,2) ='00' or lower(CONCAT('ihr - ',cast(MEMBER.commercial_flag as string), cast(MEMBER.medicare_flag as string), cast(MEMBER.medicaid_flag as string), cast(MEMBER.dual_flag as string))) is null)  -- Exclude Medicaid, but allow unmapped savvy_pids 
   AND LABS.savvy_pid > 0 AND LABS.is_restricted = 0

)

;

  /* ===================================================================================================== */
  /*                    Logs successful creation of the staging tables                                     */
  /* ===================================================================================================== */

      insert into `research-01-217611.df_uld_stage.logging`(
        success_flag, job, message_datetime)
      select
        1 as success_flag
        , 'load udd_lab_ihr staging tables' as job
        , current_datetime as message_datetime
      ;

  /* ===================================================================================================== */
  /*                    Exception occure logging creation in staging tables                               */
  /* ===================================================================================================== */

EXCEPTION WHEN ERROR THEN
      insert into `research-01-217611.df_uld_stage.logging`(
        success_flag, job, error_message, statement_text, formatted_stack_trace, message_datetime)
      select
        0 as success_flag
        , 'load udd_lab_ihr staging tables' as job
        , @@error.message as error_message
        , @@error.statement_text as statement_text
        , @@error.formatted_stack_trace as formatted_stack_trace
        , current_datetime as message_datetime
      ;


END

/*  -----------------------------------end of the Script-------------------------------------------  */



