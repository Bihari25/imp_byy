
BEGIN

/*------------------------------------Ihr-lab- final table -----------------------------------------*/


Create or replace table `research-01-217611`.`df_uld_stage`.`wkg_ihr_lab`


(

uuid                                   string     OPTIONS(description= "unique record identifier")

,savvy_pid                              int64     OPTIONS(description= "unique(persistent) patient identifier")

,savvy_did                              int64     OPTIONS(description= "unique(periodically updated) patient identifier")

,is_restricted                          int64       OPTIONS(description="1 if member is restricted (i.e., has ever been a UHG employee) and needs to be reported separately; 0 otherwise")

,message_control_id                     string     OPTIONS(description= "lab message control id(key)")

,message_date_time                      datetime     OPTIONS(description= "lab message date time(key)")

,set_id                                 int64     OPTIONS(description= "lab request(ors) set id (key)")

,set_id_obx                             int64     OPTIONS(description= "lab request(obx) set id (key)")

--,data_source                            string     OPTIONS(description= "original data source")

,data_source_id                         string     OPTIONS(description= "id for original data source")

,data_source_name                       string     OPTIONS(description= "name of original data source")

--,load_date_time_utc                     datetime     OPTIONS(description= "datetime source data loaded")

--,gender                                 string     OPTIONS(description= "patient gender")

--,race                                   string     OPTIONS(description= "patient race")

--,state_cd                               string     OPTIONS(description= "patient state code")

--,zip_cd                                 string     OPTIONS(description= "patient zip code")

--,parent_segment                         string     OPTIONS(description= "lab segment number")

,filler_order_number                    string     OPTIONS(description= "processing lab id number")

,observation_date_time                  datetime  OPTIONS(description= "Observation Date Time")

--,order_cpt4_code                        string     OPTIONS(description= "ordering cpt code")

--,lab_order_code                         string     OPTIONS(description= "lab order code")

,universal_service_identifier_text      string     OPTIONS(description= "description of lab order")

--,specimen_received_date_time            string     OPTIONS(description= "datetime specimen received by lab")

,ordering_provider_npi                  string     OPTIONS(description= "ordering provider npi")

,results_rpt_status_chng_date_time      timestamp     OPTIONS(description= "results status datetime")

,observation_loinc_number               string     OPTIONS(description= "LOINC number")

,observation_loinc_description          string     OPTIONS(description= "LOINC description")

--,observation_identifier                 string     OPTIONS(description= "observation id number")

--,observation_identifier_description     string     OPTIONS(description= "observation decription")

,observation_value                      string     OPTIONS(description= "result value")

,observation_units                      string     OPTIONS(description= "units of result")

,reference_range                        string     OPTIONS(description= "lab reference range")

,interpretation_code                    string     OPTIONS(description= "lab result interpretation code")

,result_status                          string     OPTIONS(description= "status of lab result (f, c)")

--,producers_id                           string     OPTIONS(description= "producers id number")

,lab_transaction_date                   date     OPTIONS(description= "lab billing/service date")

,billing_procedure_code                 string     OPTIONS(description= "billing procedure code")

,billing_procedure_text                 string     OPTIONS(description= "billing procedure description")

--,transaction_code                       string     OPTIONS(description= "transaction code")

--,transaction_description                string     OPTIONS(description= "transaction description")

,diagnosis_code                         string     OPTIONS(description= "diagnosis code")

,diagnosis_description                  string     OPTIONS(description= "diagnosis description")

--,procedure_code              string     OPTIONS(description= "procedure code")

--,procedure_code_text                    string     OPTIONS(description= "procedure description")

--,procedure_code_alternate_identifier    string     OPTIONS(description= "alternate procedure code")

--,procedure_code_alternate_text          string     OPTIONS(description= "alternate procedure description")

--,ordering_provider_labs_id              string     OPTIONS(description= "ordering provider lab id")

,note                                   string     OPTIONS(description= "note (includes all rows)")

,delimiter                                 string OPTIONS(description="derived to aid in mapping upper and lower bounds")

,create_datetime                        datetime     OPTIONS(description= "datetime record created")

,update_datetime                        datetime     OPTIONS(description= "datetime record updated")



	)



OPTIONS(description="raw ihr lab data in ULD standard format")

AS

SELECT GENERATE_UUID() AS uuid
 ,mh.savvy_pid,mh.savvy_did,mh.is_restricted, mh.message_control_id, mh.message_date_time,orq.set_id,ors.set_id_obx   --Keys
-- ,mh.data_source
  ,mh.data_source_id
  ,mh.data_source_name
--, current_datetime()  as load_date_time_utc
--,p.gender
--,p.race
--,p.state_cd
--,p.zip_cd
--,orq.parent_segment

,orq.filler_order_number
--,orq.order_cpt4_code
--,orq.lab_order_code
,orq.observation_date_time_obr AS observation_date_time
,orq.universal_service_identifier_text
--,orq.specimen_received_date_time   -- is this important?
,orq.ordering_provider_npi
,orq.results_rpt_status_chng_date_time   -- Do we care about this date?
--,orq.result_status

,ors.observation_loinc_number
,ors.observation_loinc_description

--,ors.observation_identifier
--,ors.observation_identifier_description
,ors.observation_value
,ors.observation_units
,ors.reference_range
,ors.interpretation_code
,ors.result_status
--,ors.observation_date_time_obx
--,ors.producers_id

,ft.lab_transaction_date
,ft.billing_procedure_code  --maybe duplicates obr?
,ft.billing_procedure_text AS billing_procedure_text
--,ft.transaction_code --maybe duplicates obr?
--,ft.transaction_description
,ft.diagnosis_code as diagnosis_code
,ft.diagnosis_description as diagnosis_description
--,ft.procedure_code_identifier
--,ft.procedure_code_text
--,ft.procedure_code_alternate_identifier
--,ft.procedure_code_alternate_text
--,' ' as ordering_provider_labs_id
,ln.note
,delimiter
,current_datetime() as create_datetime
,current_datetime() as update_datetime



FROM  `research-01-217611.df_uld_stage.wkg_ihr_messageheader` mh


INNER JOIN  `research-01-217611.df_uld_stage.wkg_ihr_observationrequest` orq
    ON mh.savvy_pid=orq.savvy_pid
    AND mh.message_control_id=orq.message_control_id
    AND mh.message_date_time=orq.message_date_time

INNER JOIN  `research-01-217611.df_uld_stage.wkg_ihr_observationresult` ors
     ON orq.savvy_pid=ors.savvy_pid
    AND orq.message_control_id=ors.message_control_id
    AND orq.message_date_time=ors.message_date_time
    AND orq.parent_segment=ors.parent_segment

LEFT JOIN  `research-01-217611.df_uld_stage.wkg_ihr_financialtransaction` ft
    ON orq.savvy_pid=ft.savvy_pid
    AND orq.message_control_id=ft.message_control_id
    AND orq.message_date_time=ft.message_date_time
    AND orq.set_id=ft.set_id

LEFT JOIN  `research-01-217611.df_uld_stage.wkg_ihr_labnotes` ln
     ON orq.savvy_pid=ln.savvy_pid
    AND orq.message_control_id=ln.message_control_id
    AND orq.message_date_time=ln.message_date_time
    AND orq.parent_segment=ln.parent_segment


 --WHERE trim(mh.message_control_id) in('M2007907011700028037','236537')
;

  /* ===================================================================================================== */
  /*                    Logs successful creation of the staging tables                                     */
  /* ===================================================================================================== */

      insert into `research-01-217611.df_uld_stage.logging`(
        success_flag, job, message_datetime)
      select
        1 as success_flag
        , 'load wkg_ihr_lab staging tables' as job
        , current_datetime as message_datetime
      ;

  /* ===================================================================================================== */
  /*                    Exception occure logging creation in staging tables                               */
  /* ===================================================================================================== */

EXCEPTION WHEN ERROR THEN
      insert into `research-01-217611.df_uld_stage.logging`(
        success_flag, job, error_message, statement_text, formatted_stack_trace, message_datetime)
      select
        0 as success_flag
        , 'load wkg_ihr_lab staging tables' as job
        , @@error.message as error_message
        , @@error.statement_text as statement_text
        , @@error.formatted_stack_trace as formatted_stack_trace
        , current_datetime as message_datetime
      ;


END

/*  -----------------------------------end of the Script-------------------------------------------  */

