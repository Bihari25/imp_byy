CREATE OR REPLACE TABLE `research-01-217611.df_uld_stage.wkg_ihr_messageheader`
 AS
(SELECT distinct
  savvy_pid,savvy_did,is_restricted, message_control_id, message_date_time  --Key
-- ,sending_application_sending_application AS data_source
  ,LOWER(sending_facility_namespace_id) AS data_source_id
  ,LOWER(sending_facility_universal_id) AS data_source_name
 -- ,load_date_time_utc

  FROM  `ds-00-191017`.`ihr_final`.`labs_msh`

  WHERE savvy_pid > -1

 -- trim(message_control_id) in('M2007907011700028037','236537')--WHERE message_control_id = 'M2007907011700028037' -- Test message

 )
 ;