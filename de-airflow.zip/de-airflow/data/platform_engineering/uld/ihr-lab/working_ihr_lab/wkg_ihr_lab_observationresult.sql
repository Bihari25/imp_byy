

BEGIN

/*------------------------------------observation result table -----------------------------------------*/

CREATE OR REPLACE TABLE `research-01-217611.df_uld_stage.wkg_ihr_observationresult`

AS

 (SELECT distinct
savvy_pid, message_control_id, message_date_time, set_id AS set_id_obx, parent_segment
--,value_type
,LOWER(observation_identifier_identifier) AS observation_loinc_number
,LOWER(observation_identifier_text) AS observation_loinc_description
--,observation_identifier_name_of_coding_system
--,observation_identifier_alternate_identifier AS observation_identifier
--,observation_identifier_alternate_text AS observation_identifier_description
--,observation_identifier_name_of_alternate_coding_system
,LOWER(observation_value) AS observation_value
,LOWER(units_identifier) AS observation_units
,LOWER(references_range) AS reference_range
,LOWER(interpretation_codes_interpretation_codes) AS interpretation_code
--,nature_of_abnormal_test
,LOWER(observation_result_status) AS result_status
--,effective_date_of_reference_range
--,user_defined_access_checks
,date_time_of_the_observation AS observation_date_time_obx
--,producers_id_producers_id  AS producers_id
--,parent_segment AS parent_segment
--,load_date_time_utc

 ,CASE WHEN LEFT(REGEXP_REPLACE(references_range,' ',''),1)='<' and SAFE_CAST(SUBSTR(REGEXP_REPLACE(references_range,' ',''),2,1) AS INT64) IS NOT NULL THEN 'lt' --first byte is <. second byte is numeric
      WHEN LEFT(REGEXP_REPLACE(references_range,' ',''),1)='>' and SAFE_CAST(SUBSTR(REGEXP_REPLACE(references_range,' ',''),2,1) AS INT64) IS NOT NULL THEN 'gt' --first byte is >, second byte is numeric
      WHEN INSTR(trim(references_range),'-')>1 THEN 'dash'                               --'-' after the first position which indicates a numeric range
      WHEN REGEXP_REPLACE(references_range,'[0-9]','')= references_range THEN 'alpha'      --no numbers
      WHEN LEFT(REGEXP_REPLACE(references_range,' |o|r',''),2) ='<=' THEN 'le'            -- Remove spaces and 'or' check for <=
      WHEN LEFT(REGEXP_REPLACE(references_range,' |o|r',''),2) ='>=' THEN 'ge'             -- Remove spaces and 'or' check for >=
        END

      AS delimiter

 FROM `ds-00-191017`.`ihr_final`.`labs_obx`

WHERE savvy_pid > -1

---trim(message_control_id) in('M2007907011700028037','236537')
--WHERE message_control_id = 'M2007907011700028037' --test message   -- more set_id's than in the request file....

 )
 ;

/* ===================================================================================================== */
   /*                    Logs successful creation of the staging tables                                     */
   /* ===================================================================================================== */

       insert into `research-01-217611.df_uld_stage.logging`(
         success_flag, job, message_datetime)
       select
         1 as success_flag
         , 'load wkg_ihr_lab_observationresult staging tables' as job
         , current_datetime as message_datetime
       ;

   /* ===================================================================================================== */
   /*                    Exception occure logging creation in staging tables                               */
   /* ===================================================================================================== */

 EXCEPTION WHEN ERROR THEN
       insert into `research-01-217611.df_uld_stage.logging`(
         success_flag, job, error_message, statement_text, formatted_stack_trace, message_datetime)
       select
         0 as success_flag
         , 'load wkg_ihr_lab_observationresult staging tables' as job
         , @@error.message as error_message
         , @@error.statement_text as statement_text
         , @@error.formatted_stack_trace as formatted_stack_trace
         , current_datetime as message_datetime
       ;


 END

 /*  -----------------------------------end of the Script-------------------------------------------  */

