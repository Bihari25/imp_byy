
BEGIN

/*------------------------------------financial transaction table -----------------------------------------*/


CREATE OR REPLACE TABLE `research-01-217611.df_uld_stage.wkg_ihr_financialtransaction`

AS

 (SELECT distinct
savvy_pid, message_control_id, message_date_time, set_id
,transaction_date_transaction_date AS lab_transaction_date
,LOWER(transaction_code_identifier) AS billing_procedure_code  --maybe duplicates obr?
,LOWER(transaction_code_text) As billing_procedure_text
--,transaction_code_name_of_coding_system
--,transaction_code_alternate_identifier as transaction_code --maybe duplicates obr?
--,transaction_code_alternate_text  AS transaction_description
--,transaction_code_name_of_alternate_coding_system
,LOWER(diagnosis_code_ft1_identifier) AS diagnosis_code
,LOWER(diagnosis_code_ft1_text)    AS diagnosis_description
--,diagnosis_code_ft1_name_of_coding_system
--,diagnosis_code_ft1_alternate_identifier
--,procedure_code_identifier
--,procedure_code_text
--,procedure_code_name_of_coding_system
--,procedure_code_alternate_identifier
--,procedure_code_alternate_text

--,load_date_time_utc

 FROM `ds-00-191017`.`ihr_final`.`labs_ft1`
WHERE savvy_pid > -1

--trim(message_control_id) in('M2007907011700028037','236537')
--WHERE message_control_id = 'M2007907011700028037' --test message
)
;


 /* ===================================================================================================== */
  /*                    Logs successful creation of the staging tables                                     */
  /* ===================================================================================================== */

      insert into `research-01-217611.df_uld_stage.logging`(
        success_flag, job, message_datetime)
      select
        1 as success_flag
        , 'load wkg_ihr_lab_financialtransaction staging tables' as job
        , current_datetime as message_datetime
      ;

  /* ===================================================================================================== */
  /*                    Exception occure logging creation in staging tables                               */
  /* ===================================================================================================== */

EXCEPTION WHEN ERROR THEN
      insert into `research-01-217611.df_uld_stage.logging`(
        success_flag, job, error_message, statement_text, formatted_stack_trace, message_datetime)
      select
        0 as success_flag
        , 'load wkg_ihr_lab_financialtransaction staging tables' as job
        , @@error.message as error_message
        , @@error.statement_text as statement_text
        , @@error.formatted_stack_trace as formatted_stack_trace
        , current_datetime as message_datetime
      ;


END

/*  -----------------------------------end of the Script-------------------------------------------  */
