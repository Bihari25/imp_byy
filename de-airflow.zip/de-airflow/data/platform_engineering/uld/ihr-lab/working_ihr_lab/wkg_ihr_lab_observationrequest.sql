


BEGIN

/*------------------------------------observation request table -----------------------------------------*/


CREATE OR REPLACE TABLE `research-01-217611.df_uld_stage.wkg_ihr_observationrequest`

AS
 (SELECT distinct

  savvy_pid, message_control_id, message_date_time, set_id, concat('OBR-',cast(set_id as string)) AS parent_segment

--,placer_order_number_entity_identifier --(same as filler_order_number_entity_identifier)
--,placer_order_number_namespace_id
--,filler_order_number_filler_order_number
--,filler_order_number_entity_identifier
--,filler_order_number_namespace_id
,CASE WHEN TRIM(filler_order_number_filler_order_number) is null THEN LOWER(filler_order_number_entity_identifier) ELSE LOWER(filler_order_number_filler_order_number) END AS filler_order_number
--,CASE WHEN TRIM(universal_service_identifier_name_of_coding_system)='c4' THEN universal_service_identifier_identifier ELSE NULL END AS order_cpt4_code
--,CASE WHEN TRIM(universal_service_identifier_name_of_coding_system)='l' THEN universal_service_identifier_identifier ELSE universal_service_identifier_alternate_identifier END AS lab_order_code
--,universal_service_identifier_identifier (CPT4 or Lab OrderCode)
,CASE WHEN trim(universal_service_identifier_text) is null THEN trim(universal_service_identifier_alternate_text) ELSE trim(universal_service_identifier_text) END AS universal_service_identifier_text
--,universal_service_identifier_name_of_coding_system
--,universal_service_identifier_alternate_identifier
--,universal_service_identifier_alternate_text
--,universal_service_identifier_name_of_alternate_coding_system
--,PARSE_DATE('%Y%m%d',substr(observation_date_time,1,8)) as observation_date
 ,observation_date_time AS observation_date_time_obr
--,specimen_received_date_time   -- is this important?
,ordering_provider_person_identifier as ordering_provider_npi
--,ordering_provider_deprecated_source_table
--,ordering_provider_assigning_authority_assigning_authority
,results_rpt_status_chng_date_time   -- Do we care about this date?
,LOWER(result_status) AS result_status
--,load_date_time_utc

 FROM `ds-00-191017`.`ihr_final`.`labs_obr`

 WHERE savvy_pid > -1

 --trim(message_control_id) in('M2007907011700028037','236537')-- message_control_id = 'M2007907011700028037' --test message
 )
;


/* ===================================================================================================== */
   /*                    Logs successful creation of the staging tables                                     */
   /* ===================================================================================================== */

       insert into `research-01-217611.df_uld_stage.logging`(
         success_flag, job, message_datetime)
       select
         1 as success_flag
         , 'load wkg_ihr_lab_observationrequest staging tables' as job
         , current_datetime as message_datetime
       ;

   /* ===================================================================================================== */
   /*                    Exception occure logging creation in staging tables                               */
   /* ===================================================================================================== */

 EXCEPTION WHEN ERROR THEN
       insert into `research-01-217611.df_uld_stage.logging`(
         success_flag, job, error_message, statement_text, formatted_stack_trace, message_datetime)
       select
         0 as success_flag
         , 'load wkg_ihr_lab_observationrequest staging tables' as job
         , @@error.message as error_message
         , @@error.statement_text as statement_text
         , @@error.formatted_stack_trace as formatted_stack_trace
         , current_datetime as message_datetime
       ;


 END

 /*  -----------------------------------end of the Script-------------------------------------------  */


