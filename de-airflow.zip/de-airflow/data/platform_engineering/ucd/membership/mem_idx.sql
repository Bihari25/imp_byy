/* Project: Universal Claims Database (UCD )

   Business Partner: Matt Holst

Inputs: `ds-00-191017.udw_final.dim_cust`
	`ds-00-191017.udw_final.dim_cust_grp`
	`ds-00-191017.udw_final.dim_cust_grp_pln`
	`ds-00-191017.udw_final.dim_cust_contr`
	`ds-00-191017.udw_final.member`
	`ds-00-191017.udw_final.member_coverage`
	`ds-00-191017.udw_final.dim_govt_pgm_typ`
	`ds-00-191017.udw_final.member_address`
	`ds-00-191017.udw_final.dim_src_sys`
  --      `ds-00-191017.df_mdm_crosswalk_r2.udw_mdm_crosswalk`  Removed 11/2/2020  savvy_pid available from udw_final source files


Created By: Dave

Created Date: 10/27
   Modified By: Dave
   Modified Date: 11/2/20
   Removed join to MDM tables.  DI has already assigned savvy_pid, savvy_did in udw_final member tables
   Granularity:  member, eligibility date range; source system, detail elements(may have overlapping or duplicate eligibility periods with multiple values


IMPORTANT NOTE:  THIS STEP WILL BE REPLACED BY member_eligibility_index2.0 once it's available
IMPORTANT NOTE:  THIS STEP WILL BE REPLACED BY member_eligibility_index2.0 once it's available
IMPORTANT NOTE:  THIS STEP WILL BE REPLACED BY member_eligibility_index2.0 once it's available
IMPORTANT NOTE:  THIS STEP WILL BE REPLACED BY member_eligibility_index2.0 once it's available
IMPORTANT NOTE:  THIS STEP WILL BE REPLACED BY member_eligibility_index2.0 once it's available
IMPORTANT NOTE:  THIS STEP WILL BE REPLACED BY member_eligibility_index2.0 once it's available
IMPORTANT NOTE:  THIS STEP WILL BE REPLACED BY member_eligibility_index2.0 once it's available
IMPORTANT NOTE:  THIS STEP WILL BE REPLACED BY member_eligibility_index2.0 once it's available
IMPORTANT NOTE:  THIS STEP WILL BE REPLACED BY member_eligibility_index2.0 once it's available
IMPORTANT NOTE:  THIS STEP WILL BE REPLACED BY member_eligibility_index2.0 once it's available
IMPORTANT NOTE:  THIS STEP WILL BE REPLACED BY member_eligibility_index2.0 once it's available
IMPORTANT NOTE:  THIS STEP WILL BE REPLACED BY member_eligibility_index2.0 once it's available
IMPORTANT NOTE:  THIS STEP WILL BE REPLACED BY member_eligibility_index2.0 once it's available



*/
BEGIN

--table times out with ctes, let's try to create a bunch of temporary tables instead and see if that helps

--WITH

/*
  --not used currently
  create or replace temp table tmp_udw_dim_cust AS
    (
    SELECT * EXCEPT (rn) FROM
    (SELECT row_number() OVER (PARTITION BY cust_pty_id ORDER BY row_eff_dt DESC, ds_loaddatetime DESC, row_expir_dt) as rn,
          * FROM `ds-00-191017.udw_final.dim_cust`
          WHERE
    --'2020-10-20' between BUS_EFF_DT and BUS_EXPIR_DT
    --and
    ROW_EXPIR_DT ='9999-12-31' and SRC_ROW_STS_CD ='a'
    ) main
    where rn = 1
    )
    ;

  create or replace temp table tmp_udw_dim_cust_grp AS
    (
    SELECT * EXCEPT (rn) FROM
    (SELECT row_number() OVER (PARTITION BY udw_cust_grp_id ORDER BY row_eff_dt DESC,ds_loaddatetime DESC, row_expir_dt) as rn,
          * FROM `ds-00-191017.udw_final.dim_cust_grp` where
    --'2020-10-20' between cust_grp_eff_dt and cust_grp_expir_dt
    --and
    ROW_EXPIR_DT ='9999-12-31' and SRC_ROW_STS_CD ='a'
    ) main
    where rn = 1
    --order by cust_pty_id
    --limit 1000;
    )
    ;

  create or replace temp table tmp_udw_dim_cust_grp_pln AS
    (
    SELECT * EXCEPT (rn) FROM
    (SELECT row_number() OVER (PARTITION BY udw_cust_grp_pln_id ORDER BY row_eff_dt DESC,ds_loaddatetime DESC, row_expir_dt) as rn,
          * FROM `ds-00-191017.udw_final.dim_cust_grp_pln` where
    --'2020-10-20' between cust_grp_pln_eff_dt and cust_grp_pln_trm_dt
    --and
    ROW_EXPIR_DT ='9999-12-31' and SRC_ROW_STS_CD ='a'
    ) main
    where rn = 1
    )
    ;
*/


create or replace table `research-01-217611.df_ucd_stage.wkg_udw_dim_cust_contr` AS
  (
  SELECT * EXCEPT (rn) FROM
  (SELECT row_number() OVER (PARTITION BY udw_cust_contr_id ORDER BY row_eff_dt DESC,ds_loaddatetime DESC, row_expir_dt) as rn,
        * FROM `ds-00-191017.udw_final.dim_cust_contr` where
  --'2020-10-20' between contr_eff_dt and contr_expir_dt
  --and
  ROW_EXPIR_DT ='9999-12-31' and SRC_ROW_STS_CD ='a'
  ) main
  where rn = 1
  )
  ;

------------------------------------------------------------------------------------------------------------------------------------------
--------------------------------------- Query for Member Index ---------------------------------------------------------------------------

create or replace table `research-01-217611.df_ucd_stage.wkg_udw_member` AS
  (
  with
    cte_restricted as
      (SELECT savvy_pid, max(is_restricted) as is_restricted
      FROM
        (select distinct savvy_pid, 0 as is_restricted from `ds-00-191017.df_mdm_crosswalk_r2.udw_mdm_crosswalk`
        union all
        SELECT distinct savvy_pid, 1 as is_restricted from `ds-00-191017.df_mdm_crosswalk_restricted_r2.udw_mdm_crosswalk`
        )
      group by savvy_pid
      )
  SELECT mbr_pty_id, orig_src_sys_cd
    , rawmember.savvy_pid
    , rawmember.savvy_did
    , rest.is_restricted
    , case when orig_src_sys_cd in ('ces','cos') and length(src_sbscr_id) < 11 then lpad(src_sbscr_id,11,'0') else lower(trim(src_sbscr_id)) end as sbscr_nbr,
    bth_dt,gdr_typ_cd,dcsd_dt, CASE WHEN mbr_pty_id = SAFE_CAST(sbscr_mbr_pty_id AS INT64) THEN 1 ELSE 0 END AS sbscr_ind,rel_cd, row_eff_dt, row_expir_dt

  FROM
    (SELECT
     row_number() OVER (PARTITION BY mbr_pty_id ORDER BY row_eff_dt DESC,ds_loaddatetime DESC, row_expir_dt ) AS rn
    , *
    FROM `ds-00-191017.udw_final.member`

    ) rawmember
    left join cte_restricted rest on rawmember.savvy_pid = rest.savvy_pid

  WHERE rn = 1 AND row_expir_dt = '9999-12-31' AND src_row_sts_cd = 'a'     --Select most recently updated record that is not expired
  )
  ;

create or replace table `research-01-217611.df_ucd_stage.wkg_udw_member_coverage` AS
  --duplicate records for some reason, so I'll add a DISTINCT and filter down only to where cov_expir_dt is at least 2016
  (
  SELECT DISTINCT mbr_pty_id,cov_eff_dt,cov_expir_dt, src_fund_arng_cd, govt_pgm_typ_desc,UDW_CUST_GRP_PLN_ID, src_pln_var_cd , src_rpt_cd,src_st_of_iss_cd,cast(udw_cust_contr_id as int64) as udw_cust_contr_id
  FROM
    (SELECT
    row_number() OVER (PARTITION BY udw_mbr_cov_id ORDER BY row_eff_dt DESC,ds_loaddatetime DESC, row_expir_dt) AS rn
  , *
  FROM      `ds-00-191017.udw_final.member_coverage` mbr_cov
  LEFT JOIN `ds-00-191017.udw_final.dim_govt_pgm_typ` gpt
       ON mbr_cov.govt_pgm_typ_cd=gpt.govt_pgm_typ_cd
       WHERE trim(cov_typ_cd) in ('m','md','1')  -- select medical coverage only

  )  rawmbrcoverage
  WHERE rn = 1 AND row_expir_dt = '9999-12-31' AND src_row_sts_cd = 'a'    -- Select most recent updated record that hasn't expired  note: Multiple coverage records can exist for each member
    AND cov_eff_dt > '2015-12-31'
  )
  ;

create or replace table `research-01-217611.df_ucd_stage.wkg_udw_member_address` as
  (
  SELECT savvy_pid,mbr_pty_id,row_eff_dt,row_expir_dt,pst_cd
  FROM
  (SELECT
   row_number() OVER (PARTITION BY mbr_pty_id ORDER BY row_eff_dt DESC,ds_loaddatetime DESC, row_expir_dt) AS rn
  , *
  FROM      `ds-00-191017.udw_final.member_address`
  )  memadd
  WHERE rn=1
  )
  ;



 create or replace table `research-01-217611.df_ucd_stage.udd_member_eligibility_index`
    (uuid                       string   OPTIONS(description = "unique row identifer")
    , savvy_pid                 int64    OPTIONS(description = "unique (persistent) member identifier")
    , savvy_did                 int64    OPTIONS(description = "unique (periodically updated) member identifier")
    , is_restricted             int64    OPTIONS(description = "1 if member is restricted (i.e., has ever been a UHG employee) and needs to be reported separately; 0 otherwise")
    , src_type                  string   OPTIONS(description = "data mart type or source")
    , business_line             string   OPTIONS(description = "identifies on to which business line the data mart type or source or group is associated with (eg. Commercial,Medicare, etc)")
   -- , year_mo                   int64    OPTIONS(description = "member year month")
    ,cov_eff_dt                 date     OPTIONS(description = "coverage effective date")
    ,cov_expir_dt               date     OPTIONS(description = "coverage expiration date")
    , birth_year                int64    OPTIONS(description = "member's birth year")
    , gender                    string   OPTIONS(description = "member's gender code")
    , death_date                date     OPTIONS(description = "member's death date")
    , zip                       string   OPTIONS(description = "member's zip code")
    , data_source               string   OPTIONS(description = "source of the data; source system group description")
    , coverage_type             string   OPTIONS(description = "type of program that the member avails under a specific business line")
    , product_id                string   OPTIONS(description = "type of healthcare product identifying code (eg. HMO, PPO, POS)")
    , medicaid_program          string   OPTIONS(description = "name of the Medicaid program the member is associated with")
    , cust_seg_nbr              string   OPTIONS(description = "the number assigned to an entity or customer segment that has purchased products and/or services from UHG, that a member is associated with")
    , cust_seg_nm               string   OPTIONS(description = "the name by which the customer segment is known")
    , sbscr_nbr                 string   OPTIONS(description = "the source system subscriber number; part of the member's natural key")
    , sbscr_ind                 int64    OPTIONS(description = "indicates whether the member is a subscriber or not; subscriber means the member who is employed by the employer group offering insurance to its employees. Default = -1.")
    , family_id                 int64    OPTIONS(description = "a hashed concatenation of a member's customer segment system id and subscriber number to form a family identification number. Default = 0.")
    , rel_cd                    string   OPTIONS(description = "the member's relationship code to the subscriber")
    , rel_desc                  string   OPTIONS(description = "describes the member's relationship to the subscriber")
    , phrm_cov_ind              string   OPTIONS(description = "pharmacy coverage indicator")
    , med_cov_ind               string   OPTIONS(description = "medical coverage indicator")
    , co_nm                     string   OPTIONS(description = "A derived field that describes the business segment to which a claim or member belongs.  Current business units are identified as Americhoice, Ovations, UnitedHealthcare, and Uniprise.")
    , hlth_pln_fund_cd          string   OPTIONS(description = "health plan fund code; a system generated code used to determine Insured vs. ASO")
    , finc_arng_cd              string   OPTIONS(description = "financial arrangement code; a rollup of the company code that denotes fully insured, service contract or MP/MMP")
    , finc_arng_desc            string   OPTIONS(description = "describes the rollup of the company code that denotes fully insured, service contract or MP/MMP")
    , contr_nbr                 string   OPTIONS(description = "Denotes the contract between UHC and CMS - (not UHG and the member/subscriber). The contract numbers represent various UHC subsidiaries/plans. CMS reimburses UHG for the subscriber/member's claims based on the contracts.")
    , contr_pbp                 string   OPTIONS(description = "Combination of the 5-digit alpha-numeric contract number and 3-digit plan benefit package number. It is used to describe the contract and plan package.")
    , contr_desc                string   OPTIONS(description = "contract description of the contract PBP code/number")
    , contr_yr                  int64    OPTIONS(description = "year associated with the contract")
    , snp_flag                  int64    OPTIONS(description = "flags 1 if the member's plan is a SNP (Special Needs Plan)")
    , snp_typ                   string   OPTIONS(description = "Ovations only field. The snp_typ field indicates the type of Special Needs Plan (SNP) and is sourced from the HP55TADM_COMBOS file. The file can be found in Appendix B in the UGAP Financial Derivation Logic document.")
    , sub_product               string   OPTIONS(description = "Ovations only field. Includes product details about the plan/contract type.")
    , dec_risk_typ              string   OPTIONS(description = "Ovations only field which contains the insurance risk type. Values includes 'global cap', 'physician cap', 'unknown', 'ffs', 'facility cap'")
    , dec_risk_typ_desc         string   OPTIONS(description = "Ovations only field which contains the insurance risk type. Values include fee for service (ffs), capitation by type, etc.")
    , mapd_flag                 int64    OPTIONS(description = "Identifies whether a contract has Medicare Advantage plus Presciption Drug (MAPD) coverage. Flags 1 if MAPD, 0 otherwise. Default 0.")
    , medicare_part_d_only_flag int64    OPTIONS(description = "Identifies whether a contract has a Prescription Drug plan but no Medicare Advantage; Logic for setting bit flag is as follows: when contr_nbr <> 'mcaid' and left(contr_nbr, 1) in ('s') then 1 else 0. Default 0.")
    , medicare_advantage_flag   int64    OPTIONS(description = "Identifies whether a contract has an MA coverage, regardless whether it includes prescription drugs or not; Logic for setting bit flag is as follows: when contr_nbr <> 'mcaid' and left(contr_nbr, 1) in ('h', 'r') then 1 else 0. Default 0.")
    , medicaid_flag             int64    OPTIONS(description = "Identifies whether a contract has a Medicaid coverage; Logic for setting bit flag is as follows: when contr_nbr = 'mcaid' then 1 else 0. Default 0.")
    , original_effective_date   date     OPTIONS(description = "The first date the Customer Segment is effective or the first date the member is enrolled in benefits.  This date does not change when the contract is renewed.")
    , termination_date          date     OPTIONS(description = "Date of which group's subscription to SMA is terminated. This represents the date when this parent group, group or subgroup ended its link with this plan.")
    , reinstatement_date        date     OPTIONS(description = "Group reinstatement date. Date when this parent group, group or subgroup reestablished its link to a specific plan. When you reinstate a plan link, all subscribers or members in this plan are also reinstated automatically.")
    , conversion_date           date     OPTIONS(description = "Group conversion date. This represents the date when this parent group, group or subgroup became active in Facets.")
    , group_type_code           string   OPTIONS(description = "Code that identifies the group's policy type. Policy type can be used to identify the rating method used to calculate premium amounts for the entity.")
    , smaindicator              int64    OPTIONS(description = "1 if Primary Care Physician is an SMA provider, otherwise 0")
    , pcp_npi                   string   OPTIONS(description = "This field is the member's attributed primary care physician's National Provider Identifier (NPI). Note, not all members have an attributed primary care physician.")
    , pcp_comm_prac_id          string   OPTIONS(description = "system generated identification number that will tie same providers with multiple individual provider ID.")

--Fields from origingal Member_eligibity_index
      ,plan_variation           string   OPTIONS(description = "Plan Variation code - defines plan level subset of customer")
      ,reporting_code           string   OPTIONS(description = "Reporting Code - customer specific group segmentation")
      ,src_st_of_iss_cd         string   OPTIONS(description = "Customer State of issue")
      ,orig_src_sys_cd          string   OPTIONS(description = "Originating source system Code")
      ,src_sys_nm               string   OPTIONS(description = "Description of Oringating source system code")
      ,current_elig_flag        INT64  OPTIONS(description = "Flag indicating member is eligible as of the run date (1=Eligible, 0=Ineligible)")
      ,exchange_org_typ         string OPTIONS(description = "Identifies type of Exchange (null,1=Non-exchange,2=Public State, eis=Indv State, eif=Indv Federal)")

--metadata columns
    , create_datetime          datetime   OPTIONS(description = "datetime record was created")
    , update_datetime          datetime   OPTIONS(description = "datetime record was updated")
    )
  OPTIONS(description = "udw member index table; one row per member per eligibility period per source")
  AS
  select distinct
      GENERATE_UUID() AS uuid
      ,savvy_pid
      ,savvy_did
      ,is_restricted
      ,src_type
      ,businessline AS business_line
      ,cov_eff_dt
      ,cov_expir_dt
      ,CAST(FORMAT_DATE('%Y',bth_dt) AS INT64) AS birth_year
      ,gdr_typ_cd AS gender
      ,dcsd_dt AS death_date
      ,pst_cd as zip
      ,'udw' as data_source
      ,'' as coverage_type
      ,'' as product_id
      ,'' as medicaid_program
      ,src_cust_contr_id as cust_seg_nbr
      ,cust_contr_nm as cust_nm
      ,sbscr_nbr
      ,sbscr_ind
      ,null AS family_id
      ,rel_cd
      ,'' as rel_desc
      ,'' as phrm_cov_ind
      ,'y' as med_cov_ind
      ,'' as co_nm
      ,'' as hlth_pln_fund_cd
      ,src_fund_arng_cd as finc_arng_cd
      ,funding as finc_arng_desc
      ,'' as contr_nbr
      ,'' as contr_pbp
      ,'' as contr_desc
      ,null as contr_yr
      ,null as snp_flag
      ,'' as snp_typ
      ,'' as sub_product
      ,'' as dec_risk_typ
      ,''dec_risk_typ_desc
      ,null as mapd_flag
      ,null as medicare_part_d_only_flag
      ,null as medicare_advantage_flag
      ,null as medicaid_flag
      ,DATE('1900-01-01') as original_effective_date
      ,DATE('9999-12-31') as termination_date
      ,DATE('9999-12-31') as reinstatement_date
      ,DATE('9999-12-31') as conversion_date
      ,'' as group_type_code
      ,null as smaindicator
      ,'' as pcp_npi
      ,'' as pcp_commm_prac_id
      ,src_pln_var_cd as plan_variation
      ,src_rpt_cd as reporting_code
      ,src_st_of_iss_cd
      ,orig_src_sys_cd
      ,src_sys_nm
      ,current_elig_flag
     ,exchange_org_typ
      ,current_datetime() as create_datetime
      ,current_datetime() as update_datetime

  FROM
      (SELECT distinct
            a.savvy_pid,
            a.savvy_did,
            a.is_restricted,
            'udw' as src_type,
            CASE WHEN a.orig_src_sys_cd ='gps' THEN 'medicaid'
                 WHEN a.orig_src_sys_cd ='csp' THEN 'medicaid'
                 WHEN trim(b.govt_pgm_typ_desc) ='both medicaid and medicare' THEN 'dual'
                 WHEN trim(b.govt_pgm_typ_desc) ='csp medicaid enrolled/external medicare enrolled.' THEN 'medicaid'
                 WHEN trim(b.govt_pgm_typ_desc) ='medicaid' THEN 'medicaid'
                 WHEN trim(b.govt_pgm_typ_desc) ='medicare' THEN 'medicare'
                 WHEN trim(b.govt_pgm_typ_desc) ='non-governmental' THEN 'commercial'
                 WHEN trim(b.govt_pgm_typ_desc) ='unknown' THEN 'commercial'
                 WHEN trim(b.govt_pgm_typ_desc) ='' THEN 'commercial'
                 ELSE 'commercial'
              END AS businessline,

            a.sbscr_nbr,
            a.bth_dt,
            a.gdr_typ_cd,
            a.dcsd_dt,
            a.sbscr_ind,
            a.rel_cd,
            add.pst_cd,
            cc.cust_contr_nm,
            cc.src_cust_contr_id,
            b.src_pln_var_cd ,
            b.src_rpt_cd ,
            b.src_st_of_iss_cd,
            a.orig_src_sys_cd,
            c.src_sys_nm,
            b.cov_eff_dt,
            b.cov_expir_dt,
            src_fund_arng_cd,
             CASE WHEN trim(src_fund_arng_cd) in('1','f','fi') THEN 'fi'
                  WHEN trim(src_fund_arng_cd) in('a','aso','sf') THEN 'aso'
                  WHEN trim(src_fund_arng_cd) in('r','mmp') THEN 'mmp'
                   WHEN a.orig_src_sys_cd='umr' THEN 'aso'
                      when a.orig_src_sys_cd='pri' THEN 'fi'
                  ELSE 'unk'
             END  AS funding,

          CASE WHEN CURRENT_DATE('America/Chicago') BETWEEN b.cov_eff_dt and b.cov_expir_dt THEN 1
                 WHEN b.cov_eff_dt > CURRENT_DATE('America/Chicago') then 1 ELSE 0 END AS current_elig_flag,  -- USE today's date to determine elgiibility
		cc.xchg_org_typ_cd AS exchange_org_typ
      FROM
         `research-01-217611.df_ucd_stage.wkg_udw_member` a
          LEFT JOIN `research-01-217611.df_ucd_stage.wkg_udw_member_coverage` b
                  ON a.mbr_pty_id=b.mbr_pty_id


          LEFT JOIN `research-01-217611.df_ucd_stage.wkg_udw_dim_cust_contr` cc
                  on b.udw_cust_contr_id = cc.udw_cust_contr_id


          LEFT JOIN `ds-00-191017.udw_final.dim_src_sys` c
                  ON a.orig_src_sys_cd= c.src_sys_cd

        --  inner join `ds-00-191017.df_mdm_crosswalk_r2.udw_mdm_crosswalk` d   -- Removed savvy_pid available in source tables
        --          on a.mbr_pty_id = cast(d.src_key_1 as int64)

        LEFT JOIN `research-01-217611.df_ucd_stage.wkg_udw_member_address` add
                ON a.savvy_pid=add.savvy_pid
                   AND a.row_eff_dt between add.row_eff_dt and add.row_expir_dt

                   --I think this condition should be here...:
                   AND a.mbr_pty_id = add.mbr_pty_id

      --WHERE CURRENT_DATE('America/Chicago') between  cov_eff_dt and cov_expir_dt

      WHERE b.cov_eff_dt is not NULL
      -- AND a.savvy_pid < 50000
      )
  ;

  --if successful, we'll get here!
  insert into `research-01-217611.df_ucd_stage.logging`(
    success_flag, job, message_datetime)
  select
    1 as success_flag
    , 'load df_ucd_stage.udd_member_eligibility_index' as job
    , current_datetime as message_datetime
  ;

  EXCEPTION WHEN ERROR THEN
    insert into `research-01-217611.df_ucd_stage.logging`(
      success_flag, job, error_message, statement_text, formatted_stack_trace, message_datetime)
    select
      0 as success_flag
      , 'load df_ucd_stage.udd_member_eligibility_index' as job
      , @@error.message as error_message
      , @@error.statement_text as statement_text
      , @@error.formatted_stack_trace as formatted_stack_trace
      , current_datetime as message_datetime
;

END
;
