/* Project: Universal Claims Database (UCD )
   Business Partner: Matt Holst
   Input:
    `research-01-217611.df_ucd_stage.udd_member_eligibility_index`
    `research-01-217611.df_ucd_stage.dim_date`

   Created By: Dave
   Created Date: 10/27
   Modified By:
   Modified Date:
   Initial data load
   Granularity:  member, month
*/
BEGIN

  create or replace table `research-01-217611.df_ucd_stage.wkg_udw_member_rxcoverage` AS
   (SELECT savvy_pid,cov_eff_dt,cov_expir_dt
   FROM
     (SELECT
       row_number() OVER (PARTITION BY udw_mbr_cov_id ORDER BY row_eff_dt DESC,ds_loaddatetime DESC, row_expir_dt) AS rn , *
           FROM `ds-00-191017.udw_final.member_coverage` mbr_cov
          WHERE trim(cov_typ_cd) in ('p','rx')  -- select pharmacy coverage only

       )  rawmbrcoverage
   WHERE rn = 1 AND row_expir_dt = '9999-12-31' AND src_row_sts_cd = 'a'    -- Select most recent updated record that hasn't expired  note: Multiple coverage records can exist for each member
   )
   ;



 create or replace table `research-01-217611.df_ucd_stage.udd_member_detail_udw`
    (uuid                       string   OPTIONS(description = "unique row identifer")
    , savvy_pid                 int64    OPTIONS(description = "unique (persistent) member identifier")
    , savvy_did                 int64    OPTIONS(description = "unique (periodically updated) member identifier")
    , is_restricted             int64    OPTIONS(description = "1 if member is restricted (i.e., has ever been a UHG employee) and needs to be reported separately; 0 otherwise")
    , src_type                  string   OPTIONS(description = "data mart type or source")
    , business_line             string   OPTIONS(description = "identifies on to which business line the data mart type or source or group is associated with (eg. Commercial,Medicare, etc)")
    , year_mo                   int64    OPTIONS(description = "member year month")
    , birth_year                int64    OPTIONS(description = "member's birth year")
    , gender                    string   OPTIONS(description = "member's gender code")
    , death_date                date     OPTIONS(description = "member's death date")
    , zip                       string   OPTIONS(description = "member's zip code")
    , data_source               string   OPTIONS(description = "source of the data; source system group description")
    , coverage_type             string   OPTIONS(description = "type of program that the member avails under a specific business line")
    , product_id                string   OPTIONS(description = "type of healthcare product identifying code (eg. HMO, PPO, POS)")
    , medicaid_program          string   OPTIONS(description = "name of the Medicaid program the member is associated with")
    , cust_seg_nbr              string   OPTIONS(description = "the number assigned to an entity or customer segment that has purchased products and/or services from UHG, that a member is associated with")
    , cust_seg_nm               string   OPTIONS(description = "the name by which the customer segment is known")
    , sbscr_nbr                 string   OPTIONS(description = "the source system subscriber number; part of the member's natural key")
    , sbscr_ind                 int64    OPTIONS(description = "indicates whether the member is a subscriber or not; subscriber means the member who is employed by the employer group offering insurance to its employees. Default = -1.")
    , family_id                 int64    OPTIONS(description = "a hashed concatenation of a member's customer segment system id and subscriber number to form a family identification number. Default = 0.")
    , rel_cd                    string   OPTIONS(description = "the member's relationship code to the subscriber")
    , rel_desc                  string   OPTIONS(description = "describes the member's relationship to the subscriber")
    , phrm_cov_ind              string   OPTIONS(description = "pharmacy coverage indicator")
    , med_cov_ind               string   OPTIONS(description = "medical coverage indicator")
    , co_nm                     string   OPTIONS(description = "A derived field that describes the business segment to which a claim or member belongs.  Current business units are identified as Americhoice, Ovations, UnitedHealthcare, and Uniprise.")
    , hlth_pln_fund_cd          string   OPTIONS(description = "health plan fund code; a system generated code used to determine Insured vs. ASO")
    , finc_arng_cd              string   OPTIONS(description = "financial arrangement code; a rollup of the company code that denotes fully insured, service contract or MP/MMP")
    , finc_arng_desc            string   OPTIONS(description = "describes the rollup of the company code that denotes fully insured, service contract or MP/MMP")
    , contr_nbr                 string   OPTIONS(description = "Denotes the contract between UHC and CMS - (not UHG and the member/subscriber). The contract numbers represent various UHC subsidiaries/plans. CMS reimburses UHG for the subscriber/member's claims based on the contracts.")
    , contr_pbp                 string   OPTIONS(description = "Combination of the 5-digit alpha-numeric contract number and 3-digit plan benefit package number. It is used to describe the contract and plan package.")
    , contr_desc                string   OPTIONS(description = "contract description of the contract PBP code/number")
    , contr_yr                  int64    OPTIONS(description = "year associated with the contract")
    , snp_flag                  int64    OPTIONS(description = "flags 1 if the member's plan is a SNP (Special Needs Plan)")
    , snp_typ                   string   OPTIONS(description = "Ovations only field. The snp_typ field indicates the type of Special Needs Plan (SNP) and is sourced from the HP55TADM_COMBOS file. The file can be found in Appendix B in the UGAP Financial Derivation Logic document.")
    , sub_product               string   OPTIONS(description = "Ovations only field. Includes product details about the plan/contract type.")
    , dec_risk_typ              string   OPTIONS(description = "Ovations only field which contains the insurance risk type. Values includes 'global cap', 'physician cap', 'unknown', 'ffs', 'facility cap'")
    , dec_risk_typ_desc         string   OPTIONS(description = "Ovations only field which contains the insurance risk type. Values include fee for service (ffs), capitation by type, etc.")
    , mapd_flag                 int64    OPTIONS(description = "Identifies whether a contract has Medicare Advantage plus Presciption Drug (MAPD) coverage. Flags 1 if MAPD, 0 otherwise. Default 0.")
    , medicare_part_d_only_flag int64    OPTIONS(description = "Identifies whether a contract has a Prescription Drug plan but no Medicare Advantage; Logic for setting bit flag is as follows: when contr_nbr <> 'mcaid' and left(contr_nbr, 1) in ('s') then 1 else 0. Default 0.")
    , medicare_advantage_flag   int64    OPTIONS(description = "Identifies whether a contract has an MA coverage, regardless whether it includes prescription drugs or not; Logic for setting bit flag is as follows: when contr_nbr <> 'mcaid' and left(contr_nbr, 1) in ('h', 'r') then 1 else 0. Default 0.")
    , medicaid_flag             int64    OPTIONS(description = "Identifies whether a contract has a Medicaid coverage; Logic for setting bit flag is as follows: when contr_nbr = 'mcaid' then 1 else 0. Default 0.")
    , original_effective_date   date     OPTIONS(description = "The first date the Customer Segment is effective or the first date the member is enrolled in benefits.  This date does not change when the contract is renewed.")
    , termination_date          date     OPTIONS(description = "Date of which group's subscription to SMA is terminated. This represents the date when this parent group, group or subgroup ended its link with this plan.")
    , reinstatement_date        date     OPTIONS(description = "Group reinstatement date. Date when this parent group, group or subgroup reestablished its link to a specific plan. When you reinstate a plan link, all subscribers or members in this plan are also reinstated automatically.")
    , conversion_date           date     OPTIONS(description = "Group conversion date. This represents the date when this parent group, group or subgroup became active in Facets.")
    , group_type_code           string   OPTIONS(description = "Code that identifies the group's policy type. Policy type can be used to identify the rating method used to calculate premium amounts for the entity.")
    , smaindicator              int64    OPTIONS(description = "1 if Primary Care Physician is an SMA provider, otherwise 0")
    , pcp_npi                   string   OPTIONS(description = "This field is the member's attributed primary care physician's National Provider Identifier (NPI). Note, not all members have an attributed primary care physician.")
    , pcp_comm_prac_id          string   OPTIONS(description = "system generated identification number that will tie same providers with multiple individual provider ID.")

      ,plan_variation           string   OPTIONS(description = "Plan Variation code - defines plan level subset of customer")
      ,reporting_code           string   OPTIONS(description = "Reporting Code - customer specific group segmentation")
      ,src_st_of_iss_cd         string   OPTIONS(description = "Customer State of issue")
      ,orig_src_sys_cd          string   OPTIONS(description = "Originating source system Code")
      ,src_sys_nm               string   OPTIONS(description = "Description of Oringating source system code")
      ,current_elig_flag        INT64  OPTIONS(description = "Flag indicating member is eligible as of the run date (1=Eligible, 0=Ineligible)")

--metadata columns
    , create_datetime          datetime   OPTIONS(description = "datetime record was created")
    , update_datetime          datetime   OPTIONS(description = "datetime record was updated")
    )
  OPTIONS(description = "udw member detail table; one row per member per eligible month per source")



AS

WITH

   MEMBERSHIP AS
      (SELECT Distinct
        savvy_pid , savvy_did, is_restricted ,src_type, business_line ,b.year_mo ,birth_year ,gender,death_date ,zip ,data_source ,coverage_type ,product_id ,medicaid_program ,cust_seg_nbr, cust_seg_nm, sbscr_nbr, sbscr_ind
       ,family_id, rel_cd, rel_desc, phrm_cov_ind, med_cov_ind, co_nm, hlth_pln_fund_cd, finc_arng_cd, finc_arng_desc, contr_nbr, contr_pbp, contr_desc, contr_yr, snp_flag, snp_typ, sub_product, dec_risk_typ
       ,dec_risk_typ_desc, mapd_flag,medicare_part_d_only_flag ,medicare_advantage_flag, medicaid_flag, original_effective_date, termination_date, reinstatement_date, conversion_date, group_type_code
       ,smaindicator, pcp_npi, pcp_comm_prac_id, plan_variation, reporting_code, src_st_of_iss_cd, orig_src_sys_cd, src_sys_nm, current_elig_flag


      FROM `research-01-217611.df_ucd_stage.udd_member_eligibility_index` a
        join `research-01-217611.df_ucd_stage.dim_month`  b on b.month_midmonth_date BETWEEN cov_eff_dt AND cov_expir_dt

      WHERE b.year_nbr >= 2016 and b.month_midmonth_date <= current_date()
       --AND a.savvy_pid < 5000 --for a sample
      )
      ,

  RXbymonth AS
      (SELECT Distinct savvy_pid, year_mo
      FROM `research-01-217611.df_ucd_stage.wkg_udw_member_rxcoverage` rx
          join `research-01-217611.df_ucd_stage.dim_month` mt on mt.month_midmonth_date BETWEEN rx.cov_eff_dt AND rx.cov_expir_dt
      WHERE mt.year_nbr >= 2016 and mt.month_midmonth_date <= current_date()
        --AND savvy_pid < 5000
        )

  SELECT
    GENERATE_UUID() as uuid
       ,m.savvy_pid , m.savvy_did, m.is_restricted,src_type, business_line ,m.year_mo ,birth_year ,gender,death_date ,zip ,data_source ,coverage_type ,product_id ,medicaid_program ,cust_seg_nbr, cust_seg_nm, sbscr_nbr, sbscr_ind
       ,family_id, rel_cd, rel_desc,
       CASE WHEN r.year_mo is Null then 'y' else 'n' end AS phrm_cov_ind
       ,med_cov_ind, co_nm, hlth_pln_fund_cd, finc_arng_cd, finc_arng_desc, contr_nbr, contr_pbp, contr_desc, contr_yr, snp_flag, snp_typ, sub_product, dec_risk_typ
       ,dec_risk_typ_desc, mapd_flag,medicare_part_d_only_flag ,medicare_advantage_flag, medicaid_flag, original_effective_date, termination_date, reinstatement_date, conversion_date, group_type_code
       ,smaindicator, pcp_npi, pcp_comm_prac_id, plan_variation, reporting_code, src_st_of_iss_cd, orig_src_sys_cd, src_sys_nm, current_elig_flag
      ,current_datetime() as create_datetime
      ,current_datetime() as update_datetime
  FROM MEMBERSHIP m
  LEFT JOIN RXbymonth r ON m.savvy_pid=r.savvy_pid and m.year_mo=r.year_mo

  ORDER BY savvy_pid, year_mo
  ;

  --if successful, we'll get here!
  insert into `research-01-217611.df_ucd_stage.logging`(
    success_flag, job, message_datetime)
  select
    1 as success_flag
    , 'load df_ucd_stage.udd_member_detail_udw' as job
    , current_datetime as message_datetime
  ;

  EXCEPTION WHEN ERROR THEN
    insert into `research-01-217611.df_ucd_stage.logging`(
      success_flag, job, error_message, statement_text, formatted_stack_trace, message_datetime)
    select
      0 as success_flag
      , 'load df_ucd_stage.udd_member_detail_udw' as job
      , @@error.message as error_message
      , @@error.statement_text as statement_text
      , @@error.formatted_stack_trace as formatted_stack_trace
      , current_datetime as message_datetime
    ;

END
;
