/***
Universal Claims Data - Customer Segment detail table

Date Created: 11 November 2020
***/

BEGIN
  ----------------------
  --customer segment detail
  ----------------------
  create or replace table `research-01-217611.df_ucd_stage.dim_customer_segment_detail`
  ( year_mo                 int64     OPTIONS(description = "customer segment year month")
    , co_id_rllp            string    OPTIONS(description = "Company ID Roll-up Summary Level Reporting for Companies with more than 1 Company ID.  E.g. OCIV, OCI and IPA all are part of the Company ID Roll-up for 'MAMSI-UHC'.  Note some Company ID Roll-up will only have 1 Company ID.")
    , co_nm                 string    OPTIONS(description = "A derived field that describes the business segment to which a claim or member belongs.  Current business units are identified as Americhoice, Ovations, UnitedHealthcare, and Uniprise.")
    , hlth_pln_fund_cd      string    OPTIONS(description = "System generated code used to determine Insured vs. ASO")
    , hlth_pln_fund_cd_desc string    OPTIONS(description = "Description of funding arrangement (Fully insured, partially insured or ASO)")
    , mkt_seg_cd            string    OPTIONS(description = "Indicates the relative size of the customer based on the number of employees.")
    , mkt_seg_rllp_desc     string    OPTIONS(description = "The business segment description of the group type classification (e.g., key accounts, small business)")
    , cust_seg_nbr          string    OPTIONS(description = "The number assigned to an entity that has purchased products and/or services from UHG. UNET: This equates to 'Policy Number'. IMCS: This equates to  Group Number.  The 'ClinOps' version of the Customer Segment table is a limited version of the table that is not timelined and only provides the customer attributes (customer name, master group information, zip codes, product, company, source system and market size) for each Customer Segment Number as of the latest extract from Galaxy for database refresh. This is a considered a current view of the customer attributes and does not necessarily indicate the attributes at the time of a claim's date of service.  The 'ClinOps' version of the Customer Segment table is currently designed to be a supporting sub-dimension from the Individual dimension table within COM.  The UGAP version of the Customer Segment table is joined directly to the claims tables.")
    , cust_seg_nm           string    OPTIONS(description = "The name by which the customer segment is known.  The 'ClinOps' version of the Customer Segment table is a limited version of the table that is not timelined and only provides the customer attributes (customer name, master group information, zip codes, product, company, source system and market size) for each Customer Segment Number as of the latest extract from Galaxy for database refresh. This is a considered a current view of the customer attributes and does not necessarily indicate the attributes at the time of a claim's date of service.  The 'ClinOps' version of the Customer Segment table is currently designed to be a supporting sub-dimension from the Individual dimension table within COM.  The UGAP version of the Customer Segment table is joined directly to the claims table.")
    , company_zip           string    OPTIONS(description = "Zip code of the customer segment")
    , company_st_cd         string    OPTIONS(description = "State code fo the customer segment")
    , orig_eff_dt           date      OPTIONS(description = "The first date the Customer Segment is effective or the first date the member is enrolled in benefits.  This date does not change when the contract is renewed.")
    , mbr_cnt               int64     OPTIONS(description = "Calculated monthly from the Galaxy Member Coverage Month table, it is the sum of members (the count or aggregate only, no member details), with coverage effective as of the first of the month. Members include both subscribers and dependents.  (For each month for which a member is effective, they receive a count of 1.)")
    , sbscr_cnt             int64     OPTIONS(description = "Calculated monthly from the Galaxy Member Coverage Month table, it is the sum of non-dependent members (the count or aggregate only, no subscriber details), with coverage effective as of the first of the month.  (For each month for which a subscriber is effective, they receive a count of 1.)")
    , grp_size_ind          string    OPTIONS(description = "A code that identifies the appropriate Group Size Band. This field is used as an ID field.")
    , grp_size_desc         string    OPTIONS(description = "The Group Size band applicable to the most recent Subscriber Count for a Customer.")
    , create_datetime       datetime  OPTIONS(description = "datetime record was created")
    )
  OPTIONS (description = "This is the dimension table for Customer Segment. It has a one row per customer number per year month granularity. This includes items such as customer name, master group information, zip codes and market size.") as
  select * except(oid, src_type)
    , current_datetime as create_datetime
  from (
          select *, row_number() over(partition by cust_seg_nbr, year_mo order by (case when src_type = 'ugap' then 1 else 2 end)) as oid
          from  (
                  select year_mo, co_id_rllp, co_nm, hlth_pln_fund_cd, hlth_pln_fund_cd_desc, mkt_seg_cd, mkt_seg_rllp_desc, cust_seg_nbr, cust_seg_nm, company_zip, company_st_cd, orig_eff_dt, mbr_cnt, sbscr_cnt
                    , grp_size_ind, grp_size_desc
                    , 'ugap' as src_type
                  from `research-01-217611.df_ucd_stage.tmp_custsegdtl_ugap`

                  union distinct
                  select year_mo, '' as co_id_rllp, '' as co_nm, finc_arng_cd as hlth_pln_fund_cd
                    , (case when finc_arng_cd = 'f' then 'fi'
                           when finc_arng_cd = 'a' then 'aso' end) as hlth_pln_fund_cd_desc
                    , '' as mkt_seg_cd, '' as mkt_seg_rllp_desc, cust_seg_nbr, cust_seg_nm, '' as company_zip, st_cd as company_st_cd, orig_eff_dt, 0 as mbr_cnt, 0 as sbscr_cnt
                    , '' as grp_size_ind,  '' as grp_size_desc
                    , 'galaxy' as src_type
                  from `research-01-217611.df_ucd_stage.tmp_dim_custsegsysdtl_galaxy`
                ) a
       ) a
  where oid = 1
  ;

insert into `research-01-217611.df_ucd_stage.logging`(
   success_flag, job, message_datetime)
 select
   1 as success_flag
   , 'load customer segment detail table' as job
   , current_datetime as message_datetime
 ;


 EXCEPTION WHEN ERROR THEN
   insert into `research-01-217611.df_ucd_stage.logging`(
     success_flag, job, error_message, statement_text, formatted_stack_trace, message_datetime)
   select
     0 as success_flag
     , 'load customer segment detail table' as job
     , @@error.message as error_message
     , @@error.statement_text as statement_text
     , @@error.formatted_stack_trace as formatted_stack_trace
     , current_datetime as message_datetime
   ;


END
;
