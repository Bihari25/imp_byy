/***
Universal Claims Data Model - Member Detail Mapping

Steps:
  1) from the data sources look pull for only those necessary columns to be used in staging table
  2) create staging table, standardization of data types can be done here
  3) create the consolidated/merged table

Date Created: 15 June 2020
***/

BEGIN

  --helper table we'll use in a couple of queries:
  --sma
  insert into  `research-01-217611.df_ucd_stage.udd_member_detail_sma`
    (uuid, savvy_pid, savvy_did, is_restricted, src_type, business_line, year_mo, birth_year, gender, death_date, zip, data_source,
      coverage_type, product_id, medicaid_program, cust_seg_nbr, cust_seg_nm, sbscr_nbr, sbscr_ind, family_id, rel_cd, rel_desc, phrm_cov_ind, med_cov_ind,
      co_nm, hlth_pln_fund_cd, finc_arng_cd, finc_arng_desc, contr_nbr, contr_pbp, contr_desc, contr_yr, snp_flag, snp_typ, sub_product, dec_risk_typ, dec_risk_typ_desc,
      mapd_flag, medicare_part_d_only_flag, medicare_advantage_flag, medicaid_flag, original_effective_date, termination_date, reinstatement_date, conversion_date,
      group_type_code, smaindicator, pcp_npi, pcp_comm_prac_id, create_datetime, update_datetime
    )
  with cte_dtl as (
    select *
    from (
            select distinct a.*, b.year_mo
              , row_number() over(partition by a.savvy_pid, b.year_mo order by eligibility_term_date desc) as oid
            from (
                   select distinct a.savvy_pid, a.savvy_did, a.is_restricted, lower(trim(a.subscriber_id)) as subscriber_id, lower(trim(a.member_relationship)) as rel_cd, lower(trim(a.member_gender)) as gender, a.member_birth_date as bth_dt
                     , extract(year from a.member_birth_date) as birth_year
                     , lower(trim(a.member_zip_code)) as zip_cd, a.sma_member_indicator as sma_indicator, ifnull(lower(trim(d.provider_npi)), '') as pcp_npi, lower(trim(d.common_practitioner_id)) as pcp_comm_prac_id
                     , b.eligibility_effective_date, (case when b.eligibility_term_date > current_date() then date_sub(current_date(), interval 1 month) else b.eligibility_term_date end) as eligibility_term_date
                     , lower(trim(b.business_line)) as business_line, lower(trim(b.product_identifier)) as product_identifier, lower(trim(b.medicaid_program)) as medicaid_program
                     , lower(trim(b.coverage_type)) as coverage_type
                     , lower(trim(c.group_id)) as group_id, lower(trim(c.group_name)) as group_name, c.group_reinstatement_date, c.group_conversion_date, c.group_original_eff_date, lower(trim(c.group_type_code)) as group_type_code
                     , min(eligibility_effective_date) over(partition by lower(trim(b.member_id)), lower(trim(b.group_id)) order by eligibility_effective_date) as deriv_eff_dt
                   from (
                          select *, row_number() over(partition by savvy_pid order by lower(trim(member_id)) desc) as oid
                          from `ds-00-191017.sierrahealth_sma_final.member`
                         ) a
                   inner join `ds-00-191017.sierrahealth_sma_final.enroll`  b on a.savvy_pid = b.savvy_pid
                                                                              and lower(trim(a.member_id)) = lower(trim(b.member_id))
                                                                              and a.oid = 1
                   inner join `ds-00-191017.sierrahealth_sma_final.group`   c on lower(trim(b.group_id)) = lower(trim(c.group_id))
                   left join `ds-00-191017.sierrahealth_sma_final.provider` d on lower(trim(a.current_pcp_id)) = lower(trim(d.provider_id))
                   --where a.is_restricted = 0
                ) a
            inner join `research-01-217611.df_ucd_stage.dim_month` b on b.month_midmonth_date between a.eligibility_effective_date and a.eligibility_term_date --15th of the month
            where b.year_nbr >= 2016
        ) x
    where oid = 1
  )
select GENERATE_UUID() uuid
    , savvy_pid
    , savvy_did
    , is_restricted
    , 'sma' as src_type
    , ifnull(business_line, '') as business_line
    , year_mo
    , birth_year
    , ifnull(gender, '') as gender
    , cast(null as date) as death_date
    , ifnull(zip_cd, '') as zip
    , 'ds-00-191017.sierrahealth_sma_final' as data_source
    , ifnull(coverage_type, '') as coverage_type
    , ifnull(product_identifier, '') as product_id
    , ifnull(medicaid_program, '') as medicaid_program
    , ifnull(group_id, '')  as cust_seg_nbr
    , ifnull(group_name, '') as cust_seg_nm
    , ifnull(subscriber_id, '') as sbscr_nbr
    , -1 as sbscr_ind
    , 0 as family_id
    , ifnull(rel_cd, '') as rel_cd
    , '' as rel_desc
    , '' as phrm_cov_ind
    , 'y' as med_cov_ind
    , '' as co_nm
    , '' as hlth_pln_fund_cd
    , '' as finc_arng_cd
    , '' as finc_arng_desc
    , '' as contr_nbr
    , '' as contr_pbp
    , '' as contr_desc
    , NULL as contr_yr
    , 0 as snp_flag
    , '' as snp_typ
    , '' as sub_product
    , '' as dec_risk_typ
    , '' as dec_risk_typ_desc
    , 0 as mapd_flag
    , 0 as medicare_part_d_only_flag
    , (case when business_line = 'medicare' then 1 else 0 end) as medicare_advantage_flag
    , (case when business_line = 'medicaid' then 1 else 0 end) as medicaid_flag
    , deriv_eff_dt as original_effective_date
    , eligibility_term_date as termination_date
    , group_reinstatement_date as reinstatement_date
    , group_conversion_date as conversion_date
    , ifnull(group_type_code, '') as group_type_code
    , ifnull(safe_cast(sma_indicator as int64), 0) as smaindicator
    , ifnull(pcp_npi, '') as pcp_npi
    , ifnull(pcp_comm_prac_id, '') as pcp_comm_prac_id

    , current_datetime as create_datetime
    , current_datetime as update_datetime

  from cte_dtl
  where year_mo >= 201601
  ;

  --galaxy
  --modifications from Seth 2020-11-03: I didn't change any of the logic, just broke the processing into several steps w/ temp tables for processing efficiency
  --modifications from Seth 2020-11-17: ...into several *more* steps w/ temp tables so it actually finishes. And I updated address to be monthly, which it surely should be
      create or replace table `research-01-217611.df_ucd_stage.tmp_dim_custsegsysdtl_galaxy`  as
        (
        select distinct a.*, b.year_mo, lower(trim(c.cust_seg_nm)) as cust_seg_nm, c.orig_eff_dt, lower(trim(c.iss_st_abbr_cd)) as st_cd
        from (
                select safe_cast(b.cust_seg_sys_id as int64) as cust_seg_sys_id, lower(trim(b.cust_seg_nbr)) as cust_seg_nbr, lower(trim(b.finc_arng_cd)) as finc_arng_cd
                  , b.cust_seg_cov_row_eff_dt, b.cust_seg_cov_row_end_dt
                  , least(b.cust_seg_cov_row_end_dt, current_date()) as end_dt
                  , lower(trim(e.bus_line_cd)) as bus_line_cd, lower(trim(e.bus_line_desc)) as bus_line_desc, lower(trim(b.src_sys_cd)) as src_sys_cd
                  , lower(trim(b.pln_var_subdiv_cd)) as pln_var_subdiv_cd, lower(trim(b.rpt_cd_br_cd)) as rpt_cd_br_cd
                  , lower(trim(d.prdct_cd)) as prdct_cd, lower(trim(d.prdct_cd_desc)) as prdct_cd_desc, lower(trim(d.indus_prdct_cd)) as indus_prdct_cd
                from `ds-00-191017.galaxy_final.dim_customer_segment_coverage` b
                left join `ds-00-191017.galaxy_final.dim_product`              d on lower(trim(b.prdct_cd)) = lower(trim(d.prdct_cd))
                                                                                 and lower(trim(b.src_sys_cd)) = lower(trim(d.src_sys_cd))
                left join `ds-00-191017.galaxy_final.dim_business_line_code`   e on lower(trim(d.bus_line_cd)) = lower(trim(e.bus_line_cd))
                where safe_cast(b.cust_seg_sys_id as int64) not in (1000000000, 2000000000)   --these are ids have multiple cust_seg_nbr with blank names
            ) a
        inner join  `ds-00-191017.galaxy_final.dim_customer_segment`  c on a.cust_seg_sys_id = c.cust_seg_sys_id and c.curr_ind = 'Y'
        inner join `research-01-217611.df_ucd_stage.dim_month` b on b.month_midmonth_date between a.cust_seg_cov_row_eff_dt and a.end_dt --15th of the month
        where b.year_nbr >= 2016
        )
        ;

    create or replace table `research-01-217611.df_ucd_stage.tmp_cust_seg_month_product_galaxy` as
        (
          select distinct cust_seg_sys_id, year_mo, prdct_cd, cust_seg_nbr, cust_seg_nm, orig_eff_dt
          from `research-01-217611.df_ucd_stage.tmp_dim_custsegsysdtl_galaxy`
        )
        ;

    create or replace table `research-01-217611.df_ucd_stage.tmp_member_month_address_galaxy` as
    --find most recently updated address for each member/month
        (
        select
          a.savvy_pid
          , a.year_mo
          , lower(trim(a.zip_cd)) as zip_cd
          , lower(trim(a.st_abbr_cd)) as st_cd
        from (
            select
              a.savvy_pid
              , b.year_mo
              , a.zip_cd
              , a.st_abbr_cd
              , row_number() over(partition by  a.savvy_pid
                                                , b.year_mo
                                  order by      a.updt_dt desc
                                                , a.mbr_sys_id desc
                                                , a.mbr_adr_row_end_dt desc
                                                ) as oid
            from `ds-00-191017.galaxy_final.member_address`  a
               inner join `research-01-217611.df_ucd_stage.dim_month` b on b.month_midmonth_date between a.mbr_adr_row_eff_dt and a.mbr_adr_row_end_dt  --15th of the month
            where
              b.month_midmonth_date between '2016-01-01' and current_date()
              and a.mbr_adr_row_end_dt >= '2016-01-01'
            ) a
        where oid = 1
        )
        ;


      create or replace table `research-01-217611.df_ucd_stage.tmp_galaxy_final_member`
      cluster by savvy_pid, cust_seg_sys_id
      as
          (
          select
            b.savvy_pid
            , b.cust_seg_sys_id
            , b.bth_dt
            , extract(year from b.bth_dt) as birth_year
            , lower(trim(b.gdr_cd)) as gender
            , lower(trim(b.sbscr_nbr)) as sbscr_nbr
            , lower(trim(b.depn_nbr)) as depn_nbr
            , lower(trim(b.rel_cd)) as rel_cd
            , lower(trim(c.rel_desc)) as rel_desc
            , lower(trim(b.cob_ind)) as cob_ind
            , lower(trim(b.depn_sts_cd)) as depn_sts_cd
            , b.fam_id as family_id
            , lower(trim(b.medcr_elig_ind)) as medcr_elig_ind
            , lower(trim(b.medcr_pri_ind)) as medcr_pri_ind
            , curr_ind
          from `ds-00-191017.galaxy_final.member`                                  b
            left join `ds-00-191017.galaxy_final.dim_relationship_code`            c on lower(trim(b.rel_cd)) = lower(trim(c.rel_cd))
          where b.curr_ind = 'y' and b.mbr_row_end_dt >= '2016-01-01'
              and b.savvy_pid > 0
              --this probably should be within an effective date range, but we'll restrict to distinct later
              --in the meantime, this will let this query finish...
          )
          ;

      create or replace table `research-01-217611.df_ucd_stage.tmp_galaxy_final_member_coverage_month`
      cluster by savvy_pid, cust_seg_sys_id
      as
          (
          select a.savvy_pid, a.savvy_did, a.is_restricted, a.mbr_sys_id, a.indv_id, a.cust_seg_sys_id
            , a.mbr_cov_mo_row_eff_dt
            , least(a.mbr_cov_mo_row_end_dt, current_date()) as mbr_cov_mo_row_end_dt
            , case when (lower(trim(a.rel_cd)) = 'ee') or (lower(trim(a.rel_cd)) = 'un' and a.DEPN_NBR = '000') then 1 else 0 end as sbscr_ind --logic from Karan, 1/22/2021
            , lower(trim(a.phrm_cov_ind)) as phrm_cov_ind
            , lower(trim(a.med_cov_ind)) as med_cov_ind
            , lower(trim(a.med_prdct_1_cd)) as prdct_cd
            , lower(trim(d.indus_prdct_cd)) as indus_prdct_cd
            , lower(trim(a.pln_var_subdiv_cd)) as pln_var_subdiv_cd
            , lower(trim(a.rpt_cd_br_cd)) as rpt_cd_br_cd
            , lower(trim(a.finc_arng_cd)) as finc_arng_cd
            , (case when lower(trim(a.finc_arng_cd)) = 'f' then 'fully insured'
                    when lower(trim(a.finc_arng_cd)) = 'a' then 'aso' end) as finc_arng_desc
            , a.mbr_med_pri_physn_prov_sys_id
            , lower(trim(e.bus_line_desc)) as business_line
            , lower(trim(a.src_sys_cd)) as src_sys_cd
          from `ds-00-191017.galaxy_final.member_coverage_month`          a
          left join `ds-00-191017.galaxy_final.dim_product`               d on lower(trim(a.med_prdct_1_cd)) = lower(trim(d.prdct_cd))
                                                                            and lower(trim(a.src_sys_cd)) = lower(trim(d.src_sys_cd))
          left join `ds-00-191017.galaxy_final.dim_business_line_code`    e on lower(trim(d.bus_line_cd)) = lower(trim(e.bus_line_cd))
          where --a.is_restricted = 0 and
            extract(year from a.mbr_cov_mo_row_end_dt) >=2016
            and a.savvy_pid > 0
          )
          ;

      create or replace table `research-01-217611.df_ucd_stage.tmp_mbr_galaxy_cte_mbr_cov` as
          (
                select *
                from `research-01-217611.df_ucd_stage.tmp_galaxy_final_member`                         b
                 inner join `research-01-217611.df_ucd_stage.tmp_galaxy_final_member_coverage_month`   a using (savvy_pid, cust_seg_sys_id)
          )
          ;

      create or replace table `research-01-217611.df_ucd_stage.tmp_mbr_galaxy` as
          (
          select distinct a.* except(cust_seg_sys_id, oid)
            , c.cust_seg_nbr, c.cust_seg_nm, c.orig_eff_dt
            , d.zip_cd, d.st_cd
          from (
                 select a.*, b.year_mo
                   , row_number() over(partition by a.savvy_pid, year_mo order by a.mbr_sys_id desc, a.phrm_cov_ind desc) as oid
                 from `research-01-217611.df_ucd_stage.tmp_mbr_galaxy_cte_mbr_cov`  a
                 inner join `research-01-217611.df_ucd_stage.dim_month` b on b.month_midmonth_date between a.mbr_cov_mo_row_eff_dt and a.mbr_cov_mo_row_end_dt  --15th of the month
                 where b.month_midmonth_date between '2016-01-01' and current_date()
                )                                                                           a
          inner join `research-01-217611.df_ucd_stage.tmp_cust_seg_month_product_galaxy`    c on a.cust_seg_sys_id = c.cust_seg_sys_id
                                                                                              and a.year_mo = c.year_mo
                                                                                              and a.prdct_cd = c.prdct_cd
          inner join `research-01-217611.df_ucd_stage.tmp_member_month_address_galaxy`      d on a.savvy_pid = d.savvy_pid
                                                                                              and a.year_mo = d.year_mo
          where oid = 1
          )
          ;

      insert into `research-01-217611.df_ucd_stage.udd_member_detail_galaxy`
        (uuid, savvy_pid, savvy_did, is_restricted, src_type, business_line, year_mo, birth_year, gender, death_date, zip, data_source,
          coverage_type, product_id, medicaid_program, cust_seg_nbr, cust_seg_nm, sbscr_nbr, sbscr_ind, family_id, rel_cd, rel_desc, phrm_cov_ind, med_cov_ind,
          co_nm, hlth_pln_fund_cd, finc_arng_cd, finc_arng_desc, contr_nbr, contr_pbp, contr_desc, contr_yr, snp_flag, snp_typ, sub_product, dec_risk_typ, dec_risk_typ_desc,
          mapd_flag, medicare_part_d_only_flag, medicare_advantage_flag, medicaid_flag, original_effective_date, termination_date, reinstatement_date, conversion_date,
          group_type_code, smaindicator, pcp_npi, pcp_comm_prac_id, create_datetime, update_datetime
        )
        with
         cte_med_mbr as (
            select a.savvy_pid, a.savvy_did, a.is_restricted, a.year_mo
              , max(case when a.business_line = 'medicare' then 1 else 0 end) as medicare_flag
              , max(case when a.business_line = 'medicaid' then 1 else 0 end) as medicaid_flag
            from (
                    select distinct savvy_pid, savvy_did, is_restricted, mbr_sys_id, indv_id, prdct_cd, business_line, year_mo
                    from `research-01-217611.df_ucd_stage.tmp_mbr_galaxy`
                    where business_line <> 'commercial' and prdct_cd <> 'not'
                  ) a
            group by a.savvy_pid, a.savvy_did, a.is_restricted, a.year_mo
          )
        select GENERATE_UUID() uuid
          , a.*
          , current_datetime as create_datetime
          , current_datetime as update_datetime
        from (
               select a.savvy_pid
                 , a.savvy_did
                 , a.is_restricted
                 , 'galaxy' as src_type
                 , a.business_line
                 , a.year_mo
                 , extract(year from a.bth_dt) as birth_year
                 , ifnull(a.gender, '') as gender
                 , cast(NULL as date) as death_date
                 , a.zip_cd as zip
                 , 'galaxy' as data_source
                 , '' as coverage_type
                 , ifnull(a.indus_prdct_cd, '') as product_id   --changed to industry product code to be consistent with sma & ugap's versions
                 , '' as medicaid_program
                 , ifnull(a.cust_seg_nbr, '') as cust_seg_nbr
                 , ifnull(a.cust_seg_nm, '') as cust_seg_nm
                 , ifnull(a.sbscr_nbr, '') as sbscr_nbr
                 , ifnull(a.sbscr_ind, -1) as sbscr_ind
                 , ifnull(a.family_id, 0) as family_id
                 , ifnull(a.rel_cd, '') as rel_cd
                 , ifnull(a.rel_desc, '') as rel_desc
                 , ifnull((case when a.finc_arng_cd = 'f' then 'y' else a.phrm_cov_ind end), '') as phrm_cov_ind
                 , ifnull((case when a.finc_arng_cd = 'f' then 'y' else a.med_cov_ind end), '') as med_cov_ind
                 , '' as co_nm
                 , ifnull((case when a.finc_arng_cd = 'f' then 'fi'
                                when a.finc_arng_cd = 'a' then 'aso' else a.finc_arng_cd end), '') as hlth_pln_fund_cd
                 , ifnull((case when a.finc_arng_cd = 'f' then 'fi'
                                when a.finc_arng_cd = 'a' then 'aso' else a.finc_arng_cd end), '') as finc_arng_cd
                 , ifnull(a.finc_arng_desc, '') as finc_arng_desc
                 , '' as contr_nbr
                 , '' as contr_pbp
                 , '' as contr_desc
                 , NULL as contr_yr
                 , 0 as snp_flag
                 , '' as snp_typ
                 , '' as sub_product
                 , '' as dec_risk_typ
                 , '' as dec_risk_typ_desc
                 , 0 as mapd_flag
                 , 0 as medicare_part_d_only_flag
                 , ifnull(a.medicare_flag, 0) as medicare_advantage_flag
                 , ifnull(a.medicaid_flag, 0) as medicaid_flag
                 , a.orig_eff_dt as original_effective_date
                 , cast(NULL as date) as termination_date
                 , cast(NULL as date) as reinstatement_date
                 , cast(NULL as date) as conversion_date
                 , '' as group_type_code
                 , 0 as smaindicator
                 , '' as pcp_npi
                 , '' as pcp_comm_prac_id
               from  (
                       select distinct a.* except (mbr_sys_id, indv_id)
                         , ifnull(max(b.medicare_flag) over(partition by a.savvy_pid, a.year_mo), 0) as medicare_flag
                         , ifnull(max(b.medicaid_flag) over(partition by a.savvy_pid, a.year_mo), 0) as medicaid_flag
                       from `research-01-217611.df_ucd_stage.tmp_mbr_galaxy` a
                       left join cte_med_mbr b using (savvy_pid, year_mo)
                     ) a
          ) a
      ;



  --ugap
  --modifications from Seth 2020-11-05: I didn't change any of the logic, just broke the processing into several steps w/ temp tables for processing efficiency
create or replace table `research-01-217611.df_ucd_stage.tmp_custsegdtl_ugap`  as
with cte_custseg_dtl as (
    select a.*, row_number() over(partition by cust_seg_sys_id, year_mo order by mbr_cnt desc) as oid
    from (
            select CAST(b.cust_seg_sys_id as INT64) as cust_seg_sys_id
              , CAST(d.year_mo as INT64) as year_mo
              , LOWER(TRIM(CAST(a.co_id_rllp as STRING))) as co_id_rllp
              , LOWER(TRIM(CAST(a.co_nm as STRING))) as co_nm
              , LOWER(TRIM(CAST(c.hlth_pln_fund_cd as STRING))) as hlth_pln_fund_cd
              , lower(trim(c.hlth_pln_fund_cd_desc)) as hlth_pln_fund_cd_desc
              , LOWER(TRIM(CAST(gi.mkt_seg_cd as STRING))) as mkt_seg_cd
              , lower(trim(gi.mkt_seg_rllp_desc)) as mkt_seg_rllp_desc
              , lower(trim(cs.cust_seg_nbr)) as cust_seg_nbr
              , lower(trim(cs.cust_seg_nm)) as cust_seg_nm
              , LOWER(TRIM(CAST(cs.zip_cd as STRING))) as company_zip
              , lower(trim(zp.st_abbr_cd)) as company_st_cd
              , cs.orig_eff_dt
              , Sum(b.mbr_cnt) as mbr_cnt
              , Sum(b.sbscr_cnt ) as sbscr_cnt
              , lower(trim(gs.grp_size_ind)) as grp_size_ind, lower(trim(gs.grp_size_desc)) as grp_size_desc
            from `ds-00-191017.ugap_final.dim_hpdm_company`  a
            inner join `ds-00-191017.ugap_final.fact_hpdm_demographics`     b  on a.co_sys_id = b.co_sys_id
            inner join `ds-00-191017.ugap_final.dim_hpdm_company_code`      c  on c.co_cd_sys_id = b.co_cd_sys_id
            inner join `ds-00-191017.ugap_final.dim_hpdm_date`              d  on d.dt_sys_id = b.dt_sys_id
            inner join `ds-00-191017.ugap_final.dim_hpdm_group_indicator`  gi  on gi.grp_ind_sys_id = b.grp_ind_sys_id
            inner join `ds-00-191017.ugap_final.dim_hpdm_customer_segment` cs  on cs.cust_Seg_Sys_Id = b.cust_Seg_Sys_Id
            inner join `ds-00-191017.ugap_final.dim_hpdm_group_size_indicator` gs on cast(lower(trim(cs.grp_size_ind_sys_id)) as int64) = gs.grp_size_ind_sys_id
            left join `ds-00-191017.ugap_final.dim_hpdm_zip`                zp on lower(trim(cs.zip_cd)) = lower(trim(zp.zip_cd))
            group by b.cust_seg_sys_id, d.year_mo, lower(trim(a.co_id_rllp)), lower(trim(a.co_nm)), lower(trim(c.hlth_pln_fund_cd)), lower(trim(c.hlth_pln_fund_cd_desc)), lower(trim(gi.mkt_seg_cd)), lower(trim(gi.mkt_seg_rllp_desc))
              , lower(trim(cs.cust_seg_nbr)), lower(trim(cs.cust_seg_nm)), lower(trim(cs.zip_cd)), lower(trim(zp.st_abbr_cd)), cs.orig_eff_dt
              , lower(trim(gs.grp_size_ind)), lower(trim(gs.grp_size_desc))
        ) a
  )
select *
from cte_custseg_dtl
where oid = 1
;


create or replace table `research-01-217611.df_ucd_stage.tmp_member_ugap_cte_galaxy`  as
    (
    select *
    from (
           select distinct a.*
              , b.year_mo
              , d.zip_cd, d.st_cd
              , row_number() over(partition by a.savvy_pid, b.year_mo order by a.mbr_sys_id desc) as oid
           --select count(*), count(distinct a.savvy_pid)  --90,199,513,118; 57,657,944
           from (
                  select a.savvy_pid, a.savvy_did, a.is_restricted, a.mbr_sys_id
                    , b.* except(savvy_pid, cust_seg_sys_id)
                    , a.cust_seg_sys_id, a.mbr_cov_mo_row_eff_dt
                    , least(a.mbr_cov_mo_row_end_dt, current_date()) as mbr_cov_mo_row_end_dt
                    , lower(trim(a.src_sys_cd)) as src_sys_cd, lower(trim(a.finc_arng_cd)) as finc_arng_cd
                    , (case when lower(trim(a.finc_arng_cd)) = 'f' then 'fully insured'
                            when lower(trim(a.finc_arng_cd)) = 'a' then 'aso' else null end) as finc_arng_desc
                    , case when (lower(trim(a.rel_cd)) = 'ee') or (lower(trim(a.rel_cd)) = 'un' and a.DEPN_NBR = '000') then 1 else 0 end as sbscr_ind --logic from Karan, 1/22/2021
                    , lower(trim(a.phrm_cov_ind)) as phrm_cov_ind, lower(trim(a.med_cov_ind)) as med_cov_ind, lower(trim(a.med_prdct_1_cd)) as med_prdct_1_cd, lower(trim(a.pln_var_subdiv_cd)) as pln_var_subdiv_cd
                    , lower(trim(a.rpt_cd_br_cd)) as rpt_cd_br_cd, mbr_med_pri_physn_prov_sys_id
                  from `ds-00-191017.galaxy_final.member_coverage_month`                a
                  inner join `research-01-217611.df_ucd_stage.tmp_galaxy_final_member`  b on a.savvy_pid = b.savvy_pid
                                                                                          and a.cust_seg_sys_id = b.cust_seg_sys_id
                  left join `ds-00-191017.galaxy_final.dim_relationship_code`           c on b.rel_cd = lower(trim(c.rel_cd))
                  where (extract(year from a.mbr_cov_mo_row_eff_dt) >= 2016 or extract(year from a.mbr_cov_mo_row_end_dt) >= 2016)
                     --and a.is_restricted = 0
                 ) a
           inner join `research-01-217611.df_ucd_stage.dim_month` b on b.month_midmonth_date between a.mbr_cov_mo_row_eff_dt and a.mbr_cov_mo_row_end_dt --15th of the month
           left join `research-01-217611.df_ucd_stage.tmp_member_month_address_galaxy`    d on a.savvy_pid = d.savvy_pid
                                                                                            and b.year_mo = d.year_mo
           where b.year_nbr >= 2016
          ) x
    where oid = 1
    )
    ;



create or replace table `research-01-217611.df_ucd_stage.tmp_distinct_fact_hpdm_demographics`  as
    /*
    there's a TON of duplication in `ds-00-191017.ugap_final.fact_hpdm_demographics` . Also in dim_hpdm_member, with different mbr_sys_ids, and the net effect is
    a giant cartesian that we then pull back to a single record.

    To handle here, we'll at least start with a "clean" version of fact_hpdm_demographics
    */
    (
    select distinct savvy_pid, dt_sys_id, prdct_sys_id, cust_seg_sys_id
    from `ds-00-191017.ugap_final.fact_hpdm_demographics`
    where savvy_pid > 0
      --and dt.year_nbr >= 2016 --already the case in fact_hpdm_demographics
    )
    ;


create or replace table `research-01-217611.df_ucd_stage.tmp_ugap_cte_mbr`  as
    (
    select *
    from (
           select distinct a.savvy_pid
              , a.savvy_did
              , a.is_restricted_flag as is_restricted
              , cast(dt.year_mo as int64) as year_mo
              , a.bth_dt, extract(year from a.bth_dt) as birth_year, lower(trim(a.sbscr_nbr)) as sbscr_nbr, lower(trim(a.depn_nbr)) as depn_nbr
              , lower(trim(a.rel_cd)) as rel_cd
              , b.cust_seg_sys_id
              , lower(trim(a.src_sys_cd)) as src_sys_cd
              , lower(trim(a.mbr_zip_cd)) as zip_cd
              , lower(trim(e.indus_prdct_cd)) as indus_prdct_cd, lower(trim(e.prdct_cd_desc)) as prdct_cd_desc, lower(trim(e.prdct_lvl_1_nm)) as prdct_lvl_1_nm, lower(trim(e.prdct_lvl_2_nm)) as prdct_lvl_2_nm
              , lower(trim(e.prdct_lvl_3_nm)) as prdct_lvl_3_nm, lower(trim(e.prdct_lvl_4_nm)) as prdct_lvl_4_nm
              , row_number() over(partition by a.savvy_pid, dt.year_mo order by a.mbr_sys_id desc) as oid
           from `ds-00-191017.ugap_final.dim_hpdm_member`                                     a
           inner join `research-01-217611.df_ucd_stage.tmp_distinct_fact_hpdm_demographics`   b on a.savvy_pid = b.savvy_pid
           inner join  `ds-00-191017.ugap_final.dim_hpdm_date`                                dt on b.dt_sys_id = dt.dt_sys_id
           left join `ds-00-191017.ugap_final.dim_hpdm_product`                               e on b.prdct_sys_id = e.prdct_sys_id
           where dt.year_nbr  >= 2016
              --and a.is_restricted_flag = 0
       ) a
    where oid = 1
    )
    ;

  insert into `research-01-217611.df_ucd_stage.udd_member_detail_hpdm`
    (uuid, savvy_pid, savvy_did, is_restricted, src_type, business_line, year_mo, birth_year, gender, death_date, zip, data_source,
      coverage_type, product_id, medicaid_program, cust_seg_nbr, cust_seg_nm, sbscr_nbr, sbscr_ind, family_id, rel_cd, rel_desc, phrm_cov_ind, med_cov_ind,
      co_nm, hlth_pln_fund_cd, finc_arng_cd, finc_arng_desc, contr_nbr, contr_pbp, contr_desc, contr_yr, snp_flag, snp_typ, sub_product, dec_risk_typ, dec_risk_typ_desc,
      mapd_flag, medicare_part_d_only_flag, medicare_advantage_flag, medicaid_flag, original_effective_date, termination_date, reinstatement_date, conversion_date,
      group_type_code, smaindicator, pcp_npi, pcp_comm_prac_id, create_datetime, update_datetime
    )
  select GENERATE_UUID() uuid
      , a.savvy_pid
      , a.savvy_did
      , a.is_restricted
      , 'ugap' as src_type
      , 'commercial' as business_line
      , a.year_mo
      , b.birth_year
      , ifnull(a.gender, '') as gender
      , cast(NULL as date) as death_date
      , ifnull(b.zip_cd, '') as zip
      , 'tops/unet' as data_source  --src_sys_code from the raw fact files
      , '' as coverage_type         --can be derived from dim_coverage_type_code
      , ifnull(b.indus_prdct_cd, '') as product_id
      , '' as medicaid_program
      , ifnull(c.cust_seg_nbr, '') as cust_seg_nbr
      , ifnull(c.cust_seg_nm, '') as cust_seg_nm
      , ifnull(lower(trim(a.sbscr_nbr)), '') as sbscr_nbr
      , ifnull(a.sbscr_ind, -1) sbscr_ind
      , ifnull(a.family_id, 0) family_id
      , ifnull(a.rel_cd, '') as rel_cd
      , ifnull(a.rel_desc, '') as rel_desc
      , ifnull((case when c.hlth_pln_fund_cd = 'fi' then 'y' else a.phrm_cov_ind end), '') as phrm_cov_ind
      , ifnull((case when c.hlth_pln_fund_cd = 'fi' then 'y' else a.med_cov_ind end), '') as med_cov_ind
      , ifnull(c.co_nm, '') as co_nm
      , ifnull(c.hlth_pln_fund_cd, '') as hlth_pln_fund_cd
      , ifnull((case when a.finc_arng_cd = 'f' then 'fi'
                     when a.finc_arng_cd = 'a' then 'aso' else a.finc_arng_cd end), '') as finc_arng_cd
      , ifnull(a.finc_arng_desc, '') as finc_arng_desc
      , '' as contr_nbr
      , '' as contr_pbp
      , '' as contr_desc
      , NULL as contr_yr
      , 0 as snp_flag
      , '' as snp_typ
      , '' as sub_product
      , '' as dec_risk_typ
      , '' as dec_risk_typ_desc
      , 0 as mapd_flag
      , 0 as medicare_part_d_only_flag
      , 0 as medicare_advantage_flag
      , 0 as medicaid_flag
      , c.orig_eff_dt as original_effective_date
      , cast(NULL as date) as termination_date
      , cast(NULL as date) as reinstatement_date
      , cast(NULL as date) as conversion_date
      , '' as group_type_code
      , 0 as smaindicator
      , '' as pcp_npi
      , '' as pcp_comm_prac_id

      , current_datetime as create_datetime
      , current_datetime as update_datetime
  from `research-01-217611.df_ucd_stage.tmp_member_ugap_cte_galaxy`   a
  inner join `research-01-217611.df_ucd_stage.tmp_ugap_cte_mbr`       b on a.savvy_pid = b.savvy_pid and a.year_mo = b.year_mo
  inner join `research-01-217611.df_ucd_stage.tmp_custsegdtl_ugap`    c on b.cust_seg_sys_id = c.cust_seg_sys_id
                                                                        and b.year_mo = c.year_mo
  ;

 --ova
   insert into `research-01-217611.df_ucd_stage.udd_member_detail_ova`
     (uuid, savvy_pid, savvy_did, is_restricted, src_type, business_line, year_mo, birth_year, gender, death_date, zip, data_source,
       coverage_type, product_id, medicaid_program, cust_seg_nbr, cust_seg_nm, sbscr_nbr, sbscr_ind, family_id, rel_cd, rel_desc, phrm_cov_ind, med_cov_ind,
       co_nm, hlth_pln_fund_cd, finc_arng_cd, finc_arng_desc, contr_nbr, contr_pbp, contr_desc, contr_yr, snp_flag, snp_typ, sub_product, dec_risk_typ, dec_risk_typ_desc,
       mapd_flag, medicare_part_d_only_flag, medicare_advantage_flag, medicaid_flag, original_effective_date, termination_date, reinstatement_date, conversion_date,
       group_type_code, smaindicator, pcp_npi, pcp_comm_prac_id, create_datetime, update_datetime
     )
   select GENERATE_UUID() uuid
    , a.* except (oid)
    , current_datetime as create_datetime
    , current_datetime as update_datetime
  from (
          select distinct a.savvy_pid
            , a.savvy_did
            , a.is_restricted_flag as is_restricted
            , 'ugap' as src_type
            , 'medicare' as business_line
            , cast(g.year_mo as int64) as year_mo
            , extract(year from d.bth_dt) as birth_year
            , ifnull(lower(trim(c.mbr_gdr_cd)), '') as gender
            , cast(NULL as date) as death_date  --we can get this from mmr/trr
            , ifnull(lower(trim(d.mbr_zip_cd)), '') as zip
            , ifnull(lower(trim(e.src_sys_desc)), '') as data_source
            , '' as coverage_type
            , ifnull(lower(trim(cmsref.product)), '') as product_id
            , '' as medicaid_program
            , ifnull(lower(trim(i.cust_seg_nbr)), '') as cust_seg_nbr
            , ifnull(lower(trim(i.cust_seg_nm)), '') as cust_seg_nm
            , ifnull(lower(trim(d.sbscr_nbr)), '') as sbscr_nbr
            , 1 as sbscr_ind
            , 0 as family_id
            , ifnull(lower(trim(d.rel_cd)), '') as rel_cd
            , ifnull(lower(trim(rel.rel_desc)), '') as rel_desc
            , (case when lower(trim(cmsref.mapdflag)) = 'y'
                    or (case when trim(lower(cont.contr_Nbr)) <> 'mcaid' and substr(lower(trim(cont.contr_Nbr)),0,1) in ('s') then 1 else 0 end) = 1 then 'y' else '' end) as phrm_cov_ind
            , (case when lower(trim(cmsref.mapdflag)) = 'y'
                    or (case when trim(lower(cont.contr_Nbr)) <> 'mcaid' and substr(lower(trim(cont.contr_Nbr)),0,1) in ('h', 'r') then 1 else 0 end) = 1 then 'y' else '' end) as med_cov_ind
            , '' as co_nm
            , '' as hlth_pln_fund_cd
            , '' as finc_arng_cd
            , '' as finc_arng_desc
            , ifnull(lower(trim(cont.contr_nbr)), '') as contr_nbr
            , ifnull(lower(trim(cont.contr_pbp)), '') as contr_pbp
            , ifnull(lower(trim(cont.contr_desc)), '') as contr_desc
            , cast(cont.contr_yr as int64) as contr_yr
            , if(lower(trim(cmsref.subproduct)) like '%snp%',1,0) as snp_flag
            , ifnull(lower(trim(tadm.snp_typ)), '') as snp_typ
            , ifnull(lower(trim(cmsref.subproduct)), '') as sub_product
            , ifnull(lower(trim(j.risk_typ)), '') as dec_risk_typ
            , ifnull(lower(trim(j.risk_typ_desc)), '') as dec_risk_typ_desc
            , ifnull(case when lower(trim(cmsref.mapdflag)) = 'y' then 1 else 0 end, 0)  as mapd_flag
            , (case when trim(lower(cont.contr_Nbr)) <> 'mcaid' and substr(lower(trim(cont.contr_Nbr)),0,1) in ('s') then 1 else 0 end) as medicare_part_d_only_flag
            , (case when trim(lower(cont.Contr_Nbr)) <> 'mcaid' and substr(lower(trim(cont.Contr_Nbr)),0,1) in ('h', 'r') then 1 else 0 end) as medicare_advantage_flag
            , (case when trim(lower(cont.Contr_Nbr)) = 'mcaid' then 1 else 0 end) as medicaid_flag
            , i.orig_eff_dt as original_effective_date
            , cast(NULL as date) as termination_date
            , cast(NULL as date) as reinstatement_date
            , cast(NULL as date) as conversion_date
            , '' as group_type_code
            , 0 as smaindicator
            , '' as pcp_npi
            , '' as pcp_comm_prac_id
            , row_number() over(partition by a.savvy_pid, g.year_mo order by a.mbr_sys_id desc) as oid
        from `ds-00-191017.ugap_final.fact_ova_demographics`              a
        left join `ds-00-191017.ugap_final.dim_hpdm_member_age_gender`    c on c.mbr_age_gdr_sys_id = a.mbr_age_gdr_sys_id
        left join `ds-00-191017.ugap_final.dim_hpdm_member`               d on d.mbr_sys_id = a.mbr_sys_id
        left join `ds-00-191017.galaxy_final.dim_relationship_code`     rel on lower(trim(d.rel_cd)) = lower(trim(rel.rel_cd))
        left join `ds-00-191017.ugap_final.dim_hpdm_source_system_combo`  e on e.src_sys_combo_sys_id = a.src_sys_combo_sys_id
        left join `ds-00-191017.ugap_final.dim_hpdm_subscriber_county`    f on f.sbscr_cnty_sys_id = a.sbscr_cnty_sys_id
        left join `ds-00-191017.ugap_final.dim_hpdm_date`                 g on g.dt_Sys_Id = a.dt_Sys_Id
        left join `ds-00-191017.ugap_final.dim_hpdm_customer_segment`     i on i.cust_seg_sys_id = a.cust_seg_sys_id
        left join `ds-00-191017.ugap_final.dim_ova_risk_type`             j on j.risk_typ_cd_sys_id = a.dec_risk_typ_sys_id
        left join `ds-00-191017.ugap_final.dim_ova_contract_v2`           cont on cont.contr_sys_id = a.contr_sys_id
                                                                              and substr(a.source_table, -6) = cont.source                /* dim_ova_contract changes each month, so access a version of the dimension table that
                                                                                                                                             was in place at the time this record from fact_ova_demographics was last updated
                                                                                                                                          */
        left join `ds-00-191017.ugap_final.dim_hpdm_zip`                  z on lower(trim(d.mbr_zip_cd)) = lower(trim(z.zip_cd))          -- 9/8/20 added to resolve statecd issue
        left join
                 (
                   with cte_oid as
                     (
                       select *,
                       ROW_NUMBER() over (partition by contr_yr, concat(contr_nbr,"-",contr_pbp),
                                          tadm_cust_seg_nbr order by tadm_prdct_cd) as rownum
                       from `ds-00-191017.ugap_final.dim_ova_tadm_combos`
                     )
                       select * except(rownum) from cte_oid
                       where rownum = 1
                 )   tadm on tadm.contr_yr = cont.contr_yr
                         and concat(lower(trim(tadm.contr_nbr)),"-",lower(trim(tadm.contr_pbp))) = lower(trim(cont.contr_pbp))
                         and lower(trim(tadm.tadm_cust_seg_nbr)) = lower(trim(i.cust_seg_nbr))
        left join
                 (
                   with cte_oid as
                     (
                       select a.*, extract(year from pbpstart) as contr_year,
                       ROW_NUMBER() over (partition by contractpbp, pbpstartyearmo, pbpendyearmo
                                 order by planbenefitpackageid, planbenefitpackagekey, createdate) as rownum
                       from `ds-00-191017.cms_final.refplanbenefitpackage` a
                     )
                       select * except(rownum) from cte_oid
                       where rownum = 1
                 )   cmsref on lower(trim(cmsref.contractpbp)) = lower(trim(cont.contr_pbp))
                           and cont.contr_yr = cmsref.contr_year
        where --a.is_restricted_flag = 0 and
          g.year_nbr >= 2016
      ) a
  where oid = 1
  ;

  --all savers
  --there are still some missing columns (important) from the source/event; ongoing process transition
  insert into `research-01-217611.df_ucd_stage.udd_member_detail_allsavers`
    (uuid, savvy_pid, savvy_did, is_restricted, src_type, business_line, year_mo, birth_year, gender, death_date, zip, data_source,
      coverage_type, product_id, medicaid_program, cust_seg_nbr, cust_seg_nm, sbscr_nbr, sbscr_ind, family_id, rel_cd, rel_desc, phrm_cov_ind, med_cov_ind,
      co_nm, hlth_pln_fund_cd, finc_arng_cd, finc_arng_desc, contr_nbr, contr_pbp, contr_desc, contr_yr, snp_flag, snp_typ, sub_product, dec_risk_typ, dec_risk_typ_desc,
      mapd_flag, medicare_part_d_only_flag, medicare_advantage_flag, medicaid_flag, original_effective_date, termination_date, reinstatement_date, conversion_date,
      group_type_code, smaindicator, pcp_npi, pcp_comm_prac_id, create_datetime, update_datetime
    )
  select
    uuid, savvy_pid, savvy_did, is_restricted, src_type, business_line, year_mo, birth_year, gender, death_date, zip, data_source,
    coverage_type, product_id, medicaid_program, cust_seg_nbr, cust_seg_nm, sbscr_nbr, sbscr_ind, family_id, rel_cd, rel_desc, phrm_cov_ind, med_cov_ind,
    co_nm, hlth_pln_fund_cd, finc_arng_cd, finc_arng_desc, contr_nbr, contr_pbp, contr_desc, contr_yr, snp_flag, snp_typ, sub_product, dec_risk_typ, dec_risk_typ_desc,
    mapd_flag, medicare_part_d_only_flag, medicare_advantage_flag, medicaid_flag, original_effective_date, termination_date, reinstatement_date, conversion_date,
    group_type_code, smaindicator, pcp_npi, pcp_comm_prac_id
    , current_datetime as create_datetime
    , current_datetime as update_datetime
  from  (
           select uuid
            ,savvy_pid
            ,savvy_did
            ,is_restricted
            ,'allsavers' as src_type
            , business_line
            , year_mo
            , birth_year
            , lower(gender) as gender
            , death_date
            , zip
            , 'udw' as data_source
            , coverage_type
            , product_id
            , medicaid_program
           , cust_seg_nbr
           , cust_seg_nm
           , sbscr_nbr
           , sbscr_ind
           , family_id
           , rel_cd
           , rel_desc
           , phrm_cov_ind
           , med_cov_ind
           , co_nm
           , hlth_pln_fund_cd
           , finc_arng_cd
           , finc_arng_desc
           , contr_pbp
           , contr_nbr
           , contr_desc
           , contr_yr
           , snp_flag
          ,  snp_typ
          ,  sub_product
          ,  dec_risk_typ
          ,  dec_risk_typ_desc
          ,  mapd_flag
          ,  medicare_part_d_only_flag
          ,  medicare_advantage_flag
          ,  medicaid_flag
          ,  original_effective_date
          ,  termination_date
          ,  reinstatement_date
          ,  conversion_date
          ,  group_type_code
          ,  smaindicator
          ,  pcp_npi
         ,   pcp_comm_prac_id

  from `research-01-217611.df_ucd_stage.udd_member_detail_udw` udw
  where udw.year_mo >= 201601
  and udw.savvy_pid > 0
  and lower(trim(udw.orig_src_sys_cd)) in ('uho') /*uhops - source for Allsavers members */
  )
  ;

  --UMR added 11-23-2020 by Seth Grossinger
  insert into `research-01-217611.df_ucd_stage.udd_member_detail_umr`
    (uuid, savvy_pid, savvy_did, is_restricted, src_type, business_line, year_mo, birth_year, gender, death_date, zip, data_source,
      coverage_type, product_id, medicaid_program, cust_seg_nbr, cust_seg_nm, sbscr_nbr, sbscr_ind, family_id, rel_cd, rel_desc, phrm_cov_ind, med_cov_ind,
      co_nm, hlth_pln_fund_cd, finc_arng_cd, finc_arng_desc, contr_nbr, contr_pbp, contr_desc, contr_yr, snp_flag, snp_typ, sub_product, dec_risk_typ, dec_risk_typ_desc,
      mapd_flag, medicare_part_d_only_flag, medicare_advantage_flag, medicaid_flag, original_effective_date, termination_date, reinstatement_date, conversion_date,
      group_type_code, smaindicator, pcp_npi, pcp_comm_prac_id, create_datetime, update_datetime
    )
  select
    uuid, savvy_pid, savvy_did, is_restricted, src_type, business_line, year_mo, birth_year, gender, death_date, zip, data_source,
    coverage_type, product_id, medicaid_program, cust_seg_nbr, cust_seg_nm, sbscr_nbr, sbscr_ind, family_id, rel_cd, rel_desc, phrm_cov_ind, med_cov_ind,
    co_nm, hlth_pln_fund_cd, finc_arng_cd, finc_arng_desc, contr_nbr, contr_pbp, contr_desc, contr_yr, snp_flag, snp_typ, sub_product, dec_risk_typ, dec_risk_typ_desc,
    mapd_flag, medicare_part_d_only_flag, medicare_advantage_flag, medicaid_flag, original_effective_date, termination_date, reinstatement_date, conversion_date,
    group_type_code, smaindicator, pcp_npi, pcp_comm_prac_id
    , current_datetime as create_datetime
    , current_datetime as update_datetime
  from  (
        select generate_uuid() as uuid
           , umr.savvy_pid
           , umr.savvy_did
           , umr.is_restricted
           ,'umr' as src_type
           , ifnull(lower(trim(prd.ln_bus_desc)), '') as business_line
           , cast(dt.year_mo as int64) as year_mo
           , extract(year from mbr.bth_dt) as birth_year
           , ifnull(lower(trim(age_gdr.mbr_gdr_cd)), 'u') as gender
           , cast(null as date) as death_date
           , lower(trim(mbr.mbr_zip_cd)) as zip
           , 'udw' as data_source
           , '' coverage_type
           , ifnull(lower(trim(prd.indus_prdct_cd)), '') product_id
           , '' medicaid_program
           , ifnull(lower(trim(cust_seg.cust_seg_nbr)), '') as cust_seg_nbr
           , ifnull(lower(trim(cust_seg.cust_seg_nm)), '') as cust_seg_nm
           , ifnull(lower(trim(mbr.sbscr_nbr)), '') as sbscr_nbr
           , -1 as sbscr_ind --unknown
           , 0 as family_id --unknown
           , ifnull(lower(trim(mbr.rel_cd)), '') as rel_cd
           , ifnull(lower(trim(rel.rel_desc)), '') as rel_desc
           , ifnull(lower(trim(rx_cov.phrm_cov_ind, '')), '') as phrm_cov_ind
           , '' as med_cov_ind
           , '' as co_nm
           , '' as hlth_pln_fund_cd
           , '' as finc_arng_cd
           , '' as finc_arng_desc
           , '' as contr_pbp
           , '' as contr_nbr
           , '' as contr_desc
           , NULL as contr_yr
           , 0 as snp_flag
           , '' as snp_typ
           , '' as sub_product
           , '' as dec_risk_typ
           , '' as dec_risk_typ_desc
           , 0 as mapd_flag
           , 0 as medicare_part_d_only_flag
           , 0 as medicare_advantage_flag
           , 0 as medicaid_flag
           , cust_seg.orig_eff_dt original_effective_date
           , cast(null as date) as termination_date
           , cast(null as date) as reinstatement_date
           , cast(null as date) as conversion_date
           , '' group_type_code
           , 0 smaindicator
           , '' pcp_npi
           , ''  pcp_comm_prac_id
        from `ds-00-191017.umr_final.umr_demographics`                          umr
          join `ds-00-191017.umr_final.hp_date`                                 dt        on umr.dt_sys_id            =   dt.dt_sys_id
          left join `ds-00-191017.umr_final.product`                            prd       on umr.prdct_sys_id         =   prd.prdct_sys_id
          left join `ds-00-191017.umr_final.hp_member`                          mbr       on umr.mbr_sys_id           =   mbr.mbr_sys_id
          left join `ds-00-191017.umr_final.member_age_gender`                  age_gdr   on umr.mbr_age_gdr_sys_id   =   age_gdr.mbr_age_gdr_sys_id
          left join `ds-00-191017.umr_final.customer_segment`                   cust_seg  on umr.cust_seg_sys_id      =   cust_seg.cust_seg_sys_id
          left join `ds-00-191017.galaxy_final.dim_relationship_code`           rel       on lower(trim(mbr.rel_cd))  =   lower(trim(rel.rel_cd))
          left join `ds-00-191017.umr_final.pharmacy_coverage`                  rx_cov    on umr.phrm_cov_sys_id      =   rx_cov.phrm_cov_sys_id
        where dt.year_mo >= '201601'
          and umr.savvy_pid > 0
        )
    ;

  -----------------------
  --build merged member table
  -----------------------
  /* ddl moved to a template */
  insert into `research-01-217611.df_ucd_stage.udd_member_detail_consolidated`
    (uuid, savvy_pid, savvy_did, is_restricted, src_type, business_line, year_mo, birth_year, gender, death_date, zip, data_source,
      coverage_type, product_id, medicaid_program, cust_seg_nbr, cust_seg_nm, sbscr_nbr, sbscr_ind, family_id, rel_cd, rel_desc, phrm_cov_ind, med_cov_ind,
      co_nm, hlth_pln_fund_cd, finc_arng_cd, finc_arng_desc, contr_nbr, contr_pbp, contr_desc, contr_yr, snp_flag, snp_typ, sub_product, dec_risk_typ, dec_risk_typ_desc,
      mapd_flag, medicare_part_d_only_flag, medicare_advantage_flag, medicaid_flag, original_effective_date, termination_date, reinstatement_date, conversion_date,
      group_type_code, smaindicator, pcp_npi, pcp_comm_prac_id, create_datetime, update_datetime
    )
  select uuid, savvy_pid, savvy_did, is_restricted, src_type, business_line, year_mo, birth_year, gender, death_date, zip, data_source, coverage_type, product_id, medicaid_program, cust_seg_nbr, cust_seg_nm, sbscr_nbr, sbscr_ind, family_id, rel_cd, rel_desc
      , phrm_cov_ind, med_cov_ind, co_nm, hlth_pln_fund_cd, finc_arng_cd, finc_arng_desc, contr_nbr, contr_pbp, contr_desc, contr_yr, snp_flag, snp_typ, sub_product, dec_risk_typ, dec_risk_typ_desc, mapd_flag, medicare_part_d_only_flag
      , medicare_advantage_flag, medicaid_flag, original_effective_date, termination_date, reinstatement_date, conversion_date, group_type_code, smaindicator, pcp_npi, pcp_comm_prac_id

      , current_datetime as create_datetime
      , current_datetime as update_datetime
  from  (
            select
              uuid, savvy_pid, savvy_did, is_restricted, src_type, business_line, year_mo, birth_year, gender, death_date, zip, data_source, coverage_type, product_id, medicaid_program, cust_seg_nbr, cust_seg_nm, sbscr_nbr, sbscr_ind, family_id, rel_cd, rel_desc
              , phrm_cov_ind, med_cov_ind, co_nm, hlth_pln_fund_cd, finc_arng_cd, finc_arng_desc, contr_nbr, contr_pbp, contr_desc, contr_yr, snp_flag, snp_typ, sub_product, dec_risk_typ, dec_risk_typ_desc, mapd_flag, medicare_part_d_only_flag
              , medicare_advantage_flag, medicaid_flag, original_effective_date, termination_date, reinstatement_date, conversion_date, group_type_code, smaindicator, pcp_npi, pcp_comm_prac_id
            from `research-01-217611.df_ucd_stage.udd_member_detail_hpdm`

            union all

            select
              uuid, savvy_pid, savvy_did, is_restricted, src_type, business_line, year_mo, birth_year, gender, death_date, zip, data_source, coverage_type, product_id, medicaid_program, cust_seg_nbr, cust_seg_nm, sbscr_nbr, sbscr_ind, family_id, rel_cd, rel_desc
              , phrm_cov_ind, med_cov_ind, co_nm, hlth_pln_fund_cd, finc_arng_cd, finc_arng_desc, contr_nbr, contr_pbp, contr_desc, contr_yr, snp_flag, snp_typ, sub_product, dec_risk_typ, dec_risk_typ_desc, mapd_flag, medicare_part_d_only_flag
              , medicare_advantage_flag, medicaid_flag, original_effective_date, termination_date, reinstatement_date, conversion_date, group_type_code, smaindicator, pcp_npi, pcp_comm_prac_id
            from `research-01-217611.df_ucd_stage.udd_member_detail_galaxy`

            union all

            select
              uuid, savvy_pid, savvy_did, is_restricted, src_type, business_line, year_mo, birth_year, gender, death_date, zip, data_source, coverage_type, product_id, medicaid_program, cust_seg_nbr, cust_seg_nm, sbscr_nbr, sbscr_ind, family_id, rel_cd, rel_desc
              , phrm_cov_ind, med_cov_ind, co_nm, hlth_pln_fund_cd, finc_arng_cd, finc_arng_desc, contr_nbr, contr_pbp, contr_desc, contr_yr, snp_flag, snp_typ, sub_product, dec_risk_typ, dec_risk_typ_desc, mapd_flag, medicare_part_d_only_flag
              , medicare_advantage_flag, medicaid_flag, original_effective_date, termination_date, reinstatement_date, conversion_date, group_type_code, smaindicator, pcp_npi, pcp_comm_prac_id
            from `research-01-217611.df_ucd_stage.udd_member_detail_ova`

            union all

            select
              uuid, savvy_pid, savvy_did, is_restricted, src_type, business_line, year_mo, birth_year, gender, death_date, zip, data_source, coverage_type, product_id, medicaid_program, cust_seg_nbr, cust_seg_nm, sbscr_nbr, sbscr_ind, family_id, rel_cd, rel_desc
              , phrm_cov_ind, med_cov_ind, co_nm, hlth_pln_fund_cd, finc_arng_cd, finc_arng_desc, contr_nbr, contr_pbp, contr_desc, contr_yr, snp_flag, snp_typ, sub_product, dec_risk_typ, dec_risk_typ_desc, mapd_flag, medicare_part_d_only_flag
              , medicare_advantage_flag, medicaid_flag, original_effective_date, termination_date, reinstatement_date, conversion_date, group_type_code, smaindicator, pcp_npi, pcp_comm_prac_id
            from `research-01-217611.df_ucd_stage.udd_member_detail_sma`
            --where savvy_pid = 188815042

            union all

            select
              uuid, savvy_pid, savvy_did, is_restricted, src_type, business_line, year_mo, birth_year, gender, death_date, zip, data_source, coverage_type, product_id, medicaid_program, cust_seg_nbr, cust_seg_nm, sbscr_nbr, sbscr_ind, family_id, rel_cd, rel_desc
              , phrm_cov_ind, med_cov_ind, co_nm, hlth_pln_fund_cd, finc_arng_cd, finc_arng_desc, contr_nbr, contr_pbp, contr_desc, contr_yr, snp_flag, snp_typ, sub_product, dec_risk_typ, dec_risk_typ_desc, mapd_flag, medicare_part_d_only_flag
              , medicare_advantage_flag, medicaid_flag, original_effective_date, termination_date, reinstatement_date, conversion_date, group_type_code, smaindicator, pcp_npi, pcp_comm_prac_id
            from `research-01-217611.df_ucd_stage.udd_member_detail_allsavers`

            union all

            select
              uuid, savvy_pid, savvy_did, is_restricted, src_type, business_line, year_mo, birth_year, gender, death_date, zip, data_source, coverage_type, product_id, medicaid_program, cust_seg_nbr, cust_seg_nm, sbscr_nbr, sbscr_ind, family_id, rel_cd, rel_desc
              , phrm_cov_ind, med_cov_ind, co_nm, hlth_pln_fund_cd, finc_arng_cd, finc_arng_desc, contr_nbr, contr_pbp, contr_desc, contr_yr, snp_flag, snp_typ, sub_product, dec_risk_typ, dec_risk_typ_desc, mapd_flag, medicare_part_d_only_flag
              , medicare_advantage_flag, medicaid_flag, original_effective_date, termination_date, reinstatement_date, conversion_date, group_type_code, smaindicator, pcp_npi, pcp_comm_prac_id
            from `research-01-217611.df_ucd_stage.udd_member_detail_bind`

            union all

            select
              uuid, savvy_pid, savvy_did, is_restricted, src_type, business_line, year_mo, birth_year, gender, death_date, zip, data_source, coverage_type, product_id, medicaid_program, cust_seg_nbr, cust_seg_nm, sbscr_nbr, sbscr_ind, family_id, rel_cd, rel_desc
              , phrm_cov_ind, med_cov_ind, co_nm, hlth_pln_fund_cd, finc_arng_cd, finc_arng_desc, contr_nbr, contr_pbp, contr_desc, contr_yr, snp_flag, snp_typ, sub_product, dec_risk_typ, dec_risk_typ_desc, mapd_flag, medicare_part_d_only_flag
              , medicare_advantage_flag, medicaid_flag, original_effective_date, termination_date, reinstatement_date, conversion_date, group_type_code, smaindicator, pcp_npi, pcp_comm_prac_id
            from `research-01-217611.df_ucd_stage.udd_member_detail_umr`
        )
    -- where is_restricted = 0
  ;

  --if successful, we'll get here!
  insert into `research-01-217611.df_ucd_stage.logging`(
    success_flag, job, message_datetime)
  select
    1 as success_flag
    , 'create member detail tables' as job
    , current_datetime as message_datetime
  ;

  EXCEPTION WHEN ERROR THEN
    insert into `research-01-217611.df_ucd_stage.logging`(
      success_flag, job, error_message, statement_text, formatted_stack_trace, message_datetime)
    select
      0 as success_flag
      , 'create member detail tables' as job
      , @@error.message as error_message
      , @@error.statement_text as statement_text
      , @@error.formatted_stack_trace as formatted_stack_trace
      , current_datetime as message_datetime
    ;

END
;
