
/* Project: Universal Claims Database (UCD )

   Business Partner: Matt Holst

   Input:
      `df_ucd_stage.udd_member_eligibility_index`
      `research-01-217611.df_ucd_stage.dim_date`

   Created By: Seth

   Created Date: 8/19/2020

   Modified By: Dave Corban

   Modified Date: 10/28/2020

   Initial data load


   Granularity:  member, month

*/

BEGIN

  create or replace table `research-01-217611.df_ucd_stage.udw_member_month`

  (   savvy_pid                 int64    OPTIONS(description = "unique (persistent) member identifier")
      , savvy_did                 int64    OPTIONS(description = "unique (periodically updated) member identifier")
      , is_restricted             int64    OPTIONS(description = "1 if member is restricted (i.e., has ever been a UHG employee) and needs to be reported separately; 0 otherwise")

  		, year_mo               int64   OPTIONS(description="Year Month of eligibility(yyyymm)")
      , elig_check_date       date    OPTIONS(description="date of eligibility check")
      , commercial_flag       int64   OPTIONS(description="flag is 1 if member has commercial coverage in year month, 0 otherwise")
      , medicare_flag         int64   OPTIONS(description="flag is 1 if member has medicare coverage in year month, 0 otherwise")
      , medicaid_flag         int64   OPTIONS(description="flag is 1 if member has medicaid coverage in year month, 0 otherwise")
      , dual_flag             int64   OPTIONS(description="flag is 1 if member has dual coverage in year month, 0 otherwise")
      , fi_flag               int64   OPTIONS(description="flag is 1 if member has commercial Fully Insured funding (FI), 0 otherwise")
      , aso_flag              int64   OPTIONS(description="flag is 1 if member has commercial Administrative Services Only funding (ASO), 0 otherwise")
      , mmp_flag              int64   OPTIONS(description="flag is 1 if member has commercial Minimum Premium funding (MMP), 0 otherwise")

  		--metadata columns
  		, create_datetime         datetime   OPTIONS(description="datetime record was created")
  		, update_datetime         datetime   OPTIONS(description="datetime record was updated")
  	)

  OPTIONS(description="summarized membership from UDW")
  AS

  WITH
    MEMBERSHIP AS
      (SELECT
        savvy_pid
        , savvy_did
        , is_restricted
        ,b.year_mo
        ,b.month_midmonth_date as elig_check_date
        ,MAX(CASE WHEN business_line = 'commercial' THEN 1 else 0 END) AS commercial_flag
        ,MAX(CASE WHEN business_line = 'medicare'   THEN 1 else 0 END) AS medicare_flag
        ,MAX(CASE WHEN business_line = 'medicaid'   THEN 1 else 0 END) AS medicaid_flag
        ,MAX(CASE WHEN business_line = 'dual'       THEN 1 else 0 END) AS dual_flag
        ,MAX(CASE WHEN business_line = 'commercial' AND finc_arng_desc = 'fi'   THEN 1 else 0 END) AS fi_flag
        ,MAX(CASE WHEN business_line = 'commercial' AND finc_arng_desc = 'aso'  THEN 1 else 0 END) AS aso_flag
        ,MAX(CASE WHEN business_line = 'commercial' AND finc_arng_desc = 'mmp'  THEN 1 else 0 END) AS mmp_flag
      FROM `research-01-217611.df_ucd_stage.udd_member_eligibility_index`   a
        join `research-01-217611.df_ucd_stage.dim_month`        b on b.month_midmonth_date BETWEEN cov_eff_dt AND cov_expir_dt --table created in the udd_member_detail_udw script
      WHERE b.month_midmonth_date between '2016-01-01' and current_date()
      GROUP BY savvy_pid, savvy_did, is_restricted, year_mo, elig_check_date
      --ORDER BY savvy_pid , year_mo
      )
  SELECT savvy_pid, savvy_did, is_restricted, year_mo, elig_check_date, commercial_flag, medicare_flag, medicaid_flag, dual_flag, fi_flag, aso_flag, mmp_flag
      ,current_datetime() as create_datetime
      ,current_datetime() as update_datetime
  FROM MEMBERSHIP
  ;

  --if successful, we'll get here!
  insert into `research-01-217611.df_ucd_stage.logging`(
    success_flag, job, message_datetime)
  select
    1 as success_flag
    , 'load df_ucd_stage.udw_member_month' as job
    , current_datetime as message_datetime
  ;

  EXCEPTION WHEN ERROR THEN
    insert into `research-01-217611.df_ucd_stage.logging`(
      success_flag, job, error_message, statement_text, formatted_stack_trace, message_datetime)
    select
      0 as success_flag
      , 'load df_ucd_stage.udw_member_month' as job
      , @@error.message as error_message
      , @@error.statement_text as statement_text
      , @@error.formatted_stack_trace as formatted_stack_trace
      , current_datetime as message_datetime
    ;

END
;
