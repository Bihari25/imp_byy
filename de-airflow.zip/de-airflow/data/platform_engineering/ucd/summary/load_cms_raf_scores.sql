/*
 Purpose         : To calculate medicare RAF score and HCCs for rolling 12 months period (Scoring period of 12 months)
 Granularity     : 1 row per member per month (with all months in scoring period where member was enrolled)
 Timeline        : 2016 onwards
 Input table/s   : df_ucd_stage.dim_month
                 : df_ucd_stage.udd_member_detail_consolidated
                 : df_ucd.medical_claim

                 --CMS RAF reference tables:

                 : df_enrichment.cms_raf_reportable_physician_procedure_code_updated
                 : df_enrichment.cms_raf_model
                 : df_enrichment.cms_raf_identify_disabled_hcc_interaction_term
                 : df_enrichment.cms_raf_identify_hcc_v22
                 : df_enrichment.cms_raf_identify_hcc_hierarchy
                 : df_enrichment.cms_raf_identify_hcc_interaction_cat
                 : df_enrichment.cms_raf_identify_interaction_term
                 : df_enrichment.cms_raf_identify_interaction_term_hierarchy
                 : df_enrichment.cms_raf_identify_interaction_term_reqd_cnt
                 : df_enrichment.cms_raf_model_demog_term

 Output table/s  : df_ucd_stage.cms_raf_scores

***Based on code for commercial RAF score calculation***
--https://code.savvysherpa.com/smehle/Universal-Data-Claims-Task-Force/blob/master/raf/raf_cms.sql
--https://code.savvysherpa.com/smehle/Snippets/tree/master/Methods/MedicareRAF

 Total run time: 30 min

*/

BEGIN

  DECLARE themodel INT64 DEFAULT 31;  /* 31 is model id for 2016 community model; see df_enrichment.cms_raf_model table to identify the model id*/

  /* ---------------------------------------------------------------------------------------------------------------------------- */
  /* ---------------- Step 1: Creating table with scoring month and start and end dates for the scoring period ------------------ */
  /* ---------------------------------------------------------------------------------------------------------------------------- */
  -- wkg_cms_raf_date_range_rolling_12_month_periods: replaced by wkg_date_range_rolling_12_month_periods

  /* ---------------------------------------------------------------------------------------------------------------------------- */
  /* ------- Step 2: Creating member month table with all the months in scoring period where member was enrolled ---------------- */
  /* -------------- along with start and end dates, total months enrolled during the scoring period ----------------------------- */
  /* ---------------------------------------------------------------------------------------------------------------------------- */
  -- wkg_cms_raf_person: replaced by wkg_summary_member_scoring_period

  /* ---------------------------------------------------------------------------------------------------------------------------- */
  /* -------------------- Step 3: All diagnosis codes for every member during the rolling 12 month time frame ------------------- */
  /* ---------------------------------------------------------------------------------------------------------------------------- */
  -- wkg_cms_raf_diag`: replaced by wkg_summary_member_diag_scoring_period


  /* ---------------------------------------------------------------------------------------------------------------------------- */
  /* ------------- Step 4: Flag for whether a member had claims during the rolling 12 months for each score month  -------------- */
  /* ---------------------------------------------------------------------------------------------------------------------------- */
  -- had_claim_during_scoring_period_flag added to wkg_summary_member_scoring_period


  /* ---------------------------------------------------------------------------------------------------------------------------- */
  /* ---------------------------------- Step 5: Get the HCC and HCC coefficient ------------------------------------------------- */
  /* ---------------------------------------------------------------------------------------------------------------------------- */
  --21.8 sec

  create or replace table `research-01-217611.df_ucd_stage.wkg_cms_raf_hcc` AS
  select distinct diag.savvy_pid, diag.score_year_mo, hcc.model_id
                /* Reset of CCs that is based on beneficiary age or sex, see V2210ED1.txt in 2016 model software */
                , case when mm.gender_cd = 'f' and icd_cd in ('d66', 'd67') then 48
                       when mm.age_last < 18 and icd_cd in ('j410', 'j411', 'j418', 'j42', 'j430', 'j431', 'j432', 'j438', 'j439', 'j440', 'j441', 'j449', 'j982', 'j983') then 112
                  else hcc.hcc_nbr
                  end as hcc_nbr
                , hcc.coefficient
  from `research-01-217611.df_ucd_stage.wkg_summary_member_diag_scoring_period`   as diag
    join `research-01-217611.df_ucd_stage.wkg_summary_member_scoring_period`      as mm     on diag.savvy_pid       =   mm.savvy_pid
                                                                                            and diag.score_year_mo  =   mm.score_year_mo
    join `research-01-217611.df_enrichment.cms_raf_identify_hcc_v22`              as hcc    on diag.diag_cd         =   hcc.icd_cd
                                                                                            and diag.icd_ver_cd     =   hcc.icd_ver_cd
                                                                                            and hcc.model_id        =   themodel
  where diag.cms_eligible_encounter_flag = 1
  ;

  /* Note: There is a step in V2210ED1.txt where we look at the age or sex for a beneficiary to see within the range of acceptable age/sex, if not then CC is set to -1.0 i.e. invalid */
  /* However, we haven't included that calculation as the part of the code */


  /* ---------------------------------------------------------------------------------------------------------------------------- */
  /* --------------Step 6: Remove lower tier HCCs for related illnesses for each member score month ----------------------------- */
  /* ---------------------------------------------------------------------------------------------------------------------------- */
  --45.4 sec

  create or replace table `research-01-217611.df_ucd_stage.wkg_cms_raf_hcc_no_child_hcc` as  --tmp b

  with remove as (select b.savvy_pid, b.score_year_mo, a.model_id, a.child_hcc_nbr
                  from `research-01-217611.df_enrichment.cms_raf_identify_hcc_hierarchy`   a
                  inner join `research-01-217611.df_ucd_stage.wkg_cms_raf_hcc`             b     on  a.model_id        = b.model_id
                                                                                                and a.parent_hcc_nbr  = b.hcc_nbr
                  )

  select distinct a.savvy_pid, a.score_year_mo, a.model_id, a.hcc_nbr, a.coefficient
  from `research-01-217611.df_ucd_stage.wkg_cms_raf_hcc`  as a
  left join  remove                                       as r  on a.savvy_pid        =   r.savvy_pid
                                                                and a.score_year_mo   =   r.score_year_mo
                                                                and a.hcc_nbr         =   r.child_hcc_nbr
                                                                and a.model_id        =   r.model_id
  where r.model_id is null
  ;

  /* ---------------------------------------------------------------------------------------------------------------------------- */
  /* -------------------------- Step 7:  Gathers the interaction categories between the HCCs  ----------------------------------- */
  /* ---------------------------------------------------------------------------------------------------------------------------- */
  --33.1 sec

  create or replace table `research-01-217611.df_ucd_stage.wkg_cms_raf_interaction_category` AS   --tmp c

  select distinct hcc.savvy_pid, hcc.score_year_mo, hcc.model_id, cat.interaction_cat
  from `research-01-217611.df_ucd_stage.wkg_cms_raf_hcc_no_child_hcc`                    hcc
  inner join `research-01-217611.df_enrichment.cms_raf_identify_hcc_interaction_cat`     cat on  hcc.model_id  = cat.model_id
                                                                                            and hcc.hcc_nbr   = cat.hcc_nbr

  ;

  /* ---------------------------------------------------------------------------------------------------------------------------- */
  /* ----------------- Step 8:  Maps each interaction category to the appropriate interaction term used later ------------------- */
  /* ---------------------------------------------------------------------------------------------------------------------------- */
  --39.6 sec

  create or replace table `research-01-217611.df_ucd_stage.wkg_cms_raf_interaction_term` as   --tmp d

  select distinct cat.savvy_pid, cat.score_year_mo, cat.model_id, cat.interaction_cat, term.interaction_term
  from `research-01-217611.df_ucd_stage.wkg_cms_raf_interaction_category`          as cat
  inner join `research-01-217611.df_enrichment.cms_raf_identify_interaction_term`  as term   on cat.interaction_cat = term.interaction_cat
                                                                                            and cat.model_id       = term.model_id
  ;


  /* ---------------------------------------------------------------------------------------------------------------------------- */
  /*  Step 9:  Counts the the interaction categories in order to make sure they are appropriate for the found interaction terms.  */
  /* -------------------------------------  This helps qualify the terms for use. ----------------------------------------------- */
  /* ---------------------------------------------------------------------------------------------------------------------------- */
  --28.3 sec

  create or replace table `research-01-217611.df_ucd_stage.wkg_cms_raf_interaction_term_coeff` as  --tmp e

  with interaction_cat_cnt as
      (select savvy_pid, score_year_mo, model_id, interaction_term, count(distinct interaction_cat) AS reqd_distinct_interaction_cat_cnt
       from `research-01-217611.df_ucd_stage.wkg_cms_raf_interaction_term`
       group by savvy_pid, score_year_mo, model_id, interaction_term
       )

  select distinct catcnt.savvy_pid, catcnt.score_year_mo, catcnt.model_id, catcnt.interaction_term, reqcnt.coefficient
  from interaction_cat_cnt                                                           as catcnt
  join `research-01-217611.df_enrichment.cms_raf_identify_interaction_term_reqd_cnt` as reqcnt     on  catcnt.model_id                           = reqcnt.model_id
                                                                                                   and catcnt.interaction_term                   = reqcnt.interaction_term
                                                                                                   and catcnt.reqd_distinct_interaction_cat_cnt  = reqcnt.reqd_distinct_interaction_cat_cnt
  ;


  /* ---------------------------------------------------------------------------------------------------------------------------- */
  /* --------------Step 10:  Remove all child interaction terms. We only want to use parent term for calculation ----------------- */
  /* ---------------------------------------------------------------------------------------------------------------------------- */
  --31.6 sec

  create or replace table `research-01-217611.df_ucd_stage.wkg_cms_raf_interaction_term_coeff_no_child_term` as  --tmp f

  with remove as
     (select term.savvy_pid, term.score_year_mo, term_hier.model_id, term_hier.interaction_term_child
      from `research-01-217611.df_enrichment.cms_raf_identify_interaction_term_hierarchy` as term_hier
      inner join `research-01-217611.df_ucd_stage.wkg_cms_raf_interaction_term_coeff`     as term      on term_hier.model_id                 = term.model_id
                                                                                                       and term_hier.interaction_term_parent = term.interaction_term
      )

  select distinct term.savvy_pid, term.score_year_mo, term.model_id, term.interaction_term, term.coefficient
  from `research-01-217611.df_ucd_stage.wkg_cms_raf_interaction_term_coeff`   term
  left join remove                                                            r      on   term.savvy_pid        = r.savvy_pid
                                                                                     and  term.score_year_mo    = r.score_year_mo
                                                                                     and  term.interaction_term = r.interaction_term_child
                                                                                     and  term.model_id         = r.model_id
  where r.model_id is null
  ;


  /* ---------------------------------------------------------------------------------------------------------------------------- */
  /* ---------------- Step 11:  Create the RAF score by adding coefficients together based on previous steps. -------------------- */
  /* ---------------------------------------------------------------------------------------------------------------------------- */
  --35.4 sec

  create or replace table `research-01-217611.df_ucd_stage.wkg_cms_raf_total_hcc_coefficient` AS  --tmp g

  with total_coefficients_based_on_hcc_and_interaction AS
    (select savvy_pid, score_year_mo, model_id, sum(Coefficient) AS raf
     from (select savvy_pid, score_year_mo, model_id, coefficient
           from `research-01-217611.df_ucd_stage.wkg_cms_raf_hcc_no_child_hcc`
           union all
           select savvy_pid, score_year_mo, model_id, coefficient
           from `research-01-217611.df_ucd_stage.wkg_cms_raf_interaction_term_coeff_no_child_term`
           )
     group by savvy_pid, score_year_mo, model_id
     )


  select savvy_pid, score_year_mo, model_id, raf
  from total_coefficients_based_on_hcc_and_interaction

  union all
  ----This script also adds 0.00 rows for diagnoses that do not factor into the sum.
  select qry.savvy_pid, qry.score_year_mo, qry.model_id, 0.000 AS raf
  from (select distinct savvy_pid, score_year_mo, all_models.model_id
        from `research-01-217611.df_ucd_stage.wkg_summary_member_diag_scoring_period` AS diag
        cross join (select distinct model_id
                    from `research-01-217611.df_enrichment.cms_raf_model` raf_model
                    where model_id = themodel and blended_model_id is not null
                    ) AS all_models
        where diag.cms_eligible_encounter_flag = 1
       ) AS qry
  left join total_coefficients_based_on_hcc_and_interaction  totcoef on qry.savvy_pid       =   totcoef.savvy_pid
                                                                    and qry.score_year_mo   =   totcoef.score_year_mo
                                                                    and qry.model_id        =   totcoef.model_id
  where totcoef.savvy_pid is null
  ;



  /* ---------------------------------------------------------------------------------------------------------------------------- */
  /* --------- Step 12:  Create derived disability AND original disease variables which correspond with OREC AND model. ---------- */
  /* ---------------------------------------------------------------------------------------------------------------------------- */
  --38.7 sec

  --This will affect the coefficients used in RAF calculations.

  CREATE OR REPLACE TABLE `research-01-217611.df_ucd_stage.wkg_cms_raf_derived_demographics` AS   --tmp h

  SELECT qry.savvy_pid, qry.score_year_mo, qry.age, qry.gender_cd, qry.mcaid, qry.nemcaid, qry.orec, qry.disabl, qry.model_id, qry.model_ver
        , case when qry.model_ver = 12 AND qry.disabl = 0 AND CAST(qry.OREC AS INT64) IN (1,3) then 1
               when qry.model_ver = 22 AND qry.disabl = 0 AND CAST(qry.OREC AS INT64) = 1 then 1
               else 0
          end as origds
  FROM (select mbr.savvy_pid, mbr.score_year_mo, mbr.age_last as age, mbr.gender_cd, mbr.mcaid, mbr.nemcaid, mbr.orec
              , case when mbr.age_last between 0 and 64 and CAST(orec as int64) between 1 and 3 then 1
                    else 0
                    end as disabl
              , raf.model_id
              , raf.model_ver
        from `research-01-217611.df_ucd_stage.wkg_summary_member_scoring_period`  as mbr
        cross join (select themodel as model_id)                                  as getmodel
        join `research-01-217611.df_enrichment.cms_raf_model`                     as raf on getmodel.model_id = raf.model_id
        where model_ver is not null
        ) AS qry
  ;



  /* ---------------------------------------------------------------------------------------------------------------------------- */
  /* -------------------- Step 13:  Identifies relevant demographic information for use in the calculation ---------------------- */
  /* ---------------------------------------------------------------------------------------------------------------------------- */
  --1 min 7 sec

  create or replace table `research-01-217611.df_ucd_stage.wkg_cms_raf_demo_coefficient` as  ---tmp i

  select distinct raf.savvy_pid, raf.score_year_mo, demog_term.model_id, demog_term.model_demog_term, demog_term.coefficient
  from `research-01-217611.df_ucd_stage.wkg_cms_raf_derived_demographics`  as raf
  inner join `research-01-217611.df_enrichment.cms_raf_model_demog_term`   as demog_term on raf.gender_cd    =   demog_term.gender_cd
                                                                                        and raf.age between demog_term.age_start AND demog_term.age_end
                                                                                        and raf.model_id    =   demog_term.model_id
  where demog_term.model_demog_term_type = 'agegender'

  union distinct

  select distinct raf.savvy_pid, raf.score_year_mo, demog_term.model_id, demog_term.model_demog_term, demog_term.Coefficient
  from `research-01-217611.df_ucd_stage.wkg_cms_raf_derived_demographics`  as raf
  inner join `research-01-217611.df_enrichment.cms_raf_model_demog_term`   as demog_term  on raf.gender_cd             =   demog_term.gender_cd
                                                                                         and raf.age between demog_term.age_start AND demog_term.age_end
                                                                                         and cast(raf.orec as int64)  =   cast(demog_term.orec as int64)
                                                                                         and raf.mcaid                =   cast(demog_term.mcaid as int64)
                                                                                         and raf.disabl               =   cast(demog_term.disabl as int64)
                                                                                         and raf.origds               =   cast(demog_term.origds as int64)
                                                                                         and raf.nemcaid              =   cast(demog_term.nemcaid as int64)
                                                                                         and raf.model_id             =   demog_term.model_id
  WHERE demog_term.model_demog_term_type = 'other';




  /* ---------------------------------------------------------------------------------------------------------------------------- */
  /* ----------------------- Step 14:  Identifies all necessary disability interactions for the HCCs ---------------------------- */
  /* ---------------------------------------------------------------------------------------------------------------------------- */
  --2.2 sec

  create or replace table `research-01-217611.df_ucd_stage.wkg_cms_raf_disability_hcc_interaction` as   --tmp j

  select distinct demo.savvy_pid, demo.score_year_mo, hcc_term.model_id, hcc_term.disabled_hcc_interaction_term, hcc_term.Coefficient
  from `research-01-217611.df_ucd_stage.wkg_cms_raf_derived_demographics`                as demo  --tmp h
  join `research-01-217611.df_ucd_stage.wkg_cms_raf_hcc_no_child_hcc`                    as hcc        on  demo.savvy_pid     = hcc.savvy_pid
                                                                                                      and demo.score_year_mo = hcc.score_year_mo
  join `research-01-217611.df_enrichment.cms_raf_identify_disabled_hcc_interaction_term` as hcc_term   on  hcc.model_id       = hcc_term.model_id
                                                                                                      and  hcc.hcc_nbr        = hcc_term.hcc_nbr
                                                                                                      and  hcc_term.model_id  = themodel
  WHERE demo.disabl = 1;



  /* ---------------------------------------------------------------------------------------------------------------------------- */
  /* -Step 15: Calculates total raf based on demographics, HCC, and demographic-HCC interaction before factoring blending models- */
  /* ---------------------------------------------------------------------------------------------------------------------------- */
  --1 min 12 sec

  create or replace table `research-01-217611.df_ucd_stage.wkg_cms_raf_total_score_before_factoring_blending` as

  with demo_raf as
    (select savvy_pid, score_year_mo, model_id, sum(coefficient) AS demog_raf
     from `research-01-217611.df_ucd_stage.wkg_cms_raf_demo_coefficient`
     group by savvy_pid, score_year_mo, model_id
     )

  , demo_hcc_interaction_raf as
    (select savvy_pid, score_year_mo, model_id, sum(coefficient) AS demog_x_hcc_raf
     from `research-01-217611.df_ucd_stage.wkg_cms_raf_disability_hcc_interaction`
     group by savvy_pid, score_year_mo, model_id
     )

  , cteMembers as
    (select savvy_pid, score_year_mo, model_id
     from demo_raf
     union distinct
     select savvy_pid, score_year_mo, model_id
     from demo_hcc_interaction_raf
     union distinct
     select savvy_pid, score_year_mo, model_id
     from `research-01-217611.df_ucd_stage.wkg_cms_raf_total_hcc_coefficient`
     )


    select mem.savvy_pid, mem.score_year_mo, mem.model_id
                      , ifnull(demoraf.demog_raf, 0) as demog_raf, ifnull(hccraf.RAF, 0) AS hcc_raf
                      , case when demoraf.demog_raf + hccraf.RAF is not null then ifnull(demohccraf.demog_x_hcc_raf,0)
                             else demohccraf.demog_x_hcc_raf
                        end AS demog_x_hcc_raf
                      , ifnull(demoraf.demog_raf,0) + ifnull(hccraf.RAF,0) + ifnull(demohccraf.demog_x_hcc_raf,0) AS total_raf
    from cteMembers                                                                 mem
    left join demo_raf                                                              demoraf     on  mem.savvy_pid       =   demoraf.savvy_pid
                                                                                                and mem.score_year_mo   =   demoraf.score_year_mo
                                                                                                and mem.model_id        =   demoraf.model_id
    left join demo_hcc_interaction_raf                                              demohccraf  on  mem.savvy_pid       =   demohccraf.savvy_pid
                                                                                                and mem.score_year_mo   =   demohccraf.score_year_mo
                                                                                                and mem.model_id        =   demohccraf.model_id
    left join `research-01-217611.df_ucd_stage.wkg_cms_raf_total_hcc_coefficient`   hccraf      on  mem.savvy_pid       =   hccraf.savvy_pid
                                                                                                and mem.score_year_mo   =   hccraf.score_year_mo
                                                                                                and mem.model_id        =   hccraf.model_id

  ;

  /* ---------------------------------------------------------------------------------------------------------------------------- */
  /* ----------------------- Step 16:  Finalizes RAF by factoring in blended models --------------------------------------------- */
  /* ---------------------------------------------------------------------------------------------------------------------------- */

  create or replace table `research-01-217611.df_ucd_stage.wkg_cms_raf_total_score_after_factoring_blending` as

  select savvy_pid, score_year_mo, model_id, demog_raf, hcc_raf, demog_x_hcc_raf, total_raf
  from `research-01-217611.df_ucd_stage.wkg_cms_raf_total_score_before_factoring_blending`

  union distinct

  ----This dataset does all the calculation required at the version level. But, needs to join to the Model record to get CodingIntensity value and subtract that value.
  select mbrCalc.savvy_pid, mbrcalc.score_year_mo, MbrCalc.model_id
                          , MbrCalc.demog_raf * (1-CIF.coding_intensity_factor) AS demog_raf
                          , MbrCalc.hcc_raf * (1-CIF.coding_intensity_factor) AS hcc_raf
                          , MbrCalc.demog_x_hcc_raf * (1-CIF.coding_intensity_factor) AS demog_x_hcc_raf
                          , MbrCalc.total_raf * (1-CIF.coding_intensity_factor) AS total_raf
  from (--Subquery A is the check to determine if we need to do a Blended Processing and pulls the necessary attributes for doing the blending if needed.
        select b.savvy_pid, b.score_year_mo, themodel AS model_id
                          , sum((b.demog_raf/a.normalization_factor)*a.blended_share) AS demog_raf
                          , sum((b.hcc_raf/a.normalization_factor)*a.blended_share) AS hcc_raf
                          , sum((b.demog_x_hcc_raf/a.normalization_factor)*a.blended_share) AS demog_x_hcc_raf
                          , sum((b.total_raf/a.normalization_factor)*a.blended_share) AS total_raf
        from (select distinct *
              from `research-01-217611.df_enrichment.cms_raf_model`
              where blended_model_id = (select model_id   --Return a record if blended processing is required.
                                        from `research-01-217611.df_enrichment.cms_raf_model`
                                        where blended_model_id is null
                                          and model_ver is null
                                          and model_id = themodel
                                          )
              ) as a
        inner join `research-01-217611.df_ucd_stage.wkg_cms_raf_total_score_before_factoring_blending`   b on a.model_id = b.model_id
        group by b.savvy_pid, b.score_year_mo
        ) MbrCalc
  inner join `research-01-217611.df_enrichment.cms_raf_model` CIF on MbrCalc.model_id = CIF.model_id;


  /* ---------------------------------------------------------------------------------------------------------------------------- */
  /* ------------------------------- Step 17:  Creating table with all model terms ---------------------------------------------- */
  /* ---------------------------------------------------------------------------------------------------------------------------- */

  -- Creates final table of HCC with one row per member per HCC term.

  create or replace table `research-01-217611.df_ucd_stage.wkg_cms_raf_all_model_terms` as

  select sub.*
    , mdl.payment_yr AS model_payment_yr
    , mdl.model_name
  from (select a.savvy_pid, a.score_year_mo, a.model_id
              , concat('hcc',cast(a.hcc_nbr as string)) AS Term
              , a.coefficient
              , case when b.model_id is not null then 1 else 0 end as used_in_calc_flag
        from `research-01-217611.df_ucd_stage.wkg_cms_raf_hcc`                   as a
        left join `research-01-217611.df_ucd_stage.wkg_cms_raf_hcc_no_child_hcc` as b on  a.savvy_pid      = b.savvy_pid
                                                                                     and a.score_year_mo  = b.score_year_mo
                                                                                     and a.model_id       = b.model_id
                                                                                     and a.hcc_nbr        = b.hcc_nbr
        union all

        select a.savvy_pid, a.score_year_mo, a.model_id
              , cast(a.interaction_term as string) AS Term
              , a.coefficient
              , case when b.model_id is not null then 1 else 0 end as used_in_calc_flag
        from `research-01-217611.df_ucd_stage.wkg_cms_raf_interaction_term_coeff`                     as a
        left join `research-01-217611.df_ucd_stage.wkg_cms_raf_interaction_term_coeff_no_child_term`  as b    on  a.savvy_pid        = b.savvy_pid
                                                                                                             and a.score_year_mo    = b.score_year_mo
                                                                                                             and a.interaction_term = b.interaction_term
        union all

        select savvy_pid, score_year_mo, model_id, model_demog_term AS Term, coefficient, 1 AS used_in_calc_flag
        FROM `research-01-217611.df_ucd_stage.wkg_cms_raf_demo_coefficient`

        union all

        select savvy_pid, score_year_mo, model_id, disabled_hcc_interaction_term AS Term, coefficient, 1 AS used_in_calc_flag
        FROM `research-01-217611.df_ucd_stage.wkg_cms_raf_disability_hcc_interaction`

        )                                                   sub
      join `research-01-217611.df_enrichment.cms_raf_model` mdl on sub.model_id = mdl.model_id

  ;

  /* ---------------------------------------------------------------------------------------------------------------------------- */
  /* ------------ Step 18:  Finally creating RAF scores with all the required fields and their descriptions --------------------- */
  /* ---------------------------------------------------------------------------------------------------------------------------- */
  --2min 20 sec

  insert into `research-01-217611.df_ucd_stage.cms_raf_scores`
    (savvy_pid, savvy_did, is_restricted, score_year_mo, scoring_period_start_date, scoring_period_end_date, mm_enrolled_during_scoring_period, last_year_mo_enrolled_during_scoring_period, had_claim_during_scoring_period_flag, gender, age, raf, hcc001, hcc002, hcc006, hcc008, hcc009, hcc010, hcc011, hcc012, hcc017, hcc018, hcc019, hcc021, hcc022, hcc023, hcc027, hcc028, hcc029, hcc033, hcc034, hcc035, hcc039, hcc040, hcc046, hcc047, hcc048, hcc051, hcc052, hcc054, hcc055, hcc056, hcc057, hcc058, hcc059, hcc060, hcc070, hcc071, hcc072, hcc073, hcc074, hcc075, hcc076, hcc077, hcc078, hcc079, hcc080, hcc082, hcc083, hcc084, hcc085, hcc086, hcc087, hcc088, hcc096, hcc099, hcc100, hcc103, hcc104, hcc106, hcc107, hcc108, hcc110, hcc111, hcc112, hcc114, hcc115, hcc122, hcc124, hcc134, hcc135, hcc136, hcc137, hcc138, hcc157, hcc158, hcc159, hcc161, hcc162, hcc166, hcc167, hcc169, hcc170, hcc173, hcc176, hcc186, hcc188, hcc189, model_id, model_payment_yr, model_name
    )

    SELECT mbr.savvy_pid,mbr.savvy_did,mbr.is_restricted,mbr.score_year_mo, mbr.scoring_period_start_date, mbr.scoring_period_end_date
                        ,mbr.mm_enrolled_during_scoring_period, mbr.last_year_mo_enrolled_during_scoring_period
                        ,mbr.had_claim_during_scoring_period_flag
                        ,mbr.gender_cd as gender
                        ,mbr.age_last as age
                        ,round(coalesce(raf.total_raf,0),3) as raf
                        ,MAX(CASE WHEN fact.hcc_nbr = 1 THEN 1 ELSE 0 END) AS hcc001
                        ,MAX(CASE WHEN fact.hcc_nbr = 2 THEN 1 ELSE 0 END) AS hcc002
                        ,MAX(CASE WHEN fact.hcc_nbr = 6 THEN 1 ELSE 0 END) AS hcc006
                        ,MAX(CASE WHEN fact.hcc_nbr = 8 THEN 1 ELSE 0 END) AS hcc008
                        ,MAX(CASE WHEN fact.hcc_nbr = 9 THEN 1 ELSE 0 END) AS hcc009
                        ,MAX(CASE WHEN fact.hcc_nbr = 10 THEN 1 ELSE 0 END) AS hcc010
                        ,MAX(CASE WHEN fact.hcc_nbr = 11 THEN 1 ELSE 0 END) AS hcc011
                        ,MAX(CASE WHEN fact.hcc_nbr = 12 THEN 1 ELSE 0 END) AS hcc012
                        ,MAX(CASE WHEN fact.hcc_nbr = 17 THEN 1 ELSE 0 END) AS hcc017
                        ,MAX(CASE WHEN fact.hcc_nbr = 18 THEN 1 ELSE 0 END) AS hcc018
                        ,MAX(CASE WHEN fact.hcc_nbr = 19 THEN 1 ELSE 0 END) AS hcc019
                        ,MAX(CASE WHEN fact.hcc_nbr = 21 THEN 1 ELSE 0 END) AS hcc021
                        ,MAX(CASE WHEN fact.hcc_nbr = 22 THEN 1 ELSE 0 END) AS hcc022
                        ,MAX(CASE WHEN fact.hcc_nbr = 23 THEN 1 ELSE 0 END) AS hcc023
                        ,MAX(CASE WHEN fact.hcc_nbr = 27 THEN 1 ELSE 0 END) AS hcc027
                        ,MAX(CASE WHEN fact.hcc_nbr = 28 THEN 1 ELSE 0 END) AS hcc028
                        ,MAX(CASE WHEN fact.hcc_nbr = 29 THEN 1 ELSE 0 END) AS hcc029
                        ,MAX(CASE WHEN fact.hcc_nbr = 33 THEN 1 ELSE 0 END) AS hcc033
                        ,MAX(CASE WHEN fact.hcc_nbr = 34 THEN 1 ELSE 0 END) AS hcc034
                        ,MAX(CASE WHEN fact.hcc_nbr = 35 THEN 1 ELSE 0 END) AS hcc035
                        ,MAX(CASE WHEN fact.hcc_nbr = 39 THEN 1 ELSE 0 END) AS hcc039
                        ,MAX(CASE WHEN fact.hcc_nbr = 40 THEN 1 ELSE 0 END) AS hcc040
                        ,MAX(CASE WHEN fact.hcc_nbr = 46 THEN 1 ELSE 0 END) AS hcc046
                        ,MAX(CASE WHEN fact.hcc_nbr = 47 THEN 1 ELSE 0 END) AS hcc047
                        ,MAX(CASE WHEN fact.hcc_nbr = 48 THEN 1 ELSE 0 END) AS hcc048
                        ,MAX(CASE WHEN fact.hcc_nbr = 51 THEN 1 ELSE 0 END) AS hcc051
                        ,MAX(CASE WHEN fact.hcc_nbr = 52 THEN 1 ELSE 0 END) AS hcc052
                        ,MAX(CASE WHEN fact.hcc_nbr = 54 THEN 1 ELSE 0 END) AS hcc054
                        ,MAX(CASE WHEN fact.hcc_nbr = 55 THEN 1 ELSE 0 END) AS hcc055
                        ,MAX(CASE WHEN fact.hcc_nbr = 56 THEN 1 ELSE 0 END) AS hcc056
                        ,MAX(CASE WHEN fact.hcc_nbr = 57 THEN 1 ELSE 0 END) AS hcc057
                        ,MAX(CASE WHEN fact.hcc_nbr = 58 THEN 1 ELSE 0 END) AS hcc058
                        ,MAX(CASE WHEN fact.hcc_nbr = 59 THEN 1 ELSE 0 END) AS hcc059
                        ,MAX(CASE WHEN fact.hcc_nbr = 60 THEN 1 ELSE 0 END) AS hcc060
                        ,MAX(CASE WHEN fact.hcc_nbr = 70 THEN 1 ELSE 0 END) AS hcc070
                        ,MAX(CASE WHEN fact.hcc_nbr = 71 THEN 1 ELSE 0 END) AS hcc071
                        ,MAX(CASE WHEN fact.hcc_nbr = 72 THEN 1 ELSE 0 END) AS hcc072
                        ,MAX(CASE WHEN fact.hcc_nbr = 73 THEN 1 ELSE 0 END) AS hcc073
                        ,MAX(CASE WHEN fact.hcc_nbr = 74 THEN 1 ELSE 0 END) AS hcc074
                        ,MAX(CASE WHEN fact.hcc_nbr = 75 THEN 1 ELSE 0 END) AS hcc075
                        ,MAX(CASE WHEN fact.hcc_nbr = 76 THEN 1 ELSE 0 END) AS hcc076
                        ,MAX(CASE WHEN fact.hcc_nbr = 77 THEN 1 ELSE 0 END) AS hcc077
                        ,MAX(CASE WHEN fact.hcc_nbr = 78 THEN 1 ELSE 0 END) AS hcc078
                        ,MAX(CASE WHEN fact.hcc_nbr = 79 THEN 1 ELSE 0 END) AS hcc079
                        ,MAX(CASE WHEN fact.hcc_nbr = 80 THEN 1 ELSE 0 END) AS hcc080
                        ,MAX(CASE WHEN fact.hcc_nbr = 82 THEN 1 ELSE 0 END) AS hcc082
                        ,MAX(CASE WHEN fact.hcc_nbr = 83 THEN 1 ELSE 0 END) AS hcc083
                        ,MAX(CASE WHEN fact.hcc_nbr = 84 THEN 1 ELSE 0 END) AS hcc084
                        ,MAX(CASE WHEN fact.hcc_nbr = 85 THEN 1 ELSE 0 END) AS hcc085
                        ,MAX(CASE WHEN fact.hcc_nbr = 86 THEN 1 ELSE 0 END) AS hcc086
                        ,MAX(CASE WHEN fact.hcc_nbr = 87 THEN 1 ELSE 0 END) AS hcc087
                        ,MAX(CASE WHEN fact.hcc_nbr = 88 THEN 1 ELSE 0 END) AS hcc088
                        ,MAX(CASE WHEN fact.hcc_nbr = 96 THEN 1 ELSE 0 END) AS hcc096
                        ,MAX(CASE WHEN fact.hcc_nbr = 99 THEN 1 ELSE 0 END) AS hcc099
                        ,MAX(CASE WHEN fact.hcc_nbr = 100 THEN 1 ELSE 0 END) AS hcc100
                        ,MAX(CASE WHEN fact.hcc_nbr = 103 THEN 1 ELSE 0 END) AS hcc103
                        ,MAX(CASE WHEN fact.hcc_nbr = 104 THEN 1 ELSE 0 END) AS hcc104
                        ,MAX(CASE WHEN fact.hcc_nbr = 106 THEN 1 ELSE 0 END) AS hcc106
                        ,MAX(CASE WHEN fact.hcc_nbr = 107 THEN 1 ELSE 0 END) AS hcc107
                        ,MAX(CASE WHEN fact.hcc_nbr = 108 THEN 1 ELSE 0 END) AS hcc108
                        ,MAX(CASE WHEN fact.hcc_nbr = 110 THEN 1 ELSE 0 END) AS hcc110
                        ,MAX(CASE WHEN fact.hcc_nbr = 111 THEN 1 ELSE 0 END) AS hcc111
                        ,MAX(CASE WHEN fact.hcc_nbr = 112 THEN 1 ELSE 0 END) AS hcc112
                        ,MAX(CASE WHEN fact.hcc_nbr = 114 THEN 1 ELSE 0 END) AS hcc114
                        ,MAX(CASE WHEN fact.hcc_nbr = 115 THEN 1 ELSE 0 END) AS hcc115
                        ,MAX(CASE WHEN fact.hcc_nbr = 122 THEN 1 ELSE 0 END) AS hcc122
                        ,MAX(CASE WHEN fact.hcc_nbr = 124 THEN 1 ELSE 0 END) AS hcc124
                        ,MAX(CASE WHEN fact.hcc_nbr = 134 THEN 1 ELSE 0 END) AS hcc134
                        ,MAX(CASE WHEN fact.hcc_nbr = 135 THEN 1 ELSE 0 END) AS hcc135
                        ,MAX(CASE WHEN fact.hcc_nbr = 136 THEN 1 ELSE 0 END) AS hcc136
                        ,MAX(CASE WHEN fact.hcc_nbr = 137 THEN 1 ELSE 0 END) AS hcc137
                        ,MAX(CASE WHEN fact.hcc_nbr = 138 THEN 1 ELSE 0 END) AS hcc138
                        ,MAX(CASE WHEN fact.hcc_nbr = 157 THEN 1 ELSE 0 END) AS hcc157
                        ,MAX(CASE WHEN fact.hcc_nbr = 158 THEN 1 ELSE 0 END) AS hcc158
                        ,MAX(CASE WHEN fact.hcc_nbr = 159 THEN 1 ELSE 0 END) AS hcc159
                        ,MAX(CASE WHEN fact.hcc_nbr = 161 THEN 1 ELSE 0 END) AS hcc161
                        ,MAX(CASE WHEN fact.hcc_nbr = 162 THEN 1 ELSE 0 END) AS hcc162
                        ,MAX(CASE WHEN fact.hcc_nbr = 166 THEN 1 ELSE 0 END) AS hcc166
                        ,MAX(CASE WHEN fact.hcc_nbr = 167 THEN 1 ELSE 0 END) AS hcc167
                        ,MAX(CASE WHEN fact.hcc_nbr = 169 THEN 1 ELSE 0 END) AS hcc169
                        ,MAX(CASE WHEN fact.hcc_nbr = 170 THEN 1 ELSE 0 END) AS hcc170
                        ,MAX(CASE WHEN fact.hcc_nbr = 173 THEN 1 ELSE 0 END) AS hcc173
                        ,MAX(CASE WHEN fact.hcc_nbr = 176 THEN 1 ELSE 0 END) AS hcc176
                        ,MAX(CASE WHEN fact.hcc_nbr = 186 THEN 1 ELSE 0 END) AS hcc186
                        ,MAX(CASE WHEN fact.hcc_nbr = 188 THEN 1 ELSE 0 END) AS hcc188
                        ,MAX(CASE WHEN fact.hcc_nbr = 189 THEN 1 ELSE 0 END) AS hcc189
                        , mdl.model_id
                        , mdl.payment_yr AS model_payment_yr
                        , mdl.model_name

        from `research-01-217611.df_ucd_stage.wkg_summary_member_scoring_period`                       mbr
        cross join (select *
                    from `research-01-217611.df_enrichment.cms_raf_model`
                    where model_id = themodel
                  )                                                                                    mdl
        left join `research-01-217611.df_ucd_stage.wkg_cms_raf_hcc_no_child_hcc`                       fact    on   mbr.savvy_pid       =   fact.savvy_pid
                                                                                                               and  mbr.score_year_mo   =   fact.score_year_mo
                                                                                                               and  fact.model_id       =   mdl.model_id
        left join `research-01-217611.df_ucd_stage.wkg_cms_raf_total_score_after_factoring_blending`   raf     on   mbr.savvy_pid       =   raf.savvy_pid
                                                                                                               and  mbr.score_year_mo   =   raf.score_year_mo
                                                                                                               and  raf.model_id        =   mdl.model_id


        group by mbr.savvy_pid,mbr.savvy_did,mbr.is_restricted, mbr.score_year_mo, mbr.scoring_period_start_date, mbr.scoring_period_end_date
                 , mbr.mm_enrolled_during_scoring_period, mbr.last_year_mo_enrolled_during_scoring_period
                 , mbr.had_claim_during_scoring_period_flag
                 , gender, age, raf
                 , mdl.model_id
                 , mdl.payment_yr
                 , mdl.model_name


  ;

  /* ---------------------------------------------------------------------------------------------------------------------------- */
  /* ----------------------------------- Step 19: Drop intermediate tables ------------------------------------------------------ */
  /* ---------------------------------------------------------------------------------------------------------------------------- */


  /*
  --drop temporary tables
  drop table `research-01-217611.df_ucd_stage.wkg_cms_raf_date_range_rolling_12_month_periods`;
  drop table `research-01-217611.df_ucd_stage.wkg_cms_raf_person`;
  drop table `research-01-217611.df_ucd_stage.wkg_cms_raf_diag`;
  drop table `research-01-217611.df_ucd_stage.wkg_cms_raf_flag_for_claim_during_scoring_period`;
  drop table `research-01-217611.df_ucd_stage.wkg_cms_raf_hcc`;
  drop table `research-01-217611.df_ucd_stage.wkg_cms_raf_hcc_no_child_hcc`;
  drop table `research-01-217611.df_ucd_stage.wkg_cms_raf_interaction_category`;
  drop table `research-01-217611.df_ucd_stage.wkg_cms_raf_interaction_term`;
  drop table `research-01-217611.df_ucd_stage.wkg_cms_raf_interaction_term_coeff`;
  drop table `research-01-217611.df_ucd_stage.wkg_cms_raf_interaction_term_coeff_no_child_term`;
  drop table `research-01-217611.df_ucd_stage.wkg_cms_raf_total_hcc_coefficient`;
  drop table `research-01-217611.df_ucd_stage.wkg_cms_raf_derived_demographics`;
  drop table `research-01-217611.df_ucd_stage.wkg_cms_raf_demo_coefficient`;
  drop table `research-01-217611.df_ucd_stage.wkg_cms_raf_disability_hcc_interaction`;
  drop table `research-01-217611.df_ucd_stage.wkg_cms_raf_total_score_before_factoring_blending`;
  drop table `research-01-217611.df_ucd_stage.wkg_cms_raf_total_score_after_factoring_blending`;
  drop table `research-01-217611.df_ucd_stage.wkg_cms_raf_all_model_terms`;
  */


    --if successful, we'll get here!
    insert into `research-01-217611.df_ucd_stage.logging`(
      success_flag, job, message_datetime)
    select
      1 as success_flag
      , 'cms raf scores' as job
      , current_datetime as message_datetime
    ;

    EXCEPTION WHEN ERROR THEN
      insert into `research-01-217611.df_ucd_stage.logging`(
        success_flag, job, error_message, statement_text, formatted_stack_trace, message_datetime)
      select
        0 as success_flag
        , 'cms raf scores' as job
        , @@error.message as error_message
        , @@error.statement_text as statement_text
        , @@error.formatted_stack_trace as formatted_stack_trace
        , current_datetime as message_datetime
      ;
END
;
