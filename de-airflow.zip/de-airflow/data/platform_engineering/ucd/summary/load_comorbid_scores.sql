/*

 Purpose         : To calculate comorbidity score and comorbid flags for rolling 12 months period (Scoring period of 12 months)
 Granularity     : 1 row per member per month
 Timeline        : 2016 onwards
 Input table/s   : df_ucd_stage.dim_month
                 : df_ucd_stage.udd_member_detail_consolidated
                 : df_ucd.medical_claim
                 : df_enrichment.dim_risk_comorbid_dx
 Output table/s  : df_ucd_stage.comorbid_scores

 Based on code for comorbid scores calculation:
 https://code.savvysherpa.com/ccasul/Universal-Data-Claims-Task-Force/blob/master/comorbidity/11_ucd_comorbid_scores.md using all 12 diagnoses from the claims

 Total run time: 40 min 14 sec

*/

BEGIN

  /* ---------------------------------------------------------------------------------------------------------------------------- */
  /* ---------------- Step 1: Creating table with scoring month and start and end dates for the scoring period ------------------ */
  /* ---------------------------------------------------------------------------------------------------------------------------- */


  --  wkg_comorbid_date_range_rolling_12_month_periods: replaced by wkg_date_range_rolling_12_month_periods


  /* ---------------------------------------------------------------------------------------------------------------------------- */
  /* ------- Step 2: Creating member month table with all enrolled months and start and end dates for the scoring period -------- */
  /* --------------------------- along with total months enrolled during the scoring period ------------------------------------- */
  /* ---------------------------------------------------------------------------------------------------------------------------- */

  --3 min 55 sec

  -- wkg_comorbid_enrollment_during_scoring_period: replaced by wkg_summary_member_scoring_period


  /* ---------------------------------------------------------------------------------------------------------------------------- */
  /* -------- Step 3: All diagnosis codes for every member during the rolling 12 month time frame for each score month  --------- */
  /* ---------------------------------------------------------------------------------------------------------------------------- */

  --14 min 35 sec

  -- wkg_comorbid_dx_during_scoring_period`: replaced by wkg_summary_member_diag_scoring_period

  /* ---------------------------------------------------------------------------------------------------------------------------- */
  /* ------------- Step 4: Flag for whether a member had claims during the rolling 12 months for each score month  -------------- */
  /* ---------------------------------------------------------------------------------------------------------------------------- */

  --3 min 28 sec

  --had_claim_during_scoring_period_flag added to wkg_summary_member_scoring_period

  /* ---------------------------------------------------------------------------------------------------------------------------- */
  /* ----------------- Step 5: Getting cormorbidity risk score weights for every member for each score month -------------------- */
  /* ---------------------------------------------------------------------------------------------------------------------------- */

  --2 min 23 sec

  create or replace table `research-01-217611.df_ucd_stage.wkg_comorbid_risk_score_weights` as
       (--Determining whether the claim dx starts with comorbidity ICD 10 dx code
        with diag_cd_starting_with_comorbidity_dx as
              (select distinct diag_cd, abbr, icd10, scale, weight
              from (select distinct diag_cd
                    from `research-01-217611.df_ucd_stage.wkg_summary_member_diag_scoring_period`)  as claim_dx
              join `research-01-217611.df_enrichment.dim_risk_comorbid_dx`                          as comorb_dx  on starts_with(claim_dx.diag_cd, comorb_dx.icd10)
              )

        select claim_dx.savvy_pid, claim_dx.score_year_mo, comorb_dx.scale, comorb_dx.abbr, max(weight) AS wght
        from `research-01-217611.df_ucd_stage.wkg_summary_member_diag_scoring_period`         as claim_dx
        inner join diag_cd_starting_with_comorbidity_dx                                       as comorb_dx      on claim_dx.diag_cd = comorb_dx.diag_cd
        group by savvy_pid, score_year_mo, scale, abbr
       )
  ;


  /* ---------------------------------------------------------------------------------------------------------------------------- */
  /* ------------- Step 6: Calculating AHRQ Elixhauser Comorbidity Score for every member for each score month ------------------ */
  /* ---------------------------------------------------------------------------------------------------------------------------- */

  -- 8min 11 sec

  create or replace table `research-01-217611.df_ucd_stage.wkg_comorbid_risk_score_aeci` as
       (select mem_sp.savvy_pid , mem_sp.score_year_mo
                                , sum(case when scale = 'aeci_m' then wght else 0 end)
                                  - case when sum(case when abbr IN ('tumor', 'mets')  --If mets and tumor are present, subtract tumor
                                    then 1 else 0 end) > 1 then 7 else 0 end
                                  as aeci_m_score

                                , sum(case when scale = 'aeci_r' then wght else 0 end)
                                  - case when sum(case when abbr in ('tumor', 'mets')  --If mets and tumor are present, subtract tumor
                                         then 1 else 0 end) > 1 then 15 else 0 end
                                  - case when sum(case when abbr IN ('dm', 'dmcx')     --If dmcx and dm present, subtract dm
                                         then 1 else 0 end) > 1 then 6 else 0 end
                                 as aeci_r_score

                                , string_agg(distinct abbr order by abbr) as aeci_condition_list

                                , max(case when abbr = 'aids' then 1 else 0 end) as aeci_aids_flag
                                , max(case when abbr = 'alcohol' then 1 else 0 end) as aeci_alcohol_flag
                                , max(case when abbr = 'anemdef' then 1 else 0 end) as aeci_anemdef_flag
                                , max(case when abbr = 'arth' then 1 else 0 end) as aeci_arth_flag
                                , max(case when abbr = 'bldloss' then 1 else 0 end) as aeci_bldloss_flag
                                , max(case when abbr = 'chf' then 1 else 0 end) as aeci_chf_flag
                                , max(case when abbr = 'chrnlung' then 1 else 0 end) as aeci_chrnlung_flag
                                , max(case when abbr = 'coag' then 1 else 0 end) as aeci_coag_flag
                                , max(case when abbr = 'depress' then 1 else 0 end) as aeci_depress_flag
                                , max(case when abbr = 'dm' then 1 else 0 end) as aeci_dm_flag
                                , max(case when abbr = 'dmcx' then 1 else 0 end) as aeci_dmcx_flag
                                , max(case when abbr = 'drug' then 1 else 0 end) as aeci_drug_flag
                                , max(case when abbr = 'htn' then 1 else 0 end) as aeci_htn_flag
                                , max(case when abbr = 'hypothy' then 1 else 0 end) as aeci_hypothy_flag
                                , max(case when abbr = 'liver' then 1 else 0 end) as aeci_liver_flag
                                , max(case when abbr = 'lymph' then 1 else 0 end) as aeci_lymph_flag
                                , max(case when abbr = 'lytes' then 1 else 0 end) as aeci_lytes_flag
                                , max(case when abbr = 'mets' then 1 else 0 end) as aeci_mets_flag
                                , max(case when abbr = 'neuro' then 1 else 0 end) as aeci_neuro_flag
                                , max(case when abbr = 'obese' then 1 else 0 end) as aeci_obese_flag
                                , max(case when abbr = 'para' then 1 else 0 end) as aeci_para_flag
                                , max(case when abbr = 'perivasc' then 1 else 0 end) as aeci_perivasc_flag
                                , max(case when abbr = 'psych' then 1 else 0 end) as aeci_psych_flag
                                , max(case when abbr = 'pulmcirc' then 1 else 0 end) as aeci_pulmcirc_flag
                                , max(case when abbr = 'renlfail' then 1 else 0 end) as aeci_renlfail_flag
                                , max(case when abbr = 'tumor' then 1 else 0 end) as aeci_tumor_flag
                                , max(case when abbr = 'ulcer' then 1 else 0 end) as aeci_ulcer_flag
                                , max(case when abbr = 'valve' then 1 else 0 end) as aeci_valve_flag
                                , max(case when abbr = 'wghtloss' then 1 else 0 end) as aeci_wghtloss_flag

        from `research-01-217611.df_ucd_stage.wkg_summary_member_scoring_period`   mem_sp
        left join `research-01-217611.df_ucd_stage.wkg_comorbid_risk_score_weights`            risk_sc  on   mem_sp.savvy_pid       =   risk_sc.savvy_pid
                                                                                                        and  mem_sp.score_year_mo   =   risk_sc.score_year_mo
                                                                                                        and  scale in ('aeci_r', 'aeci_m')
        group by savvy_pid, score_year_mo
        )
  ;


  /* ---------------------------------------------------------------------------------------------------------------------------- */
  /* -------------- Step 7: Calculating Charlson Comorbidity Index Score for every member for each score month ------------------ */
  /* ---------------------------------------------------------------------------------------------------------------------------- */

  --5 min 0 sec

  create or replace table `research-01-217611.df_ucd_stage.wkg_comorbid_risk_score_cci` as
        (select mem_sp.savvy_pid, mem_sp.score_year_mo
                                , sum(case when scale = 'cci' then wght else 0 end) as cci_score
                                , sum(case when scale = 'cci_q' then wght else 0 end) as cci_q_score
                                , string_agg(distinct abbr order by abbr) as cci_condition_list

                                , max(case when abbr = 'aids' then 1 else 0 end) as cci_aids_flag
                                , max(case when abbr = 'tumor' then 1 else 0 end) as cci_tumor_flag
                                , max(case when abbr = 'cerebrovasc' then 1 else 0 end) as cci_cerebrovasc_flag
                                , max(case when abbr = 'cpd' then 1 else 0 end) as cci_cpd_flag
                                , max(case when abbr = 'chf' then 1 else 0 end) as cci_chf_flag
                                , max(case when abbr = 'dementia' then 1 else 0 end) as cci_dementia_flag
                                , max(case when abbr = 'dmcx' then 1 else 0 end) as cci_dmcx_flag
                                , max(case when abbr = 'dm' then 1 else 0 end) as cci_dm_flag
                                , max(case when abbr = 'para' then 1 else 0 end) as cci_para_flag
                                , max(case when abbr = 'mets' then 1 else 0 end) as cci_mets_flag
                                , max(case when abbr = 'liver' then 1 else 0 end) as cci_liver_flag
                                , max(case when abbr = 'livercx' then 1 else 0 end) as cci_livercx_flag
                                , max(case when abbr = 'mi' then 1 else 0 end) as cci_mi_flag
                                , max(case when abbr = 'pud' then 1 else 0 end) as cci_pud_flag
                                , max(case when abbr = 'perivasc' then 1 else 0 end) as cci_perivasc_flag
                                , max(case when abbr = 'renlfail' then 1 else 0 end) as cci_renlfail_flag
                                , max(case when abbr = 'arth' then 1 else 0 end) as cci_arth_flag

         from `research-01-217611.df_ucd_stage.wkg_summary_member_scoring_period`   mem_sp
         left join `research-01-217611.df_ucd_stage.wkg_comorbid_risk_score_weights`            risk_sc   on   mem_sp.savvy_pid       =   risk_sc.savvy_pid
                                                                                                          and  mem_sp.score_year_mo   =   risk_sc.score_year_mo
                                                                                                          and  scale in ( 'cci', 'cci_q')
         group by savvy_pid, score_year_mo
         )
  ;


  /* ---------------------------------------------------------------------------------------------------------------------------- */
  /* -------------- Step 8: Finally, combining everything to create comorbidity score for every member month  ------------------- */
  /* ---------------------------------------------------------------------------------------------------------------------------- */

  ---2 min 26 sec

  insert into `research-01-217611.df_ucd_stage.comorbid_scores`

   (savvy_pid, savvy_did, is_restricted, score_year_mo, scoring_period_start_date, scoring_period_end_date, mm_enrolled_during_scoring_period, last_year_mo_enrolled_during_scoring_period, had_claim_during_scoring_period_flag, aeci_m_score, aeci_r_score, aeci_condition_list, aeci_aids_flag, aeci_alcohol_flag, aeci_anemdef_flag, aeci_arth_flag, aeci_bldloss_flag, aeci_chf_flag, aeci_chrnlung_flag, aeci_coag_flag, aeci_depress_flag, aeci_dm_flag, aeci_dmcx_flag, aeci_drug_flag, aeci_htn_flag, aeci_hypothy_flag, aeci_liver_flag, aeci_lymph_flag, aeci_lytes_flag, aeci_mets_flag, aeci_neuro_flag, aeci_obese_flag, aeci_para_flag, aeci_perivasc_flag, aeci_psych_flag, aeci_pulmcirc_flag, aeci_renlfail_flag, aeci_tumor_flag, aeci_ulcer_flag, aeci_valve_flag, aeci_wghtloss_flag, cci_score, cci_q_score, cci_condition_list, cci_aids_flag, cci_tumor_flag, cci_cerebrovasc_flag, cci_cpd_flag, cci_chf_flag, cci_dementia_flag, cci_dmcx_flag, cci_dm_flag, cci_para_flag, cci_mets_flag, cci_liver_flag, cci_livercx_flag, cci_mi_flag, cci_pud_flag, cci_perivasc_flag, cci_renlfail_flag, cci_arth_flag
   )

   SELECT   mbr.savvy_pid
          , mbr.savvy_did
          , mbr.is_restricted
          , mbr.score_year_mo
          , mbr.scoring_period_start_date
          , mbr.scoring_period_end_date
          , mbr.mm_enrolled_during_scoring_period
          , mbr.last_year_mo_enrolled_during_scoring_period
          , mbr.had_claim_during_scoring_period_flag

          , case when aeci_m_score<0 then 0 else aeci_m_score end as aeci_m_score /* Replace negative scores by 0 */
          , case when aeci_r_score<0 then 0 else aeci_r_score end as aeci_r_score /* Replace negative scores by 0 */
          , aeci_condition_list

          , aeci_aids_flag
          , aeci_alcohol_flag
          , aeci_anemdef_flag
          , aeci_arth_flag
          , aeci_bldloss_flag
          , aeci_chf_flag
          , aeci_chrnlung_flag
          , aeci_coag_flag
          , aeci_depress_flag
          , aeci_dm_flag
          , aeci_dmcx_flag
          , aeci_drug_flag
          , aeci_htn_flag
          , aeci_hypothy_flag
          , aeci_liver_flag
          , aeci_lymph_flag
          , aeci_lytes_flag
          , aeci_mets_flag
          , aeci_neuro_flag
          , aeci_obese_flag
          , aeci_para_flag
          , aeci_perivasc_flag
          , aeci_psych_flag
          , aeci_pulmcirc_flag
          , aeci_renlfail_flag
          , aeci_tumor_flag
          , aeci_ulcer_flag
          , aeci_valve_flag
          , aeci_wghtloss_flag

          , cci_score
          , cci_q_score
          , cci_condition_list

          , cci_aids_flag
          , cci_tumor_flag
          , cci_cerebrovasc_flag
          , cci_cpd_flag
          , cci_chf_flag
          , cci_dementia_flag
          , cci_dmcx_flag
          , cci_dm_flag
          , cci_para_flag
          , cci_mets_flag
          , cci_liver_flag
          , cci_livercx_flag
          , cci_mi_flag
          , cci_pud_flag
          , cci_perivasc_flag
          , cci_renlfail_flag
          , cci_arth_flag

  FROM `research-01-217611.df_ucd_stage.wkg_summary_member_scoring_period`            mbr
  left join `research-01-217611.df_ucd_stage.wkg_comorbid_risk_score_aeci`                        aeci   on   mbr.savvy_pid        =     aeci.savvy_pid
                                                                                                        and  mbr.score_year_mo    =     aeci.score_year_mo
  left join `research-01-217611.df_ucd_stage.wkg_comorbid_risk_score_cci`                         cci    on   mbr.savvy_pid        =     cci.savvy_pid
                                                                                                        and  mbr.score_year_mo    =     cci.score_year_mo
  ;

  /* ---------------------------------------------------------------------------------------------------------------------------- */
  /* --------------------------------------- Step 9: Drop all intermediate tables  ---------------------------------------------- */
  /* ---------------------------------------------------------------------------------------------------------------------------- */

  /* drop temporary tables
  drop table `research-01-217611.df_ucd_stage.wkg_comorbid_date_range_rolling_12_month_periods`;
  drop table `research-01-217611.df_ucd_stage.wkg_comorbid_enrollment_during_scoring_period`;
  drop table `research-01-217611.df_ucd_stage.wkg_comorbid_dx_during_scoring_period`;
  drop table `research-01-217611.df_ucd_stage.wkg_comorbid_flag_for_claim_during_scoring_period`;
  drop table `research-01-217611.df_ucd_stage.wkg_comorbid_risk_score_weights`;
  drop table `research-01-217611.df_ucd_stage.wkg_comorbid_risk_score_aeci`;
  drop table `research-01-217611.df_ucd_stage.wkg_comorbid_risk_score_cci`;
  */


  /* ------------------------------------------------- END OF CODE --------------------------------------------------------------- */

    --if successful, we'll get here!
    insert into `research-01-217611.df_ucd_stage.logging`(
      success_flag, job, message_datetime)
    select
      1 as success_flag
      , 'comorbidity scores' as job
      , current_datetime as message_datetime
    ;

    EXCEPTION WHEN ERROR THEN
      insert into `research-01-217611.df_ucd_stage.logging`(
        success_flag, job, error_message, statement_text, formatted_stack_trace, message_datetime)
      select
        0 as success_flag
        , 'comorbidity scores' as job
        , @@error.message as error_message
        , @@error.statement_text as statement_text
        , @@error.formatted_stack_trace as formatted_stack_trace
        , current_datetime as message_datetime
      ;

END
;
