/*
 Purpose         : Prepare helper tables used by multiple summary scripts
 Timeline        : 2016 onwards
 Input table/s   : df_ucd_stage.dim_month
                 : df_ucd.member_detail
                 : df_ucd.medical_claim


 Based on code for commercial RAF score calculation:
https://code.savvysherpa.com/gist/smehle/5c013d837ac5615a17aadb387995adb1
https://code.savvysherpa.com/smehle/Universal-Data-Claims-Task-Force/blob/master/raf/raf_hhs.sql

 Total run time: 43 min

*/
BEGIN


  create or replace table `research-01-217611.df_ucd_stage.wkg_date_range_rolling_12_month_periods` as
      (
      select
          greatest(sc_st.year_mo,  201601)                    as scoring_period_start_mo      /* Limit to periods that start after 1/1/2016 to limit to ICD 10 data */
          , greatest(sc_st.year_nbr, 2016)                    as scoring_period_start_year    /* Limit to periods that start after 1/1/2016 to limit to ICD 10 data */
          , sc_end.year_mo                                    as scoring_period_end_mo        /* This will be our scoring month */
          , sc_end.year_mo                                    as score_year_mo                /* This will be our scoring month */
          , greatest(sc_st.month_start_date, '2016-01-01')    as scoring_period_start_date
          , sc_end.month_end_date                             as scoring_period_end_date
          , sc_end.year_nbr                                   as scoring_period_end_year
      from
        `research-01-217611.df_ucd_stage.dim_month`           sc_st
        join `research-01-217611.df_ucd_stage.dim_month`      sc_end on sc_st.month_id + 11 = sc_end.month_id  /* for rolling 12 months */
      where
        sc_end.year_mo between 201601 and (select max(year_mo) from `research-01-217611.df_ucd_stage.member_detail_enriched`)
      )
      ;



  create or replace table `research-01-217611.df_ucd_stage.wkg_member_month_diag` as
      --distinct diag per member month to limit number of fields in distinct clause later
      (
      select
          savvy_pid
          , year_mo
          , icd_ver_cd
          , diag_cd
          , max(cms_eligible_encounter_flag)      as cms_eligible_encounter_flag
          , max(hhs_eligible_encounter_flag)      as hhs_eligible_encounter_flag

          --add some fields we don't use now but which could be helpful later
          , min(dx_seq_nbr)                       as min_dx_seq_nbr
          , min(case when cms_eligible_encounter_flag = 1 then dx_seq_nbr end)      as min_dx_seq_nbr_cms_eligible
          , min(case when hhs_eligible_encounter_flag = 1 then dx_seq_nbr end)      as min_dx_seq_nbr_hhs_eligible
      from
          `research-01-217611.df_ucd_stage.ucd_diagnosis_claim`
      group by
          savvy_pid
          , year_mo
          , icd_ver_cd
          , diag_cd
      )
      ;


  create or replace table `research-01-217611.df_ucd_stage.wkg_summary_member_scoring_period` as
        (with
          cte_member_mo as
            (select
              savvy_pid
              , savvy_did
              , is_restricted
              , year_mo
              , min(gender) as gender
              , min(birth_year) as birth_year
              , min(medicaid_flag) as medicaid_flag
            from `research-01-217611.df_ucd_stage.member_detail_enriched`
            group by savvy_pid , savvy_did, is_restricted, year_mo
            )
          , cte_member_mo_claim as
            (select distinct savvy_pid , year_mo
            from `research-01-217611.df_ucd_stage.udd_medical_claim_enriched`
            )
        select
            mm.savvy_pid
            , max(mm.savvy_did) as savvy_did
            , max(mm.is_restricted) as is_restricted
            , dr.scoring_period_start_year
            , dr.scoring_period_start_mo
            , dr.scoring_period_start_date
            , dr.scoring_period_end_year
            , dr.score_year_mo
            , dr.scoring_period_end_date

            , max(case when clm.savvy_pid is not null then 1 else 0 end) as had_claim_during_scoring_period_flag
            , min(mm.gender)                                      as gender_cd
            , min(mm.birth_year)                                  as birth_year
            , dr.scoring_period_start_year - min(mm.birth_year)   as age_first
            , dr.scoring_period_end_year - min(mm.birth_year)     as age_last
            , coalesce(max(mm.medicaid_flag),0)                   as mcaid
            , count(distinct mm.year_mo)                          as mm_enrolled_during_scoring_period
            , max(mm.year_mo)                                     as last_year_mo_enrolled_during_scoring_period

            , 0                                                   as nemcaid        --used in cms raf  --if available replace 0 with appropriate value
            , 0                                                   as orec           --used in cms raf  --if available replace 0 with appropriate value
            , "s"                                                 as Metal          --used in hhs raf
            , 0                                                   as CSR_INDICATOR  --used in hhs raf
        from
          cte_member_mo                                                                     mm
          left join cte_member_mo_claim                                                     clm   using (savvy_pid, year_mo)
          join `research-01-217611.df_ucd_stage.wkg_date_range_rolling_12_month_periods`    dr    on   mm.year_mo between dr.scoring_period_start_mo and dr.scoring_period_end_mo
        group by mm.savvy_pid
            --, mm.savvy_did
            --, mm.is_restricted
            , dr.scoring_period_start_year
            , dr.scoring_period_start_mo
            , dr.scoring_period_start_date
            , dr.scoring_period_end_year
            , dr.score_year_mo
            , dr.scoring_period_end_date
        )
        ;

  create or replace table `research-01-217611.df_ucd_stage.wkg_summary_member_diag_scoring_period` as
        (
        select
            mem_sp.savvy_pid
            , mem_sp.score_year_mo
            , clm.icd_ver_cd
            , clm.diag_cd
            , max(clm.cms_eligible_encounter_flag)      as cms_eligible_encounter_flag
            , max(clm.hhs_eligible_encounter_flag)      as hhs_eligible_encounter_flag
        from
            `research-01-217611.df_ucd_stage.wkg_summary_member_scoring_period`     mem_sp
            join `research-01-217611.df_ucd_stage.wkg_member_month_diag`            clm    on clm.savvy_pid  =  mem_sp.savvy_pid
                                                                                            and clm.year_mo between mem_sp.scoring_period_start_mo and mem_sp.score_year_mo
        group by
            mem_sp.savvy_pid
            , mem_sp.score_year_mo
            , clm.icd_ver_cd
            , clm.diag_cd
        )
        ;


    --if successful, we'll get here!
    insert into `research-01-217611.df_ucd_stage.logging`(
      success_flag, job, message_datetime)
    select
      1 as success_flag
      , 'helper tables for summary scripts' as job
      , current_datetime as message_datetime
    ;

    EXCEPTION WHEN ERROR THEN
      insert into `research-01-217611.df_ucd_stage.logging`(
        success_flag, job, error_message, statement_text, formatted_stack_trace, message_datetime)
      select
        0 as success_flag
        , 'helper tables for summary scripts' as job
        , @@error.message as error_message
        , @@error.statement_text as statement_text
        , @@error.formatted_stack_trace as formatted_stack_trace
        , current_datetime as message_datetime
      ;
END
;
