/*
 Purpose         : To calculate commercial RAF scores and HCCs for rolling 12 months period (Scoring period of 12 months)
 Granularity     : 1 row per member per month
 Timeline        : 2016 onwards
 Input table/s   : df_ucd_stage.dim_month
                 : df_ucd.member_detail
                 : df_ucd.medical_claim

                 --HHS RAF reference tables:

                 : df_enrichment.hhs_raf_reportable_physician_procedure_code
                 : df_enrichment.hhs_raf_model
                 : df_enrichment.hhs_raf_model_category
                 : df_enrichment.hhs_raf_hcc_diagnosis
                 : df_enrichment.hhs_raf_model_hcc
                 : df_enrichment.hhs_raf_hcc_hierarchy
                 : df_enrichment.hhs_raf_model_age
                 : df_enrichment.hhs_raf_model_group
                 : df_enrichment.hhs_raf_1_maturity_level_for_age0_without_newborn_hcc
                 : df_enrichment.hhs_raf_2_age_edits_for_male_age0_without_newborn_hcc
                 : df_enrichment.hhs_raf_3a_maturity_level_based_on_age_and_hcc
                 : df_enrichment.hhs_raf_3b_maturity_and_severity_level_based_on_age
                 : df_enrichment.hhs_raf_4_hcc_group_and_severity_based_on_hcc
                 : df_enrichment.hhs_raf_5_severity_and_maturity_level_hierarchy
                 : df_enrichment.hhs_raf_6a_interaction_between_group_and_hcc
                 : df_enrichment.hhs_raf_6b_interaction_between_two_groups
                 : df_enrichment.hhs_raf_7a_high_cost_interaction_groups
                 : df_enrichment.hhs_raf_7b_medium_cost_interaction_groups
                 : df_enrichment.hhs_raf_8_hcc_group_and_hcc_hierarchy

 Output table/s  : df_ucd_stage.hhs_raf_scores

 Based on code for commercial RAF score calculation:
https://code.savvysherpa.com/gist/smehle/5c013d837ac5615a17aadb387995adb1
https://code.savvysherpa.com/smehle/Universal-Data-Claims-Task-Force/blob/master/raf/raf_hhs.sql

 Total run time: 43 min

*/
BEGIN

  /* specify the model */
  DECLARE version_name string DEFAULT 'silver';
  DECLARE model_year int64 DEFAULT 2016;

  /* ---------------------------------------------------------------------------------------------------------------------------- */
  /* ---------------- Step 1: Creating table with scoring month and start and end dates for the scoring period ------------------ */
  /* ---------------------------------------------------------------------------------------------------------------------------- */


  --3.8 sec

  --  wkg_hhs_raf_date_range_rolling_12_month_periods: replaced by wkg_date_range_rolling_12_month_periods


  /* ---------------------------------------------------------------------------------------------------------------------------- */
  /* ------- Step 2: Creating member month table with all the months in scoring period where member was enrolled ---------------- */
  /* -------------- along with start and end dates, total months enrolled during the scoring period ----------------------------- */
  /* ---------------------------------------------------------------------------------------------------------------------------- */
  -- wkg_hhs_raf_person: replaced by wkg_summary_member_scoring_period

  /* ---------------------------------------------------------------------------------------------------------------------------- */
  /* -------- Step 3: All diagnosis codes for every member during the rolling 12 month time frame for each score month  --------- */
  /* ---------------------------------------------------------------------------------------------------------------------------- */
  -- wkg_hhs_raf_claim`: replaced by wkg_summary_member_diag_scoring_period


  /* ---------------------------------------------------------------------------------------------------------------------------- */
  /* ------------- Step 4: Flag for whether a member had claims during the rolling 12 months for each score month  -------------- */
  /* ---------------------------------------------------------------------------------------------------------------------------- */
  --had_claim_during_scoring_period_flag added to wkg_summary_member_scoring_period

  /* ---------------------------------------------------------------------------------------------------------------------------- */
  /* -------------------------- Step 5: Identify the age/gender model category of the member ------------------------------------ */
  /* ---------------------------------------------------------------------------------------------------------------------------- */

  --4 min
  create or replace table `research-01-217611.df_ucd_stage.wkg_hhs_raf_identify_model_category` as  --tmp A

  with identify_model_category as (select a.ModelID, b.ModelCategoryID, b.AgeStart, b.AgeEnd
                                  from `research-01-217611.df_enrichment.hhs_raf_model`             as a
                                    join `research-01-217611.df_enrichment.hhs_raf_model_category`  as b on a.ModelID = b.ModelID
                                  where model=model_year and modelversion=version_name
                                  )
  select distinct savvy_pid, score_year_mo, a.gender_cd as gendercode, age_last, AgeStart, AgeEnd, ModelID, ModelCategoryID
  from `research-01-217611.df_ucd_stage.wkg_summary_member_scoring_period`    a
    join identify_model_category                                              b   on   a.age_last Between b.AgeStart AND b.AgeEnd
  ;


  /* ---------------------------------------------------------------------------------------------------------------------------- */
  /* --------------------------------- Step 6: Add diagnosis to the model category ---------------------------------------------- */
  /* ---------------------------------------------------------------------------------------------------------------------------- */

  --1 min

  create or replace table `research-01-217611.df_ucd_stage.wkg_hhs_raf_diag` as  --tmp B

  select distinct
          a.savvy_pid
        , a.score_year_mo
        , a.ModelCategoryID
        , a.age_last as ageatdiagnosis
        , a.age_last as agelast
        , a.gendercode as gendercd
        , b.diag_cd as icdcd
  from `research-01-217611.df_ucd_stage.wkg_hhs_raf_identify_model_category`            a
  inner join `research-01-217611.df_ucd_stage.wkg_summary_member_diag_scoring_period`   b   on   a.savvy_pid      = b.savvy_pid
                                                                                            and  a.score_year_mo  = b.score_year_mo
  where a.gendercode IN ("m","f")
  and b.hhs_eligible_encounter_flag = 1
  ;

  /* ---------------------------------------------------------------------------------------------------------------------------- */
  /* -------------------------------------- Step 7: Get the HCC coefficient ----------------------------------------------------- */
  /* ---------------------------------------------------------------------------------------------------------------------------- */

  --51.4 sec

  create or replace table `research-01-217611.df_ucd_stage.wkg_hhs_raf_hcc` AS  --tmp C


  select distinct memdx.savvy_pid, memdx.score_year_mo, memdx.ModelCategoryID
                , hccmodel.ModelHCCID, hccmodel.Term, hccmodel.HCCNbr, hccmodel.Coefficient
  from `research-01-217611.df_ucd_stage.wkg_hhs_raf_diag`              memdx
  join `research-01-217611.df_enrichment.hhs_raf_hcc_diagnosis`        hccdx     on    memdx.ICDCd            = hccdx.ICDCd
  join `research-01-217611.df_enrichment.hhs_raf_model_hcc`            hccmodel  on    hccdx.ModelHCCID       = hccmodel.ModelHCCID
                                                                                 and   memdx.ModelCategoryID  = hccmodel.ModelCategoryID
  where IFNULL(hccdx.MCEGenderCondition, memdx.GenderCd) = memdx.GenderCd                          /* Checks MCE gender criteria */
  and memdx.AgeAtDiagnosis Between hccdx.MCEDiagnosisAgeStart AND hccdx.MCEDiagnosisAgeEnd         /* Checks MCE age criteria */
  and IFNULL(hccdx.HCCNbrGenderCondition, memdx.GenderCd) = memdx.GenderCd                         /* Checks HSS gender criteria */
  and memdx.AgeLast Between hccdx.HCCNbrLastAgeStart AND hccdx.HCCNbrLastAgeEnd                    /* Checks HSS age criteria */
  ;



  /* ---------------------------------------------------------------------------------------------------------------------------- */
  /* -------------------------------------------- Step 8: Remove child HCC ------------------------------------------------------ */
  /* ---------------------------------------------------------------------------------------------------------------------------- */
  --2 min
  create or replace table `research-01-217611.df_ucd_stage.wkg_hhs_raf_hcc_no_child_hcc` as  --tmp D

  with parentwithchildhcc as
  		(select memhcc.savvy_pid, memhcc.score_year_mo, memhcc.ModelCategoryID, hcchier.ChildModelHCCID
  			from `research-01-217611.df_enrichment.hhs_raf_hcc_hierarchy`   hcchier
  			join `research-01-217611.df_ucd_stage.wkg_hhs_raf_hcc`          memhcc    on   hcchier.ParentModelHCCID = memhcc.ModelHCCID)

  select memhcc.*
  from `research-01-217611.df_ucd_stage.wkg_hhs_raf_hcc`     memhcc
    left outer join  parentwithchildhcc                      remove   on  memhcc.savvy_pid      = remove.savvy_pid
                                                                       and memhcc.score_year_mo  = remove.score_year_mo
                                                                       and memhcc.ModelHCCID     = remove.ChildModelHCCID
  where remove.savvy_pid is null
  ;



  /* ---------------------------------------------------------------------------------------------------------------------------- */
  /* --------------------------------------- Step 9: Get age category ----------------------------------------------------------- */
  /* ---------------------------------------------------------------------------------------------------------------------------- */
  --1min

  create or replace table `research-01-217611.df_ucd_stage.wkg_hhs_raf_age_cat` AS   --tmp E
  select distinct a.savvy_pid, a.score_year_mo, a.ModelCategoryID, ModelAgeID
  			,CONCAT("age between ", CAST(b.AgeStart as string), "-", CAST(b.AgeEnd as string)) AS Term
  			,Coefficient
  from `research-01-217611.df_ucd_stage.wkg_hhs_raf_identify_model_category`   a
  inner join `research-01-217611.df_enrichment.hhs_raf_model_age`              b   on  a.ModelCategoryID = b.ModelCategoryID
                                                                                  and a.age_last Between b.AgeStart and b.AgeEnd
                                                                                  and a.gendercode      = b.GenderCD

  ;
  /* ---------------------------------------------------------------------------------------------------------------------------- */
  /* -------------- Step 10: Get maturity level for those with age 0 and without newborn HCC ------------------------------------ */
  /* ---------------------------------------------------------------------------------------------------------------------------- */

  --Age 0 infants lacking a newborn HHS-HCC (242-249) are assigned to Age 1.
  --Maturity level (ihcc_age1) is assigned to infants (age 0) without any of the 8 newborn HCCs in that score month
  --Line 129 (Table 8) of DIY tables

  --46.6 sec

  create or replace table `research-01-217611.df_ucd_stage.wkg_hhs_raf_model_assignment` as   --tmp f

  --identifies members that have hccid for 8 newborn HCCs that will disqualify them from receiving this modelgroupid
  with have_newborn_hcc as
    (select distinct a.savvy_pid, a.score_year_mo
     from `research-01-217611.df_ucd_stage.wkg_hhs_raf_hcc_no_child_hcc`                                     a
     inner join `research-01-217611.df_enrichment.hhs_raf_1_maturity_level_for_age0_without_newborn_hcc`     b  on a.modelhccid = b.donothave1modelhccid
                                                                                                               or a.modelhccid = b.donothave2modelhccid
                                                                                                               or a.modelhccid = b.donothave3modelhccid
                                                                                                               or a.modelhccid = b.donothave4modelhccid
                                                                                                               or a.modelhccid = b.donothave5modelhccid
                                                                                                               or a.modelhccid = b.donothave6modelhccid
                                                                                                               or a.modelhccid = b.donothave7modelhccid
                                                                                                               or a.modelhccid = b.donothave8modelhccid
     )


  select distinct	a.savvy_pid, a.score_year_mo, a.modelcategoryid, b.getmodelgroupid, b.GetGroupterm as term, b.GetGroupCoefficient as coefficient, "1_maturity_level_for_age0_without_newborn_hcc" as src
  from `research-01-217611.df_ucd_stage.wkg_hhs_raf_age_cat`                                             a
  inner join `research-01-217611.df_enrichment.hhs_raf_1_maturity_level_for_age0_without_newborn_hcc`    b   on  a.modelageid    =   b.havemodelageid    /* meets age requirement */
  left join have_newborn_hcc                                                                             c   on  a.savvy_pid     =   c.savvy_pid
                                                                                                             and a.score_year_mo =   c.score_year_mo
  where c.savvy_pid is null	/* donot have newborn hcc */
  ;


  /* ---------------------------------------------------------------------------------------------------------------------------- */
  /* --------------------- Step 11: Applying age edits if needed (male age 0 lacking newborn HCC)-------------------------------- */
  /* ---------------------------------------------------------------------------------------------------------------------------- */
  --32.9 sec

  --Reassign male age 0 infants lacking a newborn HHS-HCC (242-249) to the Age 1 age-sex variable (see Table 8, row 134).
  --If age_last is 0, gender is male and maturity group is ihcc_age1 (from df_enrichment.hhs_raf_1_maturitylevel_for_age0_without_newbornHCC)
      --then edited age_last will be 1 instead of 0 and the new coefficient will be used.
      --else the original age and age coefficient will be used.
  --Line 134 (Table 8) of DIY tables

  create or replace table `research-01-217611.df_ucd_stage.wkg_hhs_raf_age_edits` as

  select distinct a.savvy_pid, a.score_year_mo, a.ModelCategoryID, a.ModelAgeID as ModelAgeID, a.TERM, a.Coefficient
  		                       , IFNULL(c.GetAgeCoefficient, a.Coefficient) as EditedCoefficient
                             , IFNULL(c.GETModelAgeID, a.ModelAgeID) as EditedModelAgeID
                             , case when c.GETModelAgeID is null then 0 else 1 end as AgeEditFlag
  from `research-01-217611.df_ucd_stage.wkg_hhs_raf_age_cat`                                           a
  left join `research-01-217611.df_ucd_stage.wkg_hhs_raf_model_assignment`                             b   on   a.savvy_pid       =   b.savvy_pid
                                                                                                           and  a.ModelCategoryID =   b.ModelCategoryID
  left join `research-01-217611.df_enrichment.hhs_raf_2_age_edits_for_male_age0_without_newborn_hcc`   c   on   a.ModelAgeID      =   c.HAVEModelAgeID
                                                                                                           and  b.GETModelGroupID =   c.HAVEModelGroupID

  ;

  /* ---------------------------------------------------------------------------------------------------------------------------- */
  /* ------------ Step 12: get maturity level based on age and hcc (if age=0)/ age only (if age=1) ------------------------------ */
  /* ---------------------------------------------------------------------------------------------------------------------------- */

  --Create five maturity categories (ihcc_extremely_immature, ihcc_immature, ihcc_premature, ihcc_term, ihcc_age1) see Table 8, rows 124-129


  --based on age and newborn HHS-HCC (if age 0 ), see rows 125-129 of Table 8
  --23.4 sec
  insert `research-01-217611.df_ucd_stage.wkg_hhs_raf_model_assignment` (savvy_pid, score_year_mo, ModelCategoryID, GETModelGroupID, Term, Coefficient, Src)

  select distinct a.savvy_pid, a.score_year_mo, a.ModelCategoryID, GETModelGroupID, c.GetGroupterm as term, c.GetGroupCoefficient as coefficient, "2_maturity_level_based_on_age_and_hcc" Src
  from `research-01-217611.df_ucd_stage.wkg_hhs_raf_hcc_no_child_hcc`                              a
  inner join `research-01-217611.df_ucd_stage.wkg_hhs_raf_age_edits`                               b   on  a.savvy_pid        =   b.savvy_pid
                                                                                                      and a.score_year_mo    =   b.score_year_mo
                                                                                                      and a.ModelCategoryID  =   b.ModelCategoryID
  inner join `research-01-217611.df_enrichment.hhs_raf_3a_maturity_level_based_on_age_and_hcc`     c   on  c.HAVEModelAgeID   =   b.EditedModelAgeID
                                                                                                      and c.HAVEModelHCCID   =   a.ModelHCCID
  ;

  --based on age only (if age 1), see row 124 of Table 8
  --Note that age 0 or age 1 infants lacking any of the HHS-HCCs corresponding to severity levels are assigned to Severity Level 1 (Lowest).
  --23 sec
  insert `research-01-217611.df_ucd_stage.wkg_hhs_raf_model_assignment` (savvy_pid, score_year_mo, ModelCategoryID, GETModelGroupID, Term, Coefficient, Src)

  select distinct	a.savvy_pid, a.score_year_mo, a.ModelCategoryID, GETModelGroupID, b.GetGroupterm as term, b.GetGroupCoefficient as coefficient, "3_maturity_level_based_on_age" Src
  from `research-01-217611.df_ucd_stage.wkg_hhs_raf_age_edits`                                          a
  inner join `research-01-217611.df_enrichment.hhs_raf_3b_maturity_and_severity_level_based_on_age`     b     on  a.EditedModelAgeID  =   b.HaveModelAgeID
  ;


  /* ---------------------------------------------------------------------------------------------------------------------------- */
  /* ----------------------------- Step 13: Get HCC group and severity based on HCC --------------------------------------------- */
  /* ---------------------------------------------------------------------------------------------------------------------------- */

  --Assigns severity and hcc group based on HCC (for all infant, child and adult model)

  /*
  Adult
  --Create SEVERE_V3 group, severe illness indicator variable, when an adult has at least 1 of 8 HHS-HCCs that indicate a severe illness.
    Rows 5-12 of column E in Table 6 identify these 8 HHS-HCCs.
  --Create HCC group (G01-G18) using Table 6, Rows 14-69
  Child
  --Create HCC group (G01-G18) using Table 7, Rows 5-61
  Infant
  --Create severity level categories ihcc_severity (1-5) based on HHS-HCC using Table 8, Rows 5-116
  */

  --40.4 sec
  insert `research-01-217611.df_ucd_stage.wkg_hhs_raf_model_assignment` (savvy_pid, score_year_mo, ModelCategoryID, GETModelGroupID, Term, Coefficient, Src)

  select distinct a.savvy_pid, a.score_year_mo, a.ModelCategoryID, GETModelGroupID, b.GetGroupterm as term, b.GetGroupCoefficient as coefficient, "4_hcc_group_and_severity_based_on_hcc" Src
  from `research-01-217611.df_ucd_stage.wkg_hhs_raf_hcc_no_child_hcc`                              a
  inner join `research-01-217611.df_enrichment.hhs_raf_4_hcc_group_and_severity_based_on_hcc`      b   on  a.ModelHCCID   = b.HAVEModelHCCID

  ;



  /* ---------------------------------------------------------------------------------------------------------------------------- */
  /* --------------------------------- Step 14: Impose severity and maturity hierarchy------------------------------------------- */
  /* ---------------------------------------------------------------------------------------------------------------------------- */

  --Apply hierarchies so that that each age 0 or age 1 infant has only a single maturity variable set to 1
  --Apply hierarchies so that each age 0 or age 1 infant has only a single severity level variable, the highest qualifying level, set to 1 (see Table 8, rows 118-122).


  --56.1 sec

  create or replace table `research-01-217611.df_ucd_stage.wkg_hhs_raf_model_assignment_no_child_maturity_severity` as   --tmp H

  with severity_and_maturity_hierarchy as
        (select distinct b.savvy_pid, b.score_year_mo, b.ModelCategoryID, a.ChildModelGroupID
        from `research-01-217611.df_enrichment.hhs_raf_5_severity_and_maturity_level_hierarchy`    a
        inner join `research-01-217611.df_ucd_stage.wkg_hhs_raf_model_assignment`                  b on a.ParentModelGroupID = b.GETModelGroupID
        )

  select distinct a.*
  from `research-01-217611.df_ucd_stage.wkg_hhs_raf_model_assignment`  a
  left join severity_and_maturity_hierarchy                            b  on  a.savvy_pid        =   b.savvy_pid
                                                                         and a.score_year_mo    =   b.score_year_mo
                                                                         and a.GETModelGroupID  =   b.ChildModelGroupID
  where b.savvy_pid is null
  ;

  /* ---------------------------------------------------------------------------------------------------------------------------- */
  /* ---------------------------------------- Step 15: Adding interaction terms-------------------------------------------------- */
  /* ---------------------------------------------------------------------------------------------------------------------------- */

  --A) Interaction between group and hcc
  --Adult: (severe illness interactions based on interaction between group (severe illness variable) and individual hcc. See Rows 78-79, and row 86 of Table 6
  --Remaining rows for severe illness interactions in Adults (Rows 71-77 and rows 80-85 of Table 6) is interaction between two groups (severe illness variable and hcc group),
  --so, this interaction is handled in the next step

  --40.4 sec
  create or replace table `research-01-217611.df_ucd_stage.wkg_hhs_raf_model_assignment_and_interactions`  as

  /* Model Assignment removing child group */
  select distinct savvy_pid, score_year_mo, ModelCategoryID, GETModelGroupID, term, coefficient, Src
  from `research-01-217611.df_ucd_stage.wkg_hhs_raf_model_assignment_no_child_maturity_severity`

  union distinct

  /*Model Interactions */
  select distinct a.savvy_pid, a.score_year_mo, a.ModelCategoryID, c.GETModelGroupID, c.GetGroupterm as term, c.GetGroupCoefficient as coefficient, "5_interaction_between_group_and_hcc" Src
  from `research-01-217611.df_ucd_stage.wkg_hhs_raf_hcc_no_child_hcc`                                    a
  inner join `research-01-217611.df_ucd_stage.wkg_hhs_raf_model_assignment_no_child_maturity_severity`   b   on  a.savvy_pid          =   b.savvy_pid
                                                                                                            and a.score_year_mo      =   b.score_year_mo
                                                                                                            and a.ModelCategoryID    =   b.ModelCategoryID
  inner join `research-01-217611.df_enrichment.hhs_raf_6a_interaction_between_group_and_hcc`             c   on  a.ModelHCCID         =   c.HAVEModelHCCID                                                                                                                           and b.GetModelGroupID    =   c.HAVEModelGroupID
  ;

  --B) Interaction between two groups

  --Adult: Severe illness interactions based on interaction between two groups (severe illness variable and hcc group). See Rows 71-77 and Rows 80-85 of Table 6
  --Infant: Interaction between 2 group (maturity level and severity level). See rows 136-160 of Table 8

  --41.5sec

  insert `research-01-217611.df_ucd_stage.wkg_hhs_raf_model_assignment_and_interactions` (savvy_pid, score_year_mo, ModelCategoryID, GETModelGroupID, Term, Coefficient, Src)

  select distinct a.savvy_pid, a.score_year_mo, a.ModelCategoryID, c.GETModelGroupID, c.GetGroupterm as term, c.GetGroupCoefficient as coefficient, "6_interaction_between_two_groups" Src
  from `research-01-217611.df_ucd_stage.wkg_hhs_raf_model_assignment_and_interactions`             a
  inner join `research-01-217611.df_ucd_stage.wkg_hhs_raf_model_assignment_and_interactions`       b   on  a.savvy_pid          =   b.savvy_pid
                                                                                                      and a.score_year_mo      =   b.score_year_mo
                                                                                                      and a.ModelCategoryID    =   b.ModelCategoryID
                                                                                                      and a.GETModelGroupID    <>  b.GETModelGroupID
  inner join `research-01-217611.df_enrichment.hhs_raf_6b_interaction_between_two_groups`          c   on  c.HAVE1ModelGroupID  =   a.GETModelGroupID
                                                                                                      and c.HAVE2ModelGroupID  =   b.GETModelGroupID
  ;

  /* ---------------------------------------------------------------------------------------------------------------------------- */
  /* ---------------------------- Step 16: Creating interaction groups (based on cost) ------------------------------------------ */
  /* ---------------------------------------------------------------------------------------------------------------------------- */

  --A) High cost interaction groups (INT_GROUP_H)
  --Adult: if an adult has at least 1 of the 9 high-cost interactions
  --See rows 88-96 of Table 6

  --7.9 sec
  insert `research-01-217611.df_ucd_stage.wkg_hhs_raf_model_assignment_and_interactions` (savvy_pid, score_year_mo, ModelCategoryID, GETModelGroupID, Term, Coefficient, Src)

  select distinct a.savvy_pid, a.score_year_mo, a.ModelCategoryID, b.GETModelGroupID, b.GetGroupterm as term, b.GetGroupCoefficient as coefficient, "7_high_cost_interaction_groups" Src
  from `research-01-217611.df_ucd_stage.wkg_hhs_raf_model_assignment_and_interactions`         a
  inner join `research-01-217611.df_enrichment.hhs_raf_7a_high_cost_interaction_groups`        b     on b.HAVEModelGroupID   =   a.GETModelGroupID
  ;



  --B) Medium cost interaction groups (INT_GROUP_M)
  --Adult: if an adult has at least 1 of the 7 medium-cost interactions and doesn't have high cost interactions (INT_GROUP_H)
  --See rows 98-104 of Table 6

  --6.1 sec
  insert `research-01-217611.df_ucd_stage.wkg_hhs_raf_model_assignment_and_interactions` (savvy_pid, score_year_mo, ModelCategoryID, GETModelGroupID, Term, Coefficient, Src)

  with has_high_cost_interaction_group as
      (select savvy_pid, score_year_mo
       from `research-01-217611.df_ucd_stage.wkg_hhs_raf_model_assignment_and_interactions`      a
       inner join `research-01-217611.df_enrichment.hhs_raf_7b_medium_cost_interaction_groups`   b	 on a.GETModelGroupID = b.DONOTHAVEModelGroupID
       )

  select distinct a.savvy_pid, a.score_year_mo, a.ModelCategoryID, b.GETModelGroupID, b.GetGroupterm as term, b.GetGroupCoefficient as coefficient, "8_medium_cost_interaction_groups" Src
  from `research-01-217611.df_ucd_stage.wkg_hhs_raf_model_assignment_and_interactions`       a
  inner join `research-01-217611.df_enrichment.hhs_raf_7b_medium_cost_interaction_groups`    b   on   a.GETModelGroupID  =   b.HAVEModelGroupID
  left join  has_high_cost_interaction_group                                                 c   on   a.savvy_pid        =   c.savvy_pid
                                                                                                and  a.score_year_mo    =   c.score_year_mo
  where c.savvy_pid is null  /* The member shouldn't have high cost interaction group */

  ;
  /* ---------------------------------------------------------------------------------------------------------------------------- */
  /* ------------------------- Step 17: Hierarchy between HCC groups and individual HCCs ---------------------------------------- */
  /* ---------------------------------------------------------------------------------------------------------------------------- */

  --39.3 sec

  create or replace table `research-01-217611.df_ucd_stage.wkg_hhs_raf_hcc_no_child_hcc_based_on_hcc_group` as   --tmp G

  with hcc_group_and_hcc_hierarchy AS
        (select b.savvy_pid, b.score_year_mo, b.ModelCategoryID, a.ChildModelHCCID
        from `research-01-217611.df_enrichment.hhs_raf_8_hcc_group_and_hcc_hierarchy`                a
        inner join `research-01-217611.df_ucd_stage.wkg_hhs_raf_model_assignment_and_interactions`   b   on  a.ParentModelGroupID = b.GETModelGroupID
        )

  select a.*
  from `research-01-217611.df_ucd_stage.wkg_hhs_raf_hcc_no_child_hcc`   a
  left join hcc_group_and_hcc_hierarchy                                 b  on  a.savvy_pid       =   b.savvy_pid
                                                                          and a.score_year_mo   =   b.score_year_mo
                                                                          and a.ModelHCCID      =   b.ChildModelHCCID
  where b.savvy_pid  is null
  ;


  /* ---------------------------------------------------------------------------------------------------------------------------- */
  /* --------------------------------- Step 18: Create raf metal scores table --------------------------------------------------- */
  /* ---------------------------------------------------------------------------------------------------------------------------- */
  --1min 4 sec

  create or replace table `research-01-217611.df_ucd_stage.wkg_hhs_raf_metal_scores` as   --tmp I

  with all_combined as
      (select distinct savvy_pid, score_year_mo, ModelCategoryID, Coefficient
      from `research-01-217611.df_ucd_stage.wkg_hhs_raf_hcc_no_child_hcc_based_on_hcc_group`
      union all
      select savvy_pid, score_year_mo, ModelCategoryID, Coefficient
      from (select distinct savvy_pid, score_year_mo, ModelCategoryID, GETModelGroupID, Term, Coefficient   --Using distinct here to make sure there is no duplicates from different "Src".
            from `research-01-217611.df_ucd_stage.wkg_hhs_raf_model_assignment_and_interactions`
            )
      union all
      select savvy_pid, score_year_mo, ModelCategoryID, EditedCoefficient
      from `research-01-217611.df_ucd_stage.wkg_hhs_raf_age_edits`
      )

  select a.savvy_pid, a.score_year_mo, b.ModelCategory, c.ModelVersion, sum(Coefficient) TotalScore
  from all_combined                                                               a
  join `research-01-217611.df_enrichment.hhs_raf_model_category`                  b   on   a.ModelCategoryID  =   b.ModelCategoryID
  join `research-01-217611.df_enrichment.hhs_raf_model`                           c   on   c.ModelID          =   b.ModelID
  join `research-01-217611.df_ucd_stage.wkg_summary_member_scoring_period`        d   on   a.savvy_pid        =   d.savvy_pid
                                                                                      and  a.score_year_mo    =   d.score_year_mo
  where d.gender_cd IN ("m","f")
  group by a.savvy_pid, a.score_year_mo, b.ModelCategory, c.ModelVersion
  ;

  /* ---------------------------------------------------------------------------------------------------------------------------- */
  /* ----------------------------------- Step 19: Pivot scores in one row ------------------------------------------------------- */
  /* ---------------------------------------------------------------------------------------------------------------------------- */

  --53.3 sec
  create or replace table `research-01-217611.df_ucd_stage.wkg_hhs_raf_metal_scores_pivoted` AS

  select savvy_pid, score_year_mo, ModelCategory, sum(case when ModelVersion = version_name then TotalScore else 0 End) raf_score
  from `research-01-217611.df_ucd_stage.wkg_hhs_raf_metal_scores`
  group by savvy_pid, score_year_mo, ModelCategory

  ;


  /* ---------------------------------------------------------------------------------------------------------------------------- */
  /* ----------------------------------- Step 20: Adding HCC to the pivoted RAF table ------------------------------------------- */
  /* ---------------------------------------------------------------------------------------------------------------------------- */

  --2min 12sec
  create or replace table `research-01-217611.df_ucd_stage.wkg_hhs_raf_metal_scores_pivoted_and_hcc` as

  SELECT hhsraf.savvy_pid, hhsraf.score_year_mo, round(hhsraf.raf_score,3) as raf
                      , MAX(CASE WHEN fact.HCCNbr = 1 THEN 1 ELSE 0 END) AS hcc001
                      , MAX(CASE WHEN fact.HCCNbr = 2 THEN 1 ELSE 0 END) AS hcc002
                      , MAX(CASE WHEN fact.HCCNbr = 3 THEN 1 ELSE 0 END) AS hcc003
                      , MAX(CASE WHEN fact.HCCNbr = 4 THEN 1 ELSE 0 END) AS hcc004
                      , MAX(CASE WHEN fact.HCCNbr = 6 THEN 1 ELSE 0 END) AS hcc006
                      , MAX(CASE WHEN fact.HCCNbr = 8 THEN 1 ELSE 0 END) AS hcc008
                      , MAX(CASE WHEN fact.HCCNbr = 9 THEN 1 ELSE 0 END) AS hcc009
                      , MAX(CASE WHEN fact.HCCNbr = 10 THEN 1 ELSE 0 END) AS hcc010
                      , MAX(CASE WHEN fact.HCCNbr = 11 THEN 1 ELSE 0 END) AS hcc011
                      , MAX(CASE WHEN fact.HCCNbr = 12 THEN 1 ELSE 0 END) AS hcc012
                      , MAX(CASE WHEN fact.HCCNbr = 13 THEN 1 ELSE 0 END) AS hcc013
                      , MAX(CASE WHEN fact.HCCNbr = 18 THEN 1 ELSE 0 END) AS hcc018
                      , MAX(CASE WHEN fact.HCCNbr = 19 THEN 1 ELSE 0 END) AS hcc019
                      , MAX(CASE WHEN fact.HCCNbr = 20 THEN 1 ELSE 0 END) AS hcc020
                      , MAX(CASE WHEN fact.HCCNbr = 21 THEN 1 ELSE 0 END) AS hcc021
                      , MAX(CASE WHEN fact.HCCNbr = 23 THEN 1 ELSE 0 END) AS hcc023
                      , MAX(CASE WHEN fact.HCCNbr = 26 THEN 1 ELSE 0 END) AS hcc026
                      , MAX(CASE WHEN fact.HCCNbr = 27 THEN 1 ELSE 0 END) AS hcc027
                      , MAX(CASE WHEN fact.HCCNbr = 28 THEN 1 ELSE 0 END) AS hcc028
                      , MAX(CASE WHEN fact.HCCNbr = 29 THEN 1 ELSE 0 END) AS hcc029
                      , MAX(CASE WHEN fact.HCCNbr = 30 THEN 1 ELSE 0 END) AS hcc030
                      , MAX(CASE WHEN fact.HCCNbr = 34 THEN 1 ELSE 0 END) AS hcc034
                      , MAX(CASE WHEN fact.HCCNbr = 35 THEN 1 ELSE 0 END) AS hcc035
                      , MAX(CASE WHEN fact.HCCNbr = 36 THEN 1 ELSE 0 END) AS hcc036
                      , MAX(CASE WHEN fact.HCCNbr = 37 THEN 1 ELSE 0 END) AS hcc037
                      , MAX(CASE WHEN fact.HCCNbr = 38 THEN 1 ELSE 0 END) AS hcc038
                      , MAX(CASE WHEN fact.HCCNbr = 41 THEN 1 ELSE 0 END) AS hcc041
                      , MAX(CASE WHEN fact.HCCNbr = 42 THEN 1 ELSE 0 END) AS hcc042
                      , MAX(CASE WHEN fact.HCCNbr = 45 THEN 1 ELSE 0 END) AS hcc045
                      , MAX(CASE WHEN fact.HCCNbr = 46 THEN 1 ELSE 0 END) AS hcc046
                      , MAX(CASE WHEN fact.HCCNbr = 47 THEN 1 ELSE 0 END) AS hcc047
                      , MAX(CASE WHEN fact.HCCNbr = 48 THEN 1 ELSE 0 END) AS hcc048
                      , MAX(CASE WHEN fact.HCCNbr = 54 THEN 1 ELSE 0 END) AS hcc054
                      , MAX(CASE WHEN fact.HCCNbr = 55 THEN 1 ELSE 0 END) AS hcc055
                      , MAX(CASE WHEN fact.HCCNbr = 56 THEN 1 ELSE 0 END) AS hcc056
                      , MAX(CASE WHEN fact.HCCNbr = 57 THEN 1 ELSE 0 END) AS hcc057
                      , MAX(CASE WHEN fact.HCCNbr = 61 THEN 1 ELSE 0 END) AS hcc061
                      , MAX(CASE WHEN fact.HCCNbr = 62 THEN 1 ELSE 0 END) AS hcc062
                      , MAX(CASE WHEN fact.HCCNbr = 63 THEN 1 ELSE 0 END) AS hcc063
                      , MAX(CASE WHEN fact.HCCNbr = 64 THEN 1 ELSE 0 END) AS hcc064
                      , MAX(CASE WHEN fact.HCCNbr = 66 THEN 1 ELSE 0 END) AS hcc066
                      , MAX(CASE WHEN fact.HCCNbr = 67 THEN 1 ELSE 0 END) AS hcc067
                      , MAX(CASE WHEN fact.HCCNbr = 68 THEN 1 ELSE 0 END) AS hcc068
                      , MAX(CASE WHEN fact.HCCNbr = 69 THEN 1 ELSE 0 END) AS hcc069
                      , MAX(CASE WHEN fact.HCCNbr = 70 THEN 1 ELSE 0 END) AS hcc070
                      , MAX(CASE WHEN fact.HCCNbr = 71 THEN 1 ELSE 0 END) AS hcc071
                      , MAX(CASE WHEN fact.HCCNbr = 73 THEN 1 ELSE 0 END) AS hcc073
                      , MAX(CASE WHEN fact.HCCNbr = 74 THEN 1 ELSE 0 END) AS hcc074
                      , MAX(CASE WHEN fact.HCCNbr = 75 THEN 1 ELSE 0 END) AS hcc075
                      , MAX(CASE WHEN fact.HCCNbr = 81 THEN 1 ELSE 0 END) AS hcc081
                      , MAX(CASE WHEN fact.HCCNbr = 82 THEN 1 ELSE 0 END) AS hcc082
                      , MAX(CASE WHEN fact.HCCNbr = 87 THEN 1 ELSE 0 END) AS hcc087
                      , MAX(CASE WHEN fact.HCCNbr = 88 THEN 1 ELSE 0 END) AS hcc088
                      , MAX(CASE WHEN fact.HCCNbr = 89 THEN 1 ELSE 0 END) AS hcc089
                      , MAX(CASE WHEN fact.HCCNbr = 90 THEN 1 ELSE 0 END) AS hcc090
                      , MAX(CASE WHEN fact.HCCNbr = 94 THEN 1 ELSE 0 END) AS hcc094
                      , MAX(CASE WHEN fact.HCCNbr = 96 THEN 1 ELSE 0 END) AS hcc096
                      , MAX(CASE WHEN fact.HCCNbr = 97 THEN 1 ELSE 0 END) AS hcc097
                      , MAX(CASE WHEN fact.HCCNbr = 102 THEN 1 ELSE 0 END) AS hcc102
                      , MAX(CASE WHEN fact.HCCNbr = 103 THEN 1 ELSE 0 END) AS hcc103
                      , MAX(CASE WHEN fact.HCCNbr = 106 THEN 1 ELSE 0 END) AS hcc106
                      , MAX(CASE WHEN fact.HCCNbr = 107 THEN 1 ELSE 0 END) AS hcc107
                      , MAX(CASE WHEN fact.HCCNbr = 108 THEN 1 ELSE 0 END) AS hcc108
                      , MAX(CASE WHEN fact.HCCNbr = 109 THEN 1 ELSE 0 END) AS hcc109
                      , MAX(CASE WHEN fact.HCCNbr = 110 THEN 1 ELSE 0 END) AS hcc110
                      , MAX(CASE WHEN fact.HCCNbr = 111 THEN 1 ELSE 0 END) AS hcc111
                      , MAX(CASE WHEN fact.HCCNbr = 112 THEN 1 ELSE 0 END) AS hcc112
                      , MAX(CASE WHEN fact.HCCNbr = 113 THEN 1 ELSE 0 END) AS hcc113
                      , MAX(CASE WHEN fact.HCCNbr = 114 THEN 1 ELSE 0 END) AS hcc114
                      , MAX(CASE WHEN fact.HCCNbr = 115 THEN 1 ELSE 0 END) AS hcc115
                      , MAX(CASE WHEN fact.HCCNbr = 117 THEN 1 ELSE 0 END) AS hcc117
                      , MAX(CASE WHEN fact.HCCNbr = 118 THEN 1 ELSE 0 END) AS hcc118
                      , MAX(CASE WHEN fact.HCCNbr = 119 THEN 1 ELSE 0 END) AS hcc119
                      , MAX(CASE WHEN fact.HCCNbr = 120 THEN 1 ELSE 0 END) AS hcc120
                      , MAX(CASE WHEN fact.HCCNbr = 121 THEN 1 ELSE 0 END) AS hcc121
                      , MAX(CASE WHEN fact.HCCNbr = 122 THEN 1 ELSE 0 END) AS hcc122
                      , MAX(CASE WHEN fact.HCCNbr = 125 THEN 1 ELSE 0 END) AS hcc125
                      , MAX(CASE WHEN fact.HCCNbr = 126 THEN 1 ELSE 0 END) AS hcc126
                      , MAX(CASE WHEN fact.HCCNbr = 127 THEN 1 ELSE 0 END) AS hcc127
                      , MAX(CASE WHEN fact.HCCNbr = 128 THEN 1 ELSE 0 END) AS hcc128
                      , MAX(CASE WHEN fact.HCCNbr = 129 THEN 1 ELSE 0 END) AS hcc129
                      , MAX(CASE WHEN fact.HCCNbr = 130 THEN 1 ELSE 0 END) AS hcc130
                      , MAX(CASE WHEN fact.HCCNbr = 131 THEN 1 ELSE 0 END) AS hcc131
                      , MAX(CASE WHEN fact.HCCNbr = 132 THEN 1 ELSE 0 END) AS hcc132
                      , MAX(CASE WHEN fact.HCCNbr = 135 THEN 1 ELSE 0 END) AS hcc135
                      , MAX(CASE WHEN fact.HCCNbr = 137 THEN 1 ELSE 0 END) AS hcc137
                      , MAX(CASE WHEN fact.HCCNbr = 138 THEN 1 ELSE 0 END) AS hcc138
                      , MAX(CASE WHEN fact.HCCNbr = 139 THEN 1 ELSE 0 END) AS hcc139
                      , MAX(CASE WHEN fact.HCCNbr = 142 THEN 1 ELSE 0 END) AS hcc142
                      , MAX(CASE WHEN fact.HCCNbr = 145 THEN 1 ELSE 0 END) AS hcc145
                      , MAX(CASE WHEN fact.HCCNbr = 146 THEN 1 ELSE 0 END) AS hcc146
                      , MAX(CASE WHEN fact.HCCNbr = 149 THEN 1 ELSE 0 END) AS hcc149
                      , MAX(CASE WHEN fact.HCCNbr = 150 THEN 1 ELSE 0 END) AS hcc150
                      , MAX(CASE WHEN fact.HCCNbr = 151 THEN 1 ELSE 0 END) AS hcc151
                      , MAX(CASE WHEN fact.HCCNbr = 153 THEN 1 ELSE 0 END) AS hcc153
                      , MAX(CASE WHEN fact.HCCNbr = 154 THEN 1 ELSE 0 END) AS hcc154
                      , MAX(CASE WHEN fact.HCCNbr = 156 THEN 1 ELSE 0 END) AS hcc156
                      , MAX(CASE WHEN fact.HCCNbr = 158 THEN 1 ELSE 0 END) AS hcc158
                      , MAX(CASE WHEN fact.HCCNbr = 159 THEN 1 ELSE 0 END) AS hcc159
                      , MAX(CASE WHEN fact.HCCNbr = 160 THEN 1 ELSE 0 END) AS hcc160
                      , MAX(CASE WHEN fact.HCCNbr = 161 THEN 1 ELSE 0 END) AS hcc161
                      , MAX(CASE WHEN fact.HCCNbr = 162 THEN 1 ELSE 0 END) AS hcc162
                      , MAX(CASE WHEN fact.HCCNbr = 163 THEN 1 ELSE 0 END) AS hcc163
                      , MAX(CASE WHEN fact.HCCNbr = 183 THEN 1 ELSE 0 END) AS hcc183
                      , MAX(CASE WHEN fact.HCCNbr = 184 THEN 1 ELSE 0 END) AS hcc184
                      , MAX(CASE WHEN fact.HCCNbr = 187 THEN 1 ELSE 0 END) AS hcc187
                      , MAX(CASE WHEN fact.HCCNbr = 188 THEN 1 ELSE 0 END) AS hcc188
                      , MAX(CASE WHEN fact.HCCNbr = 203 THEN 1 ELSE 0 END) AS hcc203
                      , MAX(CASE WHEN fact.HCCNbr = 204 THEN 1 ELSE 0 END) AS hcc204
                      , MAX(CASE WHEN fact.HCCNbr = 205 THEN 1 ELSE 0 END) AS hcc205
                      , MAX(CASE WHEN fact.HCCNbr = 207 THEN 1 ELSE 0 END) AS hcc207
                      , MAX(CASE WHEN fact.HCCNbr = 208 THEN 1 ELSE 0 END) AS hcc208
                      , MAX(CASE WHEN fact.HCCNbr = 209 THEN 1 ELSE 0 END) AS hcc209
                      , MAX(CASE WHEN fact.HCCNbr = 217 THEN 1 ELSE 0 END) AS hcc217
                      , MAX(CASE WHEN fact.HCCNbr = 226 THEN 1 ELSE 0 END) AS hcc226
                      , MAX(CASE WHEN fact.HCCNbr = 227 THEN 1 ELSE 0 END) AS hcc227
                      , MAX(CASE WHEN fact.HCCNbr = 242 THEN 1 ELSE 0 END) AS hcc242
                      , MAX(CASE WHEN fact.HCCNbr = 243 THEN 1 ELSE 0 END) AS hcc243
                      , MAX(CASE WHEN fact.HCCNbr = 244 THEN 1 ELSE 0 END) AS hcc244
                      , MAX(CASE WHEN fact.HCCNbr = 245 THEN 1 ELSE 0 END) AS hcc245
                      , MAX(CASE WHEN fact.HCCNbr = 246 THEN 1 ELSE 0 END) AS hcc246
                      , MAX(CASE WHEN fact.HCCNbr = 247 THEN 1 ELSE 0 END) AS hcc247
                      , MAX(CASE WHEN fact.HCCNbr = 248 THEN 1 ELSE 0 END) AS hcc248
                      , MAX(CASE WHEN fact.HCCNbr = 249 THEN 1 ELSE 0 END) AS hcc249
                      , MAX(CASE WHEN fact.HCCNbr = 251 THEN 1 ELSE 0 END) AS hcc251
                      , MAX(CASE WHEN fact.HCCNbr = 253 THEN 1 ELSE 0 END) AS hcc253
                      , MAX(CASE WHEN fact.HCCNbr = 254 THEN 1 ELSE 0 END) AS hcc254
  from `research-01-217611.df_ucd_stage.wkg_hhs_raf_metal_scores_pivoted`       hhsraf
  left join `research-01-217611.df_ucd_stage.wkg_hhs_raf_hcc_no_child_hcc`      fact     on   hhsraf.savvy_pid       =   fact.savvy_pid
                                                                                        and  hhsraf.score_year_mo   =   fact.score_year_mo
  group by hhsraf.savvy_pid, hhsraf.score_year_mo, hhsraf.raf_score


  ;
  /* ---------------------------------------------------------------------------------------------------------------------------- */
  /* ----------------------------------- Step 21: Creating final RAF table ------------------------------------------------------ */
  /* ---------------------------------------------------------------------------------------------------------------------------- */

  -- 1min 28 sec

  insert into `research-01-217611.df_ucd_stage.hhs_raf_scores`
    (savvy_pid, savvy_did, is_restricted, score_year_mo, scoring_period_start_date, scoring_period_end_date, mm_enrolled_during_scoring_period, last_year_mo_enrolled_during_scoring_period, had_claim_during_scoring_period_flag, gender, age, raf, hcc001, hcc002, hcc003, hcc004, hcc006, hcc008, hcc009, hcc010, hcc011, hcc012, hcc013, hcc018, hcc019, hcc020, hcc021, hcc023, hcc026, hcc027, hcc028, hcc029, hcc030, hcc034, hcc035, hcc036, hcc037, hcc038, hcc041, hcc042, hcc045, hcc046, hcc047, hcc048, hcc054, hcc055, hcc056, hcc057, hcc061, hcc062, hcc063, hcc064, hcc066, hcc067, hcc068, hcc069, hcc070, hcc071, hcc073, hcc074, hcc075, hcc081, hcc082, hcc087, hcc088, hcc089, hcc090, hcc094, hcc096, hcc097, hcc102, hcc103, hcc106, hcc107, hcc108, hcc109, hcc110, hcc111, hcc112, hcc113, hcc114, hcc115, hcc117, hcc118, hcc119, hcc120, hcc121, hcc122, hcc125, hcc126, hcc127, hcc128, hcc129, hcc130, hcc131, hcc132, hcc135, hcc137, hcc138, hcc139, hcc142, hcc145, hcc146, hcc149, hcc150, hcc151, hcc153, hcc154, hcc156, hcc158, hcc159, hcc160, hcc161, hcc162, hcc163, hcc183, hcc184, hcc187, hcc188, hcc203, hcc204, hcc205, hcc207, hcc208, hcc209, hcc217, hcc226, hcc227, hcc242, hcc243, hcc244, hcc245, hcc246, hcc247, hcc248, hcc249, hcc251, hcc253, hcc254
    )

  select mbr.savvy_pid, mbr.savvy_did, mbr.is_restricted, mbr.score_year_mo, mbr.scoring_period_start_date, mbr.scoring_period_end_date
                      , mbr.mm_enrolled_during_scoring_period, mbr.last_year_mo_enrolled_during_scoring_period
                      , mbr.had_claim_during_scoring_period_flag
                      , mbr.gender_cd as gender, mbr.age_last as age
                      , raf.* except (savvy_pid, score_year_mo)
  from `research-01-217611.df_ucd_stage.wkg_summary_member_scoring_period`                       mbr
  left join `research-01-217611.df_ucd_stage.wkg_hhs_raf_metal_scores_pivoted_and_hcc`           raf     on   mbr.savvy_pid       =   raf.savvy_pid
                                                                                                         and  mbr.score_year_mo   =   raf.score_year_mo
   ;


  /* ---------------------------------------------------------------------------------------------------------------------------- */
  /* ----------------------------------- Step 22: Drop intermediate tables ------------------------------------------------------ */
  /* ---------------------------------------------------------------------------------------------------------------------------- */

  /* drop temporary tables
  drop table `research-01-217611.df_ucd_stage.wkg_hhs_raf_date_range_rolling_12_month_periods`;
  drop table `research-01-217611.df_ucd_stage.wkg_hhs_raf_person`;
  drop table `research-01-217611.df_ucd_stage.wkg_hhs_raf_claim`;
  drop table `research-01-217611.df_ucd_stage.wkg_hhs_raf_flag_for_claim_during_scoring_period`;
  drop table `research-01-217611.df_ucd_stage.wkg_hhs_raf_identify_model_category`;
  drop table `research-01-217611.df_ucd_stage.wkg_hhs_raf_diag`;
  drop table `research-01-217611.df_ucd_stage.wkg_hhs_raf_hcc`;
  drop table `research-01-217611.df_ucd_stage.wkg_hhs_raf_hcc_no_child_hcc`;
  drop table `research-01-217611.df_ucd_stage.wkg_hhs_raf_age_cat`;
  drop table `research-01-217611.df_ucd_stage.wkg_hhs_raf_model_assignment`;
  drop table `research-01-217611.df_ucd_stage.wkg_hhs_raf_age_edits`;
  drop table `research-01-217611.df_ucd_stage.wkg_hhs_raf_model_assignment_no_child_maturity_severity`;
  drop table `research-01-217611.df_ucd_stage.wkg_hhs_raf_model_assignment_and_interactions`;
  drop table `research-01-217611.df_ucd_stage.wkg_hhs_raf_hcc_no_child_hcc_based_on_hcc_group`;
  drop table `research-01-217611.df_ucd_stage.wkg_hhs_raf_metal_scores`;
  drop table `research-01-217611.df_ucd_stage.wkg_hhs_raf_metal_scores_pivoted`;
  drop table `research-01-217611.df_ucd_stage.wkg_hhs_raf_metal_scores_pivoted_and_hcc`;
  */


    --if successful, we'll get here!
    insert into `research-01-217611.df_ucd_stage.logging`(
      success_flag, job, message_datetime)
    select
      1 as success_flag
      , 'hhs raf scores' as job
      , current_datetime as message_datetime
    ;

    EXCEPTION WHEN ERROR THEN
      insert into `research-01-217611.df_ucd_stage.logging`(
        success_flag, job, error_message, statement_text, formatted_stack_trace, message_datetime)
      select
        0 as success_flag
        , 'hhs raf scores' as job
        , @@error.message as error_message
        , @@error.statement_text as statement_text
        , @@error.formatted_stack_trace as formatted_stack_trace
        , current_datetime as message_datetime
      ;
END
;
