/***
Universal Claims Data Model - SMA Medical Claim Mapping (new paradigm)

Date Created: 22 October 2020
***/

BEGIN

  -- delete
  -- from `research-01-217611.df_ucd_stage.udd_medical_claim_sma`
  -- where 1=1
  -- ;

  insert into `research-01-217611.df_ucd_stage.udd_medical_claim_sma`
    (uuid, savvy_pid, savvy_did, is_restricted, src_type, clm_aud_nbr, line_number, data_source, claim_sub_type, clm_dt,
    icd_ver_cd, dx1_diag_cd, dx2_diag_cd, dx3_diag_cd, dx4_diag_cd, dx5_diag_cd, dx6_diag_cd, dx7_diag_cd, dx8_diag_cd, dx9_diag_cd, dx10_diag_cd, dx11_diag_cd, dx12_diag_cd,
    rvnu_cd, proc_cd, prc1_proc_cd, prc2_proc_cd, prc3_proc_cd, prc4_proc_cd, prc5_proc_cd, prc6_proc_cd,
    drg_cd, dschrg_sts_cd, proc_mod_1_cd, proc_mod_2_cd, proc_mod_3_cd, srvc_typ_cd,
    prov_mpin, prov_tin, prov_fst_nm, prov_lst_nm, prov_zip_cd, prov_state, npi, pcp_flag, provtype, spec_typ_nm, hp_prov_cat_typ_nm,
    ama_pl_of_srvc_cd, ama_pl_of_srvc_desc, prov_prtcp_sts_cd, hp_prov_sts_rllp_desc, hlth_pln_srvc_typ_cd, hce_srvc_typ_desc, bil_typ_cd,
    bil_amt, allw_amt, net_pd_amt, oop_amt, copay_amt, ded_amt, coins_amt, disallow_amt, cob_amt,
    admit_cnt, day_cnt, srvc_unit_cnt, adjudication_dt, admit_dt, discharge_dt, create_datetime, update_datetime
    )
  select GENERATE_UUID() uuid
    , a.savvy_pid
    , a.savvy_did
    , a.is_restricted
    , 'sma' as src_type
    --, a.business_line  --will be part of the v2 enhancement; member_detail business line info should be used instead
    , ifnull(lower(trim(a.claim_number)), '') as clm_aud_nbr
    , safe_cast(a.line_number as string) as line_number
    , concat('ds-00-191017.sierrahealth_sma_final.medical: ', ifnull(lower(trim(a.source)), '')) as data_source
    , ifnull(lower(trim(a.claim_subtype )), '') claim_sub_type
    , a.service_date as clm_dt
    , case when ifnull(lower(trim(a.diagnosis_code_type)), '0') in ('0', '') then 10 else safe_cast(lower(trim(a.diagnosis_code_type)) as int64) end as icd_ver_cd
    , ifnull(lower(trim(a.primary_diagnosis_code)), '') as dx1_diag_cd
    , ifnull(b.dx2_diag_cd, '') as dx2_diag_cd
    , ifnull(b.dx3_diag_cd, '') as dx3_diag_cd
    , ifnull(b.dx4_diag_cd, '') as dx4_diag_cd
    , ifnull(b.dx5_diag_cd, '') as dx5_diag_cd
    , ifnull(b.dx6_diag_cd, '') as dx6_diag_cd
    , ifnull(b.dx7_diag_cd, '') as dx7_diag_cd
    , ifnull(b.dx8_diag_cd, '') as dx8_diag_cd
    , ifnull(b.dx9_diag_cd, '') as dx9_diag_cd
    , ifnull(b.dx10_diag_cd, '') as dx10_diag_cd
    , ifnull(b.dx11_diag_cd, '') as dx11_diag_cd
    , ifnull(b.dx12_diag_cd, '') as dx12_diag_cd
    , ifnull(replace(lower(trim(a.revenue_code)), 'unk', ''), '') as rvnu_cd
    , ifnull(lower(trim(a.procedure_code)), '') as proc_cd
    , '' as prc1_proc_cd
    , '' as prc2_proc_cd
    , '' as prc3_proc_cd
    , '' as prc4_proc_cd
    , '' as prc5_proc_cd
    , '' as prc6_proc_cd
    , case when (case when lower(trim(a.utilization_category)) = 'ip' and lower(trim(a.claim_subtype)) = 'h'  then 'ip'
                      when lower(trim(a.utilization_category)) <> 'oth' then (case when lower(trim(a.utilization_category)) = 'phy' then 'dr' else lower(trim(a.utilization_category)) end)
                      when lower(trim(a.utilization_category)) = 'oth' and lower(trim(a.claim_subtype)) = 'h' and lower(trim(c.ama_pl_of_srvc_desc)) in ('skilled nursing facility','inpatient hospital')     then 'ip'
                      when lower(trim(a.utilization_category)) = 'oth' and lower(trim(a.claim_subtype)) = 'h' and lower(trim(c.ama_pl_of_srvc_desc)) not in ('skilled nursing facility','inpatient hospital') then 'op'
                      when lower(trim(a.utilization_category)) = 'oth' and lower(trim(a.claim_subtype)) = 'm' and h.utilization_category is not null
                            then (case when lower(trim(h.utilization_category)) = 'phy' then 'dr' else lower(trim(h.utilization_category)) end)
                      when lower(trim(a.utilization_category)) = 'oth' and lower(trim(a.claim_subtype)) = 'm' and h.utilization_category is null       then 'op'
                  else lower(trim(a.utilization_category)) end) = 'ip'
                and a.service_end_date > a.service_begin_date
                and a.line_number = 1
            then '00000'
            else ''
            end as drg_cd
    , case when (case when lower(trim(a.utilization_category)) = 'ip' and lower(trim(a.claim_subtype)) = 'h'  then 'ip'
                      when lower(trim(a.utilization_category)) <> 'oth' then (case when lower(trim(a.utilization_category)) = 'phy' then 'dr' else lower(trim(a.utilization_category)) end)
                      when lower(trim(a.utilization_category)) = 'oth' and lower(trim(a.claim_subtype)) = 'h' and lower(trim(c.ama_pl_of_srvc_desc)) in ('skilled nursing facility','inpatient hospital')     then 'ip'
                      when lower(trim(a.utilization_category)) = 'oth' and lower(trim(a.claim_subtype)) = 'h' and lower(trim(c.ama_pl_of_srvc_desc)) not in ('skilled nursing facility','inpatient hospital') then 'op'
                      when lower(trim(a.utilization_category)) = 'oth' and lower(trim(a.claim_subtype)) = 'm' and h.utilization_category is not null
                            then (case when lower(trim(h.utilization_category)) = 'phy' then 'dr' else lower(trim(h.utilization_category)) end)
                      when lower(trim(a.utilization_category)) = 'oth' and lower(trim(a.claim_subtype)) = 'm' and h.utilization_category is null       then 'op'
                  else lower(trim(a.utilization_category)) end) = 'ip'
                and a.service_end_date > a.service_begin_date
                and a.line_number = 1
            then '00'
            else ''
            end as dschrg_sts_cd
    , ifnull(lower(trim(a.procedure_modifier)), '') as proc_mod_1_cd
    , '' as proc_mod_2_cd
    , '' as proc_mod_3_cd
    --, a.utilization_category as srvc_typ_cd --replace with the Kiara logic here
    , (case when lower(trim(a.utilization_category)) = 'ip' and lower(trim(a.claim_subtype)) = 'h'  then 'ip'
            when lower(trim(a.utilization_category)) <> 'oth' then (case when lower(trim(a.utilization_category)) = 'phy' then 'dr' else lower(trim(a.utilization_category)) end)
            when lower(trim(a.utilization_category)) = 'oth' and lower(trim(a.claim_subtype)) = 'h' and lower(trim(c.ama_pl_of_srvc_desc)) in ('skilled nursing facility','inpatient hospital')     then 'ip'
            when lower(trim(a.utilization_category)) = 'oth' and lower(trim(a.claim_subtype)) = 'h' and lower(trim(c.ama_pl_of_srvc_desc)) not in ('skilled nursing facility','inpatient hospital') then 'op'
            when lower(trim(a.utilization_category)) = 'oth' and lower(trim(a.claim_subtype)) = 'm' and h.utilization_category is not null
                  then (case when lower(trim(h.utilization_category)) = 'phy' then 'dr' else lower(trim(h.utilization_category)) end)
            when lower(trim(a.utilization_category)) = 'oth' and lower(trim(a.claim_subtype)) = 'm' and h.utilization_category is null       then 'op'
       else lower(trim(a.utilization_category)) end) as srvc_typ_cd
    , 0 as prov_mpin
    , ifnull(lower(trim(d.provider_tax_id)), '') as prov_tin
    , '' as prov_fst_nm
    , ifnull(lower(trim(d.provider_name)), '') as prov_lst_nm
    , ifnull(lower(trim(d.provider_zip)), '') as prov_zip_cd
    , ifnull(lower(trim(d.provider_state)), '') as prov_state
    , ifnull(safe_cast(lower(trim(d.provider_npi)) as int64), 0) as npi
    , 0 as pcp_flag  --can be derived; do we need this here in UDD?
    , '' as provtype
    , ifnull(lower(trim(d.provider_specialty)), '') as spec_typ_nm
    , '' as hp_prov_cat_typ_nm
    , ifnull(lower(trim(a.place_of_service)), '00') as ama_pl_of_srvc_cd
    , ifnull(lower(trim(c.ama_pl_of_srvc_desc)), '') as ama_pl_of_srvc_desc
    , '' as prov_prtcp_sts_cd
    , ifnull(lower(trim(a.network_status)), '') as hp_prov_sts_rllp_desc
    , 'unk' as hlth_pln_srvc_typ_cd
    , '' as hce_srvc_typ_desc
    , '' as bil_typ_cd   --bill_type is populated with 'unknown'
    , ifnull(cast(a.bill_amt as numeric), 0) as bil_amt
    , ifnull(cast(a.allow_amt as numeric), 0) as allw_amt
    , ifnull(cast(a.paid_amt as numeric), 0) as net_pd_amt
    , 0 as oop_amt
    , ifnull(cast(a.copay_amt as numeric), 0) as copay_amt
    , ifnull(cast(a.deductible_amt as numeric), 0) as ded_amt
    , ifnull(cast(a.coins_amt as numeric), 0) as coins_amt
    , ifnull(cast(a.disallow_amt as numeric), 0) as disallow_amt
    , 0 as cob_amt
    , case when (case when lower(trim(a.utilization_category)) = 'ip' and lower(trim(a.claim_subtype)) = 'h'  then 'ip'
                      when lower(trim(a.utilization_category)) <> 'oth' then (case when lower(trim(a.utilization_category)) = 'phy' then 'dr' else lower(trim(a.utilization_category)) end)
                      when lower(trim(a.utilization_category)) = 'oth' and lower(trim(a.claim_subtype)) = 'h' and lower(trim(c.ama_pl_of_srvc_desc)) in ('skilled nursing facility','inpatient hospital')     then 'ip'
                      when lower(trim(a.utilization_category)) = 'oth' and lower(trim(a.claim_subtype)) = 'h' and lower(trim(c.ama_pl_of_srvc_desc)) not in ('skilled nursing facility','inpatient hospital') then 'op'
                      when lower(trim(a.utilization_category)) = 'oth' and lower(trim(a.claim_subtype)) = 'm' and h.utilization_category is not null
                            then (case when lower(trim(h.utilization_category)) = 'phy' then 'dr' else lower(trim(h.utilization_category)) end)
                      when lower(trim(a.utilization_category)) = 'oth' and lower(trim(a.claim_subtype)) = 'm' and h.utilization_category is null       then 'op'
                  else lower(trim(a.utilization_category)) end) = 'ip'
                and a.service_end_date > a.service_begin_date
                and a.line_number = 1
            then 1
            else 0
            end as admit_cnt
    , case when (case when lower(trim(a.utilization_category)) = 'ip' and lower(trim(a.claim_subtype)) = 'h'  then 'ip'
                      when lower(trim(a.utilization_category)) <> 'oth' then (case when lower(trim(a.utilization_category)) = 'phy' then 'dr' else lower(trim(a.utilization_category)) end)
                      when lower(trim(a.utilization_category)) = 'oth' and lower(trim(a.claim_subtype)) = 'h' and lower(trim(c.ama_pl_of_srvc_desc)) in ('skilled nursing facility','inpatient hospital')     then 'ip'
                      when lower(trim(a.utilization_category)) = 'oth' and lower(trim(a.claim_subtype)) = 'h' and lower(trim(c.ama_pl_of_srvc_desc)) not in ('skilled nursing facility','inpatient hospital') then 'op'
                      when lower(trim(a.utilization_category)) = 'oth' and lower(trim(a.claim_subtype)) = 'm' and h.utilization_category is not null
                            then (case when lower(trim(h.utilization_category)) = 'phy' then 'dr' else lower(trim(h.utilization_category)) end)
                      when lower(trim(a.utilization_category)) = 'oth' and lower(trim(a.claim_subtype)) = 'm' and h.utilization_category is null       then 'op'
                  else lower(trim(a.utilization_category)) end) = 'ip'
                and a.service_end_date > a.service_begin_date
                and a.line_number = 1
            then DATE_DIFF(service_end_date, service_begin_date, DAY)
            else 0
            end as day_cnt
    , 0 as srvc_unit_cnt
    , cast(NULL as date) as adjudication_dt
    , case when (case when lower(trim(a.utilization_category)) = 'ip' and lower(trim(a.claim_subtype)) = 'h'  then 'ip'
                      when lower(trim(a.utilization_category)) <> 'oth' then (case when lower(trim(a.utilization_category)) = 'phy' then 'dr' else lower(trim(a.utilization_category)) end)
                      when lower(trim(a.utilization_category)) = 'oth' and lower(trim(a.claim_subtype)) = 'h' and lower(trim(c.ama_pl_of_srvc_desc)) in ('skilled nursing facility','inpatient hospital')     then 'ip'
                      when lower(trim(a.utilization_category)) = 'oth' and lower(trim(a.claim_subtype)) = 'h' and lower(trim(c.ama_pl_of_srvc_desc)) not in ('skilled nursing facility','inpatient hospital') then 'op'
                      when lower(trim(a.utilization_category)) = 'oth' and lower(trim(a.claim_subtype)) = 'm' and h.utilization_category is not null
                            then (case when lower(trim(h.utilization_category)) = 'phy' then 'dr' else lower(trim(h.utilization_category)) end)
                      when lower(trim(a.utilization_category)) = 'oth' and lower(trim(a.claim_subtype)) = 'm' and h.utilization_category is null       then 'op'
                  else lower(trim(a.utilization_category)) end) = 'ip'
                and a.service_end_date > a.service_begin_date
                and a.line_number = 1
            then a.service_begin_date
            end as admit_dt    --possible but not concrete....
    , case when (case when lower(trim(a.utilization_category)) = 'ip' and lower(trim(a.claim_subtype)) = 'h'  then 'ip'
                      when lower(trim(a.utilization_category)) <> 'oth' then (case when lower(trim(a.utilization_category)) = 'phy' then 'dr' else lower(trim(a.utilization_category)) end)
                      when lower(trim(a.utilization_category)) = 'oth' and lower(trim(a.claim_subtype)) = 'h' and lower(trim(c.ama_pl_of_srvc_desc)) in ('skilled nursing facility','inpatient hospital')     then 'ip'
                      when lower(trim(a.utilization_category)) = 'oth' and lower(trim(a.claim_subtype)) = 'h' and lower(trim(c.ama_pl_of_srvc_desc)) not in ('skilled nursing facility','inpatient hospital') then 'op'
                      when lower(trim(a.utilization_category)) = 'oth' and lower(trim(a.claim_subtype)) = 'm' and h.utilization_category is not null
                            then (case when lower(trim(h.utilization_category)) = 'phy' then 'dr' else lower(trim(h.utilization_category)) end)
                      when lower(trim(a.utilization_category)) = 'oth' and lower(trim(a.claim_subtype)) = 'm' and h.utilization_category is null       then 'op'
                  else lower(trim(a.utilization_category)) end) = 'ip'
                and a.service_end_date > a.service_begin_date
                and a.line_number = 1
            then a.service_end_date
            end as discharge_dt  --possible but not concrete....
    , current_datetime() as create_datetime
    , current_datetime() as update_datetime
  from `ds-00-191017.sierrahealth_sma_final.medical` a   --186,789,717
  left join (
              select service_full_dt, claim_number
                , max(case when dx_type = '02' then diag_cd else '' end) as dx2_diag_cd
                , max(case when dx_type = '03' then diag_cd else '' end) as dx3_diag_cd
                , max(case when dx_type = '04' then diag_cd else '' end) as dx4_diag_cd
                , max(case when dx_type = '05' then diag_cd else '' end) as dx5_diag_cd
                , max(case when dx_type = '06' then diag_cd else '' end) as dx6_diag_cd
                , max(case when dx_type = '07' then diag_cd else '' end) as dx7_diag_cd
                , max(case when dx_type = '08' then diag_cd else '' end) as dx8_diag_cd
                , max(case when dx_type = '09' then diag_cd else '' end) as dx9_diag_cd
                , max(case when dx_type = '10' then diag_cd else '' end) as dx10_diag_cd
                , max(case when dx_type = '11' then diag_cd else '' end) as dx11_diag_cd
                , max(case when dx_type = '12' then diag_cd else '' end) as dx12_diag_cd
              from (
                      select lower(trim(claim_number)) as claim_number, lower(trim(dx)) as diag_cd, lower(trim(dx_type)) as dx_type, diagnosis_code_type, ifnull(lower(trim(poa_ind)), '') as poa_ind
                        , dos as service_full_dt
                        , row_number() over(partition by claim_number order by lower(trim(dx_type))) as rn
                      --select min(dos), max(dos)
                      from `ds-00-191017.sierrahealth_sma_final.dxdetail`
                      where lower(trim(dx_type)) in ('02', '03', '04', '05', '06', '07', '08', '09', '10', '11', '12')
                        and extract(year from dos) >= 2016
                   )
              where rn = 1
              group by service_full_dt, claim_number
            ) b on lower(trim(a.claim_number)) = b.claim_number
                and a.service_date = b.service_full_dt
  left join `ds-00-191017.ugap_final.dim_hpdm_place_of_service_code` c on lower(trim(a.place_of_service)) = lower(trim(c.ama_pl_of_srvc_cd))
  left join `ds-00-191017.sierrahealth_sma_final.provider`           d on lower(trim(a.provider_id)) = lower(trim(d.provider_id))
  left join `ds-00-191017.ndb_final.npi`                            np on lower(trim(d.provider_npi)) = lower(trim(np.natlprovid))         -- Dave's remapping of utilization category
  left join `research-01-217611.df_enrichment.npi_taxonomy`          g on lower(trim(np.taxonomycd)) = lower(trim(g.code))   -- to get description and grouping of taxonomy code
  left join `research-01-217611.df_enrichment.taxonomytocategorymap` h on lower(trim(g.grouping)) = lower(trim(h.grouping))  -- to map from taxonomy grouping to utilization category
  where extract(year from a.service_date) >= 2016
    -- and a.is_restricted = 0
  ;


    --if successful, we'll get here!
    insert into `research-01-217611.df_ucd_stage.logging`(
      success_flag, job, message_datetime)
    select
      1 as success_flag
      , 'map sma medical claims' as job
      , current_datetime as message_datetime
    ;

    EXCEPTION WHEN ERROR THEN
      insert into `research-01-217611.df_ucd_stage.logging`(
        success_flag, job, error_message, statement_text, formatted_stack_trace, message_datetime)
      select
        0 as success_flag
        , 'map sma medical claims' as job
        , @@error.message as error_message
        , @@error.statement_text as statement_text
        , @@error.formatted_stack_trace as formatted_stack_trace
        , current_datetime as message_datetime
      ;
END
;
