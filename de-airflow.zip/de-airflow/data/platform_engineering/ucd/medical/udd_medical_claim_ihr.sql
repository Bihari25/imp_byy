/* Project: Universal Claims Database (UCD )
   Business Partner: Matt Holst
   Input: df_ihr.ihr_medical_claim; df_ihr.ihr_medical_diagnosis; df_udw.member_index_eligibility; df_enrichment.npi_taxonomy
   Created By: Seth
   Created Date: 6/08/2020
   Modified By: Dave Corban
   Modified Date: 8/19/2020
   Modified to remove source duplicates
    Modified Date: 8/24/2020
   Modified to remove medicaid
    Modified Date: 10/16/2020
   Modified to remove restricted members
            to source from ihr_final w/o datestamps
   Granularity:  Claim/line detail                                    */

  /**Used placeholders (null) for fields that are not currently not available in ihr claim table **/

BEGIN

	-- delete
  -- from `research-01-217611.df_ucd_stage.udd_medical_claim_ihr`
  -- where 1=1
  -- ;

	insert into `research-01-217611.df_ucd_stage.udd_medical_claim_ihr`
		(uuid, savvy_pid, savvy_did, is_restricted, src_type, clm_aud_nbr, line_number, data_source, claim_sub_type, clm_dt,
		icd_ver_cd, dx1_diag_cd, dx2_diag_cd, dx3_diag_cd, dx4_diag_cd, dx5_diag_cd, dx6_diag_cd, dx7_diag_cd, dx8_diag_cd, dx9_diag_cd, dx10_diag_cd, dx11_diag_cd, dx12_diag_cd,
		rvnu_cd, proc_cd, prc1_proc_cd, prc2_proc_cd, prc3_proc_cd, prc4_proc_cd, prc5_proc_cd, prc6_proc_cd,
		drg_cd, dschrg_sts_cd, proc_mod_1_cd, proc_mod_2_cd, proc_mod_3_cd, srvc_typ_cd,
		prov_mpin, prov_tin, prov_fst_nm, prov_lst_nm, prov_zip_cd, prov_state, npi, pcp_flag, provtype, spec_typ_nm, hp_prov_cat_typ_nm,
		ama_pl_of_srvc_cd, ama_pl_of_srvc_desc, prov_prtcp_sts_cd, hp_prov_sts_rllp_desc, hlth_pln_srvc_typ_cd, hce_srvc_typ_desc, bil_typ_cd,
		bil_amt, allw_amt, net_pd_amt, oop_amt, copay_amt, ded_amt, coins_amt, disallow_amt, cob_amt,
		admit_cnt, day_cnt, srvc_unit_cnt, adjudication_dt, admit_dt, discharge_dt, create_datetime, update_datetime
		)

	WITH DIAGNOSIS_pvt AS
	(
	Select source_uuid,  savvy_pid, claim_id, fln

	,max(source_load_timestamp) as source_load_timestamp

	,SAFE_CAST(max(CASE WHEN TRIM(DIAG.icd_version)='ICD10' THEN 10

	                WHEN TRIM(DIAG.icd_version)='ICD9' THEN 9

	                ELSE 10

	           END) as int64) as icd_ver_cd

	,max(CASE WHEN DIAG.diagnosis_position=1 and lower(trim(code_description))='primary diagnosis code' then lower(trim(DIAG.code)) else '' end) as dx1_diag_cd

	,max(CASE WHEN DIAG.diagnosis_position=2 then lower(trim(DIAG.code)) else '' end) as dx2_diag_cd

	,max(CASE WHEN DIAG.diagnosis_position=3 then lower(trim(DIAG.code)) else '' end) as dx3_diag_cd

	,max(CASE WHEN DIAG.diagnosis_position=4 then lower(trim(DIAG.code)) else '' end) as dx4_diag_cd

	,max(CASE WHEN DIAG.diagnosis_position=5 then lower(trim(DIAG.code)) else '' end) as dx5_diag_cd

	,max(CASE WHEN DIAG.diagnosis_position=6 then lower(trim(DIAG.code)) else '' end) as dx6_diag_cd

	,max(CASE WHEN DIAG.diagnosis_position=7 then lower(trim(DIAG.code)) else '' end) as dx7_diag_cd

	,max(CASE WHEN DIAG.diagnosis_position=8 then lower(trim(DIAG.code)) else '' end) as dx8_diag_cd

	,max(CASE WHEN DIAG.diagnosis_position=9 then lower(trim(DIAG.code)) else '' end) as dx9_diag_cd

	,max(CASE WHEN DIAG.diagnosis_position=10 then lower(trim(DIAG.code)) else '' end) as dx10_diag_cd

	,max(CASE WHEN DIAG.diagnosis_position=11 then lower(trim(DIAG.code)) else '' end) as dx11_diag_cd

	,max(CASE WHEN DIAG.diagnosis_position=12 then lower(trim(DIAG.code)) else '' end) as dx12_diag_cd

	FROM `ds-00-191017.ihr_final.medical_diagnosis` DIAG

	Group by source_uuid, savvy_pid, claim_id, fln
	)

	,PROCEDURE_pvt

	AS

	(Select source_uuid, savvy_pid, claim_id,fln

	,max(source_load_timestamp) as source_load_timestamp

	,lower(max(CASE WHEN PROC.diagnosis_position=1 then lower(trim(PROC.code)) else '' end)) as prc1_proc_cd

	,lower(max(CASE WHEN PROC.diagnosis_position=2 then lower(trim(PROC.code)) else '' end)) as prc2_proc_cd

	,lower(max(CASE WHEN PROC.diagnosis_position=3 then lower(trim(PROC.code)) else '' end)) as prc3_proc_cd

	,lower(max(CASE WHEN PROC.diagnosis_position=4 then lower(trim(PROC.code)) else '' end)) as prc4_proc_cd

	,lower(max(CASE WHEN PROC.diagnosis_position=5 then lower(trim(PROC.code)) else '' end)) as prc5_proc_cd

	,max(CASE WHEN PROC.diagnosis_position=6 then lower(trim(PROC.code)) else '' end) as prc6_proc_cd

	FROM `ds-00-191017.ihr_final.medical_procedure` PROC

	Group by source_uuid, savvy_pid, claim_id, fln
	)

	,

	DEDUPE

	AS

	(Select savvy_pid,claim_id,fln,source_uuid, detail_line_number,max(source_load_timestamp) as source_load_timestamp
	  FROM `ds-00-191017.ihr_final.medical_claim`
	  GROUP BY savvy_pid,claim_id,fln,source_uuid, detail_line_number
	)

	SELECT


	   GENERATE_UUID() AS uuid, savvy_pid, savvy_did, is_restricted, src_type, clm_aud_nbr, line_number, data_source, claim_sub_type, clm_dt, icd_ver_cd,


	    dx1_diag_cd, dx2_diag_cd, dx3_diag_cd, dx4_diag_cd, dx5_diag_cd, dx6_diag_cd, dx7_diag_cd, dx8_diag_cd, dx9_diag_cd, dx10_diag_cd, dx11_diag_cd, dx12_diag_cd,


	    rvnu_cd, proc_cd, prc1_proc_cd, prc2_proc_cd, prc3_proc_cd, prc4_proc_cd, prc5_proc_cd, prc6_proc_cd, drg_cd, dschrg_sts_cd, proc_mod_1_cd, proc_mod_2_cd, proc_mod_3_cd, srvc_typ_cd,


	    prov_mpin, prov_tin, prov_fst_nm, prov_lst_nm, prov_zip_cd, prov_state, npi,safe_cast(pcp_flag as int64) as pcp_flag, provtype, spec_typ_nm, hp_prov_cat_typ_nm,


	    ama_pl_of_srvc_cd, ama_pl_of_srvc_desc, prov_prtcp_sts_cd, hp_prov_sts_rllp_desc, hlth_pln_srvc_typ_cd, hce_srvc_typ_desc, bil_typ_cd,


	    bil_amt, allw_amt, net_pd_amt, oop_amt, copay_amt, ded_amt, coins_amt, disallow_amt, cob_amt,


	    admit_cnt, day_cnt, srvc_unit_cnt, adjudication_dt, admit_dt, discharge_dt,


	    current_datetime() as create_datetime,


	    current_datetime() as update_datetime




	  from



	    (SELECT distinct


	CLAIM.savvy_pid AS savvy_pid
	, CLAIM.savvy_did AS savvy_did
	, CLAIM.is_restricted AS is_restricted


	,lower(CONCAT('ihr - ',cast(MEMBER.commercial_flag as string), cast(MEMBER.medicare_flag as string), cast(MEMBER.medicaid_flag as string), cast(MEMBER.dual_flag as string))) as src_type


	,lower(CLAIM.fln) as clm_aud_nbr


	,lower(CLAIM.detail_line_number) AS line_number


	,'ihr_final.medical_claim' as data_source


	,CASE WHEN facility_code_qualifier='A' THEN 'h'

	     WHEN facility_code_qualifier='B' THEN 'm'

	     ELSE null

	 END as claim_sub_type

	/*
	Select best service date from claim line and convert from string values to date format.
	Hierarchy:  admission_from_date, service_start_date, statement_from_date

	*/

	,PARSE_DATE('%Y%m%d',

	    CASE WHEN admission_from_date is not null AND substr(admission_from_date,1,6) >='200001'   AND  substr(admission_from_date,1,6) <> '999999'   -- Pick admit date first if it's valid (200001 is arbitrary choice)

	    	  THEN substr(admission_from_date,1,8)  -- Strip out admit time (not always there)

	      	  ELSE

	      		CASE WHEN service_start_date is not null AND FORMAT_DATE('%Y%m',service_start_date) >='200001'  --Use service start date next if valid

			     THEN FORMAT_DATE('%Y%m%d',service_start_date)

		             ELSE

	           		 CASE WHEN substr(statement_from_date,1,8) <> '99999999'

			            THEN  substr(statement_from_date,1,8)                                                   -- last resort use statement from date

			            ELSE '19000101'                                                                     -- no valid date available

			         END

	      		END

		END)  AS clm_dt


	,case when ifnull(DIAGNOSIS_pvt.icd_ver_cd, 0) = 0 then 10 else DIAGNOSIS_pvt.icd_ver_cd end AS icd_ver_cd

	,DIAGNOSIS_pvt.dx1_diag_cd

	,DIAGNOSIS_pvt.dx2_diag_cd

	,DIAGNOSIS_pvt.dx3_diag_cd

	,DIAGNOSIS_pvt.dx4_diag_cd

	,DIAGNOSIS_pvt.dx5_diag_cd

	,DIAGNOSIS_pvt.dx6_diag_cd

	,DIAGNOSIS_pvt.dx7_diag_cd

	,DIAGNOSIS_pvt.dx8_diag_cd

	,DIAGNOSIS_pvt.dx9_diag_cd

	,DIAGNOSIS_pvt.dx10_diag_cd

	,DIAGNOSIS_pvt.dx11_diag_cd

	,DIAGNOSIS_pvt.dx12_diag_cd

	,lower(trim(service_line_revenue_code)) as rvnu_cd


	,lower(trim(CASE WHEN professional_procedure_code is not Null THEN professional_procedure_code ELSE institutional_procedure_code end)) as proc_cd

	,PROCEDURE_pvt.prc1_proc_cd

	,PROCEDURE_pvt.prc2_proc_cd

	,PROCEDURE_pvt.prc3_proc_cd


	,PROCEDURE_pvt.prc4_proc_cd


	,PROCEDURE_pvt.prc5_proc_cd


	,PROCEDURE_pvt.prc6_proc_cd


	,ifnull(lower(trim(drg_code)), '') as drg_cd



	,ifnull(lower(trim(patient_status_code)), '') as dschrg_sts_cd



	,ifnull(lower(trim(CASE WHEN professional_procedure_code is not Null THEN professional_procedure_modifier_1 ELSE institutional_procedure_modifier_1 end)), '') as proc_mod_1_cd



	,ifnull(lower(trim(CASE WHEN professional_procedure_code is not Null THEN professional_procedure_modifier_2 ELSE institutional_procedure_modifier_2 end)), '') as proc_mod_2_cd



	,ifnull(lower(trim(CASE WHEN professional_procedure_code is not Null THEN professional_procedure_modifier_3 ELSE institutional_procedure_modifier_3 end)), '') as proc_mod_3_cd



	--,CASE WHEN professional_procedure_code is not Null THEN professional_procedure_modifier_4 ELSE institutional_procedure_modifier_4 end as proc_mod_4_cd



	,CASE WHEN facility_code_qualifier='A' and facility_code_value in ('11','12','15','16','17','21','22','25','26','27','35','36','37','41','42','45','46','47','51','52','55','56','57','61','62','65','66','67','82','86') THEN 'ip'

	    ELSE CASE WHEN facility_code_qualifier='A' THEN 'op'

	    ELSE CASE WHEN trim(tax.grouping) in

	('Agencies','Ambulatory Health Care Facilities','Hospital Units','Hospitals','Laboratories','Managed Care Organizations','Nursing & Custodial Care Facilities','Residential Treatment Facilities','Suppliers','Transportation Services')

	THEN 'op'

	ELSE 'dr'

	 END END END AS srvc_typ_cd


	,0 as prov_mpin


	,ifnull(lower(trim(ifnull(provider_tax_identification_number, provider_social_security_number))), '') as  prov_tin


	,ifnull(lower(trim(billing_provider_first_name)), '') as prov_fst_nm


	,ifnull(lower(trim(billing_provider_last_name_or_organization_name)), '') as prov_lst_nm


	,ifnull(lower(trim(billing_provider_postal_zone_or_zip_code)), '') as prov_zip_cd


	,ifnull(lower(trim(billing_provider_state_code)), '') as prov_state


	,SAFE_CAST(billing_provider_npi as int64) as npi


	,CASE WHEN lower(trim(tax.classification)) in ('pediatrics','general practice','internal medicine','family medicine') then 1 else 0 end as pcp_flag

	,CASE WHEN billing_provider_entity_type_qualifier = '1' THEN 'p'

		  ELSE CASE WHEN billing_provider_entity_type_qualifier ='2' THEN 'o'

	  		ELSE 'u'

			END

		END as provtype


	,ifnull(lower(trim(tax.classification)), '') as spec_typ_nm

	, '' as hp_prov_cat_typ_nm

	,ifnull(lower(trim(Case when facility_code_qualifier = 'B' Then SAFE_CAST(facility_code_value AS STRING) else SAFE_CAST(place_of_service_code AS STRING) end)), '')  as ama_pl_of_srvc_cd



	,'' as ama_pl_of_srvc_desc



	,'' as prov_prtcp_sts_cd



	,'' as hp_prov_sts_rllp_desc



	,'' as hlth_pln_srvc_typ_cd



	,'' as hce_srvc_typ_desc



	,ifnull(lower(trim(CASE WHEN facility_code_qualifier = 'A' THEN concat(facility_code_value,claim_frequency_type_code) ELSE '000' END)), '') AS bil_typ_cd



	,CASE WHEN SAFE_CAST(REGEXP_REPLACE(professional_charge_amount, r'[^0-9.]', '') AS NUMERIC) is not NULL THEN CAST(REGEXP_REPLACE(professional_charge_amount, r'[^0-9.]', '') AS NUMERIC) ELSE SAFE_CAST(REGEXP_REPLACE(institutional_charge_amount, r'[^0-9.]', '') AS NUMERIC) END AS bil_amt



	,0 as allw_amt



	,0 as net_pd_amt



	,0 as oop_amt



	,0 as copay_amt



	,0 as ded_amt



	,0 as coins_amt



	,0 as disallow_amt



	,0 as cob_amt



	,CASE WHEN admission_from_date is not null AND CLAIM.detail_line_number='1' then 1 else 0 end as admit_cnt  ---needs to be refined



	,CASE WHEN CLAIM.unit_un_or_days_da ='DA' then safe_cast(institutional_service_unit_count as INT64) else 0 END as day_cnt  --needs to be refined



	,CASE WHEN professional_procedure_code is not Null THEN SAFE_CAST(ROUND(SAFE_CAST(REGEXP_REPLACE(professional_service_unit_count, r'[^0-9.]', '') AS NUMERIC)) AS INT64)

	      ELSE  SAFE_CAST(ROUND(SAFE_CAST(REGEXP_REPLACE(institutional_service_unit_count, r'[^0-9.]', '') AS NUMERIC)) AS INT64)

	    END AS srvc_unit_cnt


	,Date'9999-12-31' as adjudication_dt



	,CASE WHEN admission_from_date is not null AND substr(admission_from_date,1,6) >='200001'   AND  substr(admission_from_date,1,6) <> '999999'   -- (200001 is arbitrary choice)

	    	  THEN PARSE_DATE('%Y%m%d',substr(admission_from_date,1,8))

		     ELSE null

	    END as admit_dt



	,Date'9999-12-31' as discharge_dt

	--,CLAIM.source_load_timestamp AS loadtimestamp



	FROM `ds-00-191017.ihr_final.medical_claim` CLAIM

	     LEFT JOIN  `research-01-217611.df_ucd_stage.udw_member_month` MEMBER

	       on CLAIM.savvy_pid=MEMBER.savvy_pid AND
	          CAST(FORMAT_DATE('%Y%m', PARSE_DATE('%Y%m%d',

	                CASE WHEN admission_from_date is not null AND substr(admission_from_date,1,6) >='200001'   AND  substr(admission_from_date,1,6) <> '999999'   -- Pick admit date first if it's valid (200001 is arbitrary choice)

	                      THEN substr(admission_from_date,1,8)

	                       ELSE  CASE WHEN service_start_date is not null AND FORMAT_DATE('%Y%m',service_start_date) >='200001'  --Use service start date next if valid

	                      THEN FORMAT_DATE('%Y%m%d',service_start_date)

	                        ELSE CASE WHEN substr(statement_from_date,1,8) <> '99999999'

	                        THEN  substr(statement_from_date,1,8)                                                   -- last resort use statement from date

	                        ELSE '19000101'
	                              END

	                              END
	                  END)) AS INT64) = MEMBER.year_mo


	        LEFT JOIN  DIAGNOSIS_pvt

	           on CLAIM.savvy_pid=DIAGNOSIS_pvt.savvy_pid

	           AND CLAIM.claim_id=DIAGNOSIS_pvt.claim_id

	           AND  CLAIM.fln=DIAGNOSIS_pvt.fln

	           AND CLAIM.source_uuid=DIAGNOSIS_pvt.source_uuid

	           AND CLAIM.source_load_timestamp=DIAGNOSIS_pvt.source_load_timestamp

	          LEFT JOIN  PROCEDURE_pvt

	           on CLAIM.savvy_pid=PROCEDURE_pvt.savvy_pid

	           AND CLAIM.claim_id=PROCEDURE_pvt.claim_id

	           AND CLAIM.fln=PROCEDURE_pvt.fln

	           AND CLAIM.source_uuid=PROCEDURE_pvt.source_uuid

	           AND CLAIM.source_load_timestamp=PROCEDURE_pvt.source_load_timestamp

	     LEFT JOIN `research-01-217611.df_ucd_stage.npi_taxonomy` tax

	           on CLAIM.billing_provider_taxonomy_code=tax.code


	    INNER JOIN DEDUPE

	 on CLAIM.savvy_pid=DEDUPE.savvy_pid
	AND CLAIM.claim_id=DEDUPE.claim_id
	AND CLAIM.fln=DEDUPE.fln
	AND CLAIM.detail_line_number=DEDUPE.detail_line_number
	AND CLAIM.source_load_timestamp=DEDUPE.source_load_timestamp


	WHERE 1=1
  -- AND CLAIM.is_restricted = 0

	)

	  where
	    clm_dt >= '2017-01-01' AND clm_dt <=CURRENT_DATE()
	AND (substr(src_type,9,2) ='00' or src_type is null)  -- Exclude Medicaid
	;

	--if successful, we'll get here!
  insert into `research-01-217611.df_ucd_stage.logging`(
    success_flag, job, message_datetime)
  select
    1 as success_flag
    , 'map ihr medical claims' as job
    , current_datetime as message_datetime
  ;

  EXCEPTION WHEN ERROR THEN
    insert into `research-01-217611.df_ucd_stage.logging`(
      success_flag, job, error_message, statement_text, formatted_stack_trace, message_datetime)
    select
      0 as success_flag
      , 'map ihr medical claims' as job
      , @@error.message as error_message
      , @@error.statement_text as statement_text
      , @@error.formatted_stack_trace as formatted_stack_trace
      , current_datetime as message_datetime
    ;

END
;
