/* Project: Universal Claims Database (UCD )
   Business Partner: Matt Holst
   Input: miniov_inpatient_all; miniov_outpatient_all; miniov_physician_all
   Created By: Seth
   Created Date: 6/08/2020
   Modified By: Sachin
   Modified Date: 7/13/2020
   Modified source tables and column names to reflect miniov.
   Note that savvy_pid=-1 are excluded from miniov_xxx_all tables.
   Granularity:  Claim/line detail                                    */



  /**Used placeholders (null) for fields that are not currently not available in UGAP claim table **/
BEGIN

  -- delete
  -- from `research-01-217611.df_ucd_stage.udd_medical_claim_miniov`
  -- where 1=1
  -- ;

  insert into `research-01-217611.df_ucd_stage.udd_medical_claim_ova`
    (uuid, savvy_pid, savvy_did, is_restricted, src_type, clm_aud_nbr, line_number, data_source, claim_sub_type, clm_dt,
    icd_ver_cd, dx1_diag_cd, dx2_diag_cd, dx3_diag_cd, dx4_diag_cd, dx5_diag_cd, dx6_diag_cd, dx7_diag_cd, dx8_diag_cd, dx9_diag_cd, dx10_diag_cd, dx11_diag_cd, dx12_diag_cd,
    rvnu_cd, proc_cd, prc1_proc_cd, prc2_proc_cd, prc3_proc_cd, prc4_proc_cd, prc5_proc_cd, prc6_proc_cd,
    drg_cd, dschrg_sts_cd, proc_mod_1_cd, proc_mod_2_cd, proc_mod_3_cd, srvc_typ_cd,
    prov_mpin, prov_tin, prov_fst_nm, prov_lst_nm, prov_zip_cd, prov_state, npi, pcp_flag, provtype, spec_typ_nm, hp_prov_cat_typ_nm,
    ama_pl_of_srvc_cd, ama_pl_of_srvc_desc, prov_prtcp_sts_cd, hp_prov_sts_rllp_desc, hlth_pln_srvc_typ_cd, hce_srvc_typ_desc, bil_typ_cd,
    bil_amt, allw_amt, net_pd_amt, oop_amt, copay_amt, ded_amt, coins_amt, disallow_amt, cob_amt,
    admit_cnt, day_cnt, srvc_unit_cnt, adjudication_dt, admit_dt, discharge_dt, create_datetime, update_datetime
    )

    select
      uuid, savvy_pid, savvy_did, is_restricted, src_type, clm_aud_nbr, line_number, data_source, claim_sub_type, clm_dt,
      case when ifnull(icd_ver_cd, '0') = '0' or icd_ver_cd = '' then 10 else safe_cast(icd_ver_cd as int64) end as icd_ver_cd,
      dx1_diag_cd, dx2_diag_cd, dx3_diag_cd, dx4_diag_cd, dx5_diag_cd, dx6_diag_cd, dx7_diag_cd, dx8_diag_cd, dx9_diag_cd, dx10_diag_cd, dx11_diag_cd, dx12_diag_cd,
      rvnu_cd, proc_cd, prc1_proc_cd, prc2_proc_cd, prc3_proc_cd, prc4_proc_cd, prc5_proc_cd, prc6_proc_cd,
      drg_cd, dschrg_sts_cd, proc_mod_1_cd, proc_mod_2_cd, proc_mod_3_cd, srvc_typ_cd,
      prov_mpin, prov_tin, prov_fst_nm, prov_lst_nm, prov_zip_cd, prov_state, npi, pcp_flag, provtype, spec_typ_nm, hp_prov_cat_typ_nm,
      ama_pl_of_srvc_cd, ama_pl_of_srvc_desc, prov_prtcp_sts_cd, hp_prov_sts_rllp_desc, hlth_pln_srvc_typ_cd, hce_srvc_typ_desc, bil_typ_cd,
      bil_amt, allw_amt, net_pd_amt, oop_amt, copay_amt, ded_amt, coins_amt, disallow_amt, cob_amt,
      admit_cnt, day_cnt, srvc_unit_cnt, adjudication_dt, admit_dt, discharge_dt,

      current_datetime() as create_datetime,
      current_datetime() as update_datetime

    from

      (select
        GENERATE_UUID() uuid
        , clm.savvy_pid AS savvy_pid
        , clm.savvy_did AS savvy_did
        , clm.is_restricted_flag AS is_restricted
        , "ugap" AS src_type
        , ifnull(lower(trim(clm.clm_aud_nbr)), '') AS clm_aud_nbr
        , ifnull(lower(trim(clm.dtl_ln_nbr)), '') AS line_number
        , 'ds-00-191017.ugap_final.fact_ova_inpatient' AS data_source
        , '' AS claim_sub_type
        , dt.full_dt AS clm_dt
        , ifnull(clm.icd_ver_cd, '10') AS icd_ver_cd
        , ifnull(lower(trim(dx1.diag_cd)), '') AS dx1_diag_cd
        , ifnull(lower(trim(dx2.diag_cd)), '') AS dx2_diag_cd
        , ifnull(lower(trim(dx3.diag_cd)), '') AS dx3_diag_cd
        , ifnull(lower(trim(dx4.diag_cd)), '') AS dx4_diag_cd
        , ifnull(lower(trim(dx5.diag_cd)), '') AS dx5_diag_cd
        , ifnull(lower(trim(dx6.diag_cd)), '') AS dx6_diag_cd
        , ifnull(lower(trim(dx7.diag_cd)), '') AS dx7_diag_cd
        , ifnull(lower(trim(dx8.diag_cd)), '') AS dx8_diag_cd
        , ifnull(lower(trim(dx9.diag_cd)), '') AS dx9_diag_cd
        , ifnull(lower(trim(dx10.diag_cd)), '') AS dx10_diag_cd
        , ifnull(lower(trim(dx11.diag_cd)), '') AS dx11_diag_cd
        , ifnull(lower(trim(dx12.diag_cd)), '') AS dx12_diag_cd
        , ifnull(lower(trim(rvnu.rvnu_cd)), '') AS rvnu_cd
        , ifnull(lower(trim(pc.proc_cd)), '') AS proc_cd
        , ifnull(lower(trim(pc1.proc_cd)), '') as prc1_proc_cd
        , ifnull(lower(trim(pc2.proc_cd)), '') as prc2_proc_cd
        , ifnull(lower(trim(pc3.proc_cd)), '') as prc3_proc_cd
        , ifnull(lower(trim(pc4.proc_cd)), '') as prc4_proc_cd
        , ifnull(lower(trim(pc5.proc_cd)), '') as prc5_proc_cd
        , ifnull(lower(trim(pc6.proc_cd)), '') as prc6_proc_cd
        , ifnull(lower(trim(drg.drg_cd)), case when clm.admis_cnt > 0 then '00000' else '' end) AS drg_cd
        , ifnull(lower(trim(dsc.dschrg_sts_cd)), case when clm.admis_cnt > 0 then '00' else '' end) AS dschrg_sts_cd
        , ifnull(lower(trim(pmc1.proc_mod_cd)), '') AS proc_mod_1_cd
        , ifnull(lower(trim(pmc2.proc_mod_cd)), '') AS proc_mod_2_cd
        , '' AS proc_mod_3_cd
        , 'ip' AS srvc_typ_cd
        , ifnull(prov.mpin, 0) AS prov_mpin
        , ifnull(lower(trim(prov.tin)), '') AS prov_tin
        , ifnull(lower(trim(prov.prov_fst_nm)), '') AS prov_fst_nm
        , ifnull(lower(trim(prov.prov_lst_nm)), '') AS prov_lst_nm
        , ifnull(lower(trim(prov.zip_cd)), '') AS prov_zip_cd
        , '' AS prov_state
        , ifnull(safe_cast(prov.npi_nbr as int64), 0) AS npi
        , 0 AS pcp_flag
        , '' AS provtype
        , '' AS spec_typ_nm
        , ifnull(lower(trim(pcc.prov_typ_nm)), '') as hp_prov_cat_typ_nm
        , ifnull(lower(trim(pos.ama_pl_of_srvc_cd)), '00') AS ama_pl_of_srvc_cd
        , ifnull(lower(trim(pos.ama_pl_of_srvc_desc)), '') AS ama_pl_of_srvc_desc
        , ifnull(lower(trim(ppc.prov_prtcp_sts_cd)), '') AS prov_prtcp_sts_cd
        , ifnull(lower(trim(ppc.hp_prov_sts_rllp_desc)), '') AS hp_prov_sts_rllp_desc
        , ifnull(lower(trim(hpstc.hlth_pln_srvc_typ_cd)), 'unk') AS hlth_pln_srvc_typ_cd
        , ifnull(lower(trim(hpstc.hce_srvc_typ_desc)), '') AS hce_srvc_typ_desc
        , ifnull(lower(trim(clm.bil_typ_cd)), '') AS bil_typ_cd
        , ifnull(safe_cast(clm.bil_amt as numeric), 0) AS bil_amt
        , ifnull(safe_cast(clm.allw_amt as numeric), 0) AS allw_amt
        , ifnull(safe_cast(clm.net_pd_amt as numeric), 0) AS net_pd_amt
        , 0 AS oop_amt
        , ifnull(safe_cast(clm.copay_amt as numeric), 0) AS copay_amt
        , ifnull(safe_cast(clm.ded_amt as numeric), 0) AS ded_amt
        , ifnull(safe_cast(clm.coins_amt as numeric), 0) AS coins_amt
        , 0 AS disallow_amt
        , ifnull(safe_cast(clm.hlth_pln_cob_amt as numeric), 0) AS cob_amt
        , ifnull(clm.admis_cnt, 0) AS admit_cnt
        , ifnull(case when clm.admis_cnt > 0 then clm.stat_day else 0 end, 0)  AS day_cnt
        , ifnull(clm.srvc_unit_cnt, 0) AS srvc_unit_cnt
        , adt.full_dt AS adjudication_dt
        , case when clm.admis_cnt > 0 then dt.full_dt end AS admit_dt
        , case when clm.admis_cnt > 0 then DATE_ADD(dt.full_dt, INTERVAL ifnull(clm.stat_day, 0) DAY) end AS discharge_dt
      from `ds-00-191017.ugap_final.fact_ova_inpatient`             clm
        join `ds-00-191017.ugap_final.dim_hpdm_date`                dt on clm.admit_dt_sys_id         = dt.dt_sys_id
        left join `ds-00-191017.ugap_final.dim_hpdm_diagnosis_code`  dx1 on clm.diag_1_cd_sys_id      = dx1.diag_cd_sys_id      and dx1.diag_cd_sys_id > 0
        left join `ds-00-191017.ugap_final.dim_hpdm_diagnosis_code`  dx2 on clm.diag_2_cd_sys_id      = dx2.diag_cd_sys_id      and dx2.diag_cd_sys_id > 0
        left join `ds-00-191017.ugap_final.dim_hpdm_diagnosis_code`  dx3 on clm.diag_3_cd_sys_id      = dx3.diag_cd_sys_id      and dx3.diag_cd_sys_id > 0
        left join `ds-00-191017.ugap_final.dim_hpdm_diagnosis_code`  dx4 on clm.diag_4_cd_sys_id      = dx4.diag_cd_sys_id      and dx4.diag_cd_sys_id > 0
        left join `ds-00-191017.ugap_final.dim_hpdm_diagnosis_code`  dx5 on clm.diag_5_cd_sys_id      = dx5.diag_cd_sys_id      and dx5.diag_cd_sys_id > 0
        left join `ds-00-191017.ugap_final.dim_hpdm_diagnosis_code`  dx6 on clm.diag_6_cd_sys_id      = dx6.diag_cd_sys_id      and dx6.diag_cd_sys_id > 0
        left join `ds-00-191017.ugap_final.dim_hpdm_diagnosis_code`  dx7 on clm.diag_7_cd_sys_id      = dx7.diag_cd_sys_id      and dx7.diag_cd_sys_id > 0
        left join `ds-00-191017.ugap_final.dim_hpdm_diagnosis_code`  dx8 on clm.diag_8_cd_sys_id      = dx8.diag_cd_sys_id      and dx8.diag_cd_sys_id > 0
        left join `ds-00-191017.ugap_final.dim_hpdm_diagnosis_code`  dx9 on clm.diag_9_cd_sys_id      = dx9.diag_cd_sys_id      and dx9.diag_cd_sys_id > 0
        left join `ds-00-191017.ugap_final.dim_hpdm_diagnosis_code`  dx10 on clm.diag_10_cd_sys_id      = dx10.diag_cd_sys_id      and dx10.diag_cd_sys_id > 0
        left join `ds-00-191017.ugap_final.dim_hpdm_diagnosis_code`  dx11 on clm.diag_11_cd_sys_id      = dx11.diag_cd_sys_id      and dx11.diag_cd_sys_id > 0
        left join `ds-00-191017.ugap_final.dim_hpdm_diagnosis_code`  dx12 on clm.diag_12_cd_sys_id      = dx12.diag_cd_sys_id      and dx12.diag_cd_sys_id > 0
        left join `ds-00-191017.ugap_final.dim_hpdm_revenue_code`    rvnu on clm.rvnu_cd_sys_id       = rvnu.rvnu_cd_sys_id
        left join `ds-00-191017.ugap_final.dim_hpdm_procedure_code`  pc on clm.proc_cd_sys_id         = pc.proc_cd_sys_id
        left join `ds-00-191017.ugap_final.dim_hpdm_procedure_code`  pc1 on clm.proc_1_cd_sys_id      = pc1.proc_cd_sys_id
        left join `ds-00-191017.ugap_final.dim_hpdm_procedure_code`  pc2 on clm.proc_2_cd_sys_id      = pc2.proc_cd_sys_id
        left join `ds-00-191017.ugap_final.dim_hpdm_procedure_code`  pc3 on clm.proc_3_cd_sys_id      = pc3.proc_cd_sys_id
        left join `ds-00-191017.ugap_final.dim_hpdm_procedure_code`         pc4 on clm.proc_4_cd_sys_id      = pc4.proc_cd_sys_id
        left join `ds-00-191017.ugap_final.dim_hpdm_procedure_code`         pc5 on clm.proc_5_cd_sys_id      = pc5.proc_cd_sys_id
        left join `ds-00-191017.ugap_final.dim_hpdm_procedure_code`         pc6 on clm.proc_6_cd_sys_id      = pc6.proc_cd_sys_id
        left join `ds-00-191017.ugap_final.dim_hpdm_drg_code`               drg on clm.hp_deriv_drg_cd_sys_id   = drg.drg_cd_sys_id --different than miniov, but consistent with minihpdm/ugap commercial
        left join `ds-00-191017.ugap_final.dim_hpdm_discharge_status_code`  dsc on clm.dschrg_sts_cd_sys_id  = dsc.dschrg_sts_cd_sys_id
        left join `ds-00-191017.ugap_final.dim_hpdm_procedure_modifier_code`  pmc1 on clm.proc_mod_1_sys_id  = pmc1.proc_mod_sys_id
        left join `ds-00-191017.ugap_final.dim_hpdm_procedure_modifier_code`  pmc2 on clm.proc_mod_2_sys_id  = pmc2.proc_mod_sys_id
        left join `ds-00-191017.ugap_final.dim_ova_provider`                  prov on clm.srvc_prov_sys_id   = prov.prov_sys_id
        left join `ds-00-191017.ugap_final.dim_hpdm_place_of_service_code`    pos on clm.pl_of_srvc_sys_id   = pos.pl_of_srvc_sys_id
        left join `ds-00-191017.ugap_final.dim_hpdm_provider_participation_code` ppc on clm.prov_prtcp_sts_cd_sys_id  =  ppc.prov_prtcp_sts_cd_sys_id
        left join `ds-00-191017.ugap_final.dim_hpdm_hp_service_type_code`   hpstc on clm.hlth_pln_srvc_typ_cd_sys_id  =  hpstc.hlth_pln_srvc_typ_cd_sys_id
        left join `ds-00-191017.ugap_final.dim_hpdm_date`                adt on clm.adjd_dt_sys_id          = adt.dt_sys_id
        left join `ds-00-191017.ugap_final.dim_hpdm_hp_provider_category_code`    pcc on clm.srvc_prov_catgy_cd_sys_id = pcc.prov_catgy_cd_sys_id
      -- where
      --   clm.is_restricted_flag = 0

      union all

      select
        GENERATE_UUID() uuid
        , clm.savvy_pid AS savvy_pid
        , clm.savvy_did AS savvy_did
        , clm.is_restricted_flag AS is_restricted
        , "ugap" AS src_type
        , ifnull(lower(trim(clm.clm_aud_nbr)), '') AS clm_aud_nbr
        , ifnull(lower(trim(clm.dtl_ln_nbr)), '') AS line_number
        , 'ds-00-191017.ugap_final.fact_ova_outpatient' AS data_source
        , '' AS claim_sub_type
        , dt.full_dt AS clm_dt
        , ifnull(clm.icd_ver_cd, '10') AS icd_ver_cd
        , ifnull(lower(trim(dx1.diag_cd)), '') AS dx1_diag_cd
        , ifnull(lower(trim(dx2.diag_cd)), '') AS dx2_diag_cd
        , ifnull(lower(trim(dx3.diag_cd)), '') AS dx3_diag_cd
        , ifnull(lower(trim(dx4.diag_cd)), '') AS dx4_diag_cd
        , ifnull(lower(trim(dx5.diag_cd)), '') AS dx5_diag_cd
        , ifnull(lower(trim(dx6.diag_cd)), '') AS dx6_diag_cd
        , ifnull(lower(trim(dx7.diag_cd)), '') AS dx7_diag_cd
        , ifnull(lower(trim(dx8.diag_cd)), '') AS dx8_diag_cd
        , ifnull(lower(trim(dx9.diag_cd)), '') AS dx9_diag_cd
        , ifnull(lower(trim(dx10.diag_cd)), '') AS dx10_diag_cd
        , ifnull(lower(trim(dx11.diag_cd)), '') AS dx11_diag_cd
        , ifnull(lower(trim(dx12.diag_cd)), '') AS dx12_diag_cd
        , ifnull(lower(trim(rvnu.rvnu_cd)), '') AS rvnu_cd
        , ifnull(lower(trim(pc.proc_cd)), '') AS proc_cd
        , ifnull(lower(trim(pc1.proc_cd)), '') as prc1_proc_cd
        , ifnull(lower(trim(pc2.proc_cd)), '') as prc2_proc_cd
        , ifnull(lower(trim(pc3.proc_cd)), '') as prc3_proc_cd
        , ifnull(lower(trim(pc4.proc_cd)), '') as prc4_proc_cd
        , ifnull(lower(trim(pc5.proc_cd)), '') as prc5_proc_cd
        , ifnull(lower(trim(pc6.proc_cd)), '') as prc6_proc_cd
        , '' AS drg_cd
        , '' AS dschrg_sts_cd
        , ifnull(pmc1.proc_mod_cd, '') AS proc_mod_1_cd
        , ifnull(pmc2.proc_mod_cd, '') AS proc_mod_2_cd
        , '' AS proc_mod_3_cd
        , 'op' AS srvc_typ_cd
        , ifnull(prov.mpin, 0) AS prov_mpin
        , ifnull(lower(trim(prov.tin)), '') AS prov_tin
        , ifnull(lower(trim(prov.prov_fst_nm)), '') AS prov_fst_nm
        , ifnull(lower(trim(prov.prov_lst_nm)), '') AS prov_lst_nm
        , ifnull(lower(trim(prov.zip_cd)), '') AS prov_zip_cd
        , '' AS prov_state
        , ifnull(safe_cast(prov.npi_nbr as int64), 0) AS npi
        , 0 AS pcp_flag
        , '' AS provtype
        , '' AS spec_typ_nm
        , ifnull(lower(trim(pcc.prov_typ_nm)), '') as hp_prov_cat_typ_nm
        , ifnull(lower(trim(pos.clm_pl_of_srvc_cd)), '00') AS ama_pl_of_srvc_cd
        , ifnull(lower(trim(pos.clm_pl_of_srvc_desc)), '00') AS ama_pl_of_srvc_desc
        , ifnull(lower(trim(ppc.prov_prtcp_sts_cd)), '00') AS prov_prtcp_sts_cd
        , ifnull(lower(trim(ppc.hp_prov_sts_rllp_desc)), '00') AS hp_prov_sts_rllp_desc
        , ifnull(lower(trim(hpstc.hlth_pln_srvc_typ_cd)), 'unk') AS hlth_pln_srvc_typ_cd
        , ifnull(lower(trim(hpstc.hce_srvc_typ_desc)), '00') AS hce_srvc_typ_desc
        , ifnull(lower(trim(clm.bil_typ_cd)), '00') AS bil_typ_cd
        , ifnull(safe_cast(clm.bil_amt as numeric), 0) AS bil_amt
        , ifnull(safe_cast(clm.allw_amt as numeric), 0) AS allw_amt
        , ifnull(safe_cast(clm.net_pd_amt as numeric), 0) AS net_pd_amt
        , 0 AS oop_amt
        , ifnull(safe_cast(clm.copay_amt as numeric), 0) AS copay_amt
        , ifnull(safe_cast(clm.ded_amt as numeric), 0) AS ded_amt
        , ifnull(safe_cast(clm.coins_amt as numeric), 0) AS coins_amt
        , 0 AS disallow_amt
        , ifnull(safe_cast(clm.hlth_pln_cob_amt as numeric), 0) AS cob_amt
        , 0 AS admit_cnt
        , 0 AS day_cnt
        , ifnull(clm.srvc_unit_cnt, 0) AS srvc_unit_cnt
        , adt.full_dt AS adjudication_dt
        , cast(null as date) AS admit_dt
        , cast(null as date) AS discharge_dt
      from `ds-00-191017.ugap_final.fact_ova_outpatient`             clm
        join `ds-00-191017.ugap_final.dim_hpdm_date`                 dt on clm.fst_srvc_dt_sys_id     = dt.dt_sys_id
        left join `ds-00-191017.ugap_final.dim_hpdm_diagnosis_code`  dx1 on clm.diag_1_cd_sys_id      = dx1.diag_cd_sys_id
        left join `ds-00-191017.ugap_final.dim_hpdm_diagnosis_code`  dx2 on clm.diag_2_cd_sys_id      = dx2.diag_cd_sys_id
        left join `ds-00-191017.ugap_final.dim_hpdm_diagnosis_code`  dx3 on clm.diag_3_cd_sys_id      = dx3.diag_cd_sys_id
        left join `ds-00-191017.ugap_final.dim_hpdm_diagnosis_code`  dx4 on clm.diag_4_cd_sys_id      = dx4.diag_cd_sys_id
        left join `ds-00-191017.ugap_final.dim_hpdm_diagnosis_code`  dx5 on clm.diag_5_cd_sys_id      = dx5.diag_cd_sys_id
        left join `ds-00-191017.ugap_final.dim_hpdm_diagnosis_code`  dx6 on clm.diag_6_cd_sys_id      = dx6.diag_cd_sys_id
        left join `ds-00-191017.ugap_final.dim_hpdm_diagnosis_code`  dx7 on clm.diag_7_cd_sys_id      = dx7.diag_cd_sys_id
        left join `ds-00-191017.ugap_final.dim_hpdm_diagnosis_code`  dx8 on clm.diag_8_cd_sys_id      = dx8.diag_cd_sys_id
        left join `ds-00-191017.ugap_final.dim_hpdm_diagnosis_code`  dx9 on clm.diag_9_cd_sys_id      = dx9.diag_cd_sys_id
        left join `ds-00-191017.ugap_final.dim_hpdm_diagnosis_code`  dx10 on clm.diag_10_cd_sys_id      = dx10.diag_cd_sys_id
        left join `ds-00-191017.ugap_final.dim_hpdm_diagnosis_code`  dx11 on clm.diag_11_cd_sys_id      = dx11.diag_cd_sys_id
        left join `ds-00-191017.ugap_final.dim_hpdm_diagnosis_code`  dx12 on clm.diag_12_cd_sys_id      = dx12.diag_cd_sys_id
        left join `ds-00-191017.ugap_final.dim_hpdm_revenue_code`    rvnu on clm.rvnu_cd_sys_id       = rvnu.rvnu_cd_sys_id
        left join `ds-00-191017.ugap_final.dim_hpdm_procedure_code`  pc on clm.proc_cd_sys_id         = pc.proc_cd_sys_id
        left join `ds-00-191017.ugap_final.dim_hpdm_procedure_code`  pc1 on clm.proc_1_cd_sys_id      = pc1.proc_cd_sys_id
        left join `ds-00-191017.ugap_final.dim_hpdm_procedure_code`  pc2 on clm.proc_2_cd_sys_id      = pc2.proc_cd_sys_id
        left join `ds-00-191017.ugap_final.dim_hpdm_procedure_code`  pc3 on clm.proc_3_cd_sys_id      = pc3.proc_cd_sys_id
        left join `ds-00-191017.ugap_final.dim_hpdm_procedure_code`         pc4 on clm.proc_4_cd_sys_id      = pc4.proc_cd_sys_id
        left join `ds-00-191017.ugap_final.dim_hpdm_procedure_code`         pc5 on clm.proc_5_cd_sys_id      = pc5.proc_cd_sys_id
        left join `ds-00-191017.ugap_final.dim_hpdm_procedure_code`         pc6 on clm.proc_6_cd_sys_id      = pc6.proc_cd_sys_id
        left join `ds-00-191017.ugap_final.dim_hpdm_procedure_modifier_code`  pmc1 on clm.proc_mod_1_sys_id  = pmc1.proc_mod_sys_id
        left join `ds-00-191017.ugap_final.dim_hpdm_procedure_modifier_code`  pmc2 on clm.proc_mod_2_sys_id  = pmc2.proc_mod_sys_id
        left join `ds-00-191017.ugap_final.dim_ova_provider`                  prov on clm.srvc_prov_sys_id   = prov.prov_sys_id
        left join `ds-00-191017.ugap_final.dim_hpdm_place_of_service_code`    pos on clm.pl_of_srvc_sys_id   = pos.pl_of_srvc_sys_id
        left join `ds-00-191017.ugap_final.dim_hpdm_provider_participation_code` ppc on clm.prov_prtcp_sts_cd_sys_id  =  ppc.prov_prtcp_sts_cd_sys_id
        left join `ds-00-191017.ugap_final.dim_hpdm_hp_service_type_code`   hpstc on clm.hlth_pln_srvc_typ_cd_sys_id  =  hpstc.hlth_pln_srvc_typ_cd_sys_id
        left join `ds-00-191017.ugap_final.dim_hpdm_date`                adt on clm.adjd_dt_sys_id          = adt.dt_sys_id
        left join `ds-00-191017.ugap_final.dim_hpdm_hp_provider_category_code`    pcc on clm.srvc_prov_catgy_cd_sys_id = pcc.prov_catgy_cd_sys_id
      -- where
      --   clm.is_restricted_flag = 0

      union all

      select
        GENERATE_UUID() uuid
        , clm.savvy_pid AS savvy_pid
        , clm.savvy_did AS savvy_did
        , clm.is_restricted_flag AS is_restricted
        , "ugap" AS src_type
        , ifnull(lower(trim(clm.clm_aud_nbr)), '') AS clm_aud_nbr
        , '' AS line_number
        , 'ds-00-191017.ugap_final.fact_ova_physician' AS data_source
        , '' AS claim_sub_type
        , dt.full_dt AS clm_dt
        , ifnull(clm.icd_ver_cd, '10') AS icd_ver_cd
        , ifnull(lower(trim(dx1.diag_cd)), '') AS dx1_diag_cd
        , ifnull(lower(trim(dx2.diag_cd)), '') AS dx2_diag_cd
        , ifnull(lower(trim(dx3.diag_cd)), '') AS dx3_diag_cd
        , ifnull(lower(trim(dx4.diag_cd)), '') AS dx4_diag_cd
        , ifnull(lower(trim(dx5.diag_cd)), '') AS dx5_diag_cd
        , ifnull(lower(trim(dx6.diag_cd)), '') AS dx6_diag_cd
        , ifnull(lower(trim(dx7.diag_cd)), '') AS dx7_diag_cd
        , ifnull(lower(trim(dx8.diag_cd)), '') AS dx8_diag_cd
        , ifnull(lower(trim(dx9.diag_cd)), '') AS dx9_diag_cd
        , ifnull(lower(trim(dx10.diag_cd)), '') AS dx10_diag_cd
        , ifnull(lower(trim(dx11.diag_cd)), '') AS dx11_diag_cd
        , ifnull(lower(trim(dx12.diag_cd)), '') AS dx12_diag_cd
        , '' AS rvnu_cd
        , ifnull(lower(trim(pc.proc_cd)), '') AS proc_cd
        , '' as prc1_proc_cd
        , '' as prc2_proc_cd
        , '' as prc3_proc_cd
        , '' as prc4_proc_cd
        , '' as prc5_proc_cd
        , '' as prc6_proc_cd
        , '' AS drg_cd
        , '' AS dschrg_sts_cd
        , ifnull(pmc1.proc_mod_cd, '') AS proc_mod_1_cd
        , ifnull(pmc2.proc_mod_cd, '') AS proc_mod_2_cd
        , '' AS proc_mod_3_cd
        , 'dr' AS srvc_typ_cd
        , ifnull(prov.mpin, 0) AS prov_mpin
        , ifnull(lower(trim(prov.tin)), '') AS prov_tin
        , ifnull(lower(trim(prov.prov_fst_nm)), '') AS prov_fst_nm
        , ifnull(lower(trim(prov.prov_lst_nm)), '') AS prov_lst_nm
        , ifnull(lower(trim(prov.zip_cd)), '') AS prov_zip_cd
        , '' AS prov_state
        , ifnull(safe_cast(prov.npi_nbr as int64), 0) AS npi
        , 0 AS pcp_flag
        , '' AS provtype
        , '' AS spec_typ_nm
        , ifnull(lower(trim(pcc.prov_typ_nm)), '') as hp_prov_cat_typ_nm
        , ifnull(lower(trim(pos.ama_pl_of_srvc_cd)), '00') AS ama_pl_of_srvc_cd
        , ifnull(lower(trim(pos.ama_pl_of_srvc_desc)), '') AS ama_pl_of_srvc_desc
        , ifnull(lower(trim(ppc.prov_prtcp_sts_cd)), '') AS prov_prtcp_sts_cd
        , ifnull(lower(trim(ppc.hp_prov_sts_rllp_desc)), '') AS hp_prov_sts_rllp_desc
        , ifnull(lower(trim(hpstc.hlth_pln_srvc_typ_cd)), 'unk') AS hlth_pln_srvc_typ_cd
        , ifnull(lower(trim(hpstc.hce_srvc_typ_desc)), '') AS hce_srvc_typ_desc
        , '' AS bil_typ_cd
        , ifnull(safe_cast(clm.bil_amt as numeric), 0) AS bil_amt
        , ifnull(safe_cast(clm.allw_amt as numeric), 0) AS allw_amt
        , ifnull(safe_cast(clm.net_pd_amt as numeric), 0) AS net_pd_amt
        , 0 AS oop_amt
        , ifnull(safe_cast(clm.copay_amt as numeric), 0) AS copay_amt
        , ifnull(safe_cast(clm.ded_amt as numeric), 0) AS ded_amt
        , ifnull(safe_cast(clm.coins_amt as numeric), 0) AS coins_amt
        , 0 AS disallow_amt
        , ifnull(safe_cast(clm.hlth_pln_cob_amt as numeric), 0) AS cob_amt
        , 0 AS admit_cnt
        , 0 AS day_cnt
        , ifnull(clm.srvc_unit_cnt, 0) AS srvc_unit_cnt
        , adt.full_dt AS adjudication_dt
        , cast(null as date) AS admit_dt
        , cast(null as date) AS discharge_dt
      from `ds-00-191017.ugap_final.fact_ova_physician`              clm
        join `ds-00-191017.ugap_final.dim_hpdm_date`                 dt on clm.fst_srvc_dt_sys_id     = dt.dt_sys_id
        left join `ds-00-191017.ugap_final.dim_hpdm_diagnosis_code`  dx1 on clm.diag_1_cd_sys_id      = dx1.diag_cd_sys_id
        left join `ds-00-191017.ugap_final.dim_hpdm_diagnosis_code`  dx2 on clm.diag_2_cd_sys_id      = dx2.diag_cd_sys_id
        left join `ds-00-191017.ugap_final.dim_hpdm_diagnosis_code`  dx3 on clm.diag_3_cd_sys_id      = dx3.diag_cd_sys_id
        left join `ds-00-191017.ugap_final.dim_hpdm_diagnosis_code`  dx4 on clm.diag_4_cd_sys_id      = dx4.diag_cd_sys_id
        left join `ds-00-191017.ugap_final.dim_hpdm_diagnosis_code`  dx5 on clm.diag_5_cd_sys_id      = dx5.diag_cd_sys_id
        left join `ds-00-191017.ugap_final.dim_hpdm_diagnosis_code`  dx6 on clm.diag_6_cd_sys_id      = dx6.diag_cd_sys_id
        left join `ds-00-191017.ugap_final.dim_hpdm_diagnosis_code`  dx7 on clm.diag_7_cd_sys_id      = dx7.diag_cd_sys_id
        left join `ds-00-191017.ugap_final.dim_hpdm_diagnosis_code`  dx8 on clm.diag_8_cd_sys_id      = dx8.diag_cd_sys_id
        left join `ds-00-191017.ugap_final.dim_hpdm_diagnosis_code`  dx9 on clm.diag_9_cd_sys_id      = dx9.diag_cd_sys_id
        left join `ds-00-191017.ugap_final.dim_hpdm_diagnosis_code`  dx10 on clm.diag_10_cd_sys_id      = dx10.diag_cd_sys_id
        left join `ds-00-191017.ugap_final.dim_hpdm_diagnosis_code`  dx11 on clm.diag_11_cd_sys_id      = dx11.diag_cd_sys_id
        left join `ds-00-191017.ugap_final.dim_hpdm_diagnosis_code`  dx12 on clm.diag_12_cd_sys_id      = dx12.diag_cd_sys_id
        left join `ds-00-191017.ugap_final.dim_hpdm_procedure_code`  pc on clm.proc_cd_sys_id         = pc.proc_cd_sys_id
        left join `ds-00-191017.ugap_final.dim_hpdm_procedure_modifier_code`  pmc1 on clm.proc_mod_1_sys_id  = pmc1.proc_mod_sys_id
        left join `ds-00-191017.ugap_final.dim_hpdm_procedure_modifier_code`  pmc2 on clm.proc_mod_2_sys_id  = pmc2.proc_mod_sys_id
        left join `ds-00-191017.ugap_final.dim_ova_provider`                  prov on clm.srvc_prov_sys_id   = prov.prov_sys_id
        left join `ds-00-191017.ugap_final.dim_hpdm_place_of_service_code`    pos on clm.pl_of_srvc_sys_id   = pos.pl_of_srvc_sys_id
        left join `ds-00-191017.ugap_final.dim_hpdm_provider_participation_code` ppc on clm.prov_prtcp_sts_cd_sys_id  =  ppc.prov_prtcp_sts_cd_sys_id
        left join `ds-00-191017.ugap_final.dim_hpdm_hp_service_type_code`   hpstc on clm.hlth_pln_srvc_typ_cd_sys_id  =  hpstc.hlth_pln_srvc_typ_cd_sys_id
        left join `ds-00-191017.ugap_final.dim_hpdm_date`                adt on clm.adjd_dt_sys_id          = adt.dt_sys_id
        left join `ds-00-191017.ugap_final.dim_hpdm_hp_provider_category_code`    pcc on clm.srvc_prov_catgy_cd_sys_id = pcc.prov_catgy_cd_sys_id
      -- where
      --   clm.is_restricted_flag = 0
      )
    where
      clm_dt >= '2016-01-01'
  ;

  --if successful, we'll get here!
  insert into `research-01-217611.df_ucd_stage.logging`(
    success_flag, job, message_datetime)
  select
    1 as success_flag
    , 'map ugap medicare medical claims' as job
    , current_datetime as message_datetime
  ;

  EXCEPTION WHEN ERROR THEN
    insert into `research-01-217611.df_ucd_stage.logging`(
      success_flag, job, error_message, statement_text, formatted_stack_trace, message_datetime)
    select
      0 as success_flag
      , 'map ugap medicare medical claims' as job
      , @@error.message as error_message
      , @@error.statement_text as statement_text
      , @@error.formatted_stack_trace as formatted_stack_trace
      , current_datetime as message_datetime
    ;

END
;
