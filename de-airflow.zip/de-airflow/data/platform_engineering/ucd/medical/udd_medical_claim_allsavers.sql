/* Project: Universal Claims Database (UCD )
   Business Partner: Matt Holst
   Input:`ds-00-191017.allsavers_final.all_sv_claims`,`ds-00-191017.allsavers_final.all_sv_providers
   `ds-00-191017.allsavers_final.all_sv_diag` (updated monthly - Contact: Solaris; General Allsavers questions: Edson Paul Semorio)
   Created By: Sachin
   Created Date: 11/9/2020
   Granularity:  Claim/line detail
   Note that the source table had 1.1M records with savvy_pid=-1. This query excludes those records
   and keeps only claims with service year>= 2016.
  /**Used placeholders (null) for fields that are currently not available in Allsavers claim table **/

 BEGIN

  -- delete
  -- from `research-01-217611.df_ucd_stage.udd_medical_claim_allsavers`
  -- where 1=1
  -- ;

  insert into `research-01-217611.df_ucd_stage.udd_medical_claim_allsavers`
    (uuid, savvy_pid, savvy_did, is_restricted, src_type, clm_aud_nbr, line_number, data_source, claim_sub_type, clm_dt,
    icd_ver_cd, dx1_diag_cd, dx2_diag_cd, dx3_diag_cd, dx4_diag_cd, dx5_diag_cd, dx6_diag_cd, dx7_diag_cd, dx8_diag_cd, dx9_diag_cd, dx10_diag_cd, dx11_diag_cd, dx12_diag_cd,
    rvnu_cd, proc_cd, prc1_proc_cd, prc2_proc_cd, prc3_proc_cd, prc4_proc_cd, prc5_proc_cd, prc6_proc_cd,
    drg_cd, dschrg_sts_cd, proc_mod_1_cd, proc_mod_2_cd, proc_mod_3_cd, srvc_typ_cd,
    prov_mpin, prov_tin, prov_fst_nm, prov_lst_nm, prov_zip_cd, prov_state, npi, pcp_flag, provtype, spec_typ_nm, hp_prov_cat_typ_nm,
    ama_pl_of_srvc_cd, ama_pl_of_srvc_desc, prov_prtcp_sts_cd, hp_prov_sts_rllp_desc, hlth_pln_srvc_typ_cd, hce_srvc_typ_desc, bil_typ_cd,
    bil_amt, allw_amt, net_pd_amt, oop_amt, copay_amt, ded_amt, coins_amt, disallow_amt, cob_amt,
    admit_cnt, day_cnt, srvc_unit_cnt, adjudication_dt, admit_dt, discharge_dt, create_datetime, update_datetime
    )
  select
      uuid, savvy_pid, savvy_did, is_restricted, src_type, clm_aud_nbr, line_number, data_source, claim_sub_type, clm_dt,
      icd_ver_cd, dx1_diag_cd, dx2_diag_cd, dx3_diag_cd, dx4_diag_cd, dx5_diag_cd, dx6_diag_cd, dx7_diag_cd, dx8_diag_cd, dx9_diag_cd, dx10_diag_cd, dx11_diag_cd, dx12_diag_cd,rvnu_cd, proc_cd, prc1_proc_cd, prc2_proc_cd, prc3_proc_cd, prc4_proc_cd, prc5_proc_cd, prc6_proc_cd,
      drg_cd, dschrg_sts_cd, proc_mod_1_cd, proc_mod_2_cd, proc_mod_3_cd, srvc_typ_cd,
      prov_mpin, prov_tin, prov_fst_nm, prov_lst_nm, prov_zip_cd, prov_state, npi, pcp_flag, provtype, spec_typ_nm, hp_prov_cat_typ_nm,
      ama_pl_of_srvc_cd, ama_pl_of_srvc_desc, prov_prtcp_sts_cd, hp_prov_sts_rllp_desc, hlth_pln_srvc_typ_cd, hce_srvc_typ_desc, bil_typ_cd,
      bil_amt, allw_amt, net_pd_amt, oop_amt, copay_amt, ded_amt, coins_amt, disallow_amt, cob_amt,
      admit_cnt, day_cnt, srvc_unit_cnt, adjudication_dt, admit_dt, discharge_dt,
      current_datetime() as create_datetime,
      current_datetime() as update_datetime
  from
    (
  select
        GENERATE_UUID() uuid
        , clm.savvy_pid AS savvy_pid
        , clm.savvy_did as savvy_did
        , clm.is_restricted as is_restricted
        , "allsavers" AS src_type
        , ifnull(cast(clm.clmnbr as string), '')  AS clm_aud_nbr
        , ifnull(cast(clmseq as string), '') AS line_number
       , 'ds-00-191017.allsavers_final.all_sv_claims' AS data_source
        , '' AS claim_sub_type
        , parse_date('%Y%m%d',FROMDT)  AS clm_dt
        , case when ifnull(clm.icdvrs,'0')='0' then 10 else safe_cast(clm.icdvrs as int64) end icd_ver_cd
        , lower(trim(ifnull(icdcd, ''))) AS dx1_diag_cd
        , lower(trim(ifnull(d.diag2, ''))) AS dx2_diag_cd
        , lower(trim(ifnull(d.diag3, ''))) AS dx3_diag_cd
        , lower(trim(ifnull(d.diag4, ''))) AS dx4_diag_cd
        , lower(trim(ifnull(d.diag5, ''))) AS dx5_diag_cd
        , lower(trim(ifnull(d.diag6, ''))) AS dx6_diag_cd
        , lower(trim(ifnull(d.diag7, ''))) AS dx7_diag_cd
        , lower(trim(ifnull(d.diag8, ''))) AS dx8_diag_cd
        , lower(trim(ifnull(d.diag9, ''))) AS dx9_diag_cd
        , lower(trim(ifnull(d.diag10, ''))) AS dx10_diag_cd
        , lower(trim(ifnull(d.diag11, '')))  AS dx11_diag_cd
        , lower(trim(ifnull(d.diag12, '')))  AS dx12_diag_cd
        , ifnull(replace(revcd, 'unk', ''), '') AS rvnu_cd
        , lower(trim(ifnull(cptnbr, ''))) AS proc_cd
        , lower(trim(ifnull(icdprc, ''))) as prc1_proc_cd
        , '' as prc2_proc_cd
        , '' as prc3_proc_cd
        , '' as prc4_proc_cd
        , '' as prc5_proc_cd
        , '' as prc6_proc_cd
        , '' as drg_cd
        , '' as dschrg_sts_cd
        , ifnull(cptmo1, '') AS proc_mod_1_cd
        , ifnull(cptmo2, '') AS proc_mod_2_cd
        , ifnull(cptmo3, '') AS proc_mod_3_cd
        , (case
           when clm.frmtyp='1' then 'dr'
           when clm.frmtyp='2' then 'ip'
           when clm.frmtyp='3' then 'op'
           end) as srvc_typ_cd
        , safe_cast(mpincd as int64)  AS prov_mpin
        , ifnull(clm.prvtid, '') as prov_tin
        , lower(trim(ifnull(pr.prv_frst, ''))) AS prov_fst_nm
        , lower(trim(ifnull(pr.prv_lst, ''))) AS prov_lst_nm
        , ifnull(pr.prv_zip, '') AS prov_zip_cd
        , lower(trim(ifnull(pr.prv_st, ''))) AS prov_state
        , 0 AS npi
        , 0 AS pcp_flag
        , '' AS provtype
        , '' AS spec_typ_nm
        , '' as hp_prov_cat_typ_nm
        , '00' AS ama_pl_of_srvc_cd
        , '' AS ama_pl_of_srvc_desc
        , '' AS prov_prtcp_sts_cd
        , '' AS hp_prov_sts_rllp_desc
        , 'unk' AS hlth_pln_srvc_typ_cd
        , '' AS hce_srvc_typ_desc
        , ifnull(replace(billcd, '-1', ''), '') AS bil_typ_cd --use blank string instead of -1 for default value
        , safe_cast(chgamt as numeric) AS bil_amt
        , safe_cast(allow as numeric) AS allw_amt
        , safe_cast(pdamt as numeric) AS net_pd_amt
        , 0 AS oop_amt
        , safe_cast(cpyamt as numeric) AS copay_amt
        , safe_cast(dedamt as numeric) AS ded_amt
        , safe_cast(coins as numeric) AS coins_amt
        , 0 AS disallow_amt
        , 0 AS cob_amt
        , 0 as admit_cnt  /*placeholder for admit cnt.  ifnull(admit_cnt, 0) as admit_cnt*/
        , 0 as day_cnt /*placeholder for day count. case when admit_cnt = 1 then day_cnt else 0 end as day_cnt*/
        , 0 AS srvc_unit_cnt
        , cast(null as date) AS adjudication_dt
        , cast(null as date) AS admit_dt /*placeholder for admit dt case when admit_cnt = 1 then from_full_dt end AS admit_dt*/
        , cast(null as date) AS discharge_dt /*case when admit_cnt = 1 then DATE_ADD(from_full_dt, INTERVAL ifnull(day_cnt, 0) DAY) end AS discharge_dt*/

      from `ds-00-191017.allsavers_final.all_sv_claims`  clm
      left join `ds-00-191017.allsavers_final.all_sv_providers` pr on clm.prvtid=pr.prvtid and clm.prvsfx=pr.prvsfx and clm.rltnsq=pr.rltnsq
      left join `ds-00-191017.allsavers_final.all_sv_diag`  d on clm.sysid=d.sysid and clm.clmnbr=d.clmnbr and clm.subnbr=d.subnbr and clm.clmset=d.clmset
      where   clm.fromdt<>'0'
      and extract(year from parse_date('%Y%m%d',clm.fromdt)) >=2016
      -- and clm.is_restricted=0
      and clm.frmtyp in ('1','2','3') /*1=Dr, 2=IP and 3=OP */
      and clm.savvy_pid>0

 )
   ;


    --if successful, we'll get here!
    insert into `research-01-217611.df_ucd_stage.logging`(
      success_flag, job, message_datetime)
    select
      1 as success_flag
      , 'map allsavers medical claims' as job
      , current_datetime as message_datetime
    ;

    EXCEPTION WHEN ERROR THEN
      insert into `research-01-217611.df_ucd_stage.logging`(
        success_flag, job, error_message, statement_text, formatted_stack_trace, message_datetime)
      select
        0 as success_flag
        , 'map allsavers medical claims' as job
        , @@error.message as error_message
        , @@error.statement_text as statement_text
        , @@error.formatted_stack_trace as formatted_stack_trace
        , current_datetime as message_datetime
      ;

END
;
