/* Project: Universal Claims Database (UCD ) Bind version
   Business Partner: Matt Holst
   Input:                         minihpdm_{inpatient; outpatient; physician}_claim_raw
   Created By: Prerana
   Reference: Seth
   Created Date: 11/10/2020
   Granularity:  Claim/line detail                                    */

  /**Used placeholders (null) for fields that are not currently not available in UGAP claim table **/
----------------------------------------------------------------------------------------------------------------


BEGIN

 -- delete
 --  from `research-01-217611.df_ucd_stage.udd_medical_claim_bind`
 --  where 1=1
 --  ;

  insert into `research-01-217611.df_ucd_stage.udd_medical_claim_bind`
    (uuid, savvy_pid, savvy_did, is_restricted, src_type, clm_aud_nbr, line_number, data_source, claim_sub_type, clm_dt,
    icd_ver_cd, dx1_diag_cd, dx2_diag_cd, dx3_diag_cd, dx4_diag_cd, dx5_diag_cd, dx6_diag_cd, dx7_diag_cd, dx8_diag_cd, dx9_diag_cd, dx10_diag_cd, dx11_diag_cd, dx12_diag_cd,
    rvnu_cd, proc_cd, prc1_proc_cd, prc2_proc_cd, prc3_proc_cd, prc4_proc_cd, prc5_proc_cd, prc6_proc_cd,
    drg_cd, dschrg_sts_cd, proc_mod_1_cd, proc_mod_2_cd, proc_mod_3_cd, srvc_typ_cd,
    prov_mpin, prov_tin, prov_fst_nm, prov_lst_nm, prov_zip_cd, prov_state, npi, pcp_flag, provtype, spec_typ_nm, hp_prov_cat_typ_nm,
    ama_pl_of_srvc_cd, ama_pl_of_srvc_desc, prov_prtcp_sts_cd, hp_prov_sts_rllp_desc, hlth_pln_srvc_typ_cd, hce_srvc_typ_desc, bil_typ_cd,
    bil_amt, allw_amt, net_pd_amt, oop_amt, copay_amt, ded_amt, coins_amt, disallow_amt, cob_amt,
    admit_cnt, day_cnt, srvc_unit_cnt, adjudication_dt, admit_dt, discharge_dt, create_datetime, update_datetime
    )
    with admit_details as ( --this is to get the admit_cnt flag and day_cnt per claim_number instead of per claim_line
      --this will populate one row with min line number with admit_cnt and and day_cnt
      select    distinct clm.claim_id, clm.claim_line_number , clm.savvy_pid, clm.service_start_date
                , clm.admission_date , clm.discharge_date
                , DATE_DIFF(clm.discharge_date, clm.admission_date, DAY) as day_cnt
                , 1 as admit_cnt
      from      ( select   claim_id, savvy_pid,  admission_date , discharge_date, min(claim_line_number) as claim_line_number
                  from      `ds-00-191017.bind_final.medical_claim`
                  where     admission_date is not null
                  group by   claim_id, savvy_pid, admission_date,discharge_date
                 ) line_clm
      join      `ds-00-191017.bind_final.medical_claim` clm on line_clm.claim_id = clm.claim_id
                                                          and  line_clm.claim_line_number = clm.claim_line_number
                                                          and  line_clm.savvy_pid = clm.savvy_pid
                                                          and  line_clm.admission_date = clm.admission_date
                                                          and  line_clm.discharge_date = clm.discharge_date
    )

    select
       GENERATE_UUID() uuid,
      savvy_pid, savvy_did, is_restricted, src_type, clm_aud_nbr, line_number, data_source, claim_sub_type, clm_dt,
      case when ifnull(icd_ver_cd, '0') = '0' or icd_ver_cd = '' then 10 else safe_cast(icd_ver_cd as int64) end as icd_ver_cd,
      dx1_diag_cd, dx2_diag_cd, dx3_diag_cd, dx4_diag_cd, dx5_diag_cd, dx6_diag_cd, dx7_diag_cd, dx8_diag_cd, dx9_diag_cd, dx10_diag_cd, dx11_diag_cd, dx12_diag_cd,
      rvnu_cd, proc_cd, prc1_proc_cd, prc2_proc_cd, prc3_proc_cd, prc4_proc_cd, prc5_proc_cd, prc6_proc_cd,
      drg_cd, dschrg_sts_cd, proc_mod_1_cd, proc_mod_2_cd, proc_mod_3_cd, srvc_typ_cd,
      prov_mpin, prov_tin, prov_fst_nm, prov_lst_nm, prov_zip_cd, prov_state, npi, pcp_flag, provtype, spec_typ_nm, hp_prov_cat_typ_nm,
      ama_pl_of_srvc_cd, ama_pl_of_srvc_desc, prov_prtcp_sts_cd, hp_prov_sts_rllp_desc, hlth_pln_srvc_typ_cd, hce_srvc_typ_desc, bil_typ_cd,
      bil_amt, allw_amt, net_pd_amt, oop_amt, copay_amt, ded_amt, coins_amt, disallow_amt, cob_amt,
      admit_cnt, day_cnt, srvc_unit_cnt, adjudication_dt, admit_dt, discharge_dt,
      current_datetime() as create_datetime,
      current_datetime() as update_datetime
    from
      (

      select
           distinct
           clm.savvy_pid AS savvy_pid
           , clm.savvy_did as savvy_did
           , clm.is_restricted
          , "bind" AS src_type
          , ifnull(lower(trim(clm.claim_id)), '') AS clm_aud_nbr
          , ifnull(lower(trim(clm.claim_line_number)), '') AS line_number
          , 'ds-00-191017.bind_final.medical_claim' AS data_source
          , '' AS claim_sub_type
          , clm.service_start_date AS clm_dt
          , ifnull(clm.diagnosis_version, '10') AS icd_ver_cd --check this
          , ifnull(lower(trim(clm.diagnosis_code_1)), '') AS dx1_diag_cd
          , ifnull(lower(trim(clm.diagnosis_code_2)), '') AS dx2_diag_cd
          , ifnull(lower(trim(clm.diagnosis_code_3)), '') AS dx3_diag_cd
          , ifnull(lower(trim(clm.diagnosis_code_4)), '') AS dx4_diag_cd
          , ifnull(lower(trim(clm.diagnosis_code_5)), '') AS dx5_diag_cd
          , ifnull(lower(trim(clm.diagnosis_code_6)), '') AS dx6_diag_cd
          , ifnull(lower(trim(clm.diagnosis_code_7)), '') AS dx7_diag_cd
          , ifnull(lower(trim(clm.diagnosis_code_8)), '') AS dx8_diag_cd
          , ifnull(lower(trim(clm.diagnosis_code_9)), '') AS dx9_diag_cd
          , ifnull(lower(trim(clm.diagnosis_code_10)), '') AS dx10_diag_cd
          , ifnull(lower(trim(clm.diagnosis_code_11)), '') AS dx11_diag_cd
          , ifnull(lower(trim(clm.diagnosis_code_12)), '') AS dx12_diag_cd
          , ifnull(lower(trim(clm.revenue_code)), '') AS rvnu_cd
          , ifnull(lower(trim(clm.procedure_code)), '') AS proc_cd
          , ifnull(lower(trim(clm.icd_procedure_code_1)), '') as prc1_proc_cd
          , ifnull(lower(trim(clm.icd_procedure_code_2)), '') as prc2_proc_cd
          , ifnull(lower(trim(clm.icd_procedure_code_3)), '') as prc3_proc_cd
          , ifnull(lower(trim(clm.icd_procedure_code_4)), '') as prc4_proc_cd
          , '' as prc5_proc_cd --ifnull(lower(trim(pc5.proc_cd)), '') as prc5_proc_cd
          , '' as prc6_proc_cd --ifnull(lower(trim(pc6.proc_cd)), '') as prc6_proc_cd
          , ifnull(lower(trim(lpad(clm.drg_code, 5, '0') )), case when clm.admission_date is not null then '00000' else '' end) AS drg_cd ---*****check
          , ifnull(lower(trim(clm.patient_status_code)), case when clm.discharge_date is not null then '00' else '' end) AS dschrg_sts_cd ---*****check
          , ifnull(lower(trim(clm.modifier_code_1)), '') AS proc_mod_1_cd
          , ifnull(lower(trim(clm.modifier_code_2)), '') AS proc_mod_2_cd
          , ifnull(lower(trim(clm.modifier_code_3)), '') AS proc_mod_3_cd

          , CASE WHEN lower(trim(claim_type)) = 'i'
                      and clm.place_of_service in ('11','12','15','16','17','21','22','25','26','27','35','36','37','41','42','45'
                                                   ,'46','47','51','52','55','56','57','61','62','65','66','67','82','86') THEN 'ip'
	               ELSE CASE WHEN lower(trim(claim_type)) = 'i' THEN 'op'
	               ELSE CASE WHEN trim(lower(tax.grouping)) in ('agencies','ambulatory health care facilities','hospital units'
                                                        ,'hospitals','laboratories','managed care organizations'
                                                        ,'nursing & custodial care facilities','residential treatment facilities'
                                                        ,'suppliers','transportation services') THEN 'op'
	               ELSE 'dr' END END END      AS srvc_typ_cd

          , 0 AS prov_mpin
          --billing provider as the provider here added
          , ifnull(lower(trim(clm.billing_provider_tax_id_number)), '') AS prov_tin
          , ifnull(lower(trim(clm.billing_provider_first_name)),'') AS prov_fst_nm
          , ifnull(lower(trim(clm.billing_provider_last_name)),'') AS prov_lst_nm
          , ifnull(lower(trim(clm.billing_provider_zip_code)),'') AS prov_zip_cd
          , ifnull(lower(trim(clm.billing_provider_state)),'')  AS prov_state
          , ifnull(safe_cast(clm.billing_provider_npi as int64), 0) AS npi

          , 0 AS pcp_flag
          , '' AS provtype
          , '' AS spec_typ_nm
          , '' AS hp_prov_cat_typ_nm
          , ifnull(lower(trim(clm.place_of_service)), '00') AS ama_pl_of_srvc_cd
          , '' as ama_pl_of_srvc_desc
          , ifnull(lower(trim(clm.payment_network_indicator)), '') AS prov_prtcp_sts_cd
          , case when lower(trim(clm.payment_network_indicator)) = 'y' then 'par provider'
                 when lower(trim(clm.payment_network_indicator)) = 'n' then 'non-par provider'
                 else '' end AS hp_prov_sts_rllp_desc

          , 'unk' AS hlth_pln_srvc_typ_cd --, ifnull(lower(trim(hpstc.hlth_pln_srvc_typ_cd)), 'unk') AS hlth_pln_srvc_typ_cd
          , '' AS hce_srvc_typ_desc--, ifnull(lower(trim(hpstc.hce_srvc_typ_desc)), '') AS hce_srvc_typ_desc

          , ifnull(lower(trim(clm.bill_type)), '') AS bil_typ_cd
          , ifnull(safe_cast(clm.billed_amount as numeric), 0) AS bil_amt
          , ifnull(safe_cast(clm.allowed_amount as numeric), 0) AS allw_amt
          , ifnull(safe_cast(clm.plan_paid_amount as numeric), 0) AS net_pd_amt
          , 0 AS oop_amt
          , ifnull(safe_cast(clm.member_responsibility_amount as numeric), 0) AS copay_amt
          , 0 AS ded_amt
          , 0 AS coins_amt
          , 0 AS disallow_amt
          , ifnull(safe_cast(clm.other_insurance_paid_amount as numeric), 0) AS cob_amt
          --check the below 2 columns
          , ifnull(adm.admit_cnt, 0) AS admit_cnt
          , ifnull(case when adm.day_cnt > 0 then adm.day_cnt else 0 end, 0)  AS day_cnt

          , ifnull(cast(clm.units_billed as numeric), 0) AS srvc_unit_cnt
          , clm.paid_date AS adjudication_dt

          , clm.admission_date AS admit_dt
          , clm.discharge_date AS discharge_dt

        from  `ds-00-191017.bind_final.medical_claim`               clm
        left join admit_details                                     adm on clm.savvy_pid = adm.savvy_pid
                                                                           and clm.claim_id = adm.claim_id
                                                                           and clm.claim_line_number = adm.claim_line_number
                                                                           and clm.service_start_date = adm.service_start_date
                                                                           and clm.admission_date  = adm.admission_date
                                                                           and clm.discharge_date = adm.discharge_date
        left join `research-01-217611.df_ucd_stage.dim_npi_taxonomy` npi on safe_cast(clm.billing_provider_npi as int64) = npi.npi
        left join `research-01-217611.df_ucd_stage.npi_taxonomy`     tax on npi.taxonomy_code = tax.code
       )


       --405694
       --have to check the npi? and taxonomy
     /*  select distinct a.grouping  from `research-01-217611.df_ucd_stage.npi_taxonomy` a
       where lower(trim(a.grouping)) in ('agencies' ,'ambulatory health care facilities','hospital units'
                                                        ,'hospitals','laboratories','managed care organizations'
                                                        ,'nursing & custodial care facilities','residential treatment facilities'
                                                        ,'suppliers','transportation services') */
-------------------------------------------------------------------------------------------------------
;

--if successful, we'll get here!
    insert into `research-01-217611.df_ucd_stage.logging`(
      success_flag, job, message_datetime)
    select
      1 as success_flag
      , 'map bind medical claims' as job
      , current_datetime as message_datetime
    ;

    EXCEPTION WHEN ERROR THEN
      insert into `research-01-217611.df_ucd_stage.logging`(
        success_flag, job, error_message, statement_text, formatted_stack_trace, message_datetime)
      select
        0 as success_flag
        , 'map bind medical claims' as job
        , @@error.message as error_message
        , @@error.statement_text as statement_text
        , @@error.formatted_stack_trace as formatted_stack_trace
        , current_datetime as message_datetime
      ;

END
;
