/* Project: Universal Claims Database (UCD )
   Business Partner: Matt Holst
   Input: ds-00-191017.galaxy_ods.unet_claim_header,ds-00-191017.galaxy_ods.unet_claim_statistical_service`,
   `ds-00-191017.galaxy_ods.unet_inpatient_relator`,ds-00-191017.galaxy_ods.unet_facility_ub92`,ds-00-191017.galaxy_ods.member.
   Created By: Sachin
   Created Date:10/22/2020
   Modified By:
   Modified Dates:
   Sourced from ds-00 (Per New Data Management Paradigm)
   Granularity: One record per member/claim/line */


BEGIN

insert into `research-01-217611.df_ucd_stage.logging`(
    success_flag, job, message_datetime)
  select
    1 as success_flag
    , 'starting to load galaxy claim statistical table' as job
    , current_datetime as message_datetime
  ;


  create or replace table `research-01-217611.df_ucd_stage.ucd_medical_claims_galaxy_ds00` as

with med as
          (select
              a.savvy_pid,
              a.savvy_did,
              a.is_restricted,
              ip.iptnt_cnfn_sys_id,
              a.unet_clm_head_sys_id,
              srvc_prov_sys_id,
              srvc_prov_row_eff_dt,
              srvc_prov_catgy_cd,
              pl_of_srvc_sys_id,
              cast(adj_hccc_cd as int64) as adj_hccc_cd,
              "galaxy" as src_type,
              ifnull(a.clm_aud_nbr, '') as clm_aud_nbr,
              ifnull(cast(b.dtl_ln_nbr as string), '') as line_number,
              'ds-00-191017.galaxy_final.unet_claim_header' as data_source,
              '' as claim_sub_type,
              b.fst_srvc_dt as clm_dt,
              (case
                when ifnull(a.icd_ver_cd, '0') = '0' or a.icd_ver_cd = '' then 10 else safe_cast(a.icd_ver_cd as int64)
              end) as icd_ver_cd,
              ifnull(a.diag_1_cd , '') as dx1_diag_cd,
              ifnull(a.diag_2_cd, '') as dx2_diag_cd,
              ifnull(a.diag_3_cd , '') as dx3_diag_cd,
              ifnull(a.diag_4_cd, '') as dx4_diag_cd,
              ifnull(a.diag_5_cd, '') as dx5_diag_cd,
              ifnull(c.diag_6_cd, '') as dx6_diag_cd,
              ifnull(c.diag_7_cd, '') as dx7_diag_cd,
              ifnull(c.diag_8_cd, '') as dx8_diag_cd,
              ifnull(c.diag_9_cd, '') as dx9_diag_cd,
              ifnull(c.diag_10_cd, '') as dx10_diag_cd,
              ifnull(c.diag_11_cd, '') as dx11_diag_cd,
              ifnull(c.diag_12_cd, '') as dx12_diag_cd,
              ifnull(b.rvnu_cd, '') as rvnu_cd,
              ifnull(b.proc_cd, '') as proc_cd,
              ifnull(lower(trim(a.proc_1_cd)), '') as prc1_proc_cd,
              ifnull(lower(trim(a.proc_2_cd)), '') as prc2_proc_cd,
              ifnull(lower(trim(a.proc_3_cd)), '') as prc3_proc_cd,
              ifnull(lower(trim(c.proc_4_cd)), '') as prc4_proc_cd,
              ifnull(lower(trim(c.proc_5_cd)), '') as prc5_proc_cd,
              ifnull(lower(trim(c.proc_6_cd)), '') as prc6_proc_cd,
              proc_mod_1_sys_id,
              proc_mod_2_sys_id,
              proc_mod_3_sys_id,
              '' as provtyp, /*NDB's classification of a provider including Organization (O) and Person/Physician (P) */
              '' as prov_prtcp_sts_cd, /*Identifies if the servicing provider has a contract to provide services
              to UnitedHealth Group members at agreed upon rates */
              '' as hp_prov_sts_rllp_desc, /*Rollup used to determine Par vs. Non Par */
              'unk' as hlth_pln_srvc_typ_cd, /*Generated code to identify a service on a claim */
              '' as hce_srvc_typ_desc,
              ifnull(c.bil_typ_cd, '') as bil_typ_cd,
              ifnull(b.sbmt_chrg_amt, 0) as bil_amt,
              ifnull(b.allw_amt, 0) as allw_amt,
              ifnull(b.net_pd_amt, 0) as net_pd_amt,
              ifnull(b.oop_incr_amt, 0) as oop_amt,
              ifnull(b.copay_amt, 0) as copay_amt,
              ifnull(cast(b.ded_amt as numeric), 0) as ded_amt,
              ifnull(cast(b.coins_amt as numeric), 0) as coins_amt,
              ifnull(b.sbmt_chrg_amt-net_pd_amt, 0) as disallow_amt,
              ifnull(cast(b.cob_sv_amt as numeric), 0) as  cob_amt,
              ifnull(cast(b.srvc_unit_cnt as int64), 0) as service_units,
              b.adjd_dt as adjudication_date,

from  `ds-00-191017.galaxy_final.unet_claim_header`                  as a
left join `ds-00-191017.galaxy_final.unet_claim_statistical_service`  as b on  a.unet_clm_head_sys_id= b.unet_clm_head_sys_id
and a.mbr_sys_id = b.mbr_sys_id
left join `ds-00-191017.galaxy_final.unet_inpatient_relator`          as ip on b.unet_clm_srvc_sys_id = ip.unet_clm_srvc_sys_id
and b.mbr_sys_id = ip.mbr_sys_id
left join `ds-00-191017.galaxy_final.unet_facility_ub92`           	  as c on a.unet_clm_head_sys_id = c.unet_clm_head_sys_id
and a.mbr_sys_id = c.mbr_sys_id

where  extract(year from b.fst_srvc_dt) between 2016 and 2020
-- and a.is_restricted=0
  ) ,
med_all
as
  (
select med.savvy_pid,
       med.savvy_did,
       med.is_restricted,
       med.unet_clm_head_sys_id,
       med.src_type,
       med.clm_aud_nbr,
       med.line_number,
       med.data_source,
       med.claim_sub_type,
       med.clm_dt,
       med.icd_ver_cd,
       med.dx1_diag_cd,
       med.dx2_diag_cd,
       med.dx3_diag_cd,
       med.dx4_diag_cd,
       med.dx5_diag_cd,
       med.dx6_diag_cd,
       med.dx7_diag_cd,
       med.dx8_diag_cd,
       med.dx9_diag_cd,
       med.dx10_diag_cd,
       med.dx11_diag_cd,
       med.dx12_diag_cd,
       med.rvnu_cd,
       med.proc_cd,
       med.prc1_proc_cd,
       med.prc2_proc_cd,
       med.prc3_proc_cd,
       med.prc4_proc_cd,
       med.prc5_proc_cd,
       med.prc6_proc_cd,
       ifnull(ic.deriv_drg_cd, case when ic.tot_stay_day > 0 then '00000' else '' end) as drg_cd,
       ifnull(ic.dschrg_sts_cd, case when ic.tot_stay_day  > 0 then '00' else '' end) as dschrg_sts_cd,
       ifnull(g.proc_mod_cd, '') as proc_mod_1_cd,
       ifnull(h.proc_mod_cd, '') as proc_mod_2_cd,
       ifnull(i.proc_mod_cd, '') as proc_mod_3_cd,
       (case
       when med.adj_hccc_cd in (1,2,3) then 'dr' when med.adj_hccc_cd= 6 then 'ip' when med.adj_hccc_cd in (5,7) then 'op' when        med.adj_hccc_cd in (4,8,9,10,11) then null
       end) as srvc_typ_cd,
       ifnull(prov.mpin, 0) as mpin,
       ifnull(prov.tin, '') as txid,
       ifnull(lower(trim(prov.fst_nm)), '') as prov_fst_nm,
       ifnull(lower(trim(prov.lst_nm)), '') as prov_lst_nm,
       ifnull(prov.zip_cd, '') as prov_zip_cd,
       ifnull(lower(trim(prov.st_abbr_cd)), '') as prov_state,
       safe_cast(np.npi_nbr as int64) as  npi,
        0 as pcp_flag,
       '' as provtyp,
        ifnull(trim(lower(q.prov_catgy_desc)), '') as spec_typ_nm,
        '' as hp_prov_cat_typ_nm,
        ifnull(cast(r.ama_pl_of_srvc_cd as string), '00') as ama_pl_of_srvc_cd,
        ifnull(trim(lower(r.ama_pl_of_srvc_desc)), '') as ama_pl_of_srvc_desc,
        '' as prov_prtcp_sts_cd,
        '' as hp_prov_sts_rllp_desc,
        'unk' as hlth_pln_srvc_typ_cd,
        '' as hce_srvc_typ_desc,
         bil_typ_cd,
         bil_amt,
         allw_amt,
         med.net_pd_amt,
          oop_amt,
         med.copay_amt,
         med.ded_amt,
         med.coins_amt,
         med.disallow_amt,
         med.cob_amt,
         case when ic.tot_stay_day > 0 then 1 else 0 end as admit_cnt,
         ifnull(ic.tot_stay_day, 0) as day_cnt,
         service_units,
         adjudication_date,
         ic.fst_srvc_dt as admit_date,
         ic.lst_srvc_dt as discharge_date
from med

left join `ds-00-191017.galaxy_final.unet_inpatient_confinement` ic on ic.iptnt_cnfn_sys_id = med.iptnt_cnfn_sys_id
left join `ds-00-191017.galaxy_final.dim_procedure_modifier_code`  g on g.proc_mod_sys_id = med.proc_mod_1_sys_id
left join `ds-00-191017.galaxy_final.dim_procedure_modifier_code`  h on h.proc_mod_sys_id = med.proc_mod_2_sys_id
left join `ds-00-191017.galaxy_final.dim_procedure_modifier_code`  i on i.proc_mod_sys_id = med.proc_mod_3_sys_id
left join `ds-00-191017.galaxy_final.dim_provider` prov on prov.prov_sys_id = med.srvc_prov_sys_id and prov.prov_row_eff_dt = med.srvc_prov_row_eff_dt
left join (select * except(rn) from(
            select prov_sys_id, npi_nbr, load_dt, updt_dt, row_number()over(partition by prov_sys_id order by updt_dt desc) as rn
              from `ds-00-191017.galaxy_final.dim_npi_relator`
              where mpin <> 0 )
                 where rn = 1) np on np.prov_sys_id=prov.prov_sys_id
left join `ds-00-191017.galaxy_final.dim_provider_category_code`      		q on q.prov_catgy_cd = med.srvc_prov_catgy_cd
left join `ds-00-191017.galaxy_final.dim_place_of_service_code`       		r on r.pl_of_srvc_sys_id = med.pl_of_srvc_sys_id
)
select * from med_all
 ;
/**Code from Seth - add this all queries with appropriate description for 'job' */
insert into `research-01-217611.df_ucd_stage.logging`(
    success_flag, job, message_datetime)
  select
    1 as success_flag
    , 'load galaxy claim statistical table' as job
    , current_datetime as message_datetime
  ;

  EXCEPTION WHEN ERROR THEN
    insert into `research-01-217611.df_ucd_stage.logging`(
      success_flag, job, error_message, statement_text, formatted_stack_trace, message_datetime)
    select
      0 as success_flag
      , 'load galaxy claim statistical table' as job
      , @@error.message as error_message
      , @@error.statement_text as statement_text
      , @@error.formatted_stack_trace as formatted_stack_trace
      , current_datetime as message_datetime
    ;


 end;
