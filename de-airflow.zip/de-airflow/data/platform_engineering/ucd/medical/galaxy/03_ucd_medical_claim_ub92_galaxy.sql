/* Project: Universal Claims Database (UCD )
   Business Partner: Matt Holst
   Input: galaxy_commercial_medical_claim;df_enrichment.minihpdm_dim_zip
   Created By: Sachin
   Created Date:5/18/2020
   Modified by: Sachin
   Modified Date:10/27/2020
   Sourced from ds-00 (Per New Data Management Paradigm)
   Granularity:  Claim/line detail (J 2016 thru most recent)                                 */

BEGIN
  create or replace table `research-01-217611.df_ucd_stage.ucd_medical_claim_ub92_galaxy_ds00` as

    /**Used placeholders (null) for fields that are currently not available in Galaxy claim table **/
  with
      ub as
          (select distinct
              clm.savvy_pid,
              clm.savvy_did,
              clm.is_restricted,
              "galaxy" as src_type,
              ifnull(clm_aud_nbr, '') as clm_aud_nbr,
              ifnull(cast(ub.dtl_ln_nbr as string), '') as line_number,
              'ds-00-191017.galaxy_final.unet_ub92_revenue_code_statistical_service' as data_source,
              '' AS claim_sub_type,
              ub.fst_srvc_dt as clm_dt,
               (case
                when ifnull(icd_ver_cd, '0') = '0' or icd_ver_cd = '' then 10 else safe_cast(icd_ver_cd as int64)
              end) as icd_ver_cd,
              ifnull( diag_1_cd , '') as dx1_diag_cd,
              ifnull(diag_2_cd, '') as dx2_diag_cd,
              ifnull(diag_3_cd, '') as dx3_diag_cd,
              ifnull(diag_4_cd, '') as dx4_diag_cd,
                '' as dx5_diag_cd,
              '' as dx6_diag_cd,
              '' as dx7_diag_cd,
              '' as dx8_diag_cd,
              '' as dx9_diag_cd,
              '' as dx10_diag_cd,
              '' as dx11_diag_cd,
              '' as dx12_diag_cd,
              ifnull(clm.bil_rvnu_cd, '') as rvnu_cd,
              ifnull(clm.bil_proc_cd, '') as proc_cd,
              '' as prc1_proc_cd,
              '' as prc2_proc_cd,
              '' as prc3_proc_cd,
              '' as prc4_proc_cd,
              '' as prc5_proc_cd,
              '' as prc6_proc_cd,
              '' as drg_cd,
              '' as dschrg_sts_cd,
              '' as proc_mod_1_cd,
              '' as proc_mod_2_cd,
              '' as proc_mod_3_cd,
               0 as mpin,
              '' as txid,
              '' as prov_fst_nm,
              '' as prov_lst_nm,
              '' as prov_zip_cd,
              '' as prov_state,
              0 as npi,
              0 as pcp_flag,
              '' as provtyp,
              ''  as spec_typ_nm,
              '' as hp_prov_cat_typ_nm,
              '00' as ama_pl_of_srvc_cd,
              '' as ama_pl_of_srvc_desc,
              '' as prov_prtcp_sts_cd,
              '' as hp_prov_sts_rllp_desc,
              'unk' as hlth_pln_srvc_typ_cd,
              '' as hce_srvc_typ_desc,
              '' as bil_typ_cd,
              0 as bil_amt,
              0 as allw_amt,
              0 as net_pd_amt,
              0 as oop_amt,
              0 as copay_amt,
              0 as ded_amt,
              0 as coins_amt,
              0 as disallow_amt,
              0 as cob_amt,
              0 as admit_cnt,
              0 as day_cnt,
              0 as  service_units,
              adjd_dt as adjudication_date,
              cast(null as date) as admit_date,
              cast(null as date) as discharge_date
from
`ds-00-191017.galaxy_final.unet_ub92_revenue_code_statistical_service`     clm
inner join `research-01-217611.df_ucd_stage.ucd_ub92_xtra_proc_galaxy_ds00` ub  on clm.savvy_pid =ub.savvy_pid
                                                                        and clm.unet_clm_head_sys_id=ub.unet_clm_head_sys_id
                                                                        and clm.dtl_ln_nbr= ub.dtl_ln_nbr
                                                                        and clm.fst_srvc_dt                     =   ub.fst_srvc_dt
                                                                        and extract(year from clm.fst_srvc_dt)  >=  2016
                                                                        -- and clm.is_restricted=0

          ),

/*Assign service type from galaxy_medical_claim to above UB92 table based on claim number **/
ub_srvtyp as
(select distinct ub.*, gal.srvc_typ_cd
from ub inner join  `research-01-217611.df_ucd_stage.ucd_medical_claims_galaxy_ds00`  gal on ub.savvy_pid=gal.savvy_pid
                                                                                        and ub.clm_aud_nbr=gal.clm_aud_nbr
),
med as
(select
             savvy_pid,
             savvy_did,
             is_restricted,
             src_type,
             clm_aud_nbr,
             line_number,
             data_source,
             claim_sub_type,
             clm_dt,
             icd_ver_cd,
             dx1_diag_cd,
             dx2_diag_cd,
             dx3_diag_cd,
             dx4_diag_cd,
             dx5_diag_cd,
             dx6_diag_cd,
             dx7_diag_cd,
             dx8_diag_cd,
             dx9_diag_cd,
             dx10_diag_cd,
             dx11_diag_cd,
             dx12_diag_cd,
             rvnu_cd,
             proc_cd,
           --   ifnull(proc_typ_cd, '') as proc_typ_cd,
           --   ifnull(facl_proc_cd, '') as facl_proc_cd,
             prc1_proc_cd,
             prc2_proc_cd,
             prc3_proc_cd,
             prc4_proc_cd,
             prc5_proc_cd,
             prc6_proc_cd,
             drg_cd,
             dschrg_sts_cd,
             proc_mod_1_cd,
             proc_mod_2_cd,
             proc_mod_3_cd,
             mpin,
             txid,
             prov_fst_nm,
             prov_lst_nm,
             prov_zip_cd,
             prov_state,
             npi,
             pcp_flag,
             provtyp,
             spec_typ_nm,
             hp_prov_cat_typ_nm,
             ama_pl_of_srvc_cd,
             ama_pl_of_srvc_desc,
             prov_prtcp_sts_cd,
             hp_prov_sts_rllp_desc,
             hlth_pln_srvc_typ_cd,
             hce_srvc_typ_desc,
             bil_typ_cd,
             bil_amt,
             allw_amt,
             net_pd_amt,
             oop_amt,
             copay_amt,
             ded_amt,
             coins_amt,
             disallow_amt,
             cob_amt,
             admit_cnt,
             day_cnt,
             service_units,
             adjudication_date,
              admit_date,
              discharge_date,
              srvc_typ_cd
          from
              `research-01-217611.df_ucd_stage.ucd_medical_claims_galaxy_ds00`          clm

          )

  select
      GENERATE_UUID() uuid,
      com.*
  from
      (select *, 0 as ub92_source_ind from med
      union distinct
      select *, 1 as ub92_source_ind from ub_srvtyp
      ) com
  ;
/**Code from Seth - add this all queries with appropriate description for 'job' */
insert into `research-01-217611.df_ucd_stage.logging`(
    success_flag, job, message_datetime)
  select
    1 as success_flag
    , 'load galaxy claim statistical table + ub92' as job
    , current_datetime as message_datetime
  ;

  EXCEPTION WHEN ERROR THEN
    insert into `research-01-217611.df_ucd_stage.logging`(
      success_flag, job, error_message, statement_text, formatted_stack_trace, message_datetime)
    select
      0 as success_flag
      , 'load galaxy claim statistical table + ub92' as job
      , @@error.message as error_message
      , @@error.statement_text as statement_text
      , @@error.formatted_stack_trace as formatted_stack_trace
      , current_datetime as message_datetime
    ;


END
;
