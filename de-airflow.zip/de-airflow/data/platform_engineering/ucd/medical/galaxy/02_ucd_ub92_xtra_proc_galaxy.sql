/* Project: Universal Claims Database (UCD )
   Business Partner: Matt Holst
   Input: galaxy_commercial_medical_claim;df_uhgrd.galaxy_commercial_ub92_revenue
   Created By: Sachin
   Created Date:6/18/2020
   Modifed By:Sachin
   Modification: Sourced from ds-00 (Per New Data Management Paradigm)
   Granularity:  Claim/line detail (Jan 2016 thru most recent)
   Description: This query identifies extra proc/rvn codes present in ub92 claim table compared to statistical medical claim table.
     */
BEGIN
create or replace table `research-01-217611.df_ucd_stage.ucd_ub92_xtra_proc_galaxy_ds00` as
with ubc
as
(
select distinct savvy_pid,savvy_did,is_restricted,unet_clm_head_sys_id,dtl_ln_nbr,bil_proc_cd,bil_rvnu_cd,fst_srvc_dt
from  `ds-00-191017.galaxy_final.unet_ub92_revenue_code_statistical_service` clm
where extract(year from fst_srvc_dt)>=2016
-- and is_restricted=0


),
clms as
(
select distinct savvy_pid,savvy_did,is_restricted,unet_clm_head_sys_id,line_number,proc_cd,rvnu_cd,clm_dt
from  `research-01-217611.df_ucd_stage.ucd_medical_claims_galaxy_ds00` clm
/**table has been already filtered to service dates >=2016 and is_restricted=0**/

)

select  * from  ubc except distinct select * from clms
;
/**Code from Seth - add this all queries with appropriate description for 'job' */
insert into `research-01-217611.df_ucd_stage.logging`(
    success_flag, job, message_datetime)
  select
    1 as success_flag
    , 'load xtra prov/rvn codes from ub92 galaxy statistical service table' as job
    , current_datetime as message_datetime
  ;

  EXCEPTION WHEN ERROR THEN
    insert into `research-01-217611.df_ucd_stage.logging`(
      success_flag, job, error_message, statement_text, formatted_stack_trace, message_datetime)
    select
      0 as success_flag
      , 'load xtra prov/rvn codes from ub92 galaxy statistical service table' as job
      , @@error.message as error_message
      , @@error.statement_text as statement_text
      , @@error.formatted_stack_trace as formatted_stack_trace
      , current_datetime as message_datetime
    ;

END;
