/***
Universal Claims Data - Dimension tables

Date Created: 14 October 2020
***/

BEGIN
  ----------------------
  --bill type code
  ----------------------
  create or replace table `research-01-217611.df_ucd_stage.dim_bill_type_code`
  ( bil_typ_cd        string    OPTIONS(description = "Created by HCFA and provides three specific pieces of information. The first character identifies the type of facility. The second classifies the type of care. The third indicates the sequence of this bill in this particular episode of care. UNET, MAMSIand Cosmos, straight move of BIL_TYP_CD from UNET, COSMOS or MAMSI FACILITY_UB92 table. Ovations East straight move of from Galaxy COSMOS Paid/Pended Facility UB92 table. Ovations West straight move of BILLTYPE from tbDetail_SIP.csv file. TADM Derivation of BILLTYPE: Source PRDS FACT_MEDICAL_CLAIM_PROFILE table, Concatenate FACILITY_TYPE_CD + BILL_CLASSIFICATION_CD + FREQUENCY_CD")
    , bil_typ_grp     string    OPTIONS(description = "Describes the type of facility/group billed.")
    , bil_typ_desc    string    OPTIONS(description = "Describes the bill type code billed in the claim.")
    , create_datetime datetime  OPTIONS(description = "datetime record was created")
    )
  OPTIONS (description = "This is the dimension table for bill type codes. It has a one row per bill type code granularity.") as
  select *
    , (case when ends_with(bil_typ_cd, '0') is true then concat(bil_typ_grp, ': ', 'non-payment/zero claim')
            when ends_with(bil_typ_cd, '1') is true then concat(bil_typ_grp, ': ', 'admit through discharge')
            when ends_with(bil_typ_cd, '2') is true then concat(bil_typ_grp, ': ', 'interim, first claim')
            when ends_with(bil_typ_cd, '3') is true then concat(bil_typ_grp, ': ', 'interim, continuing claim')
            when ends_with(bil_typ_cd, '4') is true then concat(bil_typ_grp, ': ', 'interim, last claim')
            when ends_with(bil_typ_cd, '5') is true then concat(bil_typ_grp, ': ', 'late charge(s) only claim')
            when ends_with(bil_typ_cd, '7') is true then concat(bil_typ_grp, ': ', 'replacement of prior claim')
            when ends_with(bil_typ_cd, '8') is true then concat(bil_typ_grp, ': ', 'void/cancel of prior claim')
            when ends_with(bil_typ_cd, '9') is true then concat(bil_typ_grp, ': ', 'reserved for national assignment')
            when bil_typ_cd in ('116', '136', '146') then concat(bil_typ_grp, ': ', 'adjustment of prior claim')
        else 'unknown' end) as bil_typ_desc
    , current_datetime as create_datetime
  from (
         select bil_typ_cd
           , (case when bil_typ_cd in ('111', '112', '113', '114', '115', '116', '117', '118') then 'inpatient hospital'
                   when bil_typ_cd in ('121', '122', '123', '124', '125', '127', '128')        then 'hospital inpatient (medicare part b only)'
                   when bil_typ_cd in ('131', '132', '133', '134', '135', '136', '137', '138') then 'outpatient hospital'
                   when bil_typ_cd in ('141', '142', '143', '144', '145', '146', '147', '148') then 'outpatient diagnostic (non treatment plan)'
                   when bil_typ_cd in ('181', '182', '183', '184', '185', '187', '188') then 'hospital swing beds'
                   when bil_typ_cd in ('211', '212', '213', '214', '215', '217', '218') then 'skilled nursing'
                   when bil_typ_cd in ('221', '222', '223', '224', '225', '227', '228') then 'skilled nursing (medicare part b only)'
                   when bil_typ_cd in ('231', '232', '233', '234', '235', '237', '238') then 'skilled nursing outpatient'
                   when bil_typ_cd in ('321', '322', '323', '324', '325', '327', '328') then 'home health inpatient (not under a plan of treatment)'
                   when bil_typ_cd in ('341', '342', '343', '344', '345', '347', '348') then 'home health services (not under a plan of treatment)'
                   when bil_typ_cd in ('411', '412', '413', '414', '415', '417', '418') then 'religious non-medical health care institutions - hospital inpatient'
                   when bil_typ_cd like '43%' then 'religious non-medical health care institutions - outpatient services'
                   when bil_typ_cd like '65%' then 'intermediate care - level 1'
                   when bil_typ_cd like '66%' then 'intermediate care - level 2'
                   when bil_typ_cd in ('711', '712', '713', '714', '715', '717') then 'clinic rural health'
                   when bil_typ_cd in ('721', '722', '723', '724', '725', '727', '728') then 'hospital based or independent renal dialysis'
                   when bil_typ_cd like '73%' then 'freestanding clinic'
                   when bil_typ_cd in ('741', '742', '743', '744', '745', '747', '748') then 'clinic outpatient rehabilitation facility (orf)'
                   when bil_typ_cd in ('751', '752', '753', '754', '755', '757', '758') then 'clinic - comprehensive outpatient rehabilitation facility (corf)'
                   when bil_typ_cd like '76%' then 'clinic - community mental health center'
                   when bil_typ_cd like '77%' then 'clinic - federally qualified health center'
                   when bil_typ_cd like '78%' then 'licensed freestanding emergency medical facility'
                   when bil_typ_cd like '79%' then 'clinic - other'
                   when bil_typ_cd in ('811', '812', '813', '814', '815', '817', '818') then 'specialty facility hospice (non-hospital based)'
                   when bil_typ_cd in ('821', '822', '823', '824', '825', '827', '828') then 'specialty facility hospice (hospital based)'
                   when bil_typ_cd in ('831', '832', '833', '834', '835', '837', '838') then 'specialty facility ambulatory surgery'
                   when bil_typ_cd like '84%' then 'specialty facility - freestanding birthing center'
                   when bil_typ_cd in ('851', '852', '853', '854', '855', '857', '858') then 'specialty facility - critical access hospital'
                   when bil_typ_cd like '86%' then 'specialty facility - residential facility'
                   when bil_typ_cd like '89%' then 'specialty facility - other'
               else 'unknown' end) as bil_typ_grp
         from `ds-00-191017.ugap_final.dim_hpdm_bill_type_code`
      ) z
  ;
  ----------------------
  --diagnosis
  ----------------------
  create or replace table `research-01-217611.df_ucd_stage.dim_diagnosis_code`
  ( mdc_cd                    string   OPTIONS(description = "Identifies the grouping of diagnoses by organ system, etiology, or medical specialty. Major Diagnostic Category (MDC) Codes are more specific than Major Diagnosis Groups (MDG) and less specific than AHRQ Diagnosis Detail Categories.")
    , maj_diag_grp_nbr        string   OPTIONS(description = "A number identifying a high-level grouping of diagnoses by organ system or general condition. This is the same grouping as the Major Diagnosis Group (MDG) code however, this numeric value is created to facilitate reporting by ranges of MDGs.")
    , maj_diag_grp_cd         string   OPTIONS(description = "Identifies a high-level grouping of diagnoses by organ system or general condition. Major Diagnosis Group (MDG) codes are more specific than AHRQ Diagnosis General Categories and less specific than Major Diagnostic Category (MDC) codes.")
    , maj_diag_grp_desc       string   OPTIONS(description = "Describes a high-level grouping of diagnoses by organ system or general condition. Major Diagnosis Group (MDG) codes are more specific than AHRQ Diagnosis General Categories and less specific than Major Diagnostic Category (MDC) codes.")
    , genl_caus_txt           string   OPTIONS(description = "Describes highest level diagnosis grouping on Galaxy. Diagnoses are grouped based on external event (accident); need for urgent care (emergency illness); presence of maternity complication (normal maternity vs. complications of pregnancy); lack of presenting symptoms (routine care); mental illness diagnosis (psychiatric); substance-related mental illness diagnosis (alcoholism and drug addiction); or any other diagnosis (general sickness).")
    , gdr_spec_desc           string   OPTIONS(description = "Describes if the diagnosis is used for a specific gender.")
    , gdr_spec_cd             string   OPTIONS(description = "Identifies if the diagnosis is used for a specific gender.")
    , diag_cd                 string   OPTIONS(description = "ICD-9 (International Classification of Disease, 9th Revision, Clinical Modification) without a decimal point. ICD-9-CM is designed for the classification of morbidity and mortality information for statistical purposes and for the indexing of hospital records by disease and operations, for data storage retrieval. ICD-9-CM is an accepted national standard for coding diagnostic and disease information.")
    , diag_fst4_desc          string   OPTIONS(description = "Describes the first four characters of the International Classification of Disease, 9th Revision, Clinical Modification (ICD-9-CM) code. This used for grouping ICD-9-CM code together. ICD-9-CM is designed for the classification of morbidity and mortality information for statistical purposes and for the indexing of hospital records by disease and operations, for data storage retrieval. ICD-9-CM is an accepted national standard for coding diagnostic and disease information.")
    , diag_fst4_cd            string   OPTIONS(description = "The first four characters of the International Classification of Disease, 9th Revision, Clinical Modification (ICD-9-CM) code. This used for grouping ICD-9-CM code together. ICD-9-CM is designed for the classification of morbidity and mortality information for statistical purposes and for the indexing of hospital records by disease and operations, for data storage retrieval. ICD-9-CM is an accepted national standard for coding diagnostic and disease information.")
    , diag_fst3_desc          string   OPTIONS(description = "Describes the first three characters of the International Classification of Disease, 9th Revision, Clinical Modification (ICD-9-CM) code. This used for grouping ICD-9-CM code together. ICD-9-CM is designed for the classification of morbidity and mortality information for statistical purposes and for the indexing of hospital records by disease and operations, for data storage retrieval. ICD-9-CM is an accepted national standard for coding diagnostic and disease information.")
    , diag_fst3_cd            string   OPTIONS(description = "The first three characters of the International Classification of Disease, 9th Revision, Clinical Modification (ICD-9-CM) code. This used for grouping ICD-9-CM code together. ICD-9-CM is designed for the classification of morbidity and mortality information for statistical purposes and for the indexing of hospital records by disease and operations, for data storage retrieval. ICD-9-CM is an accepted national standard for coding diagnostic and disease information.")
    , diag_desc               string   OPTIONS(description = "Describes the International Classification of Disease, 9th Revision, Clinical Modification (ICD-9-CM) code. ICD-9-CM is designed for the classification of morbidity and mortality information for statistical purposes and for the indexing of hospital records by disease and operations, for data storage retrieval. ICD-9-CM is an accepted national standard for coding diagnostic and disease information.")
    , diag_decm_cd            string   OPTIONS(description = "ICD-9 (International Classification of Disease, 9th Revision, Clinical Modification) with a decimal point. ICD-9-CM is designed for the classification of morbidity and mortality information for statistical purposes and for the indexing of hospital records by disease and operations, for data storage retrieval. ICD-9-CM is an accepted national standard for coding diagnostic and disease information.")
    , chrnc_flg_nm            string   OPTIONS(description = "Classification of diagnosis codes. Acute Diagnoses are non re-occurring. Chronic diagnoses are those that are diagnosed on a re-occurring basis.")
    , hlth_pln_diag_cd        string   OPTIONS(description = "ICD-9 (International Classification of Disease, 9th Revision, Clinical Modification) without a decimal point. ICD-9-CM is designed for the classification of morbidity and mortality information for statistical purposes and for the indexing of hospital records by disease and operations, for data storage retrieval. ICD-9-CM is an accepted national standard for coding diagnostic and disease information.")
    , hlth_pln_diag_desc      string   OPTIONS(description = "Describes the International Classification of Disease, 9th Revision, Clinical Modification (ICD-9-CM) code. ICD-9-CM is designed for the classification of morbidity and mortality information for statistical purposes and for the indexing of hospital records by disease and operations, for data storage retrieval. ICD-9-CM is an accepted national standard for coding diagnostic and disease information.")
    , ahrq_diag_genl_catgy_cd int64    OPTIONS(description = "Identifies the AHRQ (Agency for Healthcare Research and Quality) high-level grouping of diagnosis codes which is primarily by organ system. These are less specific than Major Diagnosis Group Codes (MDCs). Straight move of Galaxy field in Diagnosis Code Table.")
    , ahrq_diag_genl_catgy_nm string   OPTIONS(description = "Names the AHRQ (Agency for Healthcare Research and Quality) high-level grouping of diagnosis codes which is primarily by organ system. These are less specific than MDCs or Major Diagnosis Group Codes.")
    , ahrq_diag_dtl_catgy_cd  int64    OPTIONS(description = "The AHRQ (Agency for Healthcare Research and Quality) detailed grouping of diagnosis codes that describe a disease (e.g. tuberculosis, hepatitis, glaucoma); a disorder (e.g. heart valve disorders, retinal disorders); a condition (e.g. inflammatorycondition of the skin, fracture of the upper limb); or a medical process (e.g. immunization / screening, medical examination / evaluation).")
    , ahrq_diag_dtl_catgy_nm  string   OPTIONS(description = "Names the AHRQ (Agency for Healthcare Research and Quality) detailed grouping of diagnosis codes that describe a disease (e.g. tuberculosis, hepatitis, glaucoma); a disorder (e.g. heart valve disorders, retinal disorders); a condition (e.g. inflammatorycondition of the skin, fracture of the upper limb); or a medical process (e.g. immunization / screening, medical examination / evaluation).")
    , diag_full_desc          string   OPTIONS(description = "The full detailed industry standard description of the diagnosis indicated by the associated code.")
    , diag_lng_desc           string   OPTIONS(description = "The longer industry standard description of the diagnosis indicated by the associated code.")
    , icd_ver_cd              int64    OPTIONS(description = "indicates if the Diagnosis Code is an ICD9 - value of '9' or for ICD10 code a value of '10'.")
    , sens_cond_ind           string   OPTIONS(description = "This indicator identifies whether a diagnosis code is considered sensitive such as mental health, abuse, etc.")
    , sens_cond_catgy         string   OPTIONS(description = "This category identifies the sensitive condition category (mental health, abuse, etc) if the sensitive condition indicator equals Y.")
    , create_datetime         datetime OPTIONS(description = "datetime record was created")
    )
  OPTIONS (description = "This is the dimension table for diagnosis codes. It has a one row per diagnosis code per icd version code granularity. The Diagnosis Dimension table contains the ICD-9-CM (International Classification of Diseases, Ninth Edition, and Clinical Modification) and ICD-10 Diagnosis Code. This code describes the presenting condition being treated.  We have added a Chronic Flag for use in Health Plan Reporting.") as
  with cte_gnl as (
      select *
        , row_number() over(partition by ahrq_diag_genl_catgy_cd order by src = 'ugap' desc, icd_ver_cd desc) as oid
      from (
            select distinct cast(ahrq_diag_genl_catgy_cd as int64) as ahrq_diag_genl_catgy_cd, lower(trim(ahrq_diag_genl_catgy_nm)) as ahrq_diag_genl_catgy_nm
              , safe_cast((case when icd_ver_cd = '0' then '10' else icd_ver_cd end) as int64) as icd_ver_cd
              , 'ugap' as src
            from `ds-00-191017.ugap_final.dim_hpdm_diagnosis_code`

            union distinct
            select distinct cast(ahrq_diag_genl_catgy_cd as int64) as ahrq_diag_genl_catgy_cd, lower(trim(ahrq_diag_genl_catgy_desc)) as ahrq_diag_genl_catgy_desc
              , safe_cast((case when icd_ver_cd = '0' then '10' else icd_ver_cd end) as int64) as icd_ver_cd
              , 'galaxy' as src
            from `ds-00-191017.galaxy_final.dim_diagnosis_code`
          ) x
    )
  , cte_dtl as (
      select *
        , row_number() over(partition by ahrq_diag_dtl_catgy_cd order by src = 'ugap' desc, icd_ver_cd desc) as oid
      from (
            select distinct cast(ahrq_diag_dtl_catgy_cd as int64) as ahrq_diag_dtl_catgy_cd, lower(trim(ahrq_diag_dtl_catgy_nm)) as ahrq_diag_dtl_catgy_nm
              , safe_cast((case when icd_ver_cd = '0' then '10' else icd_ver_cd end) as int64) as icd_ver_cd
              , 'ugap' as src
            from `ds-00-191017.ugap_final.dim_hpdm_diagnosis_code`

            union distinct
            select distinct cast(ahrq_diag_dtl_catgy_cd as int64) as ahrq_diag_dtl_catgy_cd, lower(trim(ahrq_diag_dtl_catgy_desc)) as ahrq_diag_dtl_catgy_desc, safe_cast((case when icd_ver_cd = '0' then '10' else icd_ver_cd end) as int64) as icd_ver_cd
              , 'galaxy' as src
            from `ds-00-191017.galaxy_final.dim_diagnosis_code`
          ) x
    )
    select * except (oid)
      , current_datetime as create_datetime
    from (--346,480
            select distinct mdc_cd, maj_diag_grp_nbr
              , maj_diag_grp_cd, maj_diag_grp_desc, genl_caus_txt, gdr_spec_desc, gdr_spec_cd, diag_cd, diag_fst4_desc, diag_fst4_cd, diag_fst3_desc, diag_fst3_cd, diag_desc, diag_decm_cd
              , chrnc_flg_nm, hlth_pln_diag_cd, hlth_pln_diag_desc, b.ahrq_diag_genl_catgy_cd, b.ahrq_diag_genl_catgy_nm, c.ahrq_diag_dtl_catgy_cd, c.ahrq_diag_dtl_catgy_nm, diag_full_desc, diag_lng_desc
              , a.icd_ver_cd
              , sens_cond_ind, sens_cond_catgy
              , row_number() over(partition by a.diag_cd, a.icd_ver_cd
                                  order by
                                        a.diag_desc not like 'unknown%' desc --first use not unknown descriptions
                                        , a.src = 'ugap' desc                             --then default to ugap
                                        , a.diag_desc, a.mdc_cd, a.diag_full_desc             --some stuff to make our ordering consistent from run to run if there's more than one tie above
                                      ) as oid
              from  (
                    select distinct lower(trim(mdc_cd)) as mdc_cd, lower(trim(maj_diag_grp_nbr)) as maj_diag_grp_nbr
                      , (case when lower(trim(maj_diag_grp_cd)) = 'un' and trim(maj_diag_grp_nbr) = '20' then '20' else lower(trim(maj_diag_grp_cd)) end) as maj_diag_grp_cd
                      , lower(trim(maj_diag_grp_desc)) as maj_diag_grp_desc, lower(trim(genl_caus_txt)) as genl_caus_txt, lower(trim(gdr_spec_desc)) as gdr_spec_desc, lower(trim(gdr_spec_cd)) as gdr_spec_cd
                      , lower(trim(diag_cd)) as diag_cd, lower(trim(diag_fst4_desc)) as diag_fst4_desc, lower(trim(diag_fst4_cd)) as diag_fst4_cd, lower(trim(diag_fst3_desc)) as diag_fst3_desc
                      , lower(trim(diag_fst3_cd)) as diag_fst3_cd, lower(trim(diag_desc)) as diag_desc, lower(trim(diag_decm_cd)) as diag_decm_cd
                      , lower(trim(chrnc_flg_nm)) as chrnc_flg_nm, lower(trim(hlth_pln_diag_cd)) as hlth_pln_diag_cd, lower(trim(hlth_pln_diag_desc)) as hlth_pln_diag_desc
                      , lower(trim(diag_full_desc)) as diag_full_desc, lower(trim(diag_lng_desc)) as diag_lng_desc
                      , safe_cast((case when icd_ver_cd = '0' then '10' else icd_ver_cd end) as int64) as icd_ver_cd
                      , lower(trim(sens_cond_ind)) as sens_cond_ind, lower(trim(sens_cond_catgy)) as sens_cond_catgy
                      , cast(ahrq_diag_genl_catgy_cd as int64) as ahrq_diag_genl_catgy_cd, cast(ahrq_diag_dtl_catgy_cd as int64) as ahrq_diag_dtl_catgy_cd
                      , 'ugap' as src
                    from `ds-00-191017.ugap_final.dim_hpdm_diagnosis_code`
                    union distinct
                    select distinct lpad(cast(mdc_cd as string), 2, '0') as mdc_cd, lpad(cast(maj_diag_grp_nbr as string), 2, '0') as maj_diag_grp_nbr
                      , lower(trim(maj_diag_grp_cd)) as maj_diag_grp_cd, lower(trim(maj_diag_grp_desc)) as maj_diag_grp_desc, lower(trim(genl_caus_txt)) as genl_caus_txt, lower(trim(gdr_spec_desc)) as gdr_spec_desc
                      , lower(trim(gdr_spec_cd)) as gdr_spec_cd, lower(trim(diag_cd)) as diag_cd, lower(trim(diag_fst4_desc)) as diag_fst4_desc, lower(trim(diag_fst4_cd)) as diag_fst4_cd
                      , lower(trim(diag_fst3_desc)) as diag_fst3_desc, lower(trim(diag_fst3_cd)) as diag_fst3_cd, lower(trim(diag_desc)) as diag_desc, lower(trim(diag_decm_cd)) as diag_decm_cd
                      , '' as chrnc_flg_nm, '' as hlth_pln_diag_cd, '' as hlth_pln_diag_desc, lower(trim(diag_full_desc)) as diag_full_desc, lower(trim(diag_lng_desc)) as diag_lng_desc
                      , safe_cast((case when icd_ver_cd = '0' then '10' else icd_ver_cd end) as int64) as icd_ver_cd
                      , '' as sens_cond_ind, '' as sens_cond_catgy
                      , cast(ahrq_diag_genl_catgy_cd as int64) as ahrq_diag_genl_catgy_cd, cast(ahrq_diag_dtl_catgy_cd as int64) as ahrq_diag_dtl_catgy_cd
                      , 'galaxy' as src
                    from `ds-00-191017.galaxy_final.dim_diagnosis_code`
                  ) a
            left join cte_gnl b on a.ahrq_diag_genl_catgy_cd = b.ahrq_diag_genl_catgy_cd and b.oid = 1
            left join cte_dtl c on a.ahrq_diag_dtl_catgy_cd = c.ahrq_diag_dtl_catgy_cd and c.oid = 1
         ) z
    where oid = 1
      and icd_ver_cd is not null
  ;
  ----------------------
  --discharge status code
  ----------------------
  create or replace table `research-01-217611.df_ucd_stage.dim_discharge_status_code`
  ( dschrg_sts_cd           string    OPTIONS(description = "Identifies the status of the member's inpatient stay as of the last service date on the claim.")
    , dschrg_sts_cd_desc    string    OPTIONS(description = "Describes the status of the member's inpatient stay as of the last service date on the claim.")
    , dschrg_sts_catgy_txt  string    OPTIONS(description = "Identifies the high level status of the member's inpatient stay as of the last service date on the claim. This is a grouping of Discharge Status Codes.")
    , create_datetime       datetime  OPTIONS(description = "datetime record was created")
    )
  OPTIONS (description = "This is the dimension table for discharge status codes. It has a one row per discharge status code granularity. Discharge Status Code indicates the status of the patient as of the ending service date of the period covered on this bill. Examples of Discharge Status include Discharged to Home, Left Against Medical Advice, Expired, Still Patient.") as
  select * except(oid, src)
    , current_datetime as create_datetime
  from (
          select *
            , row_number() over(partition by dschrg_sts_cd order by src = 'ugap' desc) as oid
          from  (
                  select distinct lower(trim(dschrg_sts_cd)) as dschrg_sts_cd, lower(trim(dscrg_sts_cd_desc)) as dschrg_sts_cd_desc, lower(trim(dschrg_sts_catgy_txt)) as dschrg_sts_catgy_txt
                    , 'ugap' as src
                  from `ds-00-191017.ugap_final.dim_hpdm_discharge_status_code`

                  union distinct
                  select distinct lower(trim(dschrg_sts_cd)) as dschrg_sts_cd, lower(trim(dschrg_sts_desc)) as dschrg_sts_cd_desc, lower(trim(dschrg_sts_catgy_txt)) as dschrg_sts_catgy_txt
                    , 'galaxy' as src
                  from `ds-00-191017.galaxy_final.dim_discharge_status_code`
                ) x
           --order by dschrg_sts_cd
        )
  where oid = 1
  ;
  ----------------------
  --drg
  ----------------------
  create or replace table `research-01-217611.df_ucd_stage.dim_drg_code`
  ( mdc_cd            string    OPTIONS(description = "Identifies the grouping of diagnoses by organ system, etiology, or medical specialty. Major Diagnostic Category (MDC) Codes are more specific than Major Diagnosis Groups (MDG) and less specific than AHRQ Diagnosis Detail Categories.")
    , mdc_desc        string    OPTIONS(description = "Identifies the grouping of diagnoses by organ system, etiology, or medical specialty. Major Diagnostic Category (MDC) Codes are more specific than Major Diagnosis Groups (MDG) and less specific than AHRQ Diagnosis Detail Categories.")
    , drg_cd          string    OPTIONS(description = 'A classification of inpatient hospital services based on principal diagnosis, secondary diagnosis, surgical procedures, age, gender and presence of complications. Diagnosis Related Groups (DRG) are used to reimburse hospitals and other selected providers for services rendered.')
    , drg_desc        string    OPTIONS(description = "The description for a classification of inpatient hospital services based on principal diagnosis. This field is a concatenation of the DRG Code and DRG Description.")
    , drg_wgt_fct     float64   OPTIONS(description = "The assigned weight that is intended to reflect the relative resource utilization/cost associated with each Diagnosis Related Grouping (DRG). The higher the relative weight, the greater the intensity of care provided. If a service is reimbursed based onDRG, the higher the relative weight, the greater is the payment to the hospital.")
    , drg_rate        float64   OPTIONS(description = "The DRG Rate is the base payment rate sourced from the Centers for Medicare and Medicaid (CMS). The base payment rate is divided into a labor-related and nonlabor share. The labor-related share is adjusted by the wage index applicable to the area where the hospital is located, and if the hospital is located in Alaska or Hawaii, the nonlabor share is adjusted by a cost of living adjustment factor. This base payment rate is multiplied by the DRG relative weight. For more information, refer to the CMS website: http://www.cms.hhs.gov/AcuteInpatientPPS/.")
    , create_datetime datetime  OPTIONS(description = "datetime record was created")
    )
  OPTIONS (description = "This is the dimension table for diagnosis related group codes. It has a one row per drg code granularity. A system of classifying any inpatient stay into groups for purposes of payments. This is the form of reimbursement that HCFA uses to pay hospitals for Medicare recipients. These codes are also used by a few states for all payers and by some private health plans for contracting purposes. Effective 10/1/2007, the Centers for Medicare and Medicaid Services (CMS) introduced the MS-DRG code set and retired the CMS-DRG set. The new code set refined the DRGs based on the presence of complications or co-morbidities. One effect of this change is that the MS-DRG descriptions are completely different from previous descriptions. Galaxy customers should take this change into consideration when using DRG data. In addition, the initial change increased the number of codes by approximately 30 percent. Galaxy's DRG code table contains historical CMS-DRGs as well as MS-DRG codes.") as
  select * except(oid, src)
    , current_datetime as create_datetime
  from  (
          select *
            , row_number() over(partition by drg_cd order by drg_desc not like 'unkn%' desc, src = 'ugap' desc, drg_wgt_fct desc) as oid
          from  (
                  select distinct lower(trim(mdc_cd)) as mdc_cd, lower(trim(mdc_desc)) as mdc_desc, drg_cd, lower(trim(drg_desc)) as drg_desc, drg_wgt_fct, drg_rate
                    , 'ugap' as src
                  from `ds-00-191017.ugap_final.dim_hpdm_drg_code`

                  union distinct
                  select distinct lpad(cast(mdc_cd as string), 2, '0') as mdc_cd, '' as mdc_desc, lpad(cast(drg_cd as string), 5, '0') as drg_cd, lower(trim(drg_desc)) as drg_desc, drg_wgt_fct, drg_rate
                    , 'galaxy' as src
                  from `ds-00-191017.galaxy_final.dim_drg_code`
                ) x
        )
  where oid = 1
  ;
  ----------------------
  --hce
  ----------------------
  create or replace table `research-01-217611.df_ucd_stage.dim_hce_service_type_code`
  ( hlth_pln_srvc_typ_cd          string    OPTIONS(description = "Generated code to identify a service on a claim.")
    , srvc_prr_nbr                float64   OPTIONS(description = "datetime record was created")
    , hce_srvc_typ_desc           string    OPTIONS(description = "Service Type groupings for use by HCE reporting.")
    , hlth_pln_srvc_typ_lvl_5_nm  string    OPTIONS(description = "The quintenary classification level of service(s) rendered.")
    , hlth_pln_srvc_typ_lvl_4_nm  string    OPTIONS(description = "The quartenary classification level of service(s) rendered.")
    , hlth_pln_srvc_typ_lvl_3_nm  string    OPTIONS(description = "The tertiary classification level of services(s) rendered.")
    , hlth_pln_srvc_typ_lvl_2_nm  string    OPTIONS(description = "The secondary classification level of service(s) rendered.")
    , hlth_pln_srvc_typ_lvl_1_nm  string    OPTIONS(description = "The primary classification level of service(s) rendered")
    , create_datetime             datetime  OPTIONS(description = "datetime record was created")
    )
  OPTIONS (description = "This is the dimension table for HCE (Healthcare Economics) service type codes. It has a one row per hce code granularity. The HP Service Type Code Dimension table provides 5 levels of Service Type groupings. Each claim is assigned a group of Service types as defined by National Committee for use by the Cost and Utilization Cubes.  A field is also included which contains the description used by IA&C in their reporting.") as
  select lower(trim(hlth_pln_srvc_typ_cd)) as hlth_pln_srvc_typ_cd, srvc_prr_nbr, lower(trim(hce_srvc_typ_desc)) as hce_srvc_typ_desc, lower(trim(hlth_pln_srvc_typ_lvl_5_nm)) as hlth_pln_srvc_typ_lvl_5_nm
    , lower(trim(hlth_pln_srvc_typ_lvl_4_nm)) as hlth_pln_srvc_typ_lvl_4_nm, lower(trim(hlth_pln_srvc_typ_lvl_3_nm)) as hlth_pln_srvc_typ_lvl_3_nm, lower(trim(hlth_pln_srvc_typ_lvl_2_nm)) as hlth_pln_srvc_typ_lvl_2_nm
    , lower(trim(hlth_pln_srvc_typ_lvl_1_nm)) as hlth_pln_srvc_typ_lvl_1_nm
    , current_datetime as create_datetime
  from `ds-00-191017.ugap_final.dim_hpdm_hp_service_type_code`
  ;
  ----------------------
  --NDC drug
  ----------------------
  --medispan tables
  create or replace table `research-01-217611.df_ucd_stage.medispan_drug`
  ( product_source_key          int64    OPTIONS(description = "Product source key")
    , product_id                string    OPTIONS(description = "Product Identification or NDC (National Drug Code")
    , product_id_qualifier_code string    OPTIONS(description = "Product ID qualifier code")
    , ahfs_code                 string    OPTIONS(description = "American Hospital Formulary Service Classification Compilation Code (AHFS) of the drug")
    , drug_dea_code             string    OPTIONS(description = "DEA code of the drug")
    , drug_label_name           string    OPTIONS(description = "GPI's drug label name")
    , drug_manufacturer_name    string    OPTIONS(description = "Manufacturer of the drug")
    , drug_group_name           string    OPTIONS(description = "GPI's drug group name")
    , drug_class_name           string    OPTIONS(description = "GPI's drug class name")
    , drug_subclass_name        string    OPTIONS(description = "GPI's drug sub-class name")
    , drug_basic_name           string    OPTIONS(description = "GPI's drug basic name")
    , drug_extended_name        string    OPTIONS(description = "GPI's drug extended name")
    , drug_dosage_form_id       string    OPTIONS(description = "GPI's dosage's form")
    , gcn_number                int64     OPTIONS(description = "generic number of the drug")
    , gcn_sequence_number       int64     OPTIONS(description = "generic sequence number of the drug")
    , gpi_number                string    OPTIONS(description = "Generic Product Identifier (GPI) number as assigned from Medispan associated with the drug")
    , ahfs_description          string    OPTIONS(description = "Describes the American Hospital Formulary Service Classification Compilation Code (AHFS) of the drug")
    , generic_name              string    OPTIONS(description = "Contains the drug ingredient name for a specific drug as adopted by the United States Adopted Names. The chemical name is used when the USAN name is not available.")
    , current_flag              string    OPTIONS(description = "flags 'y' if the drug is current, 'n' otherwise")
    , drug_ndc_effective_date   datetime  OPTIONS(description = "effectivity date of the ndc drug")
    , drug_ndc_terminated_date  datetime  OPTIONS(description = "terminated date of the ndc drug")
    , insert_timestamp          datetime  OPTIONS(description = "datetime record was inserted")
    , update_datetime           datetime  OPTIONS(description = "datetime record was updated")
    , load_utc_time             datetime  OPTIONS(description = "datetime record was loaded in medispan_final")
    )
  OPTIONS (description = "This is the medispan drug table. It has a one row per product id or ndc with medispan associated fields like gpi, drug group, etc. granularity. This table also contains the drug's effective and terminated dates.") as
  select product_source_key
    , lower(trim(product_id)) as product_id
    , lower(trim(product_id_qualifier_code)) as product_id_qualifier_code
    , lower(trim(ahfs_code)) as ahfs_code
    , lower(trim(drug_dea_code)) as drug_dea_code
    , lower(trim(drug_label_name)) as drug_label_name
    , lower(trim(drug_manufacturer_name)) as drug_manufacturer_name
    , lower(trim(drug_group_name)) as drug_group_name
    , lower(trim(drug_class_name)) as drug_class_name
    , lower(trim(drug_subclass_name)) as drug_subclass_name
    , lower(trim(drug_basic_name)) as drug_basic_name
    , lower(trim(drug_extended_name)) as drug_extended_name
    , lower(trim(drug_dosage_form_id)) as drug_dosage_form_id
    , gcn_number
    , gcn_sequence_number
    , lower(trim(gpi_number)) as gpi_number
    , lower(trim(ahfs_description)) as ahfs_description
    , lower(trim(generic_name)) as generic_name
    , lower(trim(current_flag)) as current_flag
    , drug_ndc_effective_date
    , drug_ndc_terminated_date
    , insert_timestamp
    , current_datetime as update_datetime
    , load_utc_time
  from `ds-00-191017.medispan_final.v_d_product`
  ;
  create or replace table `research-01-217611.df_ucd_stage.medispan_drug_ingredient`
  ( product_ingredient_source_key int64    OPTIONS(description = "Product ingredient source key")
    , product_source_key          int64    OPTIONS(description = "Product source key")
    , product_id                  int64    OPTIONS(description = "Product Identification or NDC (National Drug Code")
    , ingredient_generic_name     string    OPTIONS(description = "Product ingredient generic name")
    , ingredient_strength         float64    OPTIONS(description = "Product ingredient strength")
    , strength_unit_of_measurement_code   string    OPTIONS(description = "Unit of measure for the product ingredient strength")
    , inactive_date             date      OPTIONS(description = "product ingredient inactive date")
    , ingredient_inactive_flag  string    OPTIONS(description = "flags 'a' if the product ingredient is active, 'i' otherwise")
    , insert_timestamp          timestamp OPTIONS(description = "datetime record was inserted")
    , update_datetime           datetime  OPTIONS(description = "datetime record was updated")
    , load_utc_time             datetime  OPTIONS(description = "datetime record was loaded in medispan_final")
    )
  OPTIONS (description = "This is the medispan drug ingredient or composition table. It has a one row per product id per ingredient generic name granularity.") as
  select prod_ing_id_sk as product_ingredient_source_key
    , prod_sk as product_source_key
    , prod_id as product_id
    , lower(trim(pig_gnrc_nm)) as ingredient_generic_name
    , pig_strngth as ingredient_strength
    , lower(trim(pig_strngth_uom_cd)) as strength_unit_of_measurement_code
    , pig_inactive_dt as inactive_date
    , lower(trim(pig_ing_flg)) as ingredient_inactive_flag
    , insert_timestamp
    , current_datetime as update_datetime
    , load_utc_time
  from `ds-00-191017.medispan_final.v_d_prod_ingredient`
  ;
  --build ndc table
  create or replace table `research-01-217611.df_ucd_stage.dim_ndc_drug`
  ( ndc                            string    OPTIONS(description = "The unique code that identifies a drug product as defined by the National Drug Data File (all drug products regulated by the FDA must use an NDC).")
    , ndc_drg_row_eff_dt           date      OPTIONS(description = "First date the row became effective in Galaxy.")
    , ahfs_therapeutic_class_cd    string    OPTIONS(description = "	AHFS Therapeutic Class Code identifies the therapeutic category of a drug according to the American Hospital Formulary Service classification system. First Data Bank (FDB) discontinued the feed of this field in July 2009. First Data Bank is now sending the Extended Therapeutic Class Code which was added to the NDC Drug table and populated prospectively as of August 2009. All currently valid AHFS Therapeutic Class Codes have a corresponding Extended Therapeutic Class Code with “00” appended to the end. The Extended AHFS Therapeutic Class Code is not populated on older NDC Drug records. The AHFS Therapeutic Class Code is not populated on NDC Drug records added to the table since summer 2009. This means you will need to use both fields in order to get a full set of AHFS Therapeutic Class information.")
    , ahfs_therapeutic_class_desc  string    OPTIONS(description = "Describes the AHFS Therapeutic Class code.")
    , brnd_nm                      string    OPTIONS(description = "Provides the drug name on the package label and frequently is a trademark name. For non-branded generic products, the description will usually be the generic name.")
    , dea_drg_abus_cd              string    OPTIONS(description = "Indicates the abuse potential for a controlled drug as defined by the Drug Enforcement Agency (DEA) and is subject to change by federal regulation.")
    , dstrb_id                     string    OPTIONS(description = "The code identifying the drug distributor. It does not necessarily identify the actual drug manufacturer.	")
    , dstrb_nm                     string    OPTIONS(description = "The name of the drug distributor as listed on the drug label or indicated by the NDC. It does not necessarily identify the actual drug manufacturer.")
    , dosage_fm_desc               string    OPTIONS(description = "Dosage Form Description; Provides a description of how the drug is to be taken by the patient.")
    , drg_admin_rte_txt            string    OPTIONS(description = "Identifies the normal place or method by which a drug is administered to a patient.")
    , drg_avl_cd                   string    OPTIONS(description = "Classifies a drug by its availability to the consumer according to federal specifications.")
    , drg_catgy_cd                 string    OPTIONS(description = "Indicates that a drug product belongs to a category that is commonly treated as an exception in third party plans. For example antacids, smoking deterrents.")
    , drg_fm_cd                    string    OPTIONS(description = "Indicates the basic drug measurement unit for performing price calculations. For example, per tablet, per gram.")
    , drg_obslt_dt                 date      OPTIONS(description = "The Drug Obsolete Date is the date (or the estimated date) that the drug was declared obsolete (and replaced by another drug) or no longer available in the market place per the manufacturer's notification.")
    , drg_prc_typ_cd               string    OPTIONS(description = "Drug Pricing Type code; Indicates if a drug product should be priced as a generic or brand drug.")
    , drg_strgth_desc              string    OPTIONS(description = "Description of drug potency in units of grams, milligrams, percentage, and other terms. This field includes needle sizes, length of devices, and release rates of transdermal patches.")
    , drg_strgth_nbr               float64   OPTIONS(description = "Describes the strength of a drug product. For example: given a strength of 250 MG, 250 is the strength number. Only single ingredient products have values in this field.")
    , drg_strgth_unit_desc         string    OPTIONS(description = "Provides a metric description of the strength of a drug product. For example, given a strength of 250 MG, MG is the strength unit.")
    , drg_strgth_vol_nbr           float64   OPTIONS(description = "Indicates the volume or weight of the drug product that contains the indicated amounts of active ingredients. For example, given strength of 250 MG/5 ML, 5 is the strength volume.")
    , drg_strgth_vol_unit_desc     string    OPTIONS(description = "A metric measure indicating the volume or weight of the drug product containing the indicated amounts of active ingredients. For example, given strength of 250 MG/5ML, ML is the strength volume unit.")
    , xpnd_drg_desc                string    OPTIONS(description = "Provides an expanded description of the drug to further distinguish a medication by color, type, and trademarked dosage form, special packaging or other unique characteristics.")
    , xpnd_orange_bk_cd            string    OPTIONS(description = "Identifies the equivalency ratings assigned to an approved prescription product according to the FDA (HCFA). The code includes products that are listed in the Orange book and products not listed but purchased from manufacturers holding new drug applications. The code is specific to a pharmaceutical entity (GCN) and their five-digit labeler code.")
    , gnrc_ind                     string    OPTIONS(description = "Indicates if the drug is multiple sourced. VALID VALUES: N=Brand Name, U=Unknown, Y=Generically Named.")
    , gnrc_nm                      string    OPTIONS(description = "Contains the drug ingredient name for a specific drug as adopted by the United States Adopted Names. The chemical name is used when the USAN name is not available.")
    , gnrc_nbr                     string    OPTIONS(description = "A unique number representing the generic formulation of a drug and is specific to generic ingredient combination, route of administration and drug strength, across all drug forms.")
    , gnrc_seq_nbr                 string    OPTIONS(description = "A unique number that represents a generic formulation of a drug product. Like the Generic Code Number, the Generic Code Sequence number is specific to generic ingredient combinations, route of administration, dosage form and drug strength. The generic code number may be the same for different dosage forms, but the sequence number is specific to a dosage form.")
    , gdr_spec_drg_cd              string    OPTIONS(description = "Identifies if the drug is used for a specific gender. Will identify as gender exclusive, gender likely, or gender neutral.")
    , gnrc_therapeutic_clss_cd     string    OPTIONS(description = "Indicates the classification of drugs according to the most common intended use as the broadest therapeutic groupings available. For example antihistamines, cardiac drugs, cough and cold preparations. Data Placement: right justified prefixed with zero")
    , hcfa_aprv_dt                 date      OPTIONS(description = "The date that the Federal Drug Administration approved the drug for use as supplied on the Healthcare Finance Administration quarterly tape.")
    , hierarchial_ingredient_nbr   string    OPTIONS(description = "Includes up to nine hierarchical ingredient codes, each six characters in length. Each hierarchical ingredient code may have spaces in the fifth and sixth position.")
    , hierarchial_ingredient_seq_nbr  string    OPTIONS(description = "Provides a link between the Hierarchical Ingredient Number and a National Drug Code or a Generic Sequence Number. Can be used to identify a unique combination of ingredients for a drug independent of National Drug Code.")
    , innovator_ind               string    OPTIONS(description = "Indicates if this product held the original patent for the drug. Since this may be assigned to multiple package sizes and to replacement National Drug Codes, more than one product may appear to be the innovator.")
    , ndc_drg_row_end_dt          date      OPTIONS(description = "Last date the row was effective in Galaxy.")
    , ndc_lbl_cd                  string    OPTIONS(description = "Part of the National Drug Code (NDC), it is assigned by the Federal Drug Administration to identify manufacturers. The combination of NDC Label Code, NDC Package Code and NDC Product Code makes up a complete National Drug Code.")
    , ndc_pkg_cd                  string    OPTIONS(description = "Identifies the container in which the drug product is sold. The combination of NDC Label Code, NDC Package Code and NDC Product Code makes up a complete National Drug Code.")
    , ndc_prdct_cd                string    OPTIONS(description = "A number assigned by the Federal Drug Association to identify a drug within a manufacturer. The combination of NDC Label Code, NDC Package Code and NDC Product Code makes up a complete National Drug Code. Data Placement: right justified prefixed with zeroes")
    , pkg_desc                    string    OPTIONS(description = "Describes the container in which the drug is sold.")
    , pkg_sz_eq_nbr               float64   OPTIONS(description = "Provides a conversion of Package Size Number for non-injectable products to non-metric or most commonly used package size descriptions. For example, 15 ml = 1/2 fluid ounce.")
    , pkg_sz_nbr                  float64   OPTIONS(description = "Identifies the metric quantity of a drug used to derive a unit price. It is the usual labeled quantity from which the pharmacist dispenses which is the smallest unbreakable package as provided by the labeler/distributor. For example: 100 when the package contains 100 tablets, 20 when the package is a 20-ml vial.")
    , preg_pcaut_nbr              string    OPTIONS(description = "Pregnancy Precaution Number; Indicates if this is the first, second, or subsequent refill for the prescription.")
    , proc_cd                     string    OPTIONS(description = "Procedure Code describes the type of procedure performed or service provided. This procedure code is usually a ICD10, ICD9, CPT-4 OR HCPCS Code. Data Placement: left justified, space filled.")
    , repackaged_ind              string    OPTIONS(description = "Indicates if a drug was repackage by a labeler. Labelers usually repackage drugs into unit of use or dispensable package sizes.")
    , src_sys_cd                  string    OPTIONS(description = "System that is the source of this row’s data.")
    , side_eff_nbr                string    OPTIONS(description = "The number identifying the side affects that may be associated with a drug.")
    , spec_therapeutic_clss_cd    string    OPTIONS(description = "Specific Therapeutic Class Code; A low level classification of drugs as provided by First Data Bank.")
    , std_pkg_ind                 string    OPTIONS(description = "Indicates if the drug is dispensed in the standard package size.")
    , std_therapeutic_clss_cd     string    OPTIONS(description = "Standard Therapeutic Class Code; Used to classify drugs according to the most common intended use. For example, medical supplies, muscle relaxants, Antiparkinson. Data Placement: right justified prefixed with zero")
    , unit_dose_ind               string    OPTIONS(description = "Indicates if the manufacturer packaged the drug at the unit dose level.")
    , unit_of_use_ind             string    OPTIONS(description = "Indicates if the package is supplied with appropriate labeling and (usually) child resistant closures and is appropriate to dispense as a unit.")
    , comprs_brnd_nm              string    OPTIONS(description = "Compressed Brand Name; The brand name with all non-alphabetic and non-numeric characters and spaces removed.")
    , medco_therapeutic_clss_cd   string    OPTIONS(description = "A code that identifies the therapeutic category of a drug according to Medco's proprietary classification system.")
    , ext_ahfs_thrptc_class_cd    int64     OPTIONS(description = "Medi-Span is licensed by the American Society of Health-Care Pharmacists to use the American Hospital Formulary Service Classification Compilation Code (AHFS). The Extended AHFS Therapeutic Class Code is an eight-digit version of the six-digit AHFS Therapeutic Class Code in the A1 Record. If you receive the following warning message when joining this code table to any Galaxy Fact tables please disregard: WARNING: Multiple lengths were specified for the BY variable (field name) by input data sets. This may cause unexpected results. The data in the code on the Galaxy Fact table will join to the data in the Galaxy Code Table.")
    , ext_ahfs_thrptc_class_desc  string    OPTIONS(description = "Describes the extended AHFS Therapeutic Class Code.")
    , drug_label_name         string    OPTIONS(description = "GPI's drug label name")
    , drug_manufacturer_name  string    OPTIONS(description = "Manufacturer of the drug")
    , drug_group_name       string    OPTIONS(description = "GPI's drug group name")
    , drug_class_name       string    OPTIONS(description = "GPI's drug class name")
    , drug_subclass_name    string    OPTIONS(description = "GPI's drug sub-class name")
    , drug_basic_name       string    OPTIONS(description = "GPI's drug basic name")
    , drug_extended_name    string    OPTIONS(description = "GPI's drug extended name")
    , drug_dosage_form_id   string    OPTIONS(description = "GPI's dosage's form")
    , gpi_number        string    OPTIONS(description = "Generic Product Identifier (GPI) number as assigned from Medispan associated with the drug")
    , current_flag      string    OPTIONS(description = "flags 1 if the gpi is current, 0 otherwise")
    , create_datetime   datetime  OPTIONS(description = "datetime record was created")
    )
  OPTIONS (description = "This is the dimension table for NDC drug codes. It has a one row per ndc code granularity. The National Drug Code standards describing strength, dosages, packaging, treatment purposes and issues of drugs which are prescribed by providers for the treatment of member illness. History is maintained for the Drug entity. When new values come to Galaxy on claim records, rows are added to this table through an automated referential integrity process within Galaxy. This process is in place to prevent rows from being dropped when this table is joined to other tables within Galaxy. Fields on these rows are populated with default values.") as
  with cte_ahfs as (
      select * except(src)
        , row_number() over(partition by ahfs_therapeutic_class_cd order by src = 'galaxy' desc) as oid
      from  (
              select distinct lower(trim(ahfs_therapeutic_class_code)) as ahfs_therapeutic_class_cd, lower(trim(ahfs_therapeutic_class_desc)) as ahfs_therapeutic_class_desc
                , 'galaxy' as src
              from `ds-00-191017.galaxy_final.dim_ahfs_therapeutic_class_code`

              union distinct
              select distinct lower(trim(ahfs_therapeutic_clss_cd)) as ahfs_therapeutic_class_cd, lower(trim(ahfs_therapeutic_clss_desc)) as ahfs_therapeutic_clss_desc
                , 'ugap' as src
              from `ds-00-191017.ugap_final.dim_hpdm_ahfs_therapeutic_class`
            )
    )
  , cte_ext_ahfs as (
      select * except(src)
        , row_number() over(partition by ext_ahfs_thrptc_class_cd order by src = 'galaxy' desc) as oid
      from  (
              select distinct safe_cast(lower(trim(ext_ahfs_thrptc_class_cd)) as int64) as ext_ahfs_thrptc_class_cd, lower(trim(ext_ahfs_thrptc_class_desc)) as ext_ahfs_thrptc_class_desc
                , 'galaxy' as src
              from `ds-00-191017.galaxy_final.dim_extended_ahfs_therapeutic_class_code`

              union distinct
              select distinct safe_cast(lower(trim(ext_ahfs_thrptc_clss_cd)) as int64) as ext_ahfs_thrptc_clss_cd, lower(trim(ext_ahfs_thrptc_clss_desc)) as ext_ahfs_thrptc_clss_desc
                , 'ugap' as src
              from `ds-00-191017.ugap_final.dim_hpdm_ndc_drug`
            )
    )
  select a.*
    , lower(trim(b.drug_label_name)) as drug_label_name
    , lower(trim(b.drug_manufacturer_name)) as drug_manufacturer_name
    , lower(trim(b.drug_group_name)) as drug_group_name
    , lower(trim(b.drug_class_name)) as drug_class_name
    , lower(trim(b.drug_subclass_name)) as drug_subclass_name
    , lower(trim(b.drug_basic_name)) as drug_basic_name
    , lower(trim(b.drug_extended_name)) as drug_extended_name
    , lower(trim(b.drug_dosage_form_id)) as drug_dosage_form_id
    , lower(trim(b.gpi_number)) as gpi_number
    , lower(trim(b.current_flag)) as current_flag
    , current_datetime as create_datetime
  from (
          select * except(oid)
          from (
                  select lower(trim(ndc)) as ndc, ndc_drg_row_eff_dt, lower(trim(b.ahfs_therapeutic_class_cd)) as ahfs_therapeutic_class_code, lower(trim(b.ahfs_therapeutic_class_desc)) as ahfs_therapeutic_class_desc
                    , lower(trim(brnd_nm)) as brnd_nm, lower(trim(dea_drg_abus_cd)) as dea_drg_abus_cd, lower(trim(dstrb_id)) as dstrb_id, lower(trim(dstrb_nm)) as dstrb_nm, lower(trim(dosage_fm_desc)) as dosage_fm_desc
                    , lower(trim(drg_admin_rte_txt)) as drg_admin_rte_txt, lower(trim(drg_avl_cd)) as drg_avl_cd, lower(trim(drg_catgy_cd)) as drg_catgy_cd, lower(trim(drg_fm_cd)) as drg_fm_cd
                    , drg_obslt_dt, lower(trim(drg_prc_typ_cd)) as drg_prc_typ_cd, lower(trim(drg_strgth_desc)) as drg_strgth_desc, drg_strgth_nbr, lower(trim(drg_strgth_unit_desc)) as drg_strgth_unit_desc, drg_strgth_vol_nbr
                    , lower(trim(drg_strgth_vol_unit_desc)) as drg_strgth_vol_unit_desc, lower(trim(xpnd_drg_desc)) as xpnd_drg_desc, lower(trim(xpnd_orange_bk_cd)) as xpnd_orange_bk_cd, lower(trim(gnrc_ind)) as gnrc_ind
                    , lower(trim(gnrc_nm)) as gnrc_nm, lower(trim(gnrc_nbr)) as gnrc_nbr
                    , lower(trim(gnrc_seq_nbr)) as gnrc_seq_nbr, lower(trim(gdr_spec_drg_cd)) as gdr_spec_drg_cd, lower(trim(gnrc_therapeutic_clss_cd)) as gnrc_therapeutic_clss_cd, hcfa_aprv_dt
                    , lower(trim(hierarchial_ingredient_nbr)) as hierarchial_ingredient_nbr, lower(trim(hierarchial_ingredient_seq_nbr)) as hierarchial_ingredient_seq_nbr, lower(trim(innovator_ind)) as innovator_ind, ndc_drg_row_end_dt
                    , lower(trim(ndc_lbl_cd)) as ndc_lbl_cd, lower(trim(ndc_pkg_cd)) as ndc_pkg_cd, lower(trim(ndc_prdct_cd)) as ndc_prdct_cd, lower(trim(pkg_desc)) as pkg_desc, pkg_sz_eq_nbr, pkg_sz_nbr
                    , lower(trim(preg_pcaut_nbr)) as preg_pcaut_nbr, lower(trim(proc_cd)) as proc_cd, lower(trim(repackaged_ind)) as repackaged_ind, lower(trim(src_sys_cd)) as src_sys_cd, lower(trim(side_eff_nbr)) as side_eff_nbr
                    , lower(trim(spec_therapeutic_clss_cd)) as spec_therapeutic_clss_cd, lower(trim(std_pkg_ind)) as std_pkg_ind, lower(trim(std_therapeutic_clss_cd)) as std_therapeutic_clss_cd, lower(trim(unit_dose_ind)) as unit_dose_ind
                    , lower(trim(unit_of_use_ind)) as unit_of_use_ind, lower(trim(comprs_brnd_nm)) as comprs_brnd_nm, lower(trim(medco_therapeutic_clss_cd)) as medco_therapeutic_clss_cd
                    , c.ext_ahfs_thrptc_class_cd, lower(trim(c.ext_ahfs_thrptc_class_desc)) as ext_ahfs_thrptc_class_desc
                    , row_number() over(partition by lower(trim(ndc)) order by src = 'galaxy' desc) as oid
                  from  (
                          select distinct ndc, ndc_drg_row_eff_dt, ahfs_therapeutic_clss_cd, brnd_nm, dea_drg_abus_cd, dstrb_id, dstrb_nm, dosage_fm_desc, drg_admin_rte_txt, drg_avl_cd, drg_catgy_cd, drg_fm_cd
                            , drg_obslt_dt, drg_prc_typ_cd, drg_strgth_desc, drg_strgth_nbr, drg_strgth_unit_desc, drg_strgth_vol_nbr, drg_strgth_vol_unit_desc, xpnd_drg_desc, xpnd_orange_bk_cd, gnrc_ind, gnrc_nm, gnrc_nbr
                            , gnrc_seq_nbr, gdr_spec_drg_cd, gnrc_therapeutic_clss_cd, hcfa_aprv_dt, hierarchial_ingredient_nbr, hierarchial_ingredient_seq_nbr, innovator_ind, ndc_drg_row_end_dt, ndc_lbl_cd, ndc_pkg_cd
                            , ndc_prdct_cd, pkg_desc, pkg_sz_eq_nbr, pkg_sz_nbr, preg_pcaut_nbr, proc_cd, repackaged_ind, src_sys_cd, side_eff_nbr, spec_therapeutic_clss_cd, std_pkg_ind, std_therapeutic_clss_cd, unit_dose_ind
                            , unit_of_use_ind, comprs_brnd_nm, medco_therapeutic_clss_cd, ext_ahfs_thrptc_clss_cd
                            , 'galaxy' as src
                          from `ds-00-191017.galaxy_final.dim_ndc_drug`

                          union distinct
                          select distinct ndc, cast(NULL as date) as ndc_drg_row_eff_dt, '' as ahfs_therapeutic_clss_cd, brnd_nm, '' as dea_drg_abus_cd, '' as dstrb_id, '' as dstrb_nm, dosage_fm_desc, '' as drg_admin_rte_txt
                            , '' as drg_avl_cd, '' as drg_catgy_cd, '' as drg_fm_cd, cast(NULL as date) as drg_obslt_dt, '' as drg_prc_typ_cd, '' as drg_strgth_desc, drg_strgth_nbr, drg_strgth_unit_desc
                            , cast(NULL as float64) as drg_strgth_vol_nbr, '' as drg_strgth_vol_unit_desc, '' as xpnd_drg_desc, '' as xpnd_orange_bk_cd, '' as gnrc_ind, gnrc_nm, '' as gnrc_nbr, '' as gnrc_seq_nbr, '' as gdr_spec_drg_cd
                            , '' as gnrc_therapeutic_clss_cd, cast(NULL as date) as hcfa_aprv_dt, '' as hierarchial_ingredient_nbr, '' as hierarchial_ingredient_seq_nbr, '' as innovator_ind, cast(NULL as date) as ndc_drg_row_end_dt
                            , '' as ndc_lbl_cd, '' as ndc_pkg_cd, '' as ndc_prdct_cd, '' as pkg_desc, cast(NULL as float64) as pkg_sz_eq_nbr, cast(NULL as float64) as pkg_sz_nbr, '' as preg_pcaut_nbr, '' as proc_cd, '' as repackaged_ind
                            , '' as src_sys_cd, '' as side_eff_nbr, '' as spec_therapeutic_clss_cd, '' as std_pkg_ind, '' as std_therapeutic_clss_cd, '' as unit_dose_ind, '' as unit_of_use_ind, '' as comprs_brnd_nm
                            , '' as medco_therapeutic_clss_cd, ext_ahfs_thrptc_clss_cd
                            , 'ugap' as src
                          from `ds-00-191017.ugap_final.dim_hpdm_ndc_drug`
                        ) a
                  left join cte_ahfs     b on a.ahfs_therapeutic_clss_cd = b.ahfs_therapeutic_class_cd and b.oid = 1
                  left join cte_ext_ahfs c on safe_cast(a.ext_ahfs_thrptc_clss_cd as int64) = c.ext_ahfs_thrptc_class_cd and c.oid = 1
              ) a
         where oid = 1
       ) a
  left join (
              select *
              from `research-01-217611.df_ucd_stage.medispan_drug`
              where gpi_number is not null and gpi_number not in ('', '-')
             )  b on lower(trim(a.ndc)) = lower(trim(b.product_id))
  ;
  ----------------------
  --pharmacy
  ----------------------
  create or replace table `research-01-217611.df_ucd_stage.dim_pharmacy_provider`
  ( nabp_nbr            string    OPTIONS(description = "A number assigned by the National Council for Prescription Drug Programs (NCPDP) to uniquely identify a pharmacy.")
    , npi               int64     OPTIONS(description = "The National Provider Identifier (NPI) was adopted as the standard unique health identifier for health care providers to carry out a requirement in the Health Insurance Portability and Accountability Act of 1996 (HIPAA) for the adoption of such a standard.")
    , phrm_prov_nm      string    OPTIONS(description = "The name of the pharmacy.")
    , dspns_typ_cd      string    OPTIONS(description = "Identifies the how the customer interfaced with the provider to receive the prescription. For example, the prescription was filled at a pharmacy in a grocery store or filled via mail order. Data Placement: left justified, space filled. If you receive the following warning message when joining this code table to any Galaxy Fact tables please disregard: WARNING: Multiple lengths were specified for the BY variable (field name) by input data sets. This may cause unexpected results. The data in the code on the Galaxy Fact table will join to the data in the Galaxy Code Table.")
    , dspns_typ_desc    string    OPTIONS(description = "Describes the how the customer interfaced with the provider to receive the prescription. For example, the prescription was filled at a pharmacy in a grocery store or filled via mail order.")
    , dspns_clss_cd     string    OPTIONS(description = "Identifies the business classification of the pharmacy. For example, independent, chain or hospital.")
    , dspns_clss_desc   string    OPTIONS(description = "Describes the business classification of the pharmacy. For example, independent, chain or hospital.")
    , affil_nbr         string    OPTIONS(description = "The number assigned to any group or entity that a provider is related to for business purposes. A name that describes a grouping of pharmacies.")
    , affil_nm          string    OPTIONS(description = "The name assigned to a group or entity that a provider is related to for business purposes. A name that describes a grouping of pharmacies.")
    , affil_eff_dt      date      OPTIONS(description = "The first date the provider became related to a specific group or entity for business purposes.")
    , eft_rte_adr_txt   string    OPTIONS(description = "The electronic funds transfer route address to the bank where payments are to be deposited")
    , fed_lic_nbr       string    OPTIONS(description = "The license number assigned to the pharmacy by the federal government.")
    , fed_tax_id_nbr    string    OPTIONS(description = "The federal tax id of the provider.")
    , medcd_id          string    OPTIONS(description = "An identification number assigned to the provider by the State Medicaid Agency.")
    , pay_ctr_nbr       string    OPTIONS(description = "Identifies the location where payments for the provider go if they are not going directly to the provider.")
    , st_lic_nbr        string    OPTIONS(description = "The license number assigned to the pharmacy by the state.")
    , st_tax_nbr        string    OPTIONS(description = "The tax identification number assigned to the pharmacy by the state.")
    , adr_ln_1_txt      string    OPTIONS(description = "The first line of the address.")
    , adr_ln_2_txt      string    OPTIONS(description = "The second line of the address.")
    , city              string    OPTIONS(description = "The city associated with the provider, member, pharmacy, or customer segment address.")
    , zip_cd            string    OPTIONS(description = "The number assigned by the US Postal Service to a geographic area for the purposes of efficient mail sorting and delivery.")
    , zip_pls_4_cd      string    OPTIONS(description = "The number that specifies the geographic segment within the zip code, such as a city block, an office building, or any other unit that aids the post office in efficient mail sorting and delivery.")
    , src_sys_cd        string    OPTIONS(description = "System that is the source of this row’s data.")
    , create_datetime   datetime  OPTIONS(description = "datetime record was created")
    )
  OPTIONS (description = "This is the dimension table for Pharmacy Provider codes. It has a one row per pharmacy granularity. This table contains descriptive information about pharmacies, nursing homes or mail order facility. The Pharmacy provider is the facility filling the script for the member.") as
  select lower(trim(nabp_nbr)) as nabp_nbr, cast(phrm_npi_nbr as int64) as npi, lower(trim(phrm_prov_nm)) as phrm_prov_nm
    , lower(trim(a.dspns_typ_cd)) as dspns_typ_cd, lower(trim(b.dspns_typ_desc)) as dspns_typ_desc
    , lower(trim(a.dspns_clss_cd)) as dspns_clss_cd, lower(trim(c.dspns_clss_desc)) as dspns_clss_desc
    , lower(trim(affil_nbr)) as affil_nbr, lower(trim(affil_nm)) as affil_nm, affil_eff_dt, lower(trim(eft_rte_adr_txt)) as eft_rte_adr_txt, lower(trim(fed_lic_nbr)) as fed_lic_nbr, lower(trim(fed_tax_id_nbr)) as fed_tax_id_nbr
    , lower(trim(medcd_id)) as medcd_id, lower(trim(pay_ctr_nbr)) as pay_ctr_nbr, lower(trim(st_lic_nbr)) as st_lic_nbr, lower(trim(st_tax_nbr)) as st_tax_nbr, lower(trim(adr_ln_1_txt)) as adr_ln_1_txt
    , lower(trim(adr_ln_2_txt)) as adr_ln_2_txt, lower(trim(cty_nm)) as city, lower(trim(zip_cd)) as zip_cd, lower(trim(zip_pls_4_cd)) as zip_pls_4_cd, lower(trim(src_sys_cd)) as src_sys_cd
    , current_datetime as create_datetime
  from `ds-00-191017.galaxy_final.dim_pharmacy_npi_provider` a
  left join `ds-00-191017.galaxy_final.dim_dispense_type_code`  b on lower(trim(a.dspns_typ_cd)) = lower(trim(b.dspns_typ_cd))
  left join `ds-00-191017.galaxy_final.dim_dispense_class_code` c on safe_cast(lower(trim(a.dspns_clss_cd)) as int64) = c.dspns_clss_cd
  ;
  ----------------------
  --procedure code
  ----------------------
  create or replace table `research-01-217611.df_ucd_stage.dim_procedure_code`
  ( srvc_catgy_desc     string   OPTIONS(description = "Describes the associated Categories of Service Code.")
    , srvc_catgy_cd     string   OPTIONS(description = "Groupings of procedure codes as defined by CPT/HCPCS Industry Standards.")
    , proc_end_dt       date     OPTIONS(description = "The date that the procedure code was deleted from the Industry Standard Code listing.")
    , proc_cd           string   OPTIONS(description = "Procedure Code describes the type of procedure performed or service provided. This procedure code is usually a CPT-4 OR HCPCS Code.")
    , proc_decm_cd      string   OPTIONS(description = "The decimal identification of a specific procedure performed or service provided. A procedure code can be an ICD9, CPT4, or HCPC code.")
    , proc_desc         string   OPTIONS(description = "Describes a specific procedure performed or service provided. A procedure code can be an ICD9, CPT4, or HCPC code.")
    , gdr_lmt_cd        string   OPTIONS(description = "Identifies if the procedure is used for a specific gender.")
    , asg_grp_cd        string   OPTIONS(description = "Code indicates to which ASC (Ambulatory Surgial Grouper) group the procedure performed was assigned. The ASC list groups CPT codes into one of nine grouping levels. Each of the contracted grouping levels assigned CPT codes has a specific contracted Case Rate.")
    , ahrq_proc_genl_catgy_cd     int64    OPTIONS(description = "Identifies the AHRQ (Agency for Healthcare Research and Quality) high-level grouping of procedure codes which is primarily by organ system.")
    , ahrq_proc_genl_catgy_desc   string   OPTIONS(description = "Describes the AHRQ (Agency for Healthcare Research and Quality) high-level grouping of procedure codes which is primarily by organ system.")
    , ahrq_proc_dtl_catgy_cd      int64    OPTIONS(description = "Identifies the AHRQ (Agency for Healthcare Research and Quality) detailed grouping of procedure codes. For example, Glaucoma Procedures, Repair of Retinal Tear & Detachment.")
    , ahrq_proc_dtl_catgy_desc    string   OPTIONS(description = "Describes the AHRQ (Agency for Healthcare Research and Quality) detailed grouping of procedure codes. For example, Glaucoma Procedures, Repair of Retinal Tear & Detachment.")
    , vst_cd            string   OPTIONS(description = "Identifies if this is an actual visit or just a procedure. For example, this code can distinguish between an actual physician's office visit for the purpose of diagnosis and treatment, versus just an allergy shot.")
    , proc_typ_cd       string   OPTIONS(description = "Identifies the industry standard code set where the procedure code is defined. This will identify the code as an ICD9, ICD10, CPT4 or HCPC.")
    , sens_cond_ind     string   OPTIONS(description = "This indicator identifies whether a diagnosis code is considered sensitive such as mental health, abuse, etc.")
    , sens_cond_catgy   string   OPTIONS(description = "This category identifies the sensitive condition category (mental health, abuse, etc) if the sensitive condition indicator equals Y.")
    , create_datetime   datetime  OPTIONS(description = "datetime record was created")
    )
  OPTIONS (description = "This is the dimension table for procedure codes. It has a one row per procedure code granularity. The Procedure Code Dimension table contains all of the procedure codes that can be used as a reference for all Procedure codes on the actual Claim along with their descriptive text, visit encounter indicator, procedure type, and groupings of the codes.") as
  with cte_gnl as (
      select *
        , row_number() over(partition by ahrq_proc_genl_catgy_cd order by ahrq_proc_genl_catgy_desc not like 'unkn%'  desc,  src = 'ugap' desc, proc_typ_cd) as oid
      from (
            select distinct safe_cast(ahrq_proc_genl_catgy_cd as int64) as ahrq_proc_genl_catgy_cd, lower(trim(ahrq_proc_genl_catgy_desc)) as ahrq_proc_genl_catgy_desc, lower(trim(proc_typ_cd)) as proc_typ_cd
              , 'ugap' as src
            from `ds-00-191017.ugap_final.dim_hpdm_procedure_code`

            union distinct
            select distinct safe_cast(ahrq_proc_genl_catgy_cd as int64) as ahrq_proc_genl_catgy_cd, lower(trim(ahrq_proc_genl_catgy_desc)) as ahrq_proc_genl_catgy_desc, lower(trim(proc_typ_cd)) as proc_typ_cd
              , 'galaxy' as src
            from `ds-00-191017.galaxy_final.dim_procedure_code`
          ) x
    )
  , cte_dtl as (
      select *
        , row_number() over(partition by ahrq_proc_dtl_catgy_cd order by  ahrq_proc_dtl_catgy_desc not like 'unkn%' desc,  src = 'ugap' desc, proc_typ_cd) as oid
      from (
            select distinct safe_cast(ahrq_proc_dtl_catgy_cd as int64) as ahrq_proc_dtl_catgy_cd, lower(trim(ahrq_proc_dtl_catgy_desc)) as ahrq_proc_dtl_catgy_desc, lower(trim(proc_typ_cd)) as proc_typ_cd
              , 'ugap' as src
            from `ds-00-191017.ugap_final.dim_hpdm_procedure_code`

            union distinct
            select distinct safe_cast(ahrq_proc_dtl_catgy_cd as int64) as ahrq_proc_dtl_catgy_cd, lower(trim(ahrq_proc_dtl_catgy_desc)) as ahrq_proc_dtl_catgy_desc, lower(trim(proc_typ_cd)) as proc_typ_cd
              , 'galaxy' as src
            from `ds-00-191017.galaxy_final.dim_procedure_code`
          ) x
    )
  select * except(oid)
    , current_datetime as create_datetime
  from (
          select distinct lower(trim(srvc_catgy_desc)) as srvc_catgy_desc, lower(trim(srvc_catgy_cd)) as srvc_catgy_cd, proc_end_dt, lower(trim(proc_cd)) as proc_cd, lower(trim(proc_decm_cd)) as proc_decm_cd
            , lower(trim(proc_desc)) as proc_desc, lower(trim(gdr_lmt_cd)) as gdr_lmt_cd, lower(trim(asg_grp_cd)) as asg_grp_cd
            , b.ahrq_proc_genl_catgy_cd, b.ahrq_proc_genl_catgy_desc
            , c.ahrq_proc_dtl_catgy_cd, c.ahrq_proc_dtl_catgy_desc
            , lower(trim(a.vst_cd)) as vst_cd, lower(trim(a.proc_typ_cd)) as proc_typ_cd
            , lower(trim(sens_cond_ind)) as sens_cond_ind, lower(trim(sens_cond_catgy)) as sens_cond_catgy
            , row_number() over(partition by lower(trim(a.proc_cd)) order by lower(trim(a.proc_desc)) not like 'unk%' desc, a.src = 'ugap' desc) as oid
          from (
                  select distinct srvc_catgy_desc, srvc_catgy_cd, proc_end_dt, proc_desc, proc_cd, proc_decm_cd, gdr_lmt_cd, asg_grp_cd
                    , safe_cast(ahrq_proc_genl_catgy_cd as int64) as ahrq_proc_genl_catgy_cd, safe_cast(ahrq_proc_dtl_catgy_cd as int64) as ahrq_proc_dtl_catgy_cd
                    , vst_cd, proc_typ_cd, sens_cond_ind, sens_cond_catgy
                    , 'ugap' as src
                  from `ds-00-191017.ugap_final.dim_hpdm_procedure_code`
                  union distinct
                  select distinct srvc_catgy_desc, srvc_catgy_cd, proc_end_dt, proc_desc, proc_cd, proc_decm_cd, gdr_lmt_cd, asg_grp_cd
                    , safe_cast(ahrq_proc_genl_catgy_cd as int64) as ahrq_proc_genl_catgy_cd, safe_cast(ahrq_proc_dtl_catgy_cd as int64) as ahrq_proc_dtl_catgy_cd
                    , vst_cd, proc_typ_cd, '' as sens_cond_ind, '' as sens_cond_catgy
                    , 'galaxy' as src
                  from `ds-00-191017.galaxy_final.dim_procedure_code`
                ) a
          left join cte_gnl b on a.ahrq_proc_genl_catgy_cd = b.ahrq_proc_genl_catgy_cd and b.oid = 1
          left join cte_dtl c on a.ahrq_proc_dtl_catgy_cd = c.ahrq_proc_dtl_catgy_cd and c.oid = 1
     ) z
  where oid = 1
  ;
  ----------------------
  --procedure modifier code
  ----------------------
  create or replace table `research-01-217611.df_ucd_stage.dim_procedure_modifier_code`
  ( proc_mod_cd             string    OPTIONS(description = "Identifies more detail about the specific procedure provided or service performed. IP Derivation: Straight move of PROC_MOD_CD field from Galaxy Procedure Modifier Code table based on PROC_MOD_1_SYS_ID field from: Galaxy UNET UB92 Revenue Code Statistical Service table if UB92_RVNU_CD_STAT_SRVC_IND from UNET Claim Statistical Service table = 'Y' Galaxy UNET Claim Statistical Service table if UB92_RVNU_CD_STAT_SRVC_IND from UNET Claim Statistical Service table = 'N'; MAMSI/COSMOS: Straight move based PROC_MOD_1_SYS_ID field from MAMSI/COSMOS Claim Statistical Service table. Ovations East - straigh move based on PROC_MOD_1_SYS_ID field from COSMOS Paid/Pended Claim Statistical Service table. Ovations West: Straight move of MOD1 from tbDetail.Sxx.csvfile (xx=IP, OP, PR) TADM Derivation: Source PRDS FACT_MEDICAL_CLAIM_DETAIL table, SERVICE_MODIFIER1 field. Note IP Only -see fact field derivation logic for other fact tables.")
    , proc_mod_desc         string    OPTIONS(description = "Describes more detail about the specific procedure provided or service performed.")
    , proc_mod_grp_cd       string    OPTIONS(description = "Identifies the categorization of industry standard procedure modifier codes.")
    , proc_mod_grp_desc     string    OPTIONS(description = "Describes the categorization of industry standard procedure modifier codes.")
    , proc_mod_prov_spcl_nm string    OPTIONS(description = "The name of the provider specialty associated with the Procedure Modifier Code. The descriptions for some Procedure Modifier Codes vary by provider specialty.")
    , create_datetime       datetime  OPTIONS(description = "datetime record was created")
    )
  OPTIONS (description = "This is the dimension table for procedure modifier codes. It has a one row per procedure modifier code granularity. The Procedure Modifier Code Dimension table contains all of the procedure modifier codes that can be used as a reference for all Procedure modifier codes on the actual Claim along with their descriptive text.") as
  select * except(src, oid)
    , current_datetime as create_datetime
  from (
         select *
           , row_number() over(partition by proc_mod_cd order by proc_mod_desc not like 'unk%' desc, src = 'galaxy' desc, proc_mod_grp_cd) as oid
         from (
                 select distinct lower(trim(proc_mod_cd)) as proc_mod_cd, lower(trim(proc_mod_desc)) as proc_mod_desc, lower(trim(proc_mod_grp_cd)) as proc_mod_grp_cd, lower(trim(proc_mod_grp_desc)) as proc_mod_grp_desc
                   , lower(trim(proc_mod_prov_spcl_nm)) as proc_mod_prov_spcl_nm
                   , 'galaxy' as src
                 from `ds-00-191017.galaxy_final.dim_procedure_modifier_code`
                 union distinct
                 select distinct lower(trim(proc_mod_cd)) as proc_mod_cd, lower(trim(proc_mod_desc)) as proc_mod_desc, lower(trim(proc_mod_grp_cd)) as proc_mod_grp_cd, lower(trim(proc_mod_grp_desc)) as proc_mod_grp_desc
                   , lower(trim(proc_mod_prov_spcl_nm)) asproc_mod_prov_spcl_nm
                   , 'ugap' as src
                 from `ds-00-191017.ugap_final.dim_hpdm_procedure_modifier_code`
               ) x
       ) z
  where oid = 1
  ;
  ----------------------
  --provider
  ----------------------
  create or replace table `research-01-217611.df_ucd_stage.dim_provider_npi`
  ( npi                 int64     OPTIONS(description = "The National Provider Identifier (NPI) was adopted as the standard unique health identifier for health care providers to carry out a requirement in the Health Insurance Portability and Accountability Act of 1996 (HIPAA) for the adoption of such a standard.")
    , prov_type             string    OPTIONS(description = "Provider classification including Organization (O) and Person/Physician (P).")
    , enumeration_date      date      OPTIONS(description = "The date the npi was enumerated.")
    , deactivation_date     date      OPTIONS(description = "The date the npi was deactivated.")
    , reactivation_date     date      OPTIONS(description = "The date the npi was reactivated.")
    , deactivation_reason_cd    string    OPTIONS(description = "The code for the deactivation reason.")
    , prov_degree           string    OPTIONS(description = "EPD only. Identifies the first occurance of a provider's degree, if populated. Data Placement: left justified, space filled.")
    , full_name             string    OPTIONS(description = "The full name of an individual provider.")
    , last_name             string    OPTIONS(description = "The last name of an individual provider.")
    , first_name            string    OPTIONS(description = "The first name of an individual provider.")
    , middle_name           string    OPTIONS(description = "The middle name of an individual provider.")
    , name_suffix           string    OPTIONS(description = "The name suffix of an individual provider.")
    , gender                string     OPTIONS(description = "The gender code of an individual provider.")
    , adr_ln_1_txt          string    OPTIONS(description = "The first line of the address.")
    , adr_ln_2_txt          string    OPTIONS(description = "The second line of the address.")
    , city                  string    OPTIONS(description = "The city associated with the provider, member, pharmacy, or customer segment address.")
    , county                string    OPTIONS(description = "The county associated with the provider, member, pharmacy, or customer segment address.")
    , state                 string    OPTIONS(description = "The two-character US Postal Service Abbreviation for the state name of the provider. Complete name of the country for other values.")
    , zip_cd                string    OPTIONS(description = "The number assigned by the US Postal Service to a geographic area for the purposes of efficient mail sorting and delivery.")
    , postal_code           string    OPTIONS(description = "The postal code of the provider.")
    , dea_nbr               string    OPTIONS(description = "Number assigned by the Federal DEA (Drug Enforcement Agency) to a physician, authorizing him/her to prescribe medications. Please note, for Provider Subject Area only: For EPD sourced records, DEA Number holds the complete alpha + numeric value. For COSMOS sourced records, the leading two alpha characters are stored in the DEA Alpha Number field, while the remaining numeric portion is stored in DEA Number. To retrieve the whole DEA Number for COSMOS records, you must concatenate DEA Alpha Number and DEA Number into a single value.")
    , medicaid_id           string    OPTIONS(description = "An identification number assigned to the provider by the State Medicaid Agency.")
    , mpin                  int64     OPTIONS(description = "Identifies a unique provider, regardless of location or affiliation. MPIN uniquely identifies providers carried on EPD (Expanded Provider Database). It also identifies unique Cosmos providers that have been assigned an MPIN by EPD.")
    , taxonomy_catgy_map    string    OPTIONS(description = "NPI taxonomy category or group mapping")
    , specialty_1_shortdesc string    OPTIONS(description = "The short description of the primary specialty of the provider.")
    , specialty_1_longdesc  string    OPTIONS(description = "The long/full description of the primary specialty of the provider.")
    , specialty_2_shortdesc string    OPTIONS(description = "The short description of the secondary specialty of the provider.")
    , specialty_2_longdesc  string    OPTIONS(description = "The full/long description of the secondary specialty of the provider.")
    , specialty_3_shortdesc string    OPTIONS(description = "The short description of the tertiary specialty of the provider.")
    , specialty_3_longdesc  string    OPTIONS(description = "The full/long description of the tertiary specialty of the provider.")
    , create_datetime       datetime  OPTIONS(description = "datetime record was created")
    )
  OPTIONS (description = "This is the dimension table for Provider NPI codes. It has a one row per provider granularity. Contains detail demographic information about health care providers. Examples of providers include physicians, hospitals, group practices, ancillaries, skilled nursing facilities, pharmacies, or any other individual or group of individuals that provide health care services. The Provider table includes such information as name, Tax Identification information, provider relationships, addressees, and specialties.") as
  with cte_mpin as (
    select a.npi, c.mpin
      , row_number() over(partition by a.npi order by b.effectivedt desc, createdt desc) as oid
    from (
            select distinct npi
            from `ds-00-191017.npi_final.npidata_pfile`

            union distinct
            select distinct safe_cast(lower(trim(provider_npi)) as int64) as npi
            from `ds-00-191017.sierrahealth_sma_final.provider`
          ) a
    inner join `ds-00-191017.ndb_final.npi` b on a.npi = safe_cast(lower(trim(b.natlprovid)) as int64)
    inner join `ds-00-191017.ndb_final.provider` c on b.mpin = c.mpin
    )
  , cte_taxgroup as (
      select a.npi, lower(trim(h.grouping)) as taxonomy_catgy_map
      from `ds-00-191017.npi_final.npidata_pfile` a
      inner join `research-01-217611.df_enrichment.npi_taxonomy`          g on lower(trim(a.healthcare_provider_taxonomy_code_1)) = lower(trim(g.code))   -- to get description and grouping of taxonomy code of the primary taxonomy code
      inner join `research-01-217611.df_enrichment.taxonomytocategorymap` h on lower(trim(g.grouping)) = lower(trim(h.grouping))  -- to map from taxonomy grouping to utilization category
      --where a.npi = 1194836262
    )
  , cte_specialty as (
      select *
        , row_number() over(partition by npi order by src = 'sma' desc) as oid
      from (
              select npi
                , max(case when oid = 1 then provider_specialty      else '' end) as specialty_1_shortdesc
                , max(case when oid = 1 then provider_specialty_long else '' end) as specialty_1_longdesc
                , max(case when oid = 2 then provider_specialty      else '' end) as specialty_2_shortdesc
                , max(case when oid = 2 then provider_specialty_long else '' end) as specialty_2_longdesc
                , max(case when oid = 3 then provider_specialty      else '' end) as specialty_3_shortdesc
                , max(case when oid = 3 then provider_specialty_long else '' end) as specialty_3_longdesc
                , 'sma' as src
              from (
                      select safe_cast(trim(provider_npi) as int64) as npi
                        , lower(trim(provider_name)) as provider_name
                        , lower(trim(provider_specialty)) as provider_specialty
                        , (case when lower(trim(provider_specialty)) = 'aba'   then 'behavior analyst'
                               when lower(trim(provider_specialty)) = 'acup'  then 'acupuncture'
                               when lower(trim(provider_specialty)) = 'addm'  then 'addiction medicine'
                               when lower(trim(provider_specialty)) = 'aero'  then 'aeropace medicine'
                               when lower(trim(provider_specialty)) = 'alim'  then 'allergy and immunology'
                               when lower(trim(provider_specialty)) = 'am'    then 'clinic/center ambulatory surgical'
                               when lower(trim(provider_specialty)) in ('amb', 'ambn')   then 'ambulance services'
                               when lower(trim(provider_specialty)) = 'amed'  then 'adolescent medicine'
                               when lower(trim(provider_specialty)) in ('an', 'anes')  then 'anesthesiology'
                               when lower(trim(provider_specialty)) = 'audi'  then 'audiology'
                               when lower(trim(provider_specialty)) in ('cardi', 'cd') then 'cardiovascular disease'
                               when lower(trim(provider_specialty)) = 'cele'  then 'clinical cardiac electrophysiology'
                               when lower(trim(provider_specialty)) in ('ch', 'chir')  then 'chiropractic medicine'
                               when lower(trim(provider_specialty)) = 'chne'  then 'child neurology'
                               when lower(trim(provider_specialty)) = 'cmed'  then 'critical care medicine'
                               when lower(trim(provider_specialty)) = 'cnur'  then 'clinical neurophysiology'
                               when lower(trim(provider_specialty)) = 'crsg'  then 'colon and rectal surgery'
                               when lower(trim(provider_specialty)) = 'dbpe'  then 'pediatric developmental & behavioral'
                               when lower(trim(provider_specialty)) = 'dent'  then 'dental medicine'
                               when lower(trim(provider_specialty)) = 'derm'  then 'dermatology'
                               when lower(trim(provider_specialty)) = 'derp'  then 'dermatopathology'
                               when lower(trim(provider_specialty)) in ('di', 'dial')    then 'dialysis center'
                               when lower(trim(provider_specialty)) in ('diet', 'nutr')  then 'dietitian'
                               when lower(trim(provider_specialty)) = 'emed'  then 'emergency medicine'
                               when lower(trim(provider_specialty)) = 'endo'  then 'endocrinology, diabetes, and metabolism'
                               when lower(trim(provider_specialty)) = 'endt'  then 'endodontics'
                               when lower(trim(provider_specialty)) in ('famp', 'hosf', 'hotf')  then 'family practice'
                               when lower(trim(provider_specialty)) = 'gast'  then 'gastroenterology'
                               when lower(trim(provider_specialty)) in ('genc', 'gene')  then 'genetic counselor'
                               when lower(trim(provider_specialty)) = 'germ'  then 'geriatric medicine'
                               when lower(trim(provider_specialty)) = 'ginf'  then 'medical genetics'
                               when lower(trim(provider_specialty)) = 'gp'    then 'general practice'
                               when lower(trim(provider_specialty)) = 'gyne'  then 'gynecology'
                               when lower(trim(provider_specialty)) = 'gyno'  then 'gynecologic oncology'
                               when lower(trim(provider_specialty)) in ('hdsg', 'orsg', 'porm')  then 'orthopedic surgery'
                               when lower(trim(provider_specialty)) = 'hema'  then 'hematology'
                               when lower(trim(provider_specialty)) in ('hemo', 'heon')  then 'hematology/oncology'
                               when lower(trim(provider_specialty)) = 'hoiv'  then 'home health/home infusion'
                               when lower(trim(provider_specialty)) = 'home'  then 'home health'
                               when lower(trim(provider_specialty)) = 'hopm'  then 'hospice and palliative medicine'
                               when lower(trim(provider_specialty)) in ('hosi', 'hoti', 'im', 'intm')  then 'internal medicine'
                               when lower(trim(provider_specialty)) in ('hosp', 'hotp')  then 'pediatrics'
                               when lower(trim(provider_specialty)) = 'host'  then 'hospitalist'
                               when lower(trim(provider_specialty)) = 'infd'  then 'infectious disease medicine'
                               when lower(trim(provider_specialty)) in ('lab', 'labo')  then 'laboratory'
                               when lower(trim(provider_specialty)) = 'infd'  then 'infectious disease medicine'
                               when lower(trim(provider_specialty)) = 'mafm'  then 'maternal & fetal med/perinatology'
                               when lower(trim(provider_specialty)) = 'maft'  then 'marriage and family therapy'
                               when lower(trim(provider_specialty)) = 'msup'  then 'medical supplies'
                               when lower(trim(provider_specialty)) = 'muls'  then 'multiple-single specialty group'
                               when lower(trim(provider_specialty)) = 'mult'  then 'multi-specialty group'
                               when lower(trim(provider_specialty)) = 'mwif'  then 'advanced practice midwife'
                               when lower(trim(provider_specialty)) = 'natu'  then 'naturopath'
                               when lower(trim(provider_specialty)) = 'neon'  then 'neonatology'
                               when lower(trim(provider_specialty)) in ('ne', 'neph', 'nepp')  then 'nephrology'
                               when lower(trim(provider_specialty)) in ('nesg', 'nu')  then 'neurological surgery'
                               when lower(trim(provider_specialty)) = 'neud'  then 'neuroradiology'
                               when lower(trim(provider_specialty)) = 'neum'  then 'neuromuscular medicine'
                               when lower(trim(provider_specialty)) = 'neup'  then 'neuropsychology'
                               when lower(trim(provider_specialty)) = 'neur'  then 'neurology'
                               when lower(trim(provider_specialty)) = 'nmed'  then 'nuclear medicine'
                               when lower(trim(provider_specialty)) in ('obcc', 'obgy', 'obst', 'og')  then 'obstetrics and gynecology'
                               when lower(trim(provider_specialty)) = 'occm'  then 'occupational medicine'
                               when lower(trim(provider_specialty)) = 'occu'  then 'occupational therapy'
                               when lower(trim(provider_specialty)) in ('om', 'omed', 'opto')  then 'optometry'
                               when lower(trim(provider_specialty)) in ('omxs', 'osgy')  then 'oral and maxillofacial surgery'
                               when lower(trim(provider_specialty)) in ('on', 'onco')    then 'oncology'
                               when lower(trim(provider_specialty)) = 'opat'  then 'oral pathology'
                               when lower(trim(provider_specialty)) in ('opth', 'ot')   then 'ophthalmology'
                               when lower(trim(provider_specialty)) in ('orth', 'othd') then 'orthodontics'
                               when lower(trim(provider_specialty)) in ('otol', 'ol')   then 'otolaryngology'
                               when lower(trim(provider_specialty)) = 'path'  then 'pathology'
                               when lower(trim(provider_specialty)) = 'peai'  then 'pediatric allergy immunology'
                               when lower(trim(provider_specialty)) = 'pecd'  then 'pediatric cardiology'
                               when lower(trim(provider_specialty)) = 'pecm'  then 'pediatric critical care medicine'
                               when lower(trim(provider_specialty)) = 'pedi'  then 'pediatrics'
                               when lower(trim(provider_specialty)) in ('pedt', 'perd')  then 'pedodontics'
                               when lower(trim(provider_specialty)) = 'peem'  then 'pediatric emergency medicine'
                               when lower(trim(provider_specialty)) = 'peen'  then 'pediatric endocrinology'
                               when lower(trim(provider_specialty)) = 'pega'  then 'pediatric gastroenterology'
                               when lower(trim(provider_specialty)) = 'peho'  then 'pediatric hematology oncology'
                               when lower(trim(provider_specialty)) = 'pein'  then 'pediatric infectious disease medicine'
                               when lower(trim(provider_specialty)) = 'pene'  then 'pediatric nephrology'
                               when lower(trim(provider_specialty)) = 'penu'  then 'pediatric neurology'
                               when lower(trim(provider_specialty)) = 'peor'  then 'pediatric orthopaedic surgery'
                               when lower(trim(provider_specialty)) = 'pepm'  then 'pediatric pulmonary medicine'
                               when lower(trim(provider_specialty)) = 'perh'  then 'pediatric rheumatology'
                               when lower(trim(provider_specialty)) = 'pesg'  then 'pediatric surgery'
                               when lower(trim(provider_specialty)) = 'pesm'  then 'pediatric sports medicine'
                               when lower(trim(provider_specialty)) = 'petx'  then 'pediatric medical toxicology'
                               when lower(trim(provider_specialty)) in ('pgmt', 'pmgt')  then 'pain management'
                               when lower(trim(provider_specialty)) in ('phar', 'rx')    then 'pharmacy'
                               when lower(trim(provider_specialty)) = 'phmr'  then 'physical medicine and rehabilitation'
                               when lower(trim(provider_specialty)) = 'phth'  then 'physical therapy'
                               when lower(trim(provider_specialty)) in ('pl', 'plsg')  then 'plastic surgery'
                               when lower(trim(provider_specialty)) = 'pmed'  then 'preventive medicine'
                               when lower(trim(provider_specialty)) in ('podi', 'pods')  then 'podiatry'
                               when lower(trim(provider_specialty)) = 'pros'  then 'prosthodontics'
                               when lower(trim(provider_specialty)) in ('psya', 'psyi', 'psyt', 'pysi')  then 'psychiatry'
                               when lower(trim(provider_specialty)) = 'psyf'  then 'forensic psychiatry'
                               when lower(trim(provider_specialty)) = 'psyg'  then 'geriatric psychiatry'
                               when lower(trim(provider_specialty)) = 'psyo'  then 'psychologist'
                               when lower(trim(provider_specialty)) = 'pubh'  then 'public health'
                               when lower(trim(provider_specialty)) in ('pulm', 'pm')  then 'pulmonary medicine'
                               when lower(trim(provider_specialty)) in ('radi', 'rd')  then 'radiology'
                               when lower(trim(provider_specialty)) = 'rado'  then 'radiation oncology'
                               when lower(trim(provider_specialty)) = 'reen'  then 'reproductive endocrinology'
                               when lower(trim(provider_specialty)) = 'rest'  then 'respiratory therapy'
                               when lower(trim(provider_specialty)) = 'rheu'  then 'rheumatology'
                               when lower(trim(provider_specialty)) = 'rn'    then 'registered nurse'
                               when lower(trim(provider_specialty)) = 'sc'    then 'surgery center'
                               when lower(trim(provider_specialty)) = 'scwr'  then 'clinical/medical social worker'
                               when lower(trim(provider_specialty)) = 'sk'    then 'skilled nursing facility'
                               when lower(trim(provider_specialty)) = 'smed'  then 'sports medicine'
                               when lower(trim(provider_specialty)) = 'sppt'  then 'speech pathology'
                               when lower(trim(provider_specialty)) = 'surc'  then 'surgical critical care'
                               when lower(trim(provider_specialty)) = 'surg'  then 'surgery'
                               when lower(trim(provider_specialty)) = 'thsg'  then 'thoracic cardiovascular surgery'
                               when lower(trim(provider_specialty)) in ('ur', 'urol')  then 'urology'
                               when lower(trim(provider_specialty)) = 'urct'  then 'urgent care medicine'
                               when lower(trim(provider_specialty)) = 'vasg'  then 'vasculary surgery'
                            else lower(trim(provider_specialty)) end) as provider_specialty_long
                        , row_number() over(partition by safe_cast(trim(provider_npi) as int64) order by lower(trim(provider_specialty)) <> '' desc) as oid
                     from  (
                             select distinct * except(provider_id, common_practitioner_id, provider_tax_id, provider_medicaid_id, provider_clinic_name, provider_clinic_nbr, uhgrd_load_utc_ts)
                               , row_number() over(partition by safe_cast(trim(provider_npi) as int64), lower(trim(provider_specialty)) order by lower(trim(uhgrd_load_id))) as rn
                             from `ds-00-191017.sierrahealth_sma_final.provider`
                             --where safe_cast(trim(provider_npi) as int64) = 1124006382 --1710948070
                           ) a
                     where rn = 1
                   ) a
              where oid between 1 and 3
              group by npi

              union all
              select a.npi
               , ifnull(max(lower(trim(b1.specialization))), '') as specialty_1_shortdesc
               , ifnull(max(lower(trim(b1.specialization))), '') as specialty_1_longdesc
               , ifnull(max(lower(trim(b2.specialization))), '') as specialty_2_shortdesc
               , ifnull(max(lower(trim(b2.specialization))), '') as specialty_2_longdesc
               , ifnull(max(lower(trim(b3.specialization))), '') as specialty_3_shortdesc
               , ifnull(max(lower(trim(b3.specialization))), '') as specialty_3_longdesc
               , 'npi' as src
              from `ds-00-191017.npi_final.npidata_pfile` a
              left join `research-01-217611.df_ucd_stage.npi_taxonomy` b1 on lower(trim(a.healthcare_provider_taxonomy_code_1)) = lower(trim(b1.code))
              left join `research-01-217611.df_ucd_stage.npi_taxonomy` b2 on lower(trim(a.healthcare_provider_taxonomy_code_2)) = lower(trim(b2.code))
              left join `research-01-217611.df_ucd_stage.npi_taxonomy` b3 on lower(trim(a.healthcare_provider_taxonomy_code_3)) = lower(trim(b3.code))
              group by a.npi
            ) a
    )
  , cte_demog as (
      select * except(oid, src)
        , row_number() over(partition by npi order by src = 'npi' desc) as oid
      from (
              select safe_cast(trim(a.provider_npi) as int64) as npi
                , '' as prov_type
                , cast(NULL as date) as enumeration_date
                , cast(NULL as date) as deactivation_date
                , cast(NULL as date) as reactivation_date
                , '' as deactivation_reason_cd, '' as prov_degree
                , ifnull(lower(trim(a.provider_name)), '') as full_name
                , '' as last_name, '' as first_name, '' as middle_name, '' as name_suffix, '' as gender
                , ifnull(lower(trim(a.provider_addr_line1)), '') as address_line1
                , ifnull(lower(trim(a.provider_addr_line2)), '') as address_line2
                , ifnull(lower(trim(a.provider_city)), '') as city
                , ifnull(lower(trim(a.provider_county)), '') as county
                , ifnull(lower(trim(a.provider_state)), '') as state
                , ifnull(lower(trim(a.provider_zip)), '') as zip_cd, '' as postal_code
                , ifnull(lower(trim(a.provider_dea)), '') as dea_nbr
                , ifnull(lower(trim(a.provider_medicaid_id)), '') as medicaid_id
                , row_number() over(partition by safe_cast(trim(a.provider_npi) as int64) order by lower(trim(a.provider_addr_line1)) <> '' desc, lower(trim(a.provider_addr_line2)) <> '' desc) as oid
                , 'sma' as src
              from (
                      select distinct * except(provider_id, common_practitioner_id, provider_tax_id, provider_clinic_name, provider_clinic_nbr, uhgrd_load_utc_ts)
                        , row_number() over(partition by safe_cast(trim(provider_npi) as int64), lower(trim(provider_specialty)) order by lower(trim(uhgrd_load_id))) as rn
                      from `ds-00-191017.sierrahealth_sma_final.provider`
                      --where safe_cast(trim(provider_npi) as int64) = 1124006382 --1710948070
                    ) a
              where rn = 1

              union all
              select npi
                , (case when entity_type_code = 1 then 'physician'
                        when entity_type_code = 2 then 'organization' else '' end) as prov_type
                , safe_cast(lower(trim(provider_enumeration_date)) as date) as enumeration_date
                , safe_cast(lower(trim(npi_deactivation_date)) as date) as deactivation_date
                , safe_cast(lower(trim(npi_reactivation_date)) as date) as reactivation_date
                , lower(trim(npi_deactivation_reason_code)) as deactivation_reason_cd
                , lower(trim(provider_credential_text)) as prov_degree
                , concat((case when entity_type_code = 2 then lower(trim(provider_organization_name__legal_business_name_)) else lower(trim(provider_last_name__legal_name_)) end), ', '
                            , lower(trim(provider_first_name)), ' ', lower(trim(provider_middle_name))) as full_name
                , (case when entity_type_code = 2 then lower(trim(provider_organization_name__legal_business_name_)) else lower(trim(provider_last_name__legal_name_)) end) as last_name
                , lower(trim(provider_first_name)) as first_name
                , lower(trim(provider_middle_name)) as middle_name
                , lower(trim(provider_name_suffix_text)) as name_suffix, lower(trim(provider_gender_code)) as gender
                , lower(trim(provider_first_line_business_mailing_address)) as address_line1, lower(trim(provider_second_line_business_mailing_address)) as address_line2, lower(trim(provider_business_mailing_address_city_name)) as city
                , '' as county, lower(trim(provider_business_mailing_address_state_name)) as state, left(lower(trim(provider_business_mailing_address_postal_code)), 5) as zip_cd
                , lower(trim(provider_business_mailing_address_postal_code)) as postal_code
                , '' as dea_nbr, '' as medicaid_id
                , 1 as oid
                , 'npi' as src
              from `ds-00-191017.npi_final.npidata_pfile`
          ) a
    )
  select a.npi, a.prov_type, a.enumeration_date, a.deactivation_date, a.reactivation_date, a.deactivation_reason_cd, a.prov_degree
    , case when a.prov_type = 'organization' then replace(a.full_name, ',', '') else a.full_name end as full_name
    , a.* except (npi, prov_type, enumeration_date, deactivation_date, reactivation_date, deactivation_reason_cd, prov_degree, full_name, oid)
    , ifnull(b.mpin, 0) as mpin
    , ifnull(d.taxonomy_catgy_map, '') as taxonomy_catgy_map
    , c.* except (npi, oid, src)
    , current_datetime as create_datetime
  from  (
          select *
          from cte_demog
          where oid = 1
        ) a
  left join cte_mpin      b on a.npi = b.npi and b.oid = 1
  left join cte_specialty c on a.npi = c.npi and c.oid = 1
  left join cte_taxgroup  d on a.npi = d.npi
  where a.npi is not null
  ;
  create or replace table `research-01-217611.df_ucd_stage.dim_provider`
  ( mpin                    int64     OPTIONS(description = "Identifies a unique provider, regardless of location or affiliation. MPIN uniquely identifies providers carried on EPD (Expanded Provider Database). It also identifies unique Cosmos providers that have been assigned an MPIN by EPD.")
    , prov_type             string    OPTIONS(description = "Provider classification including Organization (O) and Person/Physician (P).")
    , prov_status           string    OPTIONS(description = "Provider status; in/out of network")
    , mpin_create_dt        date      OPTIONS(description = "Date the mpin was first created")
    , cancel_dt             date      OPTIONS(description = "Date the mpin was cancelled")
    , effective_dt          date      OPTIONS(description = "DAte the mpin was effective")
    , org_type_cd           string    OPTIONS(description = "Identifies the organization type code of the mpin.")
    , org_type_shortdesc    string    OPTIONS(description = "The short description or abbreviation of the organization type code of the mpin.")
    , org_type_longdesc     string    OPTIONS(description = "The long/full description of the organization type code of the mpin.")
    , medicare_id           string    OPTIONS(description = "COSMOS only. An identification number assigned to the provider by HCFA (Health Care Financing Administration).")
    , dea_nbr               string    OPTIONS(description = "Number assigned by the Federal DEA (Drug Enforcement Agency) to a physician, authorizing him/her to prescribe medications. Please note, for Provider Subject Area only: For EPD sourced records, DEA Number holds the complete alpha + numeric value. For COSMOS sourced records, the leading two alpha characters are stored in the DEA Alpha Number field, while the remaining numeric portion is stored in DEA Number. To retrieve the whole DEA Number for COSMOS records, you must concatenate DEA Alpha Number and DEA Number into a single value.")
    , prov_degree           string    OPTIONS(description = "EPD only. Identifies the first occurance of a provider's degree, if populated. Data Placement: left justified, space filled.")
    , last_name             string    OPTIONS(description = "The last name of an individual provider.")
    , first_name            string    OPTIONS(description = "The first name of an individual provider.")
    , middle_name           string    OPTIONS(description = "The middle name of an individual provider.")
    , mi                    string    OPTIONS(description = "The middle initial of an individual provider.")
    , name_suffix           string    OPTIONS(description = "The name suffix of an individual provider.")
    , full_name             string    OPTIONS(description = "The full name of an individual provider.")
    , gender                string    OPTIONS(description = "The gender code of an individual provider.")
    , dob                   string    OPTIONS(description = "The date of birth of an individual provider.")
    , email_address         string    OPTIONS(description = "The email address of an individual provider.")
    , street                string    OPTIONS(description = "The street address/description of an individual provider.")
    , city                  string    OPTIONS(description = "The city associated with the provider, member, pharmacy, or customer segment address.")
    , county                string    OPTIONS(description = "The county associated with the provider, member, pharmacy, or customer segment address.")
    , st_cd                 string    OPTIONS(description = "The two-character US Postal Service Abbreviation for the state name of the provider.")
    , zip_cd            string    OPTIONS(description = "The number assigned by the US Postal Service to a geographic area for the purposes of efficient mail sorting and delivery.")
    , zip_pls_4_cd      string    OPTIONS(description = "The number that specifies the geographic segment within the zip code, such as a city block, an office building, or any other unit that aids the post office in efficient mail sorting and delivery.")
    , npi                   int64     OPTIONS(description = "The National Provider Identifier (NPI) was adopted as the standard unique health identifier for health care providers to carry out a requirement in the Health Insurance Portability and Accountability Act of 1996 (HIPAA) for the adoption of such a standard.")

    , taxonomy_catgy_map string OPTIONS(description= "NPI taxonomy category or group mapping")

    , pcp_flag              int64     OPTIONS(description = "Primary Care Physician flag; 1 if primary specialty codes are in ('001','008','011','019','037','038','041','077','230','236','251','258','272','273','274','275','276','281','282','338','339','375','384','506'), 0 otherwise.")
    , specialty_1_shortdesc string    OPTIONS(description = "The short description of the primary specialty of the provider.")
    , specialty_1_longdesc  string    OPTIONS(description = "The long/full description of the primary specialty of the provider.")
    , specialty_2_shortdesc string    OPTIONS(description = "The short description of the secondary specialty of the provider.")
    , specialty_2_longdesc  string    OPTIONS(description = "The full/long description of the secondary specialty of the provider.")
    , specialty_3_shortdesc string    OPTIONS(description = "The short description of the tertiary specialty of the provider.")
    , specialty_3_longdesc  string    OPTIONS(description = "The full/long description of the tertiary specialty of the provider.")
    , create_datetime       datetime  OPTIONS(description = "datetime record was created")
    )
  OPTIONS (description = "This is the dimension table for Provider MPIN codes. It has a one row per provider granularity. Contains detail demographic information about health care providers. Examples of providers include physicians, hospitals, group practices, ancillaries, skilled nursing facilities, pharmacies, or any other individual or group of individuals that provide health care services. The Provider table includes such information as name, Tax Identification information, provider relationships, addressees, and specialties.") as
  with cte_pcpflag as (
    select a.mpin
        , max(case when oid = 1 then trim(spectypecd) end) as spectypecd
        , max(case when oid = 1 then lower(trim(shortdesc)) end) as shortdesc
        , max(case when oid = 1 then lower(trim(longdesc))  end) as longdesc
        , max(case when oid = 1 then lower(trim(provtype))  end) as provtype
        , max(case when oid = 1 and trim(spectypecd) in ('001','008','011','019','037','038','041','077','230','236','251','258','272','273','274','275','276','281','282','338'
                                                      ,'339','375','384','506')  --codes used where taken from PAM project
                          then 1 Else 0 End) as pcp_flag
        , max(case when oid = 1 then safe_cast(trim(a.natlprovid) as int64) end) as npi
        , max(case when oid = 1 then lower(trim(shortdesc)) else '' end) as specialty_1_shortdesc
        , max(case when oid = 1 then lower(trim(longdesc )) else '' end) as specialty_1_longdesc
        , max(case when oid = 2 then lower(trim(shortdesc)) else '' end) as specialty_2_shortdesc
        , max(case when oid = 2 then lower(trim(longdesc )) else '' end) as specialty_2_longdesc
        , max(case when oid = 3 then lower(trim(shortdesc)) else '' end) as specialty_3_shortdesc
        , max(case when oid = 3 then lower(trim(longdesc )) else '' end) as specialty_3_longdesc
    from  (
     			    select a.mpin, c.spectypecd, c.shortdesc, c.longdesc, a.provtype
     			           , row_number() over(partition by a.mpin order by (case when lower(trim(b.primaryind)) = 'p' then 1 else 0 end) desc) as oid --not all MPINs have Primary specialties; assign a specialty
                     , d.natlprovid
     			    --select *
     			    from `ds-00-191017.ndb_final.provider`    a
     			    inner join `ds-00-191017.ndb_final.prov_specialties`   b on a.mpin = b.mpin
     			    left join `ds-00-191017.ndb_final.specialty_types`     c on trim(b.spectypecd) = trim(c.spectypecd)
              left join `ds-00-191017.ndb_final.npi`                 d on a.mpin = d.mpin
     		  ) a
    where oid between 1 and 3
    group by a.mpin
    )
  , cte_npi as (
      select a.mpin, cast(lower(trim(b.natlprovid)) as int64) as npi
        , row_number() over(partition by a.mpin order by b.effectivedt desc) as oid   --to assign the most recent npi to an mpin
        , lower(trim(h.grouping)) as taxonomy_catgy_map
      from `ds-00-191017.ndb_final.provider` a
      inner join `ds-00-191017.ndb_final.npi` b using (mpin)
      left join `ds-00-191017.npi_final.npidata_pfile` c on safe_cast(lower(trim(b.natlprovid)) as int64) = c.npi
      left join `research-01-217611.df_enrichment.npi_taxonomy`          g on lower(trim(c.healthcare_provider_taxonomy_code_1)) = lower(trim(g.code))   -- to get description and grouping of taxonomy code of the primary taxonomy code
      left join `research-01-217611.df_enrichment.taxonomytocategorymap` h on lower(trim(g.grouping)) = lower(trim(h.grouping))  -- to map from taxonomy grouping to utilization category
    )
  , cte_prov as (
      select *
        , row_number() over(partition by mpin order by (case when src = 'ndb'    then 1
                                                             when src = 'galaxy' then 2
                                                             when src = 'miniov' then 3 else 4 end)) as oid
      from (
              select distinct a.mpin, (case when lower(trim(a.provtype)) = 'o' then 'organization' else 'physician' end) as prov_type, lower(trim(a.provstatus)) as prov_status
                , cast(a.mpincreatedt as date) as mpin_create_dt, cast(a.canceldt as date) as cancel_dt, cast(a.effectivedt as date) as effective_dt
                , lower(trim(a.orgtypecd)) as org_type_cd, lower(trim(b.shortdesc)) as org_type_shortdesc, lower(trim(b.longdesc)) as org_type_longdesc
                , lower(trim(a.medicareid)) as medicare_id, lower(trim(d.deanbr)) as dea_nbr
                , lower(trim(a.provdegree)) as prov_degree, lower(trim(a.lastname)) as last_name, lower(trim(a.firstname)) as first_name, lower(trim(a.middlename)) as middle_name
                , lower(trim(a.mi)) as mi, lower(trim(a.namesuffix)) as name_suffix
                , concat(lower(trim(a.lastname)), ', ', lower(trim(a.firstname)), ' ', lower(trim(a.mi)), '. ', ifnull(lower(trim(a.namesuffix)), '')) as full_name
                , lower(trim(a.gender)) as gender, a.dob, lower(trim(a.emailaddress)) as email_address
                , c.* except(mpin, oid)
                , 'ndb' as src
              from `ds-00-191017.ndb_final.provider` a
              left join `ds-00-191017.ndb_final.org_types` b on lower(trim(a.orgtypecd)) = lower(trim(b.orgtypecd))
              left join (
                          select a.mpin, lower(trim(c.street)) as street, lower(trim(c.city)) as city, lower(trim(c.county)) as county, lower(trim(c.state)) as st_cd, trim(c.zipcd) as zip_cd, trim(c.zippls4) as zip_pls_4_cd
                            , row_number() over(partition by a.mpin order by (case when lower(trim(b.primadrind)) = 'p' then 1 else 0 end) desc) as oid
                          from `ds-00-191017.ndb_final.provider` a
                          inner join `ds-00-191017.ndb_final.mpin_location` b using (mpin)
                          inner join `ds-00-191017.ndb_final.prov_address`  c on b.addressid = c.addressid
                        ) c on a.mpin = c.mpin and c.oid = 1
              left join `ds-00-191017.ndb_final.dea_license` d on a.mpin = d.mpin and c.st_cd = lower(trim(d.deastate))

              union distinct
              select distinct mpin, lower(trim(prov_clss_cd)) as prov_type, '' as prov_status
                , cast(NULL as date) as mpin_create_dt, cast(NULL as date) as cancel_dt, cast(prov_orig_eff_dt as date) as effective_dt
                , '' as org_type_cd, '' as org_type_shortdesc, '' as org_type_longdesc
                , lower(trim(medcr_id_nbr)) as medicare_id, concat(lower(trim(dea_alph_nbr)), lower(trim(dea_nbr))) as dea_nbr
                , '' as prov_degree, lower(trim(lst_nm)) as last_name, lower(trim(fst_nm)) as first_name, '' as middle_name
                , '' as mi, '' as name_suffix
                , lower(trim(full_nm)) as full_name
                , lower(trim(gdr_cd)) as gender, cast(NULL as string) as dob, '' as email_address
                , concat(lower(trim(adr_ln_1_txt)), ' ' , lower(trim(adr_ln_2_txt))) as street, lower(trim(cty_nm)) as city, '' as county, lower(trim(st_abbr_cd)) as st_cd, trim(zip_cd) as zip_cd
                , trim(zip_pls_4_cd) as zip_pls_4_cd
                , 'galaxy' as src
              from `ds-00-191017.galaxy_final.dim_provider`

              union distinct
              select distinct mpin, '' as prov_type, '' as prov_status
                , cast(NULL as date) as mpin_create_dt, cast(NULL as date) as cancel_dt, cast(NULL as date) as effective_dt
                , '' as org_type_cd, '' as org_type_shortdesc, '' as org_type_longdesc
                , '' as medicare_id, concat(lower(trim(dea_alph_nbr)), lower(trim(dea_nbr))) as dea_nbr
                , '' as prov_degree, lower(trim(prov_lst_nm)) as last_name, lower(trim(prov_fst_nm)) as first_name, '' as middle_name
                , '' as mi, '' as name_suffix
                , lower(trim(full_nm)) as full_name
                , '' as gender, cast(NULL as string) as dob, '' as email_address
                , lower(trim(adr_ln_1_txt)) as street, lower(trim(cty_nm)) as city, '' as county, lower(trim(st_abbr_cd)) as st_cd, trim(zip_cd) as zip_cd
                , '' as zip_pls_4_cd
                , 'miniov' as src
              from `ds-00-191017.ugap_final.dim_ova_provider`

              union distinct
              select distinct mpin, '' as prov_type, '' as prov_status
                , cast(NULL as date) as mpin_create_dt, cast(NULL as date) as cancel_dt, cast(NULL as date) as effective_dt
                , '' as org_type_cd, '' as org_type_shortdesc, '' as org_type_longdesc
                , '' as medicare_id, '' as dea_nbr
                , '' as prov_degree, lower(trim(prov_lst_nm)) as last_name, lower(trim(prov_fst_nm)) as first_name, '' as middle_name
                , '' as mi, '' as name_suffix
                , concat(lower(trim(prov_lst_nm)), ', ', lower(trim(prov_fst_nm))) as full_name
                , '' as gender, cast(NULL as string) as dob, '' as email_address
                , '' as street, '' as city, '' as county, '' as st_cd, trim(zip_cd) as zip_cd
                , '' as zip_pls_4_cd
                , 'ugap' as src
              from `ds-00-191017.ugap_final.dim_hpdm_provider`
            ) z
    )
  select a.mpin, a.prov_type, a.prov_status, a.mpin_create_dt, a.cancel_dt, a.effective_dt, a.org_type_cd, a.org_type_shortdesc, a.org_type_longdesc, a.medicare_id, a.dea_nbr
    , a.prov_degree, a.last_name, a.first_name, a.middle_name, a.mi, a.name_suffix, a.full_name, a.gender, a.dob, a.email_address, a.street, a.city, a.county, a.st_cd, a.zip_cd, a.zip_pls_4_cd
    , b.npi
    , ifnull(b.taxonomy_catgy_map, '') as taxonomy_catgy_map
    , ifnull(c.pcp_Flag, 0) as pcp_flag
    , c.specialty_1_shortdesc, c.specialty_1_longdesc, c.specialty_2_shortdesc, c.specialty_2_longdesc, c.specialty_3_shortdesc, c.specialty_3_longdesc
    , current_datetime as create_datetime
  from (
          select *
          from cte_prov
          where oid = 1
         ) a
  left join cte_npi       b on a.mpin = b.mpin and b.oid = 1
  left join cte_pcpflag   c on a.mpin = c.mpin
  ;
  ----------------------
  --hp provider category code
  ----------------------
  create or replace table `research-01-217611.df_ucd_stage.dim_provider_category`
  ( prov_catgy_cd     string    OPTIONS(description = "Contains the three-char provider code to indicate the type of provider. Data Placement: right justified prefixed with zeroes.")
    , prov_catgy_desc string    OPTIONS(description = "Describes the Provider Category Code.")
    , prov_typ_nm     string    OPTIONS(description = "The lowest level aggregation of Provider Category Code describing the type of provider. For example General Acute-Care Hospital, Anesthesiology. Other column name: catgy_rol_up_1_desc")
    , spec_typ_nm     string    OPTIONS(description = "A secondary aggregation of Provider Category Code describing the type of provider. For example, Acute-Care Hospital, Specialist. Other column name: catgy_rol_up_2_desc")
    , catgy_rol_up_3_desc     string    OPTIONS(description = "A tertiary aggregation of Provider Category Code describing the type of provider. For example, Hospital, Non-Hospital")
    , catgy_rol_up_4_desc     string    OPTIONS(description = "The highest level aggregation of Provider Category Code describing the type of provider. For example, Facility, Professional.")
    , cos_prov_spcl_cd        int64     OPTIONS(description = "Identifies the primary specialty of the provider within COSMOS. Data Placement: left justified, space filled")
    , epd_prov_alph_spcl_cd   string    OPTIONS(description = "EPD only. Contains Provider specialty alpha code. VALID VALUES: For valid values, see table EPD_PROVIDER_ALPHABETICAL_SPECIALTY_CODE in Galaxy.")
    , facl_cd           string    OPTIONS(description = "EPD only. Identifies the type of facility. EPD only. Identifies the type of facility. Data Placement: right justified prefixed with zeroes")
    , imcs_prov_typ_cd  string    OPTIONS(description = "Type of provider service. Data Placement: left justified, space filled")
    , create_datetime   datetime  OPTIONS(description = "datetime record was created")
    )
  OPTIONS (description = "This is the dimension table for Provider category codes. It has a one row per ndc code granularity. Provider Category Code represents an integrated view of Provider Category, Facility Type, Provider Degree and Provider Specialty across all source systems EPD & Cosmos for Provider; Cosmos, Unet and IMCS for Claim. This dimension includes a detailed description of the Provider Category Code (ex: Master of Arts), and providers four higher level aggregations of the Provider Category Codes. Note: The Provider Degree Code that equals 'XXX' in the Provider Category Code dimension is only used in mapping, and is not a valid degree code. When new values come to Galaxy on claim records, rows are added to this table through an automated referential integrity process within Galaxy. This process is in place to prevent rows from being dropped when this table is joined to other tables within Galaxy. Fields on these rows are populated with default values. In cases where the new values are valid, they are updated manually by Galaxy's Data Quality team.") as
  select * except(src, oid)
    , current_datetime as create_datetime
  from  (
          select *
            , row_number() over(partition by prov_catgy_cd order by src = 'galaxy' desc) as oid
          from (
                 select distinct lower(trim(prov_catgy_cd)) as prov_catgy_cd, lower(trim(prov_catgy_desc)) as prov_catgy_desc, lower(trim(catgy_rol_up_1_desc)) as prov_typ_nm, lower(trim(catgy_rol_up_2_desc)) as spec_typ_nm
                    , lower(trim(catgy_rol_up_3_desc)) as catgy_rol_up_3_desc, lower(trim(catgy_rol_up_4_desc)) as catgy_rol_up_4_desc, cos_prov_spcl_cd
                    , lower(trim(epd_prov_alph_spcl_cd)) as epd_prov_alph_spcl_cd
                    , lower(trim(facl_cd)) as facl_cd, lower(trim(imcs_prov_typ_cd)) as imcs_prov_typ_cd
                   , 'galaxy' as src
                 from `ds-00-191017.galaxy_final.dim_provider_category_code`

                 union distinct
                 select distinct lower(trim(prov_catgy_cd)) as prov_catgy_cd, lower(trim(prov_typ_nm_2)) as prov_typ_nm_2, lower(trim(prov_typ_nm)) as prov_typ_nm, lower(trim(spec_typ_nm)) as spec_typ_nm
                    , '' as catgy_rol_up_3_desc, '' as catgy_rol_up_4_desc, NULL as cos_prov_spcl_cd, '' as epd_prov_alph_spcl_cd, '' as facl_cd, '' as imcs_prov_typ_cd
                   , 'ugap' as src
                 from `ds-00-191017.ugap_final.dim_hpdm_hp_provider_category_code`
               ) z
        ) a
  where oid = 1
  ;
  ----------------------
  --revenue code
  ----------------------
  create or replace table `research-01-217611.df_ucd_stage.dim_revenue_code`
  ( rvnu_cd             string  OPTIONS(description = 'Identifies a specific accommodation, ancillary service or billing calculation for facility claims. Revenue Codes can affect reimbursement of a facility claim, particularly outpatient facility claims.')
    , rvnu_desc         string   OPTIONS(description = "Describes a specific accommodation, ancillary service or billing calculation for facility claims. Revenue Codes can affect reimbursement of a facility claim, particularly outpatient facility claims.")
    , rvnu_grp_txt      string   OPTIONS(description = "A value in this field indicates a mid-level rollup of a revenue code to allow assignment to a specified group.")
    , rvnu_catgy_txt    string   OPTIONS(description = "A value in this field allows for a higher categorization of revenue codes.")
    , optnt_catgy_txt   string   OPTIONS(description = "The Healthplan Economics categorization of outpatient Revenue Codes.")
    , iptnt_catgy_txt   string   OPTIONS(description = "The Healthplan Economics categorization of inpatient Revenue Codes.")
    , sens_cond_ind     string   OPTIONS(description = "This indicator identifies whether a diagnosis code is considered sensitive such as mental health, abuse, etc.")
    , sens_cond_catgy   string   OPTIONS(description = "This category identifies the sensitive condition category (mental health, abuse, etc) if the sensitive condition indicator equals Y.")
    , create_datetime   datetime  OPTIONS(description = "datetime record was created")
    )
  OPTIONS (description = "This is the dimension table for revenue codes. It has a one row per revenue code granularity. A Revenue Code is an industry standard code (required by HCFA) which allows identification of a specific accommodation, ancillary service or billing calculation. Revenue Codes are used by hospitals, and other facilities, to identify and categorize services provided.") as
  select * except(oid, src)
    , current_datetime as create_datetime
  from (
          select *
            , row_number() over(partition by rvnu_cd order by src = 'ugap' desc) as oid
          from  (
                  select distinct lower(trim(rvnu_cd)) as rvnu_cd, lower(trim(rvnu_desc)) as rvnu_desc, lower(trim(rvnu_grp_txt)) as rvnu_grp_txt, lower(trim(rvnu_catgy_txt)) as rvnu_catgy_txt
                    , lower(trim(optnt_catgy_txt)) as optnt_catgy_txt, lower(trim(iptnt_catgy_txt)) as iptnt_catgy_txt, lower(trim(sens_cond_ind)) as sens_cond_ind, lower(trim(sens_cond_catgy)) as sens_cond_catgy
                    , 'ugap' as src
                  from `ds-00-191017.ugap_final.dim_hpdm_revenue_code`

                  union distinct
                  select distinct lower(trim(rvnu_cd)) as rvnu_cd, lower(trim(rvnu_desc)) as rvnu_desc, lower(trim(rvnu_grp_txt)) as rvnu_grp_txt, lower(trim(rvnu_catgy_txt)) as rvnu_catgy_txt
                    , lower(trim(optnt_catgy_txt)) as optnt_catgy_txt, lower(trim(iptnt_catgy_txt)) as iptnt_catgy_txt, '' as sens_cond_ind, '' as sens_cond_catgy
                    , 'galaxy' as src
                  from `ds-00-191017.galaxy_final.dim_revenue_code`
                ) x
        )
  where oid = 1
  ;
  ----------------------
  --NPI taxonomy table
  ----------------------
  create or replace table `research-01-217611.df_ucd_stage.dim_npi_taxonomy`
  ( npi                 int64    OPTIONS(description = "The National Provider Identifier (NPI) was adopted as the standard unique health identifier for health care providers to carry out a requirement in the Health Insurance Portability and Accountability Act of 1996 (HIPAA) for the adoption of such a standard.")
    , taxonomy_code     string   OPTIONS(description = "A unique 10-character code that designates NPI Provider classification and specialization.")
    , primary_flag      string   OPTIONS(description = "Flag for the NPI Provider's primary taxonomy code.")
    , create_datetime   datetime OPTIONS(description = "datetime record was created")
    )
  OPTIONS (description = "This is the dimension table for npi taxonomies or specialties. This table is a derived dimension table from the npi extracts we get in NPI Registry every month.") as
  select *
    , current_datetime as create_datetime
  from (
          select npi, if (lower (trim (Healthcare_Provider_Taxonomy_Code_1 ))           = '', null, lower (trim (Healthcare_Provider_Taxonomy_Code_1 )))            as taxonomy_code
                    , if (lower (trim (Healthcare_Provider_Primary_Taxonomy_Switch_1 )) = '', null, lower (trim (Healthcare_Provider_Primary_Taxonomy_Switch_1 )))  as primary_flag
          from `ds-00-191017.npi_final.npidata_pfile`
          union distinct
          select npi, if (lower (trim (Healthcare_Provider_Taxonomy_Code_2 ))           = '', null, lower (trim (Healthcare_Provider_Taxonomy_Code_2 )))            as taxonomy_code
                    , if (lower (trim (Healthcare_Provider_Primary_Taxonomy_Switch_2 )) = '', null, lower (trim (Healthcare_Provider_Primary_Taxonomy_Switch_2 )))  as primary_flag
          from `ds-00-191017.npi_final.npidata_pfile`
          union distinct
          select npi, if (lower (trim (Healthcare_Provider_Taxonomy_Code_3 ))           = '', null, lower (trim (Healthcare_Provider_Taxonomy_Code_3 )))            as taxonomy_code
                    , if (lower (trim (Healthcare_Provider_Primary_Taxonomy_Switch_3 )) = '', null, lower (trim (Healthcare_Provider_Primary_Taxonomy_Switch_3 )))  as primary_flag
          from `ds-00-191017.npi_final.npidata_pfile`
          union distinct
          select npi, if (lower (trim (Healthcare_Provider_Taxonomy_Code_4 ))           = '', null, lower (trim (Healthcare_Provider_Taxonomy_Code_4 )))            as taxonomy_code
                    , if (lower (trim (Healthcare_Provider_Primary_Taxonomy_Switch_4 )) = '', null, lower (trim (Healthcare_Provider_Primary_Taxonomy_Switch_4 )))  as primary_flag
          from `ds-00-191017.npi_final.npidata_pfile`
          union distinct
          select npi, if (lower (trim (Healthcare_Provider_Taxonomy_Code_5 ))           = '', null, lower (trim (Healthcare_Provider_Taxonomy_Code_5 )))            as taxonomy_code
                    , if (lower (trim (Healthcare_Provider_Primary_Taxonomy_Switch_5 )) = '', null, lower (trim (Healthcare_Provider_Primary_Taxonomy_Switch_5 )))  as primary_flag
          from `ds-00-191017.npi_final.npidata_pfile`
          union distinct
          select npi, if (lower (trim (Healthcare_Provider_Taxonomy_Code_6 ))           = '', null, lower (trim (Healthcare_Provider_Taxonomy_Code_6 )))            as taxonomy_code
                    , if (lower (trim (Healthcare_Provider_Primary_Taxonomy_Switch_6 )) = '', null, lower (trim (Healthcare_Provider_Primary_Taxonomy_Switch_6 )))  as primary_flag
          from `ds-00-191017.npi_final.npidata_pfile`
          union distinct
          select npi, if (lower (trim (Healthcare_Provider_Taxonomy_Code_7 ))           = '', null, lower (trim (Healthcare_Provider_Taxonomy_Code_7 )))            as taxonomy_code
                    , if (lower (trim (Healthcare_Provider_Primary_Taxonomy_Switch_7 )) = '', null, lower (trim (Healthcare_Provider_Primary_Taxonomy_Switch_7 )))  as primary_flag
          from `ds-00-191017.npi_final.npidata_pfile`
          union distinct
          select npi, if (lower (trim (Healthcare_Provider_Taxonomy_Code_8 ))           = '', null, lower (trim (Healthcare_Provider_Taxonomy_Code_8 )))            as taxonomy_code
                    , if (lower (trim (Healthcare_Provider_Primary_Taxonomy_Switch_8 )) = '', null, lower (trim (Healthcare_Provider_Primary_Taxonomy_Switch_8 )))  as primary_flag
          from `ds-00-191017.npi_final.npidata_pfile`
          union distinct
          select npi, if (lower (trim (Healthcare_Provider_Taxonomy_Code_9 ))           = '', null, lower (trim (Healthcare_Provider_Taxonomy_Code_9 )))            as taxonomy_code
                    , if (lower (trim (Healthcare_Provider_Primary_Taxonomy_Switch_9 )) = '', null, lower (trim (Healthcare_Provider_Primary_Taxonomy_Switch_9 )))  as primary_flag
          from `ds-00-191017.npi_final.npidata_pfile`
          union distinct
          select npi, if (lower (trim (Healthcare_Provider_Taxonomy_Code_10))           = '', null, lower (trim (Healthcare_Provider_Taxonomy_Code_10)))            as taxonomy_code
                    , if (lower (trim (Healthcare_Provider_Primary_Taxonomy_Switch_10)) = '', null, lower (trim (Healthcare_Provider_Primary_Taxonomy_Switch_10)))  as primary_flag
          from `ds-00-191017.npi_final.npidata_pfile`
          union distinct
          select npi, if (lower (trim (Healthcare_Provider_Taxonomy_Code_11))           = '', null, lower (trim (Healthcare_Provider_Taxonomy_Code_11)))            as taxonomy_code
                    , if (lower (trim (Healthcare_Provider_Primary_Taxonomy_Switch_11)) = '', null, lower (trim (Healthcare_Provider_Primary_Taxonomy_Switch_11)))  as primary_flag
          from `ds-00-191017.npi_final.npidata_pfile`
          union distinct
          select npi, if (lower (trim (Healthcare_Provider_Taxonomy_Code_12))           = '', null, lower (trim (Healthcare_Provider_Taxonomy_Code_12)))            as taxonomy_code
                    , if (lower (trim (Healthcare_Provider_Primary_Taxonomy_Switch_12)) = '', null, lower (trim (Healthcare_Provider_Primary_Taxonomy_Switch_12)))  as primary_flag
          from `ds-00-191017.npi_final.npidata_pfile`
          union distinct
          select npi, if (lower (trim (Healthcare_Provider_Taxonomy_Code_13))           = '', null, lower (trim (Healthcare_Provider_Taxonomy_Code_13)))            as taxonomy_code
                    , if (lower (trim (Healthcare_Provider_Primary_Taxonomy_Switch_13)) = '', null, lower (trim (Healthcare_Provider_Primary_Taxonomy_Switch_13)))  as primary_flag
          from `ds-00-191017.npi_final.npidata_pfile`
          union distinct
          select npi, if (lower (trim (Healthcare_Provider_Taxonomy_Code_14))           = '', null, lower (trim (Healthcare_Provider_Taxonomy_Code_14)))            as taxonomy_code
                    , if (lower (trim (Healthcare_Provider_Primary_Taxonomy_Switch_14)) = '', null, lower (trim (Healthcare_Provider_Primary_Taxonomy_Switch_14)))  as primary_flag
          from `ds-00-191017.npi_final.npidata_pfile`
          union distinct
          select npi, if (lower (trim (Healthcare_Provider_Taxonomy_Code_15))           = '', null, lower (trim (Healthcare_Provider_Taxonomy_Code_15)))            as taxonomy_code
                    , if (lower (trim (Healthcare_Provider_Primary_Taxonomy_Switch_15)) = '', null, lower (trim (Healthcare_Provider_Primary_Taxonomy_Switch_15)))  as primary_flag
          from `ds-00-191017.npi_final.npidata_pfile`
    ) z
  ;


  /*
  integrate the date dimensions that used to be in create_date_dimension_tables
  */
  --run on web-UI:
  CREATE OR REPLACE TABLE `research-01-217611.df_ucd_stage.dim_month`(
      month_id                      INT64   OPTIONS(description="sequentially ordered month identifier")
      , year_mo                     INT64   OPTIONS(description="year and month (ex: 201806)")
      , year_mo_str                 STRING  OPTIONS(description="year and month (ex: '201806')")
      , year_nbr                    INT64   OPTIONS(description="year (ex: 201806)")
      , month_nbr                   INT64   OPTIONS(description="month (ex: 6)")
      , month_start_date            DATE    OPTIONS(description="first day of the month")
      , month_midmonth_date         DATE    OPTIONS(description="15th day of the month")
      , month_end_date              DATE    OPTIONS(description="last day of the month")
      , month_days                  INT64   OPTIONS(description="number of days in the month")
      , year_qtr                    STRING  OPTIONS(description="quarter (ex: 2018Q2)")
      )
   OPTIONS(
     description="table of months, populated with one row for each month from 1900 to 2099"
   )
  AS
     select
       	row_number() over (order by min(full_dt)) as month_id
       	, 100 * EXTRACT(YEAR FROM full_dt) + EXTRACT(MONTH FROM full_dt) year_mo
        , format_date('%Y%m', min(full_dt)) year_mo_str
       	, max(EXTRACT(YEAR FROM full_dt)) year_nbr
       	, max(EXTRACT(MONTH FROM full_dt)) month_nbr
       	, min(full_dt) as month_start_date
        , max(case when extract(day from full_dt) = 15 then full_dt end) month_midmonth_date --use the 15th of the month, which is the date we use for membership verification
        , max(full_dt) as month_end_date
        , count(full_dt) as month_days
        , max(concat(cast(EXTRACT(YEAR FROM full_dt) as string), 'Q', cast(EXTRACT(QUARTER FROM full_dt) as string))) year_qtr
     from UNNEST(
         GENERATE_DATE_ARRAY(DATE('1900-01-01'), DATE('2099-12-31'), INTERVAL 1 DAY)
         ) AS full_dt
     group by year_mo
     ;

  CREATE OR REPLACE TABLE `research-01-217611.df_ucd_stage.dim_date` (
      full_dt                       DATE    OPTIONS(description="date (ex: 2018-06-18)")
     	, year_mo                     INT64   OPTIONS(description="year and month (ex: 201806)")
      , year_mo_str                 STRING  OPTIONS(description="year and month (ex: '201806')")
     	, year_nbr                    INT64   OPTIONS(description="year (ex: 2018)")
     	, month_nbr                   INT64   OPTIONS(description="month (ex: 6)")
      , day_nbr                     INT64   OPTIONS(description="day (ex: 18)")
     	, year_qtr                    STRING  OPTIONS(description="quarter (ex: 2018Q2)")
     	, month_id                    INT64   OPTIONS(description="sequentially ordered month identifier")
      , full_dt_str                 STRING  OPTIONS(description="date formated as string (ex: '2018-06-18')")
      , full_dt_str_yyyymmdd        STRING  OPTIONS(description="date formated as string (ex: '20180618')")
     	)
  AS
      select
          full_dt
          , 100 * EXTRACT(YEAR FROM full_dt) + EXTRACT(MONTH FROM full_dt) year_mo
          , format_date('%Y%m', full_dt) year_mo_str
          , EXTRACT(YEAR FROM full_dt) year_nbr
          , EXTRACT(MONTH FROM full_dt) month_nbr
          , EXTRACT(DAY FROM full_dt) day_nbr
          , concat(cast(EXTRACT(YEAR FROM full_dt) as string), 'Q', cast(EXTRACT(QUARTER FROM full_dt) as string)) year_qtr
          , dense_rank() over (order by format_date('%Y%m', full_dt)) as month_id
          , format_date('%F', full_dt) full_dt_str
          , format_date('%Y%m%d', full_dt) full_dt_str_yyyymmdd
      from UNNEST(
          GENERATE_DATE_ARRAY(DATE('1900-01-01'), DATE('2099-12-31'), INTERVAL 1 DAY)
          ) AS full_dt
  ;

  CREATE OR REPLACE TABLE `research-01-217611.df_ucd_stage.dim_date_limited` (
      full_dt                       DATE    OPTIONS(description="date (ex: 2018-06-18)")
      , year_mo                     INT64   OPTIONS(description="year and month (ex: 201806)")
      , year_mo_str                 STRING  OPTIONS(description="year and month (ex: '201806')")
      , year_nbr                    INT64   OPTIONS(description="year (ex: 2018)")
      , month_nbr                   INT64   OPTIONS(description="month (ex: 6)")
      , day_nbr                     INT64   OPTIONS(description="day (ex: 18)")
      , year_qtr                    STRING  OPTIONS(description="quarter (ex: 2018Q2)")
      , month_id                    INT64   OPTIONS(description="sequentially ordered month identifier")
      , full_dt_str                 STRING  OPTIONS(description="date formated as string (ex: '2018-06-18')")
      , full_dt_str_yyyymmdd        STRING  OPTIONS(description="date formated as string (ex: '20180618')")
      )
  AS
      select
          full_dt
          , 100 * EXTRACT(YEAR FROM full_dt) + EXTRACT(MONTH FROM full_dt) year_mo
          , format_date('%Y%m', full_dt) year_mo_str
          , EXTRACT(YEAR FROM full_dt) year_nbr
          , EXTRACT(MONTH FROM full_dt) month_nbr
          , EXTRACT(DAY FROM full_dt) day_nbr
          , concat(cast(EXTRACT(YEAR FROM full_dt) as string), 'Q', cast(EXTRACT(QUARTER FROM full_dt) as string)) year_qtr
          , dense_rank() over (order by format_date('%Y%m', full_dt)) as month_id
          , format_date('%F', full_dt) full_dt_str
          , format_date('%Y%m%d', full_dt) full_dt_str_yyyymmdd
      from UNNEST(
          GENERATE_DATE_ARRAY(DATE('2016-01-01'), DATE('2025-12-31'), INTERVAL 1 DAY)
          ) AS full_dt
   ;


 insert into `research-01-217611.df_ucd_stage.logging`(
   success_flag, job, message_datetime)
 select
   1 as success_flag
   , 'load dimension tables' as job
   , current_datetime as message_datetime
 ;


 EXCEPTION WHEN ERROR THEN
   insert into `research-01-217611.df_ucd_stage.logging`(
     success_flag, job, error_message, statement_text, formatted_stack_trace, message_datetime)
   select
     0 as success_flag
     , 'load dimension tables' as job
     , @@error.message as error_message
     , @@error.statement_text as statement_text
     , @@error.formatted_stack_trace as formatted_stack_trace
     , current_datetime as message_datetime
   ;


END
;
