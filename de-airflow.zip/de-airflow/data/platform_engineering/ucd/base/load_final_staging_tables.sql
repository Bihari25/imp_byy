/*
Normally I'm against doing an insert into without listing specific columns, but here each table was created from a template so I can be
fairly confident they're identical.


We make 2 copies of each table, one with only unrestricted members and one with only restricted members. (Might change the latter to *all* members later.)

*/

BEGIN

    insert into `research-01-217611.df_ucd_stage.final_diagnosis_claim`
      select * from `research-01-217611.df_ucd_stage.ucd_diagnosis_claim`
      where is_restricted = 0
      ;

    insert into `research-01-217611.df_ucd_stage.final_diagnosis_claim_ihr`
      select * from `research-01-217611.df_ucd_stage.ucd_diagnosis_claim_ihr`
      where is_restricted = 0
      ;

    insert into `research-01-217611.df_ucd_stage.final_ip_confinement`
      select * from `research-01-217611.df_ucd_stage.ip_confinement`
      where is_restricted = 0
      ;

    insert into `research-01-217611.df_ucd_stage.final_member_detail`
      select * from `research-01-217611.df_ucd_stage.udd_member_detail_consolidated`
      where is_restricted = 0
      ;

    insert into `research-01-217611.df_ucd_stage.final_member_detail_enriched`
      select * from `research-01-217611.df_ucd_stage.member_detail_enriched`
      where is_restricted = 0
      ;

    insert into `research-01-217611.df_ucd_stage.final_member_summary`
      select * from `research-01-217611.df_ucd_stage.member_summary`
      where is_restricted = 0
      ;

    insert into `research-01-217611.df_ucd_stage.final_medical_claim`
      select * from `research-01-217611.df_ucd_stage.udd_medical_claim_consolidated`
      where is_restricted = 0
      ;

    insert into `research-01-217611.df_ucd_stage.final_medical_claim_ihr`
      select * from `research-01-217611.df_ucd_stage.udd_medical_claim_ihr`
      where is_restricted = 0
      ;

    insert into `research-01-217611.df_ucd_stage.final_medical_claim_enriched`
      select * from `research-01-217611.df_ucd_stage.udd_medical_claim_enriched`
      where is_restricted = 0
      ;

    insert into `research-01-217611.df_ucd_stage.final_medical_claim_ihr_enriched`
      select * from `research-01-217611.df_ucd_stage.udd_medical_claim_ihr_enriched`
      where is_restricted = 0
      ;

    insert into `research-01-217611.df_ucd_stage.final_pharmacy_claim`
      select * from `research-01-217611.df_ucd_stage.udd_pharmacy_claim_consolidated`
      where is_restricted = 0
      ;

    insert into `research-01-217611.df_ucd_stage.final_pharmacy_claim_ihr`
      select * from `research-01-217611.df_ucd_stage.udd_pharmacy_claim_ihr`
      where is_restricted = 0
      ;

    insert into `research-01-217611.df_ucd_stage.final_pharmacy_claim_enriched`
      select * from `research-01-217611.df_ucd_stage.ucd_pharmacy_claim_enriched`
      where is_restricted = 0
      ;

    insert into `research-01-217611.df_ucd_stage.final_pharmacy_claim_ihr_enriched`
      select * from `research-01-217611.df_ucd_stage.ucd_pharmacy_claim_ihr_enriched`
      where is_restricted = 0
      ;

    insert into `research-01-217611.df_ucd_stage.final_member_plan_continuous_enrollment_period`
      select * from `research-01-217611.df_ucd_stage.member_plan_continuous_enrollment_period`
      where is_restricted = 0
      ;

    insert into `research-01-217611.df_ucd_stage.final_member_continuous_enrollment_period`
      select * from `research-01-217611.df_ucd_stage.member_continuous_enrollment_period`
      where is_restricted = 0
      ;

    insert into `research-01-217611.df_ucd_stage.final_member_comorbidity_scores`
      select * from `research-01-217611.df_ucd_stage.comorbid_scores`
      where is_restricted = 0
    ;

    insert into `research-01-217611.df_ucd_stage.final_member_cms_raf_scores`
      select * from `research-01-217611.df_ucd_stage.cms_raf_scores`
      where is_restricted = 0
    ;

    insert into `research-01-217611.df_ucd_stage.final_member_hhs_raf_scores`
      select * from `research-01-217611.df_ucd_stage.hhs_raf_scores`
      where is_restricted = 0
    ;




    insert into `research-01-217611.df_ucd_stage.final_diagnosis_claim_restricted`
      select * from `research-01-217611.df_ucd_stage.ucd_diagnosis_claim`
      where is_restricted = 1
      ;

    insert into `research-01-217611.df_ucd_stage.final_diagnosis_claim_ihr_restricted`
      select * from `research-01-217611.df_ucd_stage.ucd_diagnosis_claim_ihr`
      where is_restricted = 1
      ;

    insert into `research-01-217611.df_ucd_stage.final_ip_confinement_restricted`
      select * from `research-01-217611.df_ucd_stage.ip_confinement`
      where is_restricted = 1
      ;

    insert into `research-01-217611.df_ucd_stage.final_member_detail_restricted`
      select * from `research-01-217611.df_ucd_stage.udd_member_detail_consolidated`
      where is_restricted = 1
      ;

    insert into `research-01-217611.df_ucd_stage.final_member_detail_enriched_restricted`
      select * from `research-01-217611.df_ucd_stage.member_detail_enriched`
      where is_restricted = 1
      ;

    insert into `research-01-217611.df_ucd_stage.final_member_summary_restricted`
      select * from `research-01-217611.df_ucd_stage.member_summary`
      where is_restricted = 1
      ;

    insert into `research-01-217611.df_ucd_stage.final_medical_claim_restricted`
      select * from `research-01-217611.df_ucd_stage.udd_medical_claim_consolidated`
      where is_restricted = 1
      ;

    insert into `research-01-217611.df_ucd_stage.final_medical_claim_ihr_restricted`
      select * from `research-01-217611.df_ucd_stage.udd_medical_claim_ihr`
      where is_restricted = 1
      ;

    insert into `research-01-217611.df_ucd_stage.final_medical_claim_enriched_restricted`
      select * from `research-01-217611.df_ucd_stage.udd_medical_claim_enriched`
      where is_restricted = 1
      ;

    insert into `research-01-217611.df_ucd_stage.final_medical_claim_ihr_enriched_restricted`
      select * from `research-01-217611.df_ucd_stage.udd_medical_claim_ihr_enriched`
      where is_restricted = 1
      ;

    insert into `research-01-217611.df_ucd_stage.final_pharmacy_claim_restricted`
      select * from `research-01-217611.df_ucd_stage.udd_pharmacy_claim_consolidated`
      where is_restricted = 1
      ;

    insert into `research-01-217611.df_ucd_stage.final_pharmacy_claim_ihr_restricted`
      select * from `research-01-217611.df_ucd_stage.udd_pharmacy_claim_ihr`
      where is_restricted = 1
      ;

    insert into `research-01-217611.df_ucd_stage.final_pharmacy_claim_enriched_restricted`
      select * from `research-01-217611.df_ucd_stage.ucd_pharmacy_claim_enriched`
      where is_restricted = 1
      ;

    insert into `research-01-217611.df_ucd_stage.final_pharmacy_claim_ihr_enriched_restricted`
      select * from `research-01-217611.df_ucd_stage.ucd_pharmacy_claim_ihr_enriched`
      where is_restricted = 1
      ;

    insert into `research-01-217611.df_ucd_stage.final_member_plan_continuous_enrollment_period_restricted`
      select * from `research-01-217611.df_ucd_stage.member_plan_continuous_enrollment_period`
      where is_restricted = 1
      ;

    insert into `research-01-217611.df_ucd_stage.final_member_continuous_enrollment_period_restricted`
      select * from `research-01-217611.df_ucd_stage.member_continuous_enrollment_period`
      where is_restricted = 1
      ;

    insert into `research-01-217611.df_ucd_stage.final_member_comorbidity_scores_restricted`
      select * from `research-01-217611.df_ucd_stage.comorbid_scores`
      where is_restricted = 1
      ;

    insert into `research-01-217611.df_ucd_stage.final_member_cms_raf_scores_restricted`
      select * from `research-01-217611.df_ucd_stage.cms_raf_scores`
      where is_restricted = 1
      ;

    insert into `research-01-217611.df_ucd_stage.final_member_hhs_raf_scores_restricted`
      select * from `research-01-217611.df_ucd_stage.hhs_raf_scores`
      where is_restricted = 1
      ;


  --if successful, we'll get here!
  insert into `research-01-217611.df_ucd_stage.logging`(
    success_flag, job, message_datetime)
  select
    1 as success_flag
    , 'load the final staging tables' as job
    , current_datetime as message_datetime
  ;

  EXCEPTION WHEN ERROR THEN
    insert into `research-01-217611.df_ucd_stage.logging`(
      success_flag, job, error_message, statement_text, formatted_stack_trace, message_datetime)
    select
      0 as success_flag
      , 'load the final staging tables' as job
      , @@error.message as error_message
      , @@error.statement_text as statement_text
      , @@error.formatted_stack_trace as formatted_stack_trace
      , current_datetime as message_datetime
    ;

END
;
