BEGIN

    --monitor source data for potential changes in data_types, etc
    --this could also be used in the future (if we move it to the beginning of our refresh) to monitor tables for incremental changes and avoid updating unchanged data
    insert into `research-01-217611.df_ucd_stage.src_dataset_log`
      (table_reference_full , dataset_id , table_id , table_creation_time , table_last_modified_time , row_count , size_bytes , size_GB , column_name , data_type, log_datetime)
    select
      a.table_reference_full , a.dataset_id , a.table_id , a.table_creation_time , a.table_last_modified_time , a.row_count , a.size_bytes , a.size_GB , a.column_name , a.data_type
      , current_datetime() as log_datetime
    from
      `research-01-217611.df_ucd_stage.vw_info_final_all`         a
      left join `research-01-217611.df_ucd_stage.src_dataset_log` b on a.table_reference_full = b.table_reference_full
                                                                    and a.table_last_modified_time = b.table_last_modified_time
    where b.table_reference_full is null
    ;


    --monitor source data for record counts by month
    --this could also be used in the future (if we move it to the beginning of our refresh) to monitor tables for incremental changes and avoid updating unchanged data
    insert into  `research-01-217611.df_ucd_stage.src_record_count_log`
      (what_it_is, table_reference_full, table_last_modified_time, year_mo, ct_records, log_time)
    select
      a.what_it_is
      , a.table_reference_full
      , a.table_last_modified_time
      , a.year_mo
      , a.ct_records
      , a.log_time
    from
        (
        /* --------------------------------------------------------------------------- */
        /* ------------------------------  All Savers  ------------------------------- */
        /* --------------------------------------------------------------------------- */
        select
          'allsavers claims' what_it_is
          , '`ds-00-191017.allsavers_final.all_sv_claims`' table_reference_full
          , (select max(table_last_modified_time ) from `research-01-217611.df_ucd_stage.vw_info_allsavers_final` where table_id = 'all_sv_claims') as table_last_modified_time
          , cast(substr(fromdt, 1, 6) as int64) as year_mo
          , count(*) as ct_records
          , current_timestamp() as log_time
        from `ds-00-191017.allsavers_final.all_sv_claims`
        --where fromdt > '20160000'
        group by what_it_is
          , table_reference_full
          , table_last_modified_time
          , year_mo

        union all

        /* --------------------------------------------------------------------------- */
        /* ------------------------------     Bind     ------------------------------- */
        /* --------------------------------------------------------------------------- */
        select
          'bind med' what_it_is
          , '`ds-00-191017.bind_final.medical_claim`' table_reference_full
          , (select max(table_last_modified_time ) from `research-01-217611.df_ucd_stage.vw_info_bind_final` where table_id = 'medical_claim') as table_last_modified_time
          , cast(FORMAT_DATE('%Y%m', service_start_date ) AS int64) as year_mo
          , count(*) as ct_records
          , current_timestamp() as log_time
        from `ds-00-191017.bind_final.medical_claim`
        --where service_start_date between '2016-01-01' and current_date()
        group by what_it_is
          , table_reference_full
          , table_last_modified_time
          , year_mo

        union all

        select
          'bind rx' what_it_is
          , '`ds-00-191017.bind_final.pharmacy_claim`' table_reference_full
          , (select max(table_last_modified_time ) from `research-01-217611.df_ucd_stage.vw_info_bind_final` where table_id = 'pharmacy_claim') as table_last_modified_time
          , cast(FORMAT_DATE('%Y%m', date_of_service ) AS int64) as year_mo
          , count(*) as ct_records
          , current_timestamp() as log_time
        from `ds-00-191017.bind_final.pharmacy_claim`
        --where date_of_service between '2016-01-01' and current_date()
        group by what_it_is
          , table_reference_full
          , table_last_modified_time
          , year_mo

        union all

        select 'bind membership' what_it_is
              , '`ds-00-191017.bind_final.member_enrollment`' table_reference_full
              , (select max(table_last_modified_time ) from `research-01-217611.df_ucd_stage.vw_info_bind_final` where table_id = 'member_enrollment') as table_last_modified_time
              , dt.year_mo as year_mo
              , count(*) as ct_records
              , current_timestamp() as log_time
        from `ds-00-191017.bind_final.member_enrollment`          bind
        join `research-01-217611.df_ucd_stage.dim_month`          dt on dt.month_midmonth_date BETWEEN bind.coverage_effective_date and bind.coverage_termination_date
        --where dt.year_mo in (201901, 201604, 202007)
        group by what_it_is
              , table_reference_full
              , table_last_modified_time
              , year_mo

        union all

        /* --------------------------------------------------------------------------- */
        /* ------------------------------    Galaxy    ------------------------------- */
        /* --------------------------------------------------------------------------- */
        select
          'galaxy med' what_it_is
          , '`ds-00-191017.galaxy_final.unet_claim_statistical_service`' table_reference_full
          , (select max(table_last_modified_time ) from `research-01-217611.df_ucd_stage.vw_info_galaxy_final` where table_id = 'unet_claim_statistical_service') as table_last_modified_time
          , cast(FORMAT_DATE('%Y%m', fst_srvc_dt) as int64) as year_mo
          , count(*) as ct_records
          , current_timestamp() as log_time
        from  `ds-00-191017.galaxy_final.unet_claim_statistical_service`
        --where extract(year from fst_srvc_dt) between 2016 and extract(year from current_date())
        group by what_it_is
          , table_reference_full
          , table_last_modified_time
          , year_mo


        union all

        select
          'galaxy rx' what_it_is
          , '`ds-00-191017.galaxy_final.pharmacy_claims`' table_reference_full
          , (select max(table_last_modified_time ) from `research-01-217611.df_ucd_stage.vw_info_galaxy_final` where table_id = 'pharmacy_claims') as table_last_modified_time
          , cast(FORMAT_DATE('%Y%m', fill_dt ) as int64) as year_mo
          , count(*) as ct_records
          , current_timestamp() as log_time
        from  `ds-00-191017.galaxy_final.pharmacy_claims`
        --where extract(year from fill_dt) between 2016 and extract(year from current_date())
        group by what_it_is
          , table_reference_full
          , table_last_modified_time
          , year_mo

        union all

        select 'galaxy membership' what_it_is
              , '`ds-00-191017.galaxy_final.member_coverage_month`' table_reference_full
              , (select max(table_last_modified_time ) from `research-01-217611.df_ucd_stage.vw_info_galaxy_final` where table_id = 'member_coverage_month') as table_last_modified_time
              , b.year_mo as year_mo
              , count(*) as ct_records
              , current_timestamp() as log_time
        from `ds-00-191017.galaxy_final.member_coverage_month`  a
        inner join `research-01-217611.df_ucd_stage.dim_month`  b on b.month_midmonth_date between a.mbr_cov_mo_row_eff_dt  and a.mbr_cov_mo_row_end_dt
        group by what_it_is
              , table_reference_full
              , table_last_modified_time
              , year_mo

        union all

        /* --------------------------------------------------------------------------- */
        /* ------------------------------ Healthscope  ------------------------------- */
        /* --------------------------------------------------------------------------- */
        select
          'healthscope bob med' what_it_is
          , '`ds-00-191017.healthscope_final.hsb_bob_claims`' table_reference_full
          , (select max(table_last_modified_time ) from `research-01-217611.df_ucd_stage.vw_info_healthscope_final` where table_id = 'hsb_bob_claims') as table_last_modified_time
          , cast(FORMAT_DATE('%Y%m', servicedate ) AS int64) as year_mo
          , count(*) as ct_records
          , current_timestamp() as log_time
        from `ds-00-191017.healthscope_final.hsb_bob_claims`
        --where servicedate between '2016-01-01' and current_date()
        group by what_it_is
          , table_reference_full
          , table_last_modified_time
          , year_mo

        union all

        select
          'healthscope bob rx' what_it_is
          , '`ds-00-191017.healthscope_final.hsb_bob_rx`' table_reference_full
          , (select max(table_last_modified_time ) from `research-01-217611.df_ucd_stage.vw_info_healthscope_final` where table_id = 'hsb_bob_rx') as table_last_modified_time
          , cast(FORMAT_DATE('%Y%m', filldate ) AS int64) as year_mo
          , count(*) as ct_records
          , current_timestamp() as log_time
        from `ds-00-191017.healthscope_final.hsb_bob_rx`
        --where filldate between '2016-01-01' and current_date()
        group by what_it_is
          , table_reference_full
          , table_last_modified_time
          , year_mo

        union all

        select
          'healthscope walmart med' what_it_is
          , '`ds-00-191017.healthscope_final.hsb_walmart_claims`' table_reference_full
          , (select max(table_last_modified_time ) from `research-01-217611.df_ucd_stage.vw_info_healthscope_final` where table_id = 'hsb_walmart_claims') as table_last_modified_time
          , cast(FORMAT_DATE('%Y%m', servicedate ) AS int64) as year_mo
          , count(*) as ct_records
          , current_timestamp() as log_time
        from `ds-00-191017.healthscope_final.hsb_walmart_claims`
        --where servicedate between '2016-01-01' and current_date()
        group by what_it_is
          , table_reference_full
          , table_last_modified_time
          , year_mo

        union all

        select
          'healthscope walmart rx' what_it_is
          , '`ds-00-191017.healthscope_final.hsb_walmart_rx`' table_reference_full
          , (select max(table_last_modified_time ) from `research-01-217611.df_ucd_stage.vw_info_healthscope_final` where table_id = 'hsb_walmart_rx') as table_last_modified_time
          , cast(FORMAT_DATE('%Y%m', filldate ) AS int64) as year_mo
          , count(*) as ct_records
          , current_timestamp() as log_time
        from `ds-00-191017.healthscope_final.hsb_walmart_rx`
        --where filldate between '2016-01-01' and current_date()
        group by what_it_is
          , table_reference_full
          , table_last_modified_time
          , year_mo

        union all

        select 'healthscope bob membership' what_it_is
              , '`ds-00-191017.healthscope_final.hsb_bob_enroll`' table_reference_full
              , (select max(table_last_modified_time ) from `research-01-217611.df_ucd_stage.vw_info_healthscope_final` where table_id = 'hsb_bob_enroll') as table_last_modified_time
              , b.year_mo as year_mo
              , count(*) as ct_records
              , current_timestamp() as log_time
        from `ds-00-191017.healthscope_final.hsb_bob_enroll`    a
        inner join `research-01-217611.df_ucd_stage.dim_month`  b on b.month_midmonth_date between a.eligibilityeffectivedate and a.eligibilitytermdate
        group by what_it_is
              , table_reference_full
              , table_last_modified_time
              , year_mo

        union all

        select 'healthscope walmart membership' what_it_is
              , '`ds-00-191017.healthscope_final.hsb_walmart_enroll`' table_reference_full
              , (select max(table_last_modified_time ) from `research-01-217611.df_ucd_stage.vw_info_healthscope_final` where table_id = 'hsb_walmart_enroll') as table_last_modified_time
              , b.year_mo as year_mo
              , count(*) as ct_records
              , current_timestamp() as log_time
        from `ds-00-191017.healthscope_final.hsb_walmart_enroll` a
        inner join `research-01-217611.df_ucd_stage.dim_month`   b on b.month_midmonth_date between a.eligibilityeffectivedate and a.eligibilitytermdate
        group by what_it_is
              , table_reference_full
              , table_last_modified_time
              , year_mo

        union all

        /* --------------------------------------------------------------------------- */
        /* ------------------------------     IHR      ------------------------------- */
        /* --------------------------------------------------------------------------- */
        --rules for setting clm_dt are complex, but we're just trying to catch big changes in reported claims so it's fine if we just use some reasonable rule here
        select
          'ihr med' what_it_is
          , '`ds-00-191017.ihr_final.medical_claim`' table_reference_full
          , (select max(table_last_modified_time ) from `research-01-217611.df_ucd_stage.vw_info_ihr_final` where table_id = 'medical_claim') as table_last_modified_time
          , cast(year_mo_str as int64) as year_mo
          , count(*) as ct_records
          , current_timestamp() as log_time
        from
            (select
                coalesce(FORMAT_DATE('%Y%m',service_start_date) --use service_start_date if it exists
                          , substr(admission_from_date,1,6)      --otherwise, admission_from_date
                          , substr(statement_from_date,1,6)      --otherwise, statement_from_date
                        ) as year_mo_str
            from `ds-00-191017.ihr_final.medical_claim`
            )
        --where year_mo_str between '2016' and FORMAT_DATE('%Y%m', current_date())
        group by what_it_is
          , table_reference_full
          , table_last_modified_time
          , year_mo

        union all

        select
          'ihr rx' what_it_is
          , '`ds-00-191017.ihr_final.rx`' table_reference_full
          , (select max(table_last_modified_time ) from `research-01-217611.df_ucd_stage.vw_info_ihr_final` where table_id = 'rx') as table_last_modified_time
          , cast(FORMAT_DATE('%Y%m', date_of_service) AS int64) as year_mo
          , count(*) as ct_records
          , current_timestamp() as log_time
        from `ds-00-191017.ihr_final.rx`
        --where date_of_service between '2016-01-01' and current_date()
        group by what_it_is
          , table_reference_full
          , table_last_modified_time
          , year_mo


        union all


        /* --------------------------------------------------------------------------- */
        /* ------------------------------     SMA      ------------------------------- */
        /* --------------------------------------------------------------------------- */
        select
          'sma med' what_it_is
          , '`ds-00-191017.sierrahealth_sma_final.medical`' table_reference_full
          , (select max(table_last_modified_time ) from `research-01-217611.df_ucd_stage.vw_info_sierrahealth_sma_final` where table_id = 'medical') as table_last_modified_time
          , cast(FORMAT_DATE('%Y%m', service_date ) AS int64) as year_mo
          , count(*) as ct_records
          , current_timestamp() as log_time
        from `ds-00-191017.sierrahealth_sma_final.medical`
        --where service_date between '2016-01-01' and current_date()
        group by what_it_is
          , table_reference_full
          , table_last_modified_time
          , year_mo

        union all

        select
          'sma rx' what_it_is
          , '`ds-00-191017.sierrahealth_sma_final.pharmacy`' table_reference_full
          , (select max(table_last_modified_time ) from `research-01-217611.df_ucd_stage.vw_info_sierrahealth_sma_final` where table_id = 'pharmacy') as table_last_modified_time
          , cast(FORMAT_DATE('%Y%m', fill_date ) AS int64) as year_mo
          , count(*) as ct_records
          , current_timestamp() as log_time
        from `ds-00-191017.sierrahealth_sma_final.pharmacy`
        --where fill_date between '2016-01-01' and current_date()
        group by what_it_is
          , table_reference_full
          , table_last_modified_time
          , year_mo

        union all

        select 'sma membership' what_it_is
              , '`ds-00-191017.sierrahealth_sma_final.enroll`' table_reference_full
              , (select max(table_last_modified_time ) from `research-01-217611.df_ucd_stage.vw_info_sierrahealth_sma_final` where table_id = 'enroll') as table_last_modified_time
              , b.year_mo as year_mo
              , count(*) as ct_records
              , current_timestamp() as log_time
        from `ds-00-191017.sierrahealth_sma_final.enroll`       a
        inner join `research-01-217611.df_ucd_stage.dim_month`  b on b.month_midmonth_date between a.eligibility_effective_date and a.eligibility_term_date
        group by what_it_is
              , table_reference_full
              , table_last_modified_time
              , year_mo

        union all

        /* --------------------------------------------------------------------------- */
        /* ------------------------------     UDW      ------------------------------- */
        /* --------------------------------------------------------------------------- */
        select 'udw membership' what_it_is
              , '`ds-00-191017.udw_final.member_coverage`' table_reference_full
              , (select max(table_last_modified_time ) from `research-01-217611.df_ucd_stage.vw_info_udw_final` where table_id = 'member_coverage') as table_last_modified_time
              , dt.year_mo as year_mo
              , count(*) as ct_records
              , current_timestamp() as log_time
        from `ds-00-191017.udw_final.member_coverage`            udw
        join `research-01-217611.df_ucd_stage.dim_month`          dt on dt.month_midmonth_date BETWEEN udw.cov_eff_dt and udw.cov_expir_dt
        --where dt.year_mo in (201901, 201604, 202007)
        group by what_it_is
              , table_reference_full
              , table_last_modified_time
              , year_mo

        union all

        /* --------------------------------------------------------------------------- */
        /* ------------------------------     UGAP     ------------------------------- */
        /* --------------------------------------------------------------------------- */
        select
          what_it_is
          , table_reference_full
          , table_last_modified_time
          , cast(b.year_mo as int64) as year_mo
          , count(*) as ct_records
          , current_timestamp() as log_time
        from
          (         select '`ds-00-191017.ugap_final.fact_hpdm_demographics`' as table_reference_full, 'ugap hpdm membership' as what_it_is,  dt_sys_id as dt_sys_id            from `ds-00-191017.ugap_final.fact_hpdm_demographics`
          union all select '`ds-00-191017.ugap_final.fact_hpdm_inpatient`' as table_reference_full,    'ugap hpdm ip' as what_it_is,          admit_dt_sys_id as dt_sys_id      from `ds-00-191017.ugap_final.fact_hpdm_inpatient`
          union all select '`ds-00-191017.ugap_final.fact_hpdm_outpatient`' as table_reference_full,   'ugap hpdm op' as what_it_is,          fst_srvc_dt_sys_id as dt_sys_id   from `ds-00-191017.ugap_final.fact_hpdm_outpatient`
          union all select '`ds-00-191017.ugap_final.fact_hpdm_pharmacy`' as table_reference_full,     'ugap hpdm rx' as what_it_is,          fill_dt_sys_id as dt_sys_id       from `ds-00-191017.ugap_final.fact_hpdm_pharmacy`
          union all select '`ds-00-191017.ugap_final.fact_hpdm_physician`' as table_reference_full,    'ugap hpdm dr' as what_it_is,          fst_srvc_dt_sys_id as dt_sys_id   from `ds-00-191017.ugap_final.fact_hpdm_physician`
          union all select '`ds-00-191017.ugap_final.fact_ova_demographics`' as table_reference_full,  'ugap ov membership' as what_it_is,    dt_sys_id as dt_sys_id            from `ds-00-191017.ugap_final.fact_ova_demographics`
          union all select '`ds-00-191017.ugap_final.fact_ova_inpatient`' as table_reference_full,     'ugap ov ip' as what_it_is,            admit_dt_sys_id as dt_sys_id      from `ds-00-191017.ugap_final.fact_ova_inpatient`
          union all select '`ds-00-191017.ugap_final.fact_ova_outpatient`' as table_reference_full,    'ugap ov op' as what_it_is,            fst_srvc_dt_sys_id as dt_sys_id   from `ds-00-191017.ugap_final.fact_ova_outpatient`
          union all select '`ds-00-191017.ugap_final.fact_ova_pharmacy`' as table_reference_full,      'ugap ov rx' as what_it_is,            fill_dt_sys_id as dt_sys_id       from `ds-00-191017.ugap_final.fact_ova_pharmacy`
          union all select '`ds-00-191017.ugap_final.fact_ova_physician`' as table_reference_full,     'ugap ov dr' as what_it_is,            fst_srvc_dt_sys_id as dt_sys_id   from `ds-00-191017.ugap_final.fact_ova_physician`
          ) a
          join `ds-00-191017.ugap_final.dim_hpdm_date` b using (dt_sys_id)
          join (select distinct table_reference_full , table_last_modified_time from `research-01-217611.df_ucd_stage.vw_info_ugap_final`) using (table_reference_full)
        --where b.full_dt between '2016-01-01' and current_date()
        group by what_it_is
          , table_reference_full
          , table_last_modified_time
          , year_mo

        union all

        /* --------------------------------------------------------------------------- */
        /* ------------------------------     UMR      ------------------------------- */
        /* --------------------------------------------------------------------------- */
        select
          what_it_is
          , table_reference_full
          , table_last_modified_time
          , cast(b.year_mo as int64) as year_mo
          , count(*) as ct_records
          , current_timestamp() as log_time
        from
          (         select '`ds-00-191017.umr_final.umr_demographics`' as table_reference_full, 'umr membership' as what_it_is,  dt_sys_id as dt_sys_id            from `ds-00-191017.umr_final.umr_demographics`
          union all select '`ds-00-191017.umr_final.umr_inpatient`' as table_reference_full,    'umr ip' as what_it_is,          admit_dt_sys_id as dt_sys_id      from `ds-00-191017.umr_final.umr_inpatient`
          union all select '`ds-00-191017.umr_final.umr_outpatient`' as table_reference_full,   'umr op' as what_it_is,          fst_srvc_dt_sys_id as dt_sys_id   from `ds-00-191017.umr_final.umr_outpatient`
          union all select '`ds-00-191017.umr_final.umr_pharmacy`' as table_reference_full,     'umr rx' as what_it_is,          fill_dt_sys_id as dt_sys_id       from `ds-00-191017.umr_final.umr_pharmacy`
          union all select '`ds-00-191017.umr_final.umr_physician`' as table_reference_full,    'umr dr' as what_it_is,          fst_srvc_dt_sys_id as dt_sys_id   from `ds-00-191017.umr_final.umr_physician`
          ) a
          join `ds-00-191017.umr_final.hp_date` b using (dt_sys_id)
          join (select distinct table_reference_full , table_last_modified_time from `research-01-217611.df_ucd_stage.vw_info_umr_final`) using (table_reference_full)
        --where b.full_dt between '2016-01-01' and current_date()
        group by what_it_is
          , table_reference_full
          , table_last_modified_time
          , year_mo

    ) a
    left join (select distinct table_reference_full, table_last_modified_time from `research-01-217611.df_ucd_stage.src_record_count_log`) b on a.table_reference_full = b.table_reference_full
                                                                                                                                             and a.table_last_modified_time = b.table_last_modified_time
    where
      year_mo between 201601 and cast(FORMAT_DATE('%Y%m', current_date()) AS int64)
      and b.table_reference_full is null --only load changed data
    ;


  --if successful, we'll get here!
  insert into `research-01-217611.df_ucd_stage.logging`(
  	success_flag, job, message_datetime)
  select
  	1 as success_flag
  	, 'load source audit tables' as job
  	, current_datetime as message_datetime
  ;

  EXCEPTION WHEN ERROR THEN
  	insert into `research-01-217611.df_ucd_stage.logging`(
  		success_flag, job, error_message, statement_text, formatted_stack_trace, message_datetime)
  	select
  		0 as success_flag
      , 'load source audit tables' as job
    	, @@error.message as error_message
  		, @@error.statement_text as statement_text
  		, @@error.formatted_stack_trace as formatted_stack_trace
  		, current_datetime as message_datetime
  	;


END
;
