BEGIN

  DECLARE table_id STRING;
  DECLARE table_last_modified_date DATE;
  DECLARE start_comparison_period_suffix STRING;
  DECLARE end_comparison_period_suffix STRING;


    /*************  membership  *************/
    --do some initial validation on the pharmacy_claim_enriched table
    SET (table_id, table_last_modified_date, start_comparison_period_suffix, end_comparison_period_suffix) = (
      SELECT AS STRUCT
          table_id
          , cast(table_last_modified_time as date)  table_last_modified_date
          , format_date('%Y%m%d', date_add(cast(table_last_modified_time as date), interval -1 month)) start_comparison_period_suffix
          , format_date('%Y%m%d', date_add(cast(table_last_modified_time as date), interval -1 day)) end_comparison_period_suffix
      from `research-01-217611.df_ucd.vw_info`
      where table_id = 'member_detail'
      and ordinal_position = 1 --just one row for each table
      );

    insert into `research-01-217611.df_ucd_stage.auditing`
    	(table_id, table_last_modified_date, measure, measure_data_type, current_value, min_old_value, max_old_value, change, change_unit, message_datetime)
    with
      arc as
        (select  _table_suffix which_version, count(*) row_count, count(distinct savvy_pid) mbr_count, count(distinct savvy_pid || ' . ' || year_mo) mm_count
        from `research-01-217611.df_ucd.member_detail_arc_*` rx
        where rx._table_suffix between start_comparison_period_suffix and end_comparison_period_suffix
        group by _table_suffix
        )

      , curr as
        (select  count(*) row_count, count(distinct savvy_pid) mbr_count, count(distinct savvy_pid || ' . ' || year_mo) mm_count
        from `research-01-217611.df_ucd.member_detail` mx
        )

    select table_id , table_last_modified_date
      , 'row_count'
      , 'int64'
      , cast(curr.row_count as string)
      , cast(min(arc.row_count) as string)
      , cast(max(arc.row_count) as string)
      , 100 * (curr.row_count / max(arc.row_count) - 1)
      , '%'
      , current_datetime()
    from arc cross join curr
    group by curr.row_count

    union all

    select table_id , table_last_modified_date
      , 'mbr_count'
      , 'int64'
      , cast(curr.mbr_count as string)
      , cast(min(arc.mbr_count) as string)
      , cast(max(arc.mbr_count) as string)
      , 100 * (curr.mbr_count / max(arc.mbr_count) - 1)
      , '%'
      , current_datetime()
    from arc cross join curr
    group by curr.mbr_count

    union all

    select table_id , table_last_modified_date
      , 'mm_count'
      , 'int64'
      , cast(curr.mm_count as string)
      , cast(min(arc.mm_count) as string)
      , cast(max(arc.mm_count) as string)
      , 100 * (curr.mm_count / max(arc.mm_count) - 1)
      , '%'
      , current_datetime()
    from arc cross join curr
    group by curr.mm_count
    ;

    /*************  done with membership claims  *************/

    /*************  medical claims  *************/
    --do some initial validation on the pharmacy_claim_enriched table
    SET (table_id, table_last_modified_date, start_comparison_period_suffix, end_comparison_period_suffix) = (
      SELECT AS STRUCT
          table_id
          , cast(table_last_modified_time as date)  table_last_modified_date
          , format_date('%Y%m%d', date_add(cast(table_last_modified_time as date), interval -1 month)) start_comparison_period_suffix
          , format_date('%Y%m%d', date_add(cast(table_last_modified_time as date), interval -1 day)) end_comparison_period_suffix
      from `research-01-217611.df_ucd.vw_info`
      where table_id = 'medical_claim_enriched'
      and ordinal_position = 1 --just one row for each table
      );

    insert into `research-01-217611.df_ucd_stage.auditing`
    	(table_id, table_last_modified_date, measure, measure_data_type, current_value, min_old_value, max_old_value, change, change_unit, message_datetime)
    with
      arc as
        (select  _table_suffix which_version, count(*) row_count, count(distinct savvy_pid) mbr_count, sum(allw_amt) total_allw
          , max(clm_dt) last_clm_dt
          , max(admit_dt) last_admit_dt
          , sum(admit_cnt) ct_admit
          , count(case when proc_cd like '99213' then 1 end) ct_99213
        from `research-01-217611.df_ucd.medical_claim_enriched_arc_*` rx
        where rx._table_suffix between start_comparison_period_suffix and end_comparison_period_suffix
        group by _table_suffix
        )

      , curr as
        (select  count(*) row_count, count(distinct savvy_pid) mbr_count, sum(allw_amt) total_allw
          , max(clm_dt) last_clm_dt
          , max(admit_dt) last_admit_dt
          , sum(admit_cnt) ct_admit
          , count(case when proc_cd like '99213' then 1 end) ct_99213
        from `research-01-217611.df_ucd.medical_claim_enriched` mx
        )

      , curr_base as
        (select count(*) row_count
        from `research-01-217611.df_ucd.medical_claim` rx
        )

    select table_id , table_last_modified_date
      , 'row_count (vs medical_claim)'
      , 'int64'
      , cast(curr.row_count as string)
      , cast(curr_base.row_count as string)
      , cast(curr_base.row_count as string)
      , 100 * (curr.row_count / curr_base.row_count - 1)
      , '%'
      , current_datetime()
    from curr_base cross join curr

    union all

    select table_id , table_last_modified_date
      , 'row_count'
      , 'int64'
      , cast(curr.row_count as string)
      , cast(min(arc.row_count) as string)
      , cast(max(arc.row_count) as string)
      , 100 * (curr.row_count / max(arc.row_count) - 1)
      , '%'
      , current_datetime()
    from arc cross join curr
    group by curr.row_count

    union all

    select table_id , table_last_modified_date
      , 'mbr_count'
      , 'int64'
      , cast(curr.mbr_count as string)
      , cast(min(arc.mbr_count) as string)
      , cast(max(arc.mbr_count) as string)
      , 100 * (curr.mbr_count / max(arc.mbr_count) - 1)
      , '%'
      , current_datetime()
    from arc cross join curr
    group by curr.mbr_count

    union all

    select table_id , table_last_modified_date
      , 'total_allw'
      , 'numeric'
      , cast(curr.total_allw  as string)
      , cast(min(arc.total_allw) as string)
      , cast(max(arc.total_allw) as string)
      , 100 * (curr.total_allw / max(arc.total_allw) - 1)
      , '%'
      , current_datetime()
    from arc cross join curr
    group by curr.total_allw

    union all

    select table_id , table_last_modified_date
      , 'ct_admit'
      , 'int64'
      , cast(curr.ct_admit as string)
      , cast(min(arc.ct_admit) as string)
      , cast(max(arc.ct_admit) as string)
      , 100 * (curr.ct_admit / max(arc.ct_admit) - 1)
      , '%'
      , current_datetime()
    from arc cross join curr
    group by curr.ct_admit

    union all

    select table_id , table_last_modified_date
      , 'ct_99213'
      , 'int64'
      , cast(curr.ct_99213 as string)
      , cast(min(arc.ct_99213) as string)
      , cast(max(arc.ct_99213) as string)
      , 100 * (curr.ct_99213 / max(arc.ct_99213) - 1)
      , '%'
      , current_datetime()
    from arc cross join curr
    group by curr.ct_99213

    union all

    select table_id , table_last_modified_date
      , 'last_clm_dt'
      , 'date'
      , cast(curr.last_clm_dt as string)
      , cast(min(arc.last_clm_dt) as string)
      , cast(max(arc.last_clm_dt) as string)
      , date_diff(curr.last_clm_dt, max(arc.last_clm_dt), day)
      , 'day'
      , current_datetime()
    from arc cross join curr
    group by curr.last_clm_dt

    union all

    select table_id , table_last_modified_date
      , 'last_admit_dt'
      , 'date'
      , cast(curr.last_admit_dt as string)
      , cast(min(arc.last_admit_dt) as string)
      , cast(max(arc.last_admit_dt) as string)
      , date_diff(curr.last_admit_dt, max(arc.last_admit_dt), day)
      , 'day'
      , current_datetime()
    from arc cross join curr
    group by curr.last_admit_dt
    ;

    /*************  done with medical claims  *************/

    /*************  pharmacy claims  *************/
    --do some initial validation on the pharmacy_claim_enriched table
    SET (table_id, table_last_modified_date, start_comparison_period_suffix, end_comparison_period_suffix) = (
      SELECT AS STRUCT
          table_id
          , cast(table_last_modified_time as date)  table_last_modified_date
          , format_date('%Y%m%d', date_add(cast(table_last_modified_time as date), interval -1 month)) start_comparison_period_suffix
          , format_date('%Y%m%d', date_add(cast(table_last_modified_time as date), interval -1 day)) end_comparison_period_suffix
      from `research-01-217611.df_ucd.vw_info`
      where table_id = 'pharmacy_claim_enriched'
      and ordinal_position = 1 --just one row for each table
      );

    insert into `research-01-217611.df_ucd_stage.auditing`
    	(table_id, table_last_modified_date, measure, measure_data_type, current_value, min_old_value, max_old_value, change, change_unit, message_datetime)
    with
      arc as
        (select  _table_suffix which_version, count(*) row_count, count(distinct savvy_pid) mbr_count, sum(allw_amt) total_allw, max(fill_dt) last_fill_dt
          , sum(case when ext_ahfs_thrptc_clss_desc like '%insulin%' then scrpt_cnt else 0 end) ct_insulin_scrpt
        from `research-01-217611.df_ucd.pharmacy_claim_enriched_arc_*` rx
        where rx._table_suffix between start_comparison_period_suffix and end_comparison_period_suffix
        group by _table_suffix
        )

      , curr as
        (select count(*) row_count, count(distinct savvy_pid) mbr_count, sum(allw_amt) total_allw, max(fill_dt) last_fill_dt
          , sum(case when ext_ahfs_thrptc_clss_desc like '%insulin%' then scrpt_cnt else 0 end) ct_insulin_scrpt
        from `research-01-217611.df_ucd.pharmacy_claim_enriched` rx
        )

      , curr_base as
        (select count(*) row_count
        from `research-01-217611.df_ucd.pharmacy_claim` rx
        )

    select table_id , table_last_modified_date
      , 'row_count (vs pharmacy_claim)'
      , 'int64'
      , cast(curr.row_count as string)
      , cast(curr_base.row_count as string)
      , cast(curr_base.row_count as string)
      , 100 * (curr.row_count / curr_base.row_count - 1)
      , '%'
      , current_datetime()
    from curr_base cross join curr

    union all

    select table_id , table_last_modified_date
      , 'row_count'
      , 'int64'
      , cast(curr.row_count as string)
      , cast(min(arc.row_count) as string)
      , cast(max(arc.row_count) as string)
      , 100 * (curr.row_count / max(arc.row_count) - 1)
      , '%'
      , current_datetime()
    from arc cross join curr
    group by curr.row_count

    union all

    select table_id , table_last_modified_date
      , 'mbr_count'
      , 'int64'
      , cast(curr.mbr_count as string)
      , cast(min(arc.mbr_count) as string)
      , cast(max(arc.mbr_count) as string)
      , 100 * (curr.mbr_count / max(arc.mbr_count) - 1)
      , '%'
      , current_datetime()
    from arc cross join curr
    group by curr.mbr_count

    union all

    select table_id , table_last_modified_date
      , 'total_allw'
      , 'numeric'
      , cast(curr.total_allw  as string)
      , cast(min(arc.total_allw) as string)
      , cast(max(arc.total_allw) as string)
      , 100 * (curr.total_allw / max(arc.total_allw) - 1)
      , '%'
      , current_datetime()
    from arc cross join curr
    group by curr.total_allw

    union all

    select table_id , table_last_modified_date
      , 'last_fill_dt'
      , 'date'
      , cast(curr.last_fill_dt as string)
      , cast(min(arc.last_fill_dt) as string)
      , cast(max(arc.last_fill_dt) as string)
      , date_diff(curr.last_fill_dt, max(arc.last_fill_dt), day)
      , 'day'
      , current_datetime()
    from arc cross join curr
    group by curr.last_fill_dt

    union all

    select table_id , table_last_modified_date
      , 'ct_insulin_scrpt'
      , 'int64'
      , cast(curr.ct_insulin_scrpt as string)
      , cast(min(arc.ct_insulin_scrpt) as string)
      , cast(max(arc.ct_insulin_scrpt) as string)
      , 100 * (curr.ct_insulin_scrpt / max(arc.ct_insulin_scrpt) - 1)
      , '%'
      , current_datetime()
    from arc cross join curr
    group by curr.ct_insulin_scrpt
    ;

    /*************  done with pharmacy claims  *************/

    /*************  cms raf  *************/
    --do some initial validation on the pharmacy_claim_enriched table
    SET (table_id, table_last_modified_date, start_comparison_period_suffix, end_comparison_period_suffix) = (
      SELECT AS STRUCT
          table_id
          , cast(table_last_modified_time as date)  table_last_modified_date
          , format_date('%Y%m%d', date_add(cast(table_last_modified_time as date), interval -1 month)) start_comparison_period_suffix
          , format_date('%Y%m%d', date_add(cast(table_last_modified_time as date), interval -1 day)) end_comparison_period_suffix
      from `research-01-217611.df_ucd.vw_info`
      where table_id = 'member_cms_raf_scores'
      and ordinal_position = 1 --just one row for each table
      );


    insert into `research-01-217611.df_ucd_stage.auditing`
    	(table_id, table_last_modified_date, measure, measure_data_type, current_value, min_old_value, max_old_value, change, change_unit, message_datetime)
    with
      arc as
        (select  _table_suffix which_version, count(*) row_count, round(avg(raf), 3) avg_raf, round(avg(case when age >= 65 then raf end), 3) avg_raf_senior, sum(hcc019) ct_hcc019
        from `research-01-217611.df_ucd.member_cms_raf_scores_arc_*` rx
        where rx._table_suffix between start_comparison_period_suffix and end_comparison_period_suffix
        group by _table_suffix
        )

      , curr as
        (select count(*) row_count, round(avg(raf), 3) avg_raf, round(avg(case when age >= 65 then raf end), 3) avg_raf_senior, sum(hcc019) ct_hcc019
        from `research-01-217611.df_ucd.member_cms_raf_scores` rx
        )

      , curr_hhs as
        (select count(*) row_count
        from `research-01-217611.df_ucd.member_hhs_raf_scores` rx
        )

      , curr_comorbid as
        (select count(*) row_count
        from `research-01-217611.df_ucd.member_comorbidity_scores` rx
        )

    select table_id , table_last_modified_date
      , 'row_count (vs hhs and comorbidity)'
      , 'int64'
      , cast(curr.row_count as string)
      , cast(least(curr_hhs.row_count, curr_comorbid.row_count) as string)
      , cast(greatest(curr_hhs.row_count, curr_comorbid.row_count) as string)
      , 100 * (curr.row_count / greatest(curr_hhs.row_count, curr_comorbid.row_count) - 1)
      , '%'
      , current_datetime()
    from curr cross join curr_hhs cross join curr_comorbid

    union all

    select table_id , table_last_modified_date
      , 'row_count'
      , 'int64'
      , cast(curr.row_count as string)
      , cast(min(arc.row_count) as string)
      , cast(max(arc.row_count) as string)
      , 100 * (curr.row_count / max(arc.row_count) - 1)
      , '%'
      , current_datetime()
    from arc cross join curr
    group by curr.row_count

    union all

    select table_id , table_last_modified_date
      , 'avg_raf'
      , 'float64'
      , cast(curr.avg_raf as string)
      , cast(min(arc.avg_raf) as string)
      , cast(max(arc.avg_raf) as string)
      , 100 * (curr.avg_raf / max(arc.avg_raf) - 1)
      , '%'
      , current_datetime()
    from arc cross join curr
    group by curr.avg_raf

    union all

    select table_id , table_last_modified_date
      , 'avg_raf_senior'
      , 'float64'
      , cast(curr.avg_raf_senior as string)
      , cast(min(arc.avg_raf_senior) as string)
      , cast(max(arc.avg_raf_senior) as string)
      , 100 * (curr.avg_raf_senior / max(arc.avg_raf_senior) - 1)
      , '%'
      , current_datetime()
    from arc cross join curr
    group by curr.avg_raf_senior

    union all

    select table_id , table_last_modified_date
      , 'ct_hcc019'
      , 'int64'
      , cast(curr.ct_hcc019 as string)
      , cast(min(arc.ct_hcc019) as string)
      , cast(max(arc.ct_hcc019) as string)
      , 100 * (curr.ct_hcc019 / max(arc.ct_hcc019) - 1)
      , '%'
      , current_datetime()
    from arc cross join curr
    group by curr.ct_hcc019
    ;

    /*************  done with cms raf  *************/


    /*************  hhs raf  *************/
    --do some initial validation on the pharmacy_claim_enriched table
    SET (table_id, table_last_modified_date, start_comparison_period_suffix, end_comparison_period_suffix) = (
      SELECT AS STRUCT
          table_id
          , cast(table_last_modified_time as date)  table_last_modified_date
          , format_date('%Y%m%d', date_add(cast(table_last_modified_time as date), interval -1 month)) start_comparison_period_suffix
          , format_date('%Y%m%d', date_add(cast(table_last_modified_time as date), interval -1 day)) end_comparison_period_suffix
      from `research-01-217611.df_ucd.vw_info`
      where table_id = 'member_hhs_raf_scores'
      and ordinal_position = 1 --just one row for each table
      );


    insert into `research-01-217611.df_ucd_stage.auditing`
    	(table_id, table_last_modified_date, measure, measure_data_type, current_value, min_old_value, max_old_value, change, change_unit, message_datetime)
    with
      arc as
        (select  _table_suffix which_version, count(*) row_count, round(avg(raf), 3) avg_raf, round(avg(case when age between 18 and 64 then raf end), 3) avg_raf_adult, sum(hcc021) ct_hcc021
        from `research-01-217611.df_ucd.member_hhs_raf_scores_arc_*` rx
        where rx._table_suffix between start_comparison_period_suffix and end_comparison_period_suffix
        group by _table_suffix
        )

      , curr as
        (select count(*) row_count, round(avg(raf), 3) avg_raf, round(avg(case when age between 18 and 64 then raf end), 3) avg_raf_adult, sum(hcc021) ct_hcc021
        from `research-01-217611.df_ucd.member_hhs_raf_scores` rx
        )

    select table_id , table_last_modified_date
      , 'row_count'
      , 'int64'
      , cast(curr.row_count as string)
      , cast(min(arc.row_count) as string)
      , cast(max(arc.row_count) as string)
      , 100 * (curr.row_count / max(arc.row_count) - 1)
      , '%'
      , current_datetime()
    from arc cross join curr
    group by curr.row_count


    union all

    select table_id , table_last_modified_date
      , 'avg_raf'
      , 'float64'
      , cast(curr.avg_raf as string)
      , cast(min(arc.avg_raf) as string)
      , cast(max(arc.avg_raf) as string)
      , 100 * (curr.avg_raf / max(arc.avg_raf) - 1)
      , '%'
      , current_datetime()
    from arc cross join curr
    group by curr.avg_raf

    union all

    select table_id , table_last_modified_date
      , 'avg_raf_adult'
      , 'float64'
      , cast(curr.avg_raf_adult as string)
      , cast(min(arc.avg_raf_adult) as string)
      , cast(max(arc.avg_raf_adult) as string)
      , 100 * (curr.avg_raf_adult / max(arc.avg_raf_adult) - 1)
      , '%'
      , current_datetime()
    from arc cross join curr
    group by curr.avg_raf_adult

    union all

    select table_id , table_last_modified_date
      , 'ct_hcc021'
      , 'int64'
      , cast(curr.ct_hcc021 as string)
      , cast(min(arc.ct_hcc021) as string)
      , cast(max(arc.ct_hcc021) as string)
      , 100 * (curr.ct_hcc021 / max(arc.ct_hcc021) - 1)
      , '%'
      , current_datetime()
    from arc cross join curr
    group by curr.ct_hcc021
    ;

    /*************  done with hhs raf  *************/


    /*************  comorbidity scores  *************/
    --do some initial validation on the pharmacy_claim_enriched table
    SET (table_id, table_last_modified_date, start_comparison_period_suffix, end_comparison_period_suffix) = (
      SELECT AS STRUCT
          table_id
          , cast(table_last_modified_time as date)  table_last_modified_date
          , format_date('%Y%m%d', date_add(cast(table_last_modified_time as date), interval -1 month)) start_comparison_period_suffix
          , format_date('%Y%m%d', date_add(cast(table_last_modified_time as date), interval -1 day)) end_comparison_period_suffix
      from `research-01-217611.df_ucd.vw_info`
      where table_id = 'member_comorbidity_scores'
      and ordinal_position = 1 --just one row for each table
      );


    insert into `research-01-217611.df_ucd_stage.auditing`
    	(table_id, table_last_modified_date, measure, measure_data_type, current_value, min_old_value, max_old_value, change, change_unit, message_datetime)
    with
      arc as
        (select  _table_suffix which_version, count(*) row_count
          , avg(aeci_m_score) avg_aeci_m_score, avg(aeci_r_score ) avg_aeci_r_score, sum(aeci_chf_flag) ct_aeci_chf
          , avg(cci_score) avg_cci_score, avg(cci_q_score) avg_cci_q_score, sum(cci_mi_flag) ct_cci_mi
        from `research-01-217611.df_ucd.member_comorbidity_scores_arc_*` rx
        where rx._table_suffix between start_comparison_period_suffix and end_comparison_period_suffix
        group by _table_suffix
        )

      , curr as
        (select count(*) row_count
          , avg(aeci_m_score) avg_aeci_m_score, avg(aeci_r_score ) avg_aeci_r_score, sum(aeci_chf_flag) ct_aeci_chf
          , avg(cci_score) avg_cci_score, avg(cci_q_score) avg_cci_q_score, sum(cci_mi_flag) ct_cci_mi
        from `research-01-217611.df_ucd.member_comorbidity_scores` rx
        )

    select table_id , table_last_modified_date
      , 'row_count'
      , 'int64'
      , cast(curr.row_count as string)
      , cast(min(arc.row_count) as string)
      , cast(max(arc.row_count) as string)
      , 100 * (curr.row_count / max(arc.row_count) - 1)
      , '%'
      , current_datetime()
    from arc cross join curr
    group by curr.row_count

    union all

    select table_id , table_last_modified_date
      , 'avg_aeci_m_score'
      , 'float64'
      , cast(curr.avg_aeci_m_score as string)
      , cast(min(arc.avg_aeci_m_score) as string)
      , cast(max(arc.avg_aeci_m_score) as string)
      , 100 * (curr.avg_aeci_m_score / max(arc.avg_aeci_m_score) - 1)
      , '%'
      , current_datetime()
    from arc cross join curr
    group by curr.avg_aeci_m_score

    union all

    select table_id , table_last_modified_date
      , 'avg_aeci_r_score'
      , 'float64'
      , cast(curr.avg_aeci_r_score as string)
      , cast(min(arc.avg_aeci_r_score) as string)
      , cast(max(arc.avg_aeci_r_score) as string)
      , 100 * (curr.avg_aeci_r_score / max(arc.avg_aeci_r_score) - 1)
      , '%'
      , current_datetime()
    from arc cross join curr
    group by curr.avg_aeci_r_score

    union all

    select table_id , table_last_modified_date
      , 'ct_aeci_chf'
      , 'int64'
      , cast(curr.ct_aeci_chf as string)
      , cast(min(arc.ct_aeci_chf) as string)
      , cast(max(arc.ct_aeci_chf) as string)
      , 100 * (curr.ct_aeci_chf / max(arc.ct_aeci_chf) - 1)
      , '%'
      , current_datetime()
    from arc cross join curr
    group by curr.ct_aeci_chf

    union all

    select table_id , table_last_modified_date
      , 'avg_cci_score'
      , 'float64'
      , cast(curr.avg_cci_score as string)
      , cast(min(arc.avg_cci_score) as string)
      , cast(max(arc.avg_cci_score) as string)
      , 100 * (curr.avg_cci_score / max(arc.avg_cci_score) - 1)
      , '%'
      , current_datetime()
    from arc cross join curr
    group by curr.avg_cci_score

    union all

    select table_id , table_last_modified_date
      , 'avg_cci_q_score'
      , 'float64'
      , cast(curr.avg_cci_q_score as string)
      , cast(min(arc.avg_cci_q_score) as string)
      , cast(max(arc.avg_cci_q_score) as string)
      , 100 * (curr.avg_cci_q_score / max(arc.avg_cci_q_score) - 1)
      , '%'
      , current_datetime()
    from arc cross join curr
    group by curr.avg_cci_q_score

    union all

    select table_id , table_last_modified_date
      , 'ct_cci_mi'
      , 'int64'
      , cast(curr.ct_cci_mi as string)
      , cast(min(arc.ct_cci_mi) as string)
      , cast(max(arc.ct_cci_mi) as string)
      , 100 * (curr.ct_cci_mi / max(arc.ct_cci_mi) - 1)
      , '%'
      , current_datetime()
    from arc cross join curr
    group by curr.ct_cci_mi
    ;

    /*************  done with comorbidity scores  *************/

  --if successful, we'll get here!
  insert into `research-01-217611.df_ucd_stage.logging`(
  	success_flag, job, message_datetime)
  select
  	1 as success_flag
  	, 'load ucd audit table' as job
  	, current_datetime as message_datetime
  ;

  EXCEPTION WHEN ERROR THEN
  	insert into `research-01-217611.df_ucd_stage.logging`(
  		success_flag, job, error_message, statement_text, formatted_stack_trace, message_datetime)
  	select
  		0 as success_flag
      , 'load ucd audit table' as job
    	, @@error.message as error_message
  		, @@error.statement_text as statement_text
  		, @@error.formatted_stack_trace as formatted_stack_trace
  		, current_datetime as message_datetime
  	;


END
;
