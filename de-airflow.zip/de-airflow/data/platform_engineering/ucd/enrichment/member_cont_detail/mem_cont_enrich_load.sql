BEGIN
  /*
  create a working table listing plan information so we can save resources later
  by joining on plan_id rather than a long list of fields
  */
  create or replace table `research-01-217611.df_ucd_stage.wkg_plan`
  OPTIONS(description='working table with 1 row per plan. "Plan" is currently defined as a unique combination of (cust_seg_nbr, cust_seg_nm, co_nm, hlth_pln_fund_cd, contr_nbr, contr_pbp, contr_desc, business_line, phrm_cov_ind, med_cov_ind, snp_flag, snp_typ, dec_risk_typ, dec_risk_typ_desc).')
  as
  select *
    , row_number() over () as plan_id
  from
      (select distinct
        cust_seg_nbr
        , cust_seg_nm
        , co_nm
        , hlth_pln_fund_cd
        , contr_nbr
        , contr_pbp
        , contr_desc
        , business_line
        , phrm_cov_ind
        , med_cov_ind
        , snp_flag
        , snp_typ
        , dec_risk_typ
        , dec_risk_typ_desc
      from
        `research-01-217611.df_ucd_stage.udd_member_detail_consolidated`
      )
  ;

  create or replace table `research-01-217611.df_ucd_stage.wkg_member_plan_month`
  OPTIONS(description='working table with 1 row per member/plan/month. . "Plan" is currently defined as a unique combination of (cust_seg_nbr, cust_seg_nm, co_nm, hlth_pln_fund_cd, contr_nbr, contr_pbp, contr_desc, business_line, phrm_cov_ind, med_cov_ind, snp_flag, snp_typ, dec_risk_typ, dec_risk_typ_desc).')
  as
  select
    plan.plan_id
    , md.savvy_pid
    , md.savvy_did
    , md.is_restricted
    , md.year_mo
    , mnth.month_id
    , mnth.year_nbr
    , max(md.zip) as zip
    , max(md.mapd_flag) as mapd_flag
    , max(md.medicare_part_d_only_flag) as medicare_part_d_only_flag
    , max(md.medicare_advantage_flag) as medicare_advantage_flag
    , array_agg(distinct src_type order by src_type) as src_types
  from `research-01-217611.df_ucd_stage.wkg_plan`                             plan
    join `research-01-217611.df_ucd_stage.udd_member_detail_consolidated`     md    using (cust_seg_nbr, cust_seg_nm
                                                                                          , co_nm, hlth_pln_fund_cd
                                                                                          , contr_nbr, contr_pbp, contr_desc
                                                                                          , business_line , phrm_cov_ind, med_cov_ind
                                                                                          , snp_flag, snp_typ
                                                                                          , dec_risk_typ, dec_risk_typ_desc)
    join `research-01-217611.df_ucd_stage.dim_month`                          mnth  using (year_mo)
  --where (mod(savvy_pid, 134175) = 15534 --and year_mo between 201912 and 202001 or savvy_pid in (42635, 111280)) and savvy_pid < 10E6
  group by
    plan_id
    , savvy_pid
    , savvy_did
    , is_restricted
    , year_mo
    , month_id
    , year_nbr
  ;


  create or replace table `research-01-217611.df_ucd_stage.wkg_member_month`
    --cluster by savvy_pid, year_mo
  OPTIONS(description='working table with 1 row per member/month')
  as
  select
    savvy_pid
    , savvy_did
    , is_restricted
    , year_mo
    , year_nbr
    , month_id
    , min(cust_seg_nbr) as min_cust_seg_nbr
    , max(cust_seg_nbr) as max_cust_seg_nbr
    , min(cust_seg_nm) as min_cust_seg_nm
    , max(cust_seg_nm) as max_cust_seg_nm
    , min(co_nm) as min_co_nm
    , max(co_nm) as max_co_nm
    , min(hlth_pln_fund_cd) as min_hlth_pln_fund_cd
    , max(hlth_pln_fund_cd) as max_hlth_pln_fund_cd
    , min(contr_nbr) as min_contr_nbr
    , max(contr_nbr) as max_contr_nbr
    , min(contr_pbp) as min_contr_pbp
    , max(contr_pbp) as max_contr_pbp
    , min(contr_desc) as min_contr_desc
    , max(contr_desc) as max_contr_desc
    , min(business_line) as min_business_line
    , max(business_line) as max_business_line
    , min(phrm_cov_ind) as min_phrm_cov_ind
    , max(phrm_cov_ind) as max_phrm_cov_ind
    , min(med_cov_ind) as min_med_cov_ind
    , max(med_cov_ind) as max_med_cov_ind
    , min(snp_flag) as min_snp_flag
    , max(snp_flag) as max_snp_flag
    , min(snp_typ) as min_snp_typ
    , max(snp_typ) as max_snp_typ
    , min(dec_risk_typ) as min_dec_risk_typ
    , max(dec_risk_typ) as max_dec_risk_typ
    , min(dec_risk_typ_desc) as min_dec_risk_typ_desc
    , max(dec_risk_typ_desc) as max_dec_risk_typ_desc
    , min(mapd_flag) as min_mapd_flag
    , max(mapd_flag) as max_mapd_flag
    , min(medicare_part_d_only_flag) as min_medicare_part_d_only_flag
    , max(medicare_part_d_only_flag) as max_medicare_part_d_only_flag
    , min(medicare_advantage_flag) as min_medicare_advantage_flag
    , max(medicare_advantage_flag) as max_medicare_advantage_flag
    , min(zip) as min_zip
    , max(zip) as max_zip
    , array_agg(distinct src_type order by src_type) as src_types
  from `research-01-217611.df_ucd_stage.udd_member_detail_consolidated`       mm
    join `research-01-217611.df_ucd_stage.dim_month`                          mnth  using (year_mo)
  group by
      savvy_pid
      , savvy_did
      , is_restricted
      , year_mo
      , year_nbr
      , month_id
  ;

  create or replace table `research-01-217611.df_ucd_stage.wkg_continuous_time_periods`
  OPTIONS(description='working table listing all (3,6,9,12,18,24,36,48,60)-month ranges from 2016 through the end of our most recent membership data')
  as
  select
      row_number() over(order by month_count, start_mo.month_id) time_period_id
      , month_count
      , start_mo.month_id as start_month_id
      , end_mo.month_id as end_month_id

      , start_mo.year_mo as start_year_mo
      , end_mo.year_mo as end_year_mo

      , start_mo.month_start_date as start_date
      , end_mo.month_end_date as end_date
  from unnest([3,6,9,12,18,24,36,48,60])                                  as month_count
      cross join `research-01-217611.df_ucd_stage.dim_month`              as start_mo
      join `research-01-217611.df_ucd_stage.dim_month`                    as end_mo on end_mo.month_id = start_mo.month_id + month_count - 1
  where
      --eligibility month between 2015 and the month after the most recent claims we have
      start_mo.year_nbr >= 2016
      and end_mo.year_mo <= (select max(year_mo) from `research-01-217611.df_ucd_stage.udd_member_detail_consolidated`)
  ;

  insert into  `research-01-217611.df_ucd_stage.member_plan_continuous_enrollment_period`
    (savvy_pid, savvy_did, is_restricted, cust_seg_nbr, cust_seg_nm, co_nm, hlth_pln_fund_cd, contr_nbr, contr_pbp, contr_desc,
      business_line, phrm_cov_ind, med_cov_ind, snp_flag, snp_typ, dec_risk_typ, dec_risk_typ_desc,
      plan_start_year_mo, plan_end_year_mo, plan_mm, mm_2016, mm_2017, mm_2018, mm_2019, mm_2020, mm_2021,
      continuous_mapd_flag, continuous_medicare_part_d_only_flag, continuous_medicare_advantage_flag, continuous_zip,
      last_mapd_flag, last_medicare_part_d_only_flag, last_medicare_advantage_flag, last_zip, src_types, create_datetime, update_datetime
    )

  with
      mm_detail as
        (select
            *
            , month_id
              + row_number() over(partition by savvy_pid, plan_id order by year_mo desc) range_grouper
          from
            `research-01-217611.df_ucd_stage.wkg_member_plan_month`
          --where mod(savvy_pid, 134175) = 15534 --and year_mo between 201912 and 202001
          --order by savvy_pid , year_mo , src_type
          )
      , mbr_plan_range as
          (select
              savvy_pid
              , savvy_did
              , is_restricted
              , plan_id
              , range_grouper
              , min(year_mo) plan_start_year_mo
              , max(year_mo) plan_end_year_mo
              , count(*) plan_mm
              , count(case when year_nbr = 2016 then 1 end) mm_2016
              , count(case when year_nbr = 2017 then 1 end) mm_2017
              , count(case when year_nbr = 2018 then 1 end) mm_2018
              , count(case when year_nbr = 2019 then 1 end) mm_2019
              , count(case when year_nbr = 2020 then 1 end) mm_2020
              , count(case when year_nbr = 2021 then 1 end) mm_2021
              , case when count(distinct mapd_flag) = 1 then 1 else 0 end as continuous_mapd_flag
              , case when count(distinct medicare_part_d_only_flag) = 1 then 1 else 0 end as continuous_medicare_part_d_only_flag
              , case when count(distinct medicare_advantage_flag) = 1 then 1 else 0 end as continuous_medicare_advantage_flag
              , case when count(distinct zip) = 1 then 1 else 0 end as continuous_zip
          from mm_detail a
          group by
              savvy_pid
              , savvy_did
              , is_restricted
              , plan_id
              , range_grouper
          )
      , plan_range_sources as
          (select a.savvy_pid, a.plan_id, a.range_grouper, array_agg(distinct src_type order by src_type) as src_types
          from mbr_plan_range                                             a
            join `research-01-217611.df_ucd_stage.wkg_member_plan_month`  b on a.savvy_pid = b.savvy_pid
                                                                            and a.plan_id = b.plan_id
                                                                            and b.year_mo between a.plan_start_year_mo and a.plan_end_year_mo
            cross join unnest(b.src_types) as src_type
          group by a.savvy_pid, a.plan_id, a.range_grouper
          )
  select
    mbr_plan_range.savvy_pid
    , mbr_plan_range.savvy_did
    , mbr_plan_range.is_restricted
    , plan.cust_seg_nbr
    , plan.cust_seg_nm
    , plan.co_nm
    , plan.hlth_pln_fund_cd
    , plan.contr_nbr
    , plan.contr_pbp
    , plan.contr_desc
    , plan.business_line
    , plan.phrm_cov_ind
    , plan.med_cov_ind
    , plan.snp_flag
    , plan.snp_typ
    , plan.dec_risk_typ
    , plan.dec_risk_typ_desc
    , mbr_plan_range.plan_start_year_mo
    , mbr_plan_range.plan_end_year_mo
    , mbr_plan_range.plan_mm
    , mbr_plan_range.mm_2016
    , mbr_plan_range.mm_2017
    , mbr_plan_range.mm_2018
    , mbr_plan_range.mm_2019
    , mbr_plan_range.mm_2020
    , mbr_plan_range.mm_2021
    , mbr_plan_range.continuous_mapd_flag
    , mbr_plan_range.continuous_medicare_part_d_only_flag
    , mbr_plan_range.continuous_medicare_advantage_flag
    , mbr_plan_range.continuous_zip
    , last_mo.mapd_flag                           as last_mapd_flag
    , last_mo.medicare_part_d_only_flag           as last_medicare_part_d_only_flag
    , last_mo.medicare_advantage_flag             as last_medicare_advantage_flag
    , last_mo.zip as last_zip
    , plan_range_sources.src_types

    , current_datetime as create_datetime
    , current_datetime as update_datetime
  from `research-01-217611.df_ucd_stage.wkg_plan`   plan
    join                                            mbr_plan_range        using (plan_id)
    join mm_detail                                  last_mo               using (savvy_pid, plan_id, range_grouper)
    join                                            plan_range_sources    using (savvy_pid, plan_id, range_grouper)
  where
    mbr_plan_range.plan_end_year_mo = last_mo.year_mo
  ;

  insert into `research-01-217611.df_ucd_stage.member_continuous_enrollment_period`
    (savvy_pid, savvy_did, is_restricted, range_start_year_mo, range_end_year_mo, range_mm, mm_2016, mm_2017, mm_2018, mm_2019, mm_2020, mm_2021,
      continuous_cust_seg_nbr, continuous_cust_seg_nm, continuous_co_nm, continuous_hlth_pln_fund_cd, continuous_contr_nbr, continuous_contr_pbp,
      continuous_contr_desc, continuous_business_line, continuous_phrm_cov_ind, continuous_med_cov_ind, continuous_snp_flag, continuous_snp_typ,
      continuous_dec_risk_typ, continuous_dec_risk_typ_desc, continuous_mapd_flag, continuous_medicare_part_d_only_flag, continuous_medicare_advantage_flag, continuous_zip,
      last_cust_seg_nbr, last_cust_seg_nm, last_co_nm, last_hlth_pln_fund_cd, last_contr_nbr, last_contr_pbp, last_contr_desc,
      last_business_line, last_phrm_cov_ind, last_med_cov_ind, last_snp_flag, last_snp_typ, last_dec_risk_typ, last_dec_risk_typ_desc,
      last_mapd_flag, last_medicare_part_d_only_flag, last_medicare_advantage_flag, last_zip, src_types, create_datetime, update_datetime
    )

  with
      mm_detail as
        (select
            *
            , month_id
              + row_number() over(partition by savvy_pid order by year_mo desc) range_grouper
          from
            `research-01-217611.df_ucd_stage.wkg_member_month`
          --where mod(savvy_pid, 134175) = 15534 --and year_mo between 201912 and 202001
          --order by savvy_pid , year_mo , src_type
          )
      , mbr_range as
          (select
              savvy_pid
              , savvy_did
              , is_restricted
              , range_grouper
              , min(year_mo) range_start_year_mo
              , max(year_mo) range_end_year_mo
              , count(*) range_mm
              , count(case when year_nbr = 2016 then 1 end) mm_2016
              , count(case when year_nbr = 2017 then 1 end) mm_2017
              , count(case when year_nbr = 2018 then 1 end) mm_2018
              , count(case when year_nbr = 2019 then 1 end) mm_2019
              , count(case when year_nbr = 2020 then 1 end) mm_2020
              , count(case when year_nbr = 2021 then 1 end) mm_2021
              , case when min(min_cust_seg_nbr) = max(max_cust_seg_nbr) then 1 else 0 end		as continuous_cust_seg_nbr
              , case when min(min_cust_seg_nm) = max(max_cust_seg_nm) then 1 else 0 end		as continuous_cust_seg_nm
              , case when min(min_co_nm) = max(max_co_nm) then 1 else 0 end		as continuous_co_nm
              , case when min(min_hlth_pln_fund_cd) = max(max_hlth_pln_fund_cd) then 1 else 0 end		as continuous_hlth_pln_fund_cd
              , case when min(min_contr_nbr) = max(max_contr_nbr) then 1 else 0 end		as continuous_contr_nbr
              , case when min(min_contr_pbp) = max(max_contr_pbp) then 1 else 0 end		as continuous_contr_pbp
              , case when min(min_contr_desc) = max(max_contr_desc) then 1 else 0 end		as continuous_contr_desc
              , case when min(min_business_line) = max(max_business_line) then 1 else 0 end		as continuous_business_line
              , case when min(min_phrm_cov_ind) = max(max_phrm_cov_ind) then 1 else 0 end		as continuous_phrm_cov_ind
              , case when min(min_med_cov_ind) = max(max_med_cov_ind) then 1 else 0 end		as continuous_med_cov_ind
              , case when min(min_snp_flag) = max(max_snp_flag) then 1 else 0 end		as continuous_snp_flag
              , case when min(min_snp_typ) = max(max_snp_typ) then 1 else 0 end		as continuous_snp_typ
              , case when min(min_dec_risk_typ) = max(max_dec_risk_typ) then 1 else 0 end		as continuous_dec_risk_typ
              , case when min(min_dec_risk_typ_desc) = max(max_dec_risk_typ_desc) then 1 else 0 end		as continuous_dec_risk_typ_desc
              , case when min(min_mapd_flag) = max(max_mapd_flag) then 1 else 0 end		as continuous_mapd_flag
              , case when min(min_medicare_part_d_only_flag) = max(max_medicare_part_d_only_flag) then 1 else 0 end		as continuous_medicare_part_d_only_flag
              , case when min(min_medicare_advantage_flag) = max(max_medicare_advantage_flag) then 1 else 0 end		as continuous_medicare_advantage_flag
              , case when min(min_zip) = max(max_zip) then 1 else 0 end		as continuous_zip
          from mm_detail a
          group by
              savvy_pid
              , savvy_did
              , is_restricted
              , range_grouper
          )
      , range_sources as
          (select a.savvy_pid, a.range_grouper, array_agg(distinct src_type order by src_type) as src_types
          from mbr_range                                                  a
            join `research-01-217611.df_ucd_stage.wkg_member_month`       b on a.savvy_pid = b.savvy_pid
                                                                            and b.year_mo between a.range_start_year_mo and a.range_end_year_mo
            cross join unnest(b.src_types) as src_type
          group by a.savvy_pid, a.range_grouper
          )
  select
    mbr_range.savvy_pid
    , mbr_range.savvy_did
    , mbr_range.is_restricted
    , mbr_range.range_start_year_mo
    , mbr_range.range_end_year_mo
    , mbr_range.range_mm
    , mbr_range.mm_2016
    , mbr_range.mm_2017
    , mbr_range.mm_2018
    , mbr_range.mm_2019
    , mbr_range.mm_2020
    , mbr_range.mm_2021
    , mbr_range.continuous_cust_seg_nbr
    , mbr_range.continuous_cust_seg_nm
    , mbr_range.continuous_co_nm
    , mbr_range.continuous_hlth_pln_fund_cd
    , mbr_range.continuous_contr_nbr
    , mbr_range.continuous_contr_pbp
    , mbr_range.continuous_contr_desc
    , mbr_range.continuous_business_line
    , mbr_range.continuous_phrm_cov_ind
    , mbr_range.continuous_med_cov_ind
    , mbr_range.continuous_snp_flag
    , mbr_range.continuous_snp_typ
    , mbr_range.continuous_dec_risk_typ
    , mbr_range.continuous_dec_risk_typ_desc
    , mbr_range.continuous_mapd_flag
    , mbr_range.continuous_medicare_part_d_only_flag
    , mbr_range.continuous_medicare_advantage_flag
    , mbr_range.continuous_zip
    , last_mo.max_cust_seg_nbr		as last_cust_seg_nbr
    , last_mo.max_cust_seg_nm		as last_cust_seg_nm
    , last_mo.max_co_nm		as last_co_nm
    , last_mo.max_hlth_pln_fund_cd		as last_hlth_pln_fund_cd
    , last_mo.max_contr_nbr		as last_contr_nbr
    , last_mo.max_contr_pbp		as last_contr_pbp
    , last_mo.max_contr_desc		as last_contr_desc
    , last_mo.max_business_line		as last_business_line
    , last_mo.max_phrm_cov_ind		as last_phrm_cov_ind
    , last_mo.max_med_cov_ind		as last_med_cov_ind
    , last_mo.max_snp_flag		as last_snp_flag
    , last_mo.max_snp_typ		as last_snp_typ
    , last_mo.max_dec_risk_typ		as last_dec_risk_typ
    , last_mo.max_dec_risk_typ_desc		as last_dec_risk_typ_desc
    , last_mo.max_mapd_flag		as last_mapd_flag
    , last_mo.max_medicare_part_d_only_flag		as last_medicare_part_d_only_flag
    , last_mo.max_medicare_advantage_flag		as last_medicare_advantage_flag
    , last_mo.max_zip		as last_zip
    , range_sources.src_types
    , current_datetime as create_datetime
    , current_datetime as update_datetime
  from                                              mbr_range
    join mm_detail                                  last_mo               using (savvy_pid, range_grouper)
    join                                            range_sources    using (savvy_pid, range_grouper)
  where
    mbr_range.range_end_year_mo = last_mo.year_mo
  ;

  /*
  create or replace table `research-01-217611.df_ucd_stage.member_enrollment_period`
    (month_count    INT64   OPTIONS(description="")
    , start_year_mo    INT64   OPTIONS(description="")
    , end_year_mo    INT64   OPTIONS(description="")
    , start_date    DATE   OPTIONS(description="")
    , end_date    DATE   OPTIONS(description="")
    , savvy_pid    INT64   OPTIONS(description="Unique member identifier")
    , continuous_cust_seg_nbr    INT64   OPTIONS(description="1 if cust_seg_nbr is the same during the entire period; otherwise 0")
    , continuous_cust_seg_nm    INT64   OPTIONS(description="1 if cust_seg_nm is the same during the entire period; otherwise 0")
    , continuous_co_nm    INT64   OPTIONS(description="1 if co_nm is the same during the entire period; otherwise 0")
    , continuous_hlth_pln_fund_cd    INT64   OPTIONS(description="1 if hlth_pln_fund_cd is the same during the entire period; otherwise 0")
    , continuous_contr_nbr    INT64   OPTIONS(description="1 if contr_nbr is the same during the entire period; otherwise 0")
    , continuous_contr_pbp    INT64   OPTIONS(description="1 if contr_pbp is the same during the entire period; otherwise 0")
    , continuous_contr_desc    INT64   OPTIONS(description="1 if contr_desc is the same during the entire period; otherwise 0")
    , continuous_business_line    INT64   OPTIONS(description="1 if business_line is the same during the entire period; otherwise 0")
    , continuous_phrm_cov_ind    INT64   OPTIONS(description="1 if phrm_cov_ind is the same during the entire period; otherwise 0")
    , continuous_med_cov_ind    INT64   OPTIONS(description="1 if med_cov_ind is the same during the entire period; otherwise 0")
    , continuous_snp_flag    INT64   OPTIONS(description="1 if snp_flag is the same during the entire period; otherwise 0")
    , continuous_snp_typ    INT64   OPTIONS(description="1 if snp_typ is the same during the entire period; otherwise 0")
    , continuous_dec_risk_typ    INT64   OPTIONS(description="1 if dec_risk_typ is the same during the entire period; otherwise 0")
    , continuous_dec_risk_typ_desc    INT64   OPTIONS(description="1 if dec_risk_typ_desc is the same during the entire period; otherwise 0")
    , continuous_mapd_flag    INT64   OPTIONS(description="1 if mapd_flag is the same during the entire period; otherwise 0")
    , continuous_medicare_part_d_only_flag    INT64   OPTIONS(description="1 if medicare_part_d_only_flag is the same during the entire period; otherwise 0")
    , continuous_medicare_advantage_flag    INT64   OPTIONS(description="1 if medicare_advantage_flag is the same during the entire period; otherwise 0")
    , continuous_zip    INT64   OPTIONS(description="1 if zip is the same during the entire period; otherwise 0")
    , last_cust_seg_nbr    STRING   OPTIONS(description="(max) cust_seg_nbr in the last month of the entire period")
    , last_cust_seg_nm    STRING   OPTIONS(description="(max) cust_seg_nm in the last month of the entire period")
    , last_co_nm    STRING   OPTIONS(description="(max) co_nm in the last month of the entire period")
    , last_hlth_pln_fund_cd    STRING   OPTIONS(description="(max) hlth_pln_fund_cd in the last month of the entire period")
    , last_contr_nbr    STRING   OPTIONS(description="(max) contr_nbr in the last month of the entire period")
    , last_contr_pbp    STRING   OPTIONS(description="(max) contr_pbp in the last month of the entire period")
    , last_contr_desc    STRING   OPTIONS(description="(max) contr_desc in the last month of the entire period")
    , last_business_line    STRING   OPTIONS(description="(max) business_line in the last month of the entire period")
    , last_phrm_cov_ind    STRING   OPTIONS(description="(max) phrm_cov_ind in the last month of the entire period")
    , last_med_cov_ind    STRING   OPTIONS(description="(max) med_cov_ind in the last month of the entire period")
    , last_snp_flag    INT64   OPTIONS(description="(max) snp_flag in the last month of the entire period")
    , last_snp_typ    STRING   OPTIONS(description="(max) snp_typ in the last month of the entire period")
    , last_dec_risk_typ    STRING   OPTIONS(description="(max) dec_risk_typ in the last month of the entire period")
    , last_dec_risk_typ_desc    STRING   OPTIONS(description="(max) dec_risk_typ_desc in the last month of the entire period")
    , last_mapd_flag    INT64   OPTIONS(description="(max) mapd_flag in the last month of the entire period")
    , last_medicare_part_d_only_flag    INT64   OPTIONS(description="(max) medicare_part_d_only_flag in the last month of the entire period")
    , last_medicare_advantage_flag    INT64   OPTIONS(description="(max) medicare_advantage_flag in the last month of the entire period")
    , last_zip    STRING   OPTIONS(description="(max) zip in the last month of the entire period")

    --metadata columns
    , create_datetime          datetime   OPTIONS(description = "datetime record was created")
    , update_datetime          datetime   OPTIONS(description = "datetime record was updated")
    )

    OPTIONS(description='1 row per member per continuously enrolled period of (3,6,9,12,18,24,36,48,60)-months, which can span multiple plans. The "continuous_" columns indicate whether the member\'s plan had the same characteristics in month in the period, while the "last_" columns indicate the most recent characteristics of the member\`s plan in the period. A member with membership from 201901-201907, for example, would have 3-month periods ending in each month from 201903-201907 and 6-month periods ending in 201906 and 201907.'
    )

    as

  with
      continuous_enrollment_periods as
          (select
            tp.time_period_id
            , mm.savvy_pid
            , case when min(mm.min_cust_seg_nbr) = max(mm.max_cust_seg_nbr) then 1 else 0 end as continuous_cust_seg_nbr
            , case when min(mm.min_cust_seg_nm) = max(mm.max_cust_seg_nm) then 1 else 0 end as continuous_cust_seg_nm
            , case when min(mm.min_co_nm) = max(mm.max_co_nm) then 1 else 0 end as continuous_co_nm
            , case when min(mm.min_hlth_pln_fund_cd) = max(mm.max_hlth_pln_fund_cd) then 1 else 0 end as continuous_hlth_pln_fund_cd
            , case when min(mm.min_contr_nbr) = max(mm.max_contr_nbr) then 1 else 0 end as continuous_contr_nbr
            , case when min(mm.min_contr_pbp) = max(mm.max_contr_pbp) then 1 else 0 end as continuous_contr_pbp
            , case when min(mm.min_contr_desc) = max(mm.max_contr_desc) then 1 else 0 end as continuous_contr_desc
            , case when min(mm.min_business_line) = max(mm.max_business_line) then 1 else 0 end as continuous_business_line
            , case when min(mm.min_phrm_cov_ind) = max(mm.max_phrm_cov_ind) then 1 else 0 end as continuous_phrm_cov_ind
            , case when min(mm.min_med_cov_ind) = max(mm.max_med_cov_ind) then 1 else 0 end as continuous_med_cov_ind
            , case when min(mm.min_snp_flag) = max(mm.max_snp_flag) then 1 else 0 end as continuous_snp_flag
            , case when min(mm.min_snp_typ) = max(mm.max_snp_typ) then 1 else 0 end as continuous_snp_typ
            , case when min(mm.min_dec_risk_typ) = max(mm.max_dec_risk_typ) then 1 else 0 end as continuous_dec_risk_typ
            , case when min(mm.min_dec_risk_typ_desc) = max(mm.max_dec_risk_typ_desc) then 1 else 0 end as continuous_dec_risk_typ_desc
            , case when min(mm.min_mapd_flag) = max(mm.max_mapd_flag) then 1 else 0 end as continuous_mapd_flag
            , case when min(mm.min_medicare_part_d_only_flag) = max(mm.max_medicare_part_d_only_flag) then 1 else 0 end as continuous_medicare_part_d_only_flag
            , case when min(mm.min_medicare_advantage_flag) = max(mm.max_medicare_advantage_flag) then 1 else 0 end as continuous_medicare_advantage_flag
            , case when min(mm.min_zip) = max(mm.max_zip) then 1 else 0 end as continuous_zip
          from `research-01-217611.df_ucd_stage.wkg_continuous_time_periods`  tp
            join `research-01-217611.df_ucd_stage.wkg_member_month`           mm on mm.year_mo between tp.start_year_mo and tp.end_year_mo
          --where savvy_pid in (15534, 42635, 111280, 149709)
          group by
            tp.time_period_id
            , tp.month_count
            , mm.savvy_pid
          having
            tp.month_count = count(distinct mm.year_mo)
          )
  select
    tp.month_count
    , tp.start_year_mo
    , tp.end_year_mo
    , tp.start_date
    , tp.end_date
    , ce.savvy_pid
    , ce.continuous_cust_seg_nbr
    , ce.continuous_cust_seg_nm
    , ce.continuous_co_nm
    , ce.continuous_hlth_pln_fund_cd
    , ce.continuous_contr_nbr
    , ce.continuous_contr_pbp
    , ce.continuous_contr_desc
    , ce.continuous_business_line
    , ce.continuous_phrm_cov_ind
    , ce.continuous_med_cov_ind
    , ce.continuous_snp_flag
    , ce.continuous_snp_typ
    , ce.continuous_dec_risk_typ
    , ce.continuous_dec_risk_typ_desc
    , ce.continuous_mapd_flag
    , ce.continuous_medicare_part_d_only_flag
    , ce.continuous_medicare_advantage_flag
    , ce.continuous_zip
    , last_mo.max_cust_seg_nbr as last_cust_seg_nbr
    , last_mo.max_cust_seg_nm as last_cust_seg_nm
    , last_mo.max_co_nm as last_co_nm
    , last_mo.max_hlth_pln_fund_cd as last_hlth_pln_fund_cd
    , last_mo.max_contr_nbr as last_contr_nbr
    , last_mo.max_contr_pbp as last_contr_pbp
    , last_mo.max_contr_desc as last_contr_desc
    , last_mo.max_business_line as last_business_line
    , last_mo.max_phrm_cov_ind as last_phrm_cov_ind
    , last_mo.max_med_cov_ind as last_med_cov_ind
    , last_mo.max_snp_flag as last_snp_flag
    , last_mo.max_snp_typ as last_snp_typ
    , last_mo.max_dec_risk_typ as last_dec_risk_typ
    , last_mo.max_dec_risk_typ_desc as last_dec_risk_typ_desc
    , last_mo.max_mapd_flag as last_mapd_flag
    , last_mo.max_medicare_part_d_only_flag as last_medicare_part_d_only_flag
    , last_mo.max_medicare_advantage_flag as last_medicare_advantage_flag
    , last_mo.max_zip as last_zip

    , current_datetime as create_datetime
    , current_datetime as update_datetime
  from
    `research-01-217611.df_ucd_stage.wkg_continuous_time_periods`     tp
    join continuous_enrollment_periods                                ce      on tp.time_period_id = ce.time_period_id
    join `research-01-217611.df_ucd_stage.wkg_member_month`           last_mo on ce.savvy_pid = last_mo.savvy_pid
                                                                              and tp.end_year_mo = last_mo.year_mo
  ;
  */
  --if successful, we'll get here!
  insert into `research-01-217611.df_ucd_stage.logging`(
    success_flag, job, message_datetime)
  select
    1 as success_flag
    , 'create continuous membership breakout tables' as job
    , current_datetime as message_datetime
  ;

  EXCEPTION WHEN ERROR THEN
    insert into `research-01-217611.df_ucd_stage.logging`(
      success_flag, job, error_message, statement_text, formatted_stack_trace, message_datetime)
    select
      0 as success_flag
      , 'create continuous membership breakout tables' as job
      , @@error.message as error_message
      , @@error.statement_text as statement_text
      , @@error.formatted_stack_trace as formatted_stack_trace
      , current_datetime as message_datetime
    ;


END
;
