/***
Universal Claims Data - Member detail enriched

Date Created: 28 October 2020
***/

BEGIN

--census
create or replace table `research-01-217611.df_ucd_stage.tmp_ucd_census` as
with cte_census as (
      select a.*
        , ifnull(round(safe_divide(b15003_002+b15003_003+b15003_004+b15003_005+b15003_006+b15003_007+b15003_008+b15003_009+b15003_010+b15003_011+b15003_012+b15003_013+b15003_014+b15003_015,b15003_001),2),0) as low_educ
        , ifnull(round(safe_divide(b15003_022+b15003_023+b15003_024+b15003_025,b15003_001),2),0) as high_educ
        , ifnull(round(b19013_001,2),0)                         as income
        , ifnull(round(safe_divide(b17020_002,b17020_001),2),0) as poverty
        , ifnull(round(safe_divide(b23025_005,b23025_001),2),0) as unemployment
        , ifnull(round(b25077_001,2),0)                         as property
        , ifnull(round(safe_divide((b25014_005+b25014_006+b25014_007+b25014_011+b25014_012+b25014_013),b25014_001),2),0) as household
        , B15003_001, B15003_002, B15003_003, B15003_004, B15003_005, B15003_006, B15003_007, B15003_008, B15003_009, B15003_010, B15003_011, B15003_012, B15003_013, B15003_014, B15003_015
        , B15003_016, B15003_017, B15003_018, B15003_019, B15003_020, B15003_021, B15003_022, B15003_023, B15003_024, B15003_025
        , B19083_001
        , B19013_001
        , B17020_001, B17020_002, B17020_010
        , B02001_001, B02001_002, B02001_003, B02001_004, B02001_005, B02001_006, B02001_007, B02001_008
        , B23025_001, B23025_002, B23025_003, B23025_004, B23025_005, B23025_006, B23025_007
        , B25077_001
        , B25014_001, B25014_002, B25014_003, B25014_004, B25014_005 , B25014_006, B25014_007, B25014_008, B25014_009, B25014_010
        , B25014_011, B25014_012, B25014_013
      from `research-01-217611.df_enrichment.census_geography` a
      inner join `research-01-217611.df_enrichment.census_2017` b on a.logrecno = b.logrecno and a.year = b.year and lower(trim(a.state)) = lower(trim(b.statecode))
      where a.year = 2017
        --and a.state = 'mn'
        and b.statisticsid = 1
        --and a.name like 'zcta%'
      --order by a.logrecno
   )
, cte_ses1 as (
      select ifnull(max(b19013_001),0) as income_max
           , ifnull(min(b19013_001),0) as income_min
           , ifnull(max(b25077_001),0) as property_max
           , ifnull(min(b25077_001),0) as property_min
      from `research-01-217611.df_enrichment.census_geography` a
      join `research-01-217611.df_enrichment.census_2017` b on trim(b.logrecno) = trim(a.logrecno)
                                                          and trim(lower(b.statecode)) = trim(lower(a.state))
                                                          and b.statisticsid = 1
                                                          and b.year = 2017
   )
, cte_ses as (
      select state
            , logrecno
            , geoid
            , round(50 + 100*((-0.07*household)+(0.08*property)+(-0.10*poverty)+(0.11*income)+(0.10*high_educ)+(-0.11*low_educ)+(-0.08*unemployment)),2) as ses_index
       from (
                select logrecno
                   , state
                   , geoid
                   , safe_divide(income - income_min,income_max- income_min)         as income
                   , safe_divide(property - property_min,property_max- property_min) as property
                   , low_educ
                   , high_educ
                   , household
                   , poverty
                   , unemployment
              from cte_census a cross join cte_ses1 b
           )
   )
select a.*, concat(safe.substr(a.geoid, 8, 2), safe.substr(a.geoid, 10, 3)) as fips, b.ses_index
  , (case when a.geoid like '86000us%' then  safe.substr(a.geoid, 8, 5) end) as zcta
from cte_census a
inner join cte_ses b on a.logrecno = b.logrecno and a.geoid = b.geoid   --a.state = b.state
--579,055
;
--build
insert into `research-01-217611.df_ucd_stage.member_detail_enriched`
    (savvy_pid, savvy_did, is_restricted, src_type, business_line, year_mo, month_id, month_nbr, year_qtr, year_nbr, birth_year, age, gender, death_flag, death_date, zip, st_cd, county, msa, zcta, fips, usr_class, division, region, data_source, coverage_type, product_id, medicaid_program, cust_seg_nbr, cust_seg_nm, sbscr_nbr, sbscr_ind, orec, family_id, rel_cd, rel_desc, phrm_cov_ind, phrm_cov_flag, med_cov_ind, med_cov_flag, co_nm, hlth_pln_fund_cd, hlth_pln_fund_cd_desc, finc_arng_cd, finc_arng_desc, contr_nbr, contr_pbp, contr_desc, contr_yr, policy_state, snp_flag, snp_typ, sub_product, dec_risk_typ, dec_risk_typ_desc, dual_elig, mapd_flag, medicare_part_d_only_flag, medicare_advantage_flag, medicaid_flag, original_effective_date, termination_date, reinstatement_date, conversion_date, group_type_code, smaindicator, pcp_npi, pcp_comm_prac_id, geoid, logrecno, census_year, low_educ, high_educ, income, poverty, unemployment, property, household, ses_index, b15003_001, b15003_002, b15003_003, b15003_004, b15003_005, b15003_006, b15003_007, b15003_008, b15003_009, b15003_010, b15003_011, b15003_012, b15003_013, b15003_014, b15003_015, b15003_016, b15003_017, b15003_018, b15003_019, b15003_020, b15003_021, b15003_022, b15003_023, b15003_024, b15003_025, b19083_001, b19013_001, b17020_001, b17020_002, b17020_010, b02001_001, b02001_002, b02001_003, b02001_004, b02001_005, b02001_006, b02001_007, b02001_008, b23025_001, b23025_002, b23025_003, b23025_004, b23025_005, b23025_006, b23025_007, b25077_001, b25014_001, b25014_002, b25014_003, b25014_004, b25014_005, b25014_006, b25014_007, b25014_008, b25014_009, b25014_010, b25014_011, b25014_012, b25014_013
    )
with cte_death_dt as (
      select distinct savvy_pid
       , if((max(flag) over(partition by savvy_pid)) = 1, max(derived_date_of_death) over(partition by savvy_pid), min(derived_date_of_death) over(partition by savvy_pid)) as derived_date_of_death
      from (
              select distinct a.savvy_pid
                   , (case when trim(transactionreplycode) = '091' then 1 else 0 end) as flag
                   , cast(deriveddateofdeath as date)    as derived_date_of_death
                   , b.transactioneffectivedate, b.transactiondate, transactionreplycode
              from `research-01-217611.df_ucd_stage.udd_member_detail_consolidated` a
              inner join `ds-00-191017.cms_final.cmstrr_current_p`                  b on a.savvy_pid = b.savvy_pid
              where trim(transactionreplycode) in ('090', '091', '092')
                and a.year_mo > 201512
           ) z
    )
, cte_mmr_orec as (
      select *
      from (
             select a.savvy_pid
                  , a.year_mo
                  , (case when trim(b.originalreasonforentitlement) = '9' then '0' else  trim(b.originalreasonforentitlement) end)    as orec
                  , (case when trim(b.medicaidstatusflag) = '1' then 1 else 0  end)                                                   as dual_elig
                  , concat(lower(trim(b.contractnumber)), '-', lower(trim(b.planbenefitpackageid))) as contr_pbp
                  , lower(trim(b.contractnumber)) as contr_nbr
                  , lower(trim(d.pbpdescription)) as contr_desc
                  , d.contract_year as contr_yr
                  , d.medicare_advantage_flag, d.mapd_flag, d.medicare_part_d_only_flag
                  , row_number() over(partition by a.savvy_pid, a.year_mo order by b.paymentadjustmentenddate desc, b.adjustmentreasoncode is null desc) as oid
             from `research-01-217611.df_ucd_stage.udd_member_detail_consolidated`   a
             inner join `ds-00-191017.cms_final.cmsmmr_current_p`                    b on a.savvy_pid = b.savvy_pid and a.year_mo = cast(lower(trim(b.paymentdateym)) as int64)
             inner join `research-01-217611.df_ucd_stage.dim_month`                  c on a.year_mo = c.year_mo
             left join (
                         select contractnumber, planbenefitpackageid, pbpstart, pbpend, pbpdescription, pbpstate, concat(lower(trim(contractnumber)), '-', lower(trim(planbenefitpackageid))) as contr_pbp
                           , extract(year from pbpstart) as contract_year
                           , (case when isma is true then 1 else 0 end) as medicare_advantage_flag
                           , (case when ismapd is true then 1 else 0 end) as mapd_flag
                           , (case when ispdponly is true then 1 else 0 end) as medicare_part_d_only_flag
                         from `ds-00-191017.cms_final.refplanbenefitpackage`
                       ) d   on c.year_nbr = d.contract_year
                            and concat(lower(trim(b.contractnumber)), '-', lower(trim(b.planbenefitpackageid))) = d.contr_pbp
             where a.year_mo > 201512
        ) a
      where oid = 1
    )
, cte_contracpbp as (
      select *
        , (case when state_code is null then lead(state_code) over(partition by contract_id, plan_id order by contract_year) else state_code end) as derv_statecode
      from (
            select 2016 as contract_year, contract_id, plan_id, plan_name, state_code
            from `research-01-217611.df_enrichment.medicare_plan_finder_2017`

            union distinct
            select contract_year, contract_id, plan_id, plan_name, state_code
            from `research-01-217611.df_enrichment.medicare_plan_finder_2017`

            union distinct
            select contract_year, contract_id, plan_id, plan_name, state_code
            from `research-01-217611.df_enrichment.medicare_plan_finder_2018`

            union distinct
            select contract_year, contract_id, plan_id, plan_name, state_code
            from `research-01-217611.df_enrichment.medicare_plan_finder_2019`

            union distinct
            select 2020 as contract_year, contract_id, plan_id, plan_name, state_code
            from `research-01-217611.df_enrichment.medicare_plan_finder_2019`   --we should add 2020 medicare plan finder
           ) z
   )
select a.savvy_pid, a.savvy_did, a.is_restricted, a.src_type, a.business_line
  , a.year_mo, c.month_id, c.month_nbr, c.year_qtr, c.year_nbr
  , a.* except(savvy_pid, savvy_did, is_restricted, src_type, business_line, year_mo)
  , d.geoid
  , d.logrecno
  , d.year as census_year
  , low_educ
  , high_educ
  , income
  , poverty
  , unemployment
  , property
  , household
  , ses_index
  , B15003_001, B15003_002, B15003_003, B15003_004, B15003_005, B15003_006, B15003_007, B15003_008, B15003_009, B15003_010, B15003_011, B15003_012, B15003_013, B15003_014, B15003_015
  , B15003_016, B15003_017, B15003_018, B15003_019, B15003_020, B15003_021, B15003_022, B15003_023, B15003_024, B15003_025
  , B19083_001
  , B19013_001
  , B17020_001, B17020_002, B17020_010
  , B02001_001, B02001_002, B02001_003, B02001_004, B02001_005, B02001_006, B02001_007, B02001_008
  , B23025_001, B23025_002, B23025_003, B23025_004, B23025_005, B23025_006, B23025_007
  , B25077_001
  , B25014_001, B25014_002, B25014_003, B25014_004, B25014_005 , B25014_006, B25014_007, B25014_008, B25014_009, B25014_010
  , B25014_011, B25014_012, B25014_013
from (
        select a.savvy_pid
          , a.savvy_did
          , a.is_restricted
          , a.src_type
          , a.business_line
          , a.year_mo
          , a.birth_year
          , (extract(year from current_date()) - a.birth_year) as age
          , a.gender
          , (case when b.derived_date_of_death is not null then 1 else 0 end) as death_flag
          , b.derived_date_of_death as death_date
          , a.zip
          , ifnull(lower(trim(d.St_Cd)), '') as st_cd
          , ifnull(lower(trim(d.County)), '') as county
          , ifnull(lower(trim(d.MSA)), '') as msa
          , ifnull(trim(e.ZCTA), '') as zcta
          , ifnull(lower(trim(d.FIPS)), '') as fips
          , ifnull(lower(trim(e.USR_Class)), '') as usr_class
          , (case when upper(trim(d.St_Cd)) in ('CT', 'MA', 'ME', 'NH', 'RI', 'VT')                   then 'new england'
                  when upper(trim(d.St_Cd)) in ('NJ', 'NY', 'PA')                                     then 'mid atlantic'
                  when upper(trim(d.St_Cd)) in ('IL', 'IN', 'MI', 'OH', 'WI')                         then 'east north central'
                  when upper(trim(d.St_Cd)) in ('IA', 'KS', 'MN', 'MO', 'ND', 'NE', 'SD')             then 'west north central'
                  when upper(trim(d.St_Cd)) in ('DC', 'DE', 'FL', 'GA', 'MD', 'NC', 'SC', 'VA', 'WV') then 'south atlantic'
                  when upper(trim(d.St_Cd)) in ('AL', 'KY', 'MS', 'TN')                               then 'east south central'
                  when upper(trim(d.St_Cd)) in ('AR', 'LA', 'OK', 'TX')                               then 'west south central'
                  when upper(trim(d.St_Cd)) in ('AZ', 'CO', 'ID', 'MT', 'NM', 'NV', 'UT', 'WY')       then 'mountain'
                  when upper(trim(d.St_Cd)) in ('AK', 'CA', 'HI', 'OR', 'WA')                         then 'pacific'
             else 'other' end) as division
          , (case when upper(trim(d.St_Cd)) in ('CT', 'MA', 'ME', 'NH', 'RI', 'VT', 'NJ', 'NY', 'PA')                                                  then 'northeast'
                  when  upper(trim(d.St_Cd)) in ('IL', 'IN', 'MI', 'OH', 'WI', 'IA', 'KS', 'MN', 'MO', 'ND', 'NE', 'SD')                               then 'midwest'
                  when  upper(trim(d.St_Cd)) in ('DC', 'DE', 'FL', 'GA', 'MD', 'NC', 'SC', 'VA', 'WV', 'AL', 'KY', 'MS', 'TN', 'AR', 'LA', 'OK', 'TX') then 'south'
                  when  upper(trim(d.St_Cd)) in ('AZ', 'CO', 'ID', 'MT', 'NM', 'NV', 'UT', 'WY', 'AK', 'CA', 'HI', 'OR', 'WA')                         then 'west'
             else 'other' end) as region
          , a.data_source
          , a.coverage_type
          , a.product_id
          , a.medicaid_program
          , a.cust_seg_nbr
          , a.cust_seg_nm
          , a.sbscr_nbr
          , a.sbscr_ind
          , ifnull(c.orec, (case when a.business_line = 'medicare' then '0' else '' end)) as orec
          , a.family_id
          , a.rel_cd
          , a.rel_desc
          , a.phrm_cov_ind
          , (case when a.phrm_cov_ind = 'y' then 1 else 0 end) as phrm_cov_flag
          , a.med_cov_ind
          , (case when a.med_cov_ind = 'y' then 1 else 0 end) as med_cov_flag
          , a.co_nm
          , ifnull(a.hlth_pln_fund_cd, '') as hlth_pln_fund_cd
          , ifnull((case when a.hlth_pln_fund_cd = 'fi'   then 'fully insured'
                         when a.hlth_pln_fund_cd = 'aso'  then 'aso'  else f.hlth_pln_fund_cd_desc end), '') as hlth_pln_fund_cd_desc
          , a.finc_arng_cd
          , a.finc_arng_desc
          , coalesce(a.contr_nbr, c.contr_nbr, '') as contr_nbr
          , coalesce(a.contr_pbp, c.contr_pbp, '') as contr_pbp
          , coalesce(a.contr_desc, c.contr_desc, '') as contr_desc
          , coalesce(a.contr_yr, c.contr_yr) as contr_yr
          , coalesce(y.derv_statecode, f.company_st_cd, '') as policy_state
          , a.snp_flag
          , a.snp_typ
          , a.sub_product
          , a.dec_risk_typ
          , a.dec_risk_typ_desc
          , coalesce(c.dual_elig, (case when (a.business_line = 'commercial' and (a.medicare_advantage_flag = 1 or a.medicaid_flag = 1))
                                          or (a.medicare_advantage_flag = 1 and a.medicaid_flag = 1) then 1 else 0 end), 0) as dual_elig
          , coalesce(a.mapd_flag, c.mapd_flag) as mapd_flag
          , coalesce(a.medicare_part_d_only_flag, c.medicare_part_d_only_flag) as medicare_part_d_only_flag
          , coalesce(a.medicare_advantage_flag, c.medicare_advantage_flag) as medicare_advantage_flag
          , a.medicaid_flag
          , a.original_effective_date
          , a.termination_date
          , a.reinstatement_date
          , a.conversion_date
          , a.group_type_code
          , a.smaindicator
          , a.pcp_npi
          , a.pcp_comm_prac_id
        from `research-01-217611.df_ucd_stage.udd_member_detail_consolidated` a
        left join cte_death_dt                                                b on a.savvy_pid = b.savvy_pid
        left join cte_mmr_orec                                                c on a.savvy_pid = c.savvy_pid and a.year_mo = c.year_mo
        left join cte_contracpbp                                              y on a.contr_yr = y.contract_year and lower(trim(a.contr_pbp)) = concat(lower(trim(y.contract_id)), '-', lower(trim(y.plan_id)))
        left join `research-01-217611.df_enrichment.Zip_Census` d on trim(a.zip) = trim(d.zip)
        left join `research-01-217611.df_enrichment.ZCTA`       e on trim(d.zcta) = trim(e.ZCTA)
        left join `research-01-217611.df_ucd_stage.dim_customer_segment_detail` f on a.cust_seg_nbr = f.cust_seg_nbr and a.year_mo = f.year_mo
    ) a
left join `research-01-217611.df_ucd_stage.tmp_ucd_census` d on d.fips = a.fips
                                                            and d.geoid like '050%'  --county level roll up
left join `research-01-217611.df_ucd_stage.dim_month`      c on a.year_mo = c.year_mo
;

  --if successful, we'll get here!
  insert into `research-01-217611.df_ucd_stage.logging`(
    success_flag, job, message_datetime)
  select
    1 as success_flag
    , 'create member detail enriched table' as job
    , current_datetime as message_datetime
  ;

  EXCEPTION WHEN ERROR THEN
    insert into `research-01-217611.df_ucd_stage.logging`(
      success_flag, job, error_message, statement_text, formatted_stack_trace, message_datetime)
    select
      0 as success_flag
      , 'create member detail tables' as job
      , @@error.message as error_message
      , @@error.statement_text as statement_text
      , @@error.formatted_stack_trace as formatted_stack_trace
      , current_datetime as message_datetime
    ;

END
;
