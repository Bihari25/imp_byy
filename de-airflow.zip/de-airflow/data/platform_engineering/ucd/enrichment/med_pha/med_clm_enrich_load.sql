/* =====================================================================================================
   Author(s):     Susan Mehle (smehle@uhg.SavvySherpa.com) and Seth Grossinger (sethgrossinger@uhg.com)
   Create date:   10/27/2020
   Data Product:  Universal Claims Data (UCD)
   Description: 	Adds descriptions and additional date fields to the UCD Medical Claims table.
                  A single script exceeds system resources, so the process has been broken into several
                  smaller steps
   Date Range:    Begins in 2016
   Granularity:   Per member per src_type per claim line

   Input:

   Output:
   ===================================================================================================== */

BEGIN
  DECLARE yr_start INT64 DEFAULT 2016;
  DECLARE yr_stop INT64 DEFAULT EXTRACT(YEAR FROM CURRENT_DATE());


  /* ===================================================================================================== */
  /* Create dimension tables to use */
      --one big cause of performance problems is joining to large dimension tables, so we'll create working
      --copies of just what we need. Provider is the big problem here, but we'll clean up diagnosis and
      --procedure while we're at it
  /* ===================================================================================================== */

  create or replace table `research-01-217611.df_ucd_stage.wkg_dim_provider_in_use`
    cluster by mpin
    as
    (
    select prov.*
    from
        `research-01-217611.df_ucd_stage.dim_provider`                prov
        join (select distinct prov_mpin from `research-01-217611.df_ucd_stage.udd_medical_claim_consolidated`
              union distinct
              select distinct prov_mpin from `research-01-217611.df_ucd_stage.udd_medical_claim_ihr`
              )                                                       clm  on clm.prov_mpin = prov.mpin
    where prov.mpin > 0 --only use the table if the mpin is known
    );

  create or replace table `research-01-217611.df_ucd_stage.wkg_dim_provider_npi_in_use`
    cluster by npi
    as
    (
    select prov.*
    from
        `research-01-217611.df_ucd_stage.dim_provider_npi`                prov
        join (select distinct npi from `research-01-217611.df_ucd_stage.udd_medical_claim_consolidated`
              union distinct
              select distinct npi  from `research-01-217611.df_ucd_stage.udd_medical_claim_ihr`
              )                                                       clm  on clm.npi = prov.npi
    where prov.npi > 0 --only use the table if the npi is known
    );


  create or replace table `research-01-217611.df_ucd_stage.wkg_dim_diagnosis_code_in_use`
    cluster by diag_cd, icd_ver_cd
    as
    (
    with cte_distinct_diag as
        (
        select distinct diag_cd, clm.icd_ver_cd
        from
          `research-01-217611.df_ucd_stage.udd_medical_claim_consolidated`             as clm
          cross join unnest(
                            [
                                clm.dx1_diag_cd, clm.dx2_diag_cd, clm.dx3_diag_cd,
                                clm.dx4_diag_cd, clm.dx5_diag_cd, clm.dx6_diag_cd,
                                clm.dx7_diag_cd, clm.dx8_diag_cd, clm.dx9_diag_cd,
                                clm.dx10_diag_cd, clm.dx11_diag_cd, clm.dx12_diag_cd
                            ]
                            )                                                          as diag_cd

        union distinct

        select distinct diag_cd, clm.icd_ver_cd
        from
          `research-01-217611.df_ucd_stage.udd_medical_claim_ihr`                      as clm
          cross join unnest(
                            [
                                clm.dx1_diag_cd, clm.dx2_diag_cd, clm.dx3_diag_cd,
                                clm.dx4_diag_cd, clm.dx5_diag_cd, clm.dx6_diag_cd,
                                clm.dx7_diag_cd, clm.dx8_diag_cd, clm.dx9_diag_cd,
                                clm.dx10_diag_cd, clm.dx11_diag_cd, clm.dx12_diag_cd
                            ]
                            )                                                          as diag_cd

        )
    select diag.*
    from
        `research-01-217611.df_ucd_stage.dim_diagnosis_code`          diag
        join cte_distinct_diag                                        clm  on clm.icd_ver_cd = diag.icd_ver_cd
                                                                           and clm.diag_cd = diag.diag_cd
    );


  create or replace table `research-01-217611.df_ucd_stage.wkg_dim_procedure_code_in_use`
    cluster by proc_cd
    as
    (
    with cte_distinct_proc as
        (
        select distinct px
        from
          `research-01-217611.df_ucd_stage.udd_medical_claim_consolidated`             as clm
          cross join unnest(
                            [
                                clm.proc_cd,
                                clm.prc1_proc_cd, clm.prc2_proc_cd, clm.prc3_proc_cd,
                                clm.prc4_proc_cd, clm.prc5_proc_cd, clm.prc6_proc_cd
                            ]
                            )                                                          as px

        union distinct

        select distinct proc_cd
        from
          `research-01-217611.df_ucd_stage.udd_medical_claim_ihr`                      as clm
          cross join unnest(
                            [
                                clm.proc_cd,
                                clm.prc1_proc_cd, clm.prc2_proc_cd, clm.prc3_proc_cd,
                                clm.prc4_proc_cd, clm.prc5_proc_cd, clm.prc6_proc_cd
                            ]
                            )                                                          as px

        )
    select proc.*
    from
        `research-01-217611.df_ucd_stage.dim_procedure_code`          proc
        join cte_distinct_proc                                        clm  on clm.px = proc.proc_cd
    );




  /* ======================================================================================================== */
  /* Create empty table`research-01-217611.df_ucd_stage.udd_medical_claim_enriched -- now handled as template */
  /* ======================================================================================================== */


  /* ===================================================================================================== */
  /* Create working tables */
  /* ===================================================================================================== */

    CREATE OR replace TABLE `research-01-217611.df_ucd_stage.wkg_member_detail_member_month_src_type`
    PARTITION BY range_bucket(year_nbr, generate_array(yr_start, yr_stop, 1)) AS
    --also used in pharmacy_claim_enriched
    --could be more than one record per member per year_mo, so let's get a single birth year, etc to use for age computation
    SELECT   savvy_pid
               ,year_mo
               ,year_nbr
               ,src_type
               ,max(birth_year) as birth_year
               ,max(is_restricted) as is_restricted
               ,max(case when hlth_pln_fund_cd = 'fi' then 1 else 0 end) as fi_flag --member was associated with fi plan during the month
               ,max(business_line) as business_line
               ,max(mapd_flag) mapd_flag
    FROM `research-01-217611.df_ucd_stage.udd_member_detail_consolidated` a
      join `research-01-217611.df_ucd_stage.dim_month` b using (year_mo)
    --WHERE savvy_pid IN (4923534,24539754,19784768,25619013,27012159,20887453,513199555,21950682,33067494,163438041) --SAMPLE
    GROUP BY savvy_pid, year_mo, year_nbr, src_type
    ;

    CREATE OR replace TABLE `research-01-217611.df_ucd_stage.wkg_medical_claim_enriched_diag1_columns`
    PARTITION BY range_bucket(year_nbr, generate_array(yr_start, yr_stop, 1)) AS
    SELECT claim.uuid
            ,EXTRACT(YEAR FROM claim.clm_dt) AS year_nbr
            ,claim.dx1_diag_cd
            ,dx1.diag_desc AS dx1_diag_desc
            ,dx1.diag_full_desc AS dx1_diag_full_desc
            ,dx1.diag_fst4_cd AS dx1_diag_fst4_cd
            ,dx1.diag_fst4_desc AS dx1_diag_fst4_desc
            ,dx1.diag_fst3_cd AS dx1_diag_fst3_cd
            ,dx1.diag_fst3_desc AS dx1_diag_fst3_desc
            ,dx1.diag_decm_cd AS dx1_diag_decm_cd
            ,dx1.ahrq_diag_genl_catgy_cd AS dx1_ahrq_diag_genl_catgy_cd
            ,dx1.ahrq_diag_genl_catgy_nm AS dx1_ahrq_diag_genl_catgy_nm
            ,dx1.ahrq_diag_dtl_catgy_cd AS dx1_ahrq_diag_dtl_catgy_cd
            ,dx1.ahrq_diag_dtl_catgy_nm AS dx1_ahrq_diag_dtl_catgy_nm
            ,dx1.chrnc_flg_nm AS dx1_chrnc_flg_nm
      FROM `research-01-217611.df_ucd_stage.udd_medical_claim_consolidated` AS claim
        LEFT JOIN `research-01-217611.df_ucd_stage.wkg_dim_diagnosis_code_in_use` AS dx1 ON claim.dx1_diag_cd = dx1.diag_cd and claim.icd_ver_cd = dx1.icd_ver_cd
    --WHERE savvy_pid IN (4923534,24539754,19784768,25619013,27012159,20887453,513199555,21950682,33067494,163438041) --SAMPLE
    ;

    create or replace table `research-01-217611.df_ucd_stage.wkg_medical_claim_enriched_diag2_columns`
    PARTITION BY range_bucket(year_nbr, generate_array(yr_start, yr_stop, 1)) AS
    SELECT claim.uuid
            ,EXTRACT(YEAR FROM claim.clm_dt) AS year_nbr
            ,claim.dx2_diag_cd
            ,dx2.diag_desc AS dx2_diag_desc
            ,dx2.diag_full_desc AS dx2_diag_full_desc
            ,dx2.diag_fst4_cd AS dx2_diag_fst4_cd
            ,dx2.diag_fst4_desc AS dx2_diag_fst4_desc
            ,dx2.diag_fst3_cd AS dx2_diag_fst3_cd
            ,dx2.diag_fst3_desc AS dx2_diag_fst3_desc
            ,dx2.diag_decm_cd AS dx2_diag_decm_cd
            ,dx2.ahrq_diag_genl_catgy_cd AS dx2_ahrq_diag_genl_catgy_cd
            ,dx2.ahrq_diag_genl_catgy_nm AS dx2_ahrq_diag_genl_catgy_nm
            ,dx2.ahrq_diag_dtl_catgy_cd AS dx2_ahrq_diag_dtl_catgy_cd
            ,dx2.ahrq_diag_dtl_catgy_nm AS dx2_ahrq_diag_dtl_catgy_nm
            ,dx2.chrnc_flg_nm AS dx2_chrnc_flg_nm
      FROM `research-01-217611.df_ucd_stage.udd_medical_claim_consolidated` AS claim
        LEFT JOIN `research-01-217611.df_ucd_stage.wkg_dim_diagnosis_code_in_use` AS dx2 ON claim.dx2_diag_cd = dx2.diag_cd and claim.icd_ver_cd = dx2.icd_ver_cd
    --WHERE savvy_pid IN (4923534,24539754,19784768,25619013,27012159,20887453,513199555,21950682,33067494,163438041) --SAMPLE
    ;

    create or replace table `research-01-217611.df_ucd_stage.wkg_medical_claim_enriched_diag3_columns`
    PARTITION BY range_bucket(year_nbr, generate_array(yr_start, yr_stop, 1)) AS
    SELECT claim.uuid
            ,EXTRACT(YEAR FROM claim.clm_dt) AS year_nbr
            ,claim.dx3_diag_cd
            ,dx3.diag_desc AS dx3_diag_desc
            ,dx3.diag_full_desc AS dx3_diag_full_desc
            ,dx3.diag_fst4_cd AS dx3_diag_fst4_cd
            ,dx3.diag_fst4_desc AS dx3_diag_fst4_desc
            ,dx3.diag_fst3_cd AS dx3_diag_fst3_cd
            ,dx3.diag_fst3_desc AS dx3_diag_fst3_desc
            ,dx3.diag_decm_cd AS dx3_diag_decm_cd
            ,dx3.ahrq_diag_genl_catgy_cd AS dx3_ahrq_diag_genl_catgy_cd
            ,dx3.ahrq_diag_genl_catgy_nm AS dx3_ahrq_diag_genl_catgy_nm
            ,dx3.ahrq_diag_dtl_catgy_cd AS dx3_ahrq_diag_dtl_catgy_cd
            ,dx3.ahrq_diag_dtl_catgy_nm AS dx3_ahrq_diag_dtl_catgy_nm
            ,dx3.chrnc_flg_nm AS dx3_chrnc_flg_nm
      FROM `research-01-217611.df_ucd_stage.udd_medical_claim_consolidated` AS claim
        LEFT JOIN `research-01-217611.df_ucd_stage.wkg_dim_diagnosis_code_in_use` AS dx3 ON claim.dx3_diag_cd = dx3.diag_cd and claim.icd_ver_cd = dx3.icd_ver_cd
  --WHERE savvy_pid IN (4923534,24539754,19784768,25619013,27012159,20887453,513199555,21950682,33067494,163438041) --SAMPLE
    ;

    create or replace table `research-01-217611.df_ucd_stage.wkg_medical_claim_enriched_proc_columns`
    PARTITION BY range_bucket(year_nbr, generate_array(yr_start, yr_stop, 1)) AS
    SELECT claim.uuid
            ,EXTRACT(YEAR FROM claim.clm_dt) AS year_nbr
            ,claim.proc_cd
            ,px0.proc_desc
            ,px0.proc_decm_cd
            ,px0.ahrq_proc_genl_catgy_cd
            ,px0.ahrq_proc_genl_catgy_desc
            ,px0.ahrq_proc_dtl_catgy_cd
            ,px0.ahrq_proc_dtl_catgy_desc
            ,px0.gdr_lmt_cd
            ,px0.proc_typ_cd
            ,prc1_proc_cd
            ,px1.proc_desc AS prc1_proc_desc
            ,px1.proc_decm_cd AS prc1_proc_decm_cd
            ,px1.ahrq_proc_genl_catgy_cd AS prc1_ahrq_proc_genl_catgy_cd
            ,px1.ahrq_proc_genl_catgy_desc AS prc1_ahrq_proc_genl_catgy_desc
            ,px1.ahrq_proc_dtl_catgy_cd AS prc1_ahrq_proc_dtl_catgy_cd
            ,px1.ahrq_proc_dtl_catgy_desc AS prc1_ahrq_proc_dtl_catgy_desc
            ,px1.gdr_lmt_cd AS prc1_gdr_lmt_cd
            ,px1.proc_typ_cd AS prc1_proc_typ_cd
            ,claim.proc_mod_1_cd
            ,proc_mod1.proc_mod_desc AS proc_mod_1_desc
            ,proc_mod1.proc_mod_grp_cd AS proc_mod_1_grp_cd
            ,proc_mod1.proc_mod_grp_desc AS proc_mod_1_grp_desc
            ,claim.proc_mod_2_cd
            ,proc_mod2.proc_mod_desc AS proc_mod_2_desc
            ,proc_mod2.proc_mod_grp_cd AS proc_mod_2_grp_cd
            ,proc_mod2.proc_mod_grp_desc AS proc_mod_2_grp_desc
            ,claim.proc_mod_3_cd
            ,proc_mod3.proc_mod_desc AS proc_mod_3_desc
            ,proc_mod3.proc_mod_grp_cd AS proc_mod_3_grp_cd
            ,proc_mod3.proc_mod_grp_desc AS proc_mod_3_grp_desc
      FROM `research-01-217611.df_ucd_stage.udd_medical_claim_consolidated` AS claim
        LEFT JOIN `research-01-217611.df_ucd_stage.wkg_dim_procedure_code_in_use` AS px0 ON claim.proc_cd = px0.proc_cd
        LEFT JOIN `research-01-217611.df_ucd_stage.wkg_dim_procedure_code_in_use` AS px1 ON claim.prc1_proc_cd = px1.proc_cd
        LEFT JOIN `research-01-217611.df_ucd_stage.dim_procedure_modifier_code` AS proc_mod1 ON claim.proc_mod_1_cd = proc_mod1.proc_mod_cd
        LEFT JOIN `research-01-217611.df_ucd_stage.dim_procedure_modifier_code` AS proc_mod2 ON claim.proc_mod_2_cd = proc_mod2.proc_mod_cd
        LEFT JOIN `research-01-217611.df_ucd_stage.dim_procedure_modifier_code` AS proc_mod3 ON claim.proc_mod_3_cd = proc_mod3.proc_mod_cd
  --WHERE savvy_pid IN (4923534,24539754,19784768,25619013,27012159,20887453,513199555,21950682,33067494,163438041) --SAMPLE
      ;

    create or replace table `research-01-217611.df_ucd_stage.wkg_medical_claim_enriched_prov_columns_mpin`
    PARTITION BY range_bucket(year_nbr, generate_array(yr_start, yr_stop, 1)) AS
    SELECT claim.uuid
            ,EXTRACT(YEAR FROM claim.clm_dt) AS year_nbr
            ,prov.prov_type AS provtype
            ,prov.mpin AS prov_mpin
            ,prov.npi AS npi
            ,prov.specialty_1_longdesc AS spec_typ_nm
            ,prov.pcp_flag AS pcp_flag

      FROM `research-01-217611.df_ucd_stage.udd_medical_claim_consolidated` AS claim
         JOIN `research-01-217611.df_ucd_stage.wkg_dim_provider_in_use` AS prov ON claim.prov_mpin = prov.mpin --already filters out mpin=0
    ;

    create or replace table `research-01-217611.df_ucd_stage.wkg_medical_claim_enriched_prov_columns_npi`
    PARTITION BY range_bucket(year_nbr, generate_array(yr_start, yr_stop, 1)) AS
    SELECT claim.uuid
            ,EXTRACT(YEAR FROM claim.clm_dt) AS year_nbr
            ,npi.prov_type AS provtype
            ,npi.mpin AS prov_mpin
            ,npi.npi AS npi
            ,npi.specialty_1_longdesc AS spec_typ_nm
      FROM `research-01-217611.df_ucd_stage.udd_medical_claim_consolidated` AS claim
         JOIN `research-01-217611.df_ucd_stage.wkg_dim_provider_npi_in_use` as npi on claim.npi = npi.npi --already filters out npi=0
    ;


    create or replace table `research-01-217611.df_ucd_stage.wkg_medical_claim_enriched_prov_columns`
    PARTITION BY range_bucket(year_nbr, generate_array(yr_start, yr_stop, 1)) AS
    SELECT claim.uuid
            ,EXTRACT(YEAR FROM claim.clm_dt) AS year_nbr
            ,COALESCE(mpin.provtype, npi.provtype, claim.provtype) AS provtype
            ,COALESCE(mpin.prov_mpin, npi.prov_mpin, claim.prov_mpin) AS prov_mpin
            ,COALESCE(npi.npi, mpin.npi, claim.npi) AS npi
            ,COALESCE(mpin.spec_typ_nm, npi.spec_typ_nm, claim.spec_typ_nm) AS spec_typ_nm
            ,COALESCE(mpin.pcp_flag, claim.pcp_flag) AS pcp_flag
      FROM `research-01-217611.df_ucd_stage.udd_medical_claim_consolidated` AS claim
        LEFT JOIN `research-01-217611.df_ucd_stage.wkg_medical_claim_enriched_prov_columns_mpin` AS mpin ON claim.uuid = mpin.uuid and EXTRACT(YEAR FROM claim.clm_dt) = mpin.year_nbr
        LEFT JOIN `research-01-217611.df_ucd_stage.wkg_medical_claim_enriched_prov_columns_npi`  AS npi  ON claim.uuid = npi.uuid  and EXTRACT(YEAR FROM claim.clm_dt) = npi.year_nbr
    ;



    CREATE OR REPLACE TABLE `research-01-217611.df_ucd_stage.wkg_member_ip_confinement_date`
    CLUSTER BY savvy_pid, ip_confined_dt
    AS
    SELECT DISTINCT ip.savvy_pid , dt.full_dt AS ip_confined_dt
    FROM `research-01-217611.df_ucd_stage.ip_confinement` AS ip
      JOIN `research-01-217611.df_ucd_stage.dim_date` AS dt ON dt.full_dt BETWEEN ip.admit_dt AND ip.discharge_dt
    ;

    create or replace table `research-01-217611.df_ucd_stage.wkg_medical_claim_enriched_other_join_columns`
    PARTITION BY range_bucket(year_nbr, generate_array(yr_start, yr_stop, 1)) AS
    SELECT claim.uuid
            ,IFNULL(dtl.business_line, '') AS business_line
            ,IFNULL(dtl.fi_flag, 0) AS fi_flag
      --       ,(CASE WHEN .src_sys_cd = 'co' THEN 1 ELSE 0  END) AS co_flag [Flags COSMOS data, was in UCD 1.0, field needed to calculate value is not currently available]
            ,IFNULL(dtl.mapd_flag, 0) as mapd_flag
            ,dt.month_id
            ,dt.month_nbr
            ,dt.day_nbr
            ,dt.year_qtr
            ,dt.year_nbr
            ,dt.year_mo
            ,claim.rvnu_cd
            ,rvnu.rvnu_desc
            ,rvnu.optnt_catgy_txt
            ,rvnu.iptnt_catgy_txt
      --       ,claim.srvc_catgy_cd [was present in version 1.0, not currently available]
      --       ,claim.srvc_catgy_desc[was present in version 1.0, not currently available]
            ,claim.drg_cd
            ,drg.drg_desc
            ,drg.drg_rate
            ,drg.drg_wgt_fct
            ,drg.mdc_cd
            ,drg.mdc_desc
            ,claim.dschrg_sts_cd
            ,dschrg_stts.dschrg_sts_cd_desc
            ,dschrg_stts.dschrg_sts_catgy_txt

            ,case when
                  (substr(claim.bil_typ_cd, 1, 2) in ("11", "41")
                     or (claim.srvc_typ_cd='ip' and claim.bil_typ_cd ='')
                     ) /*Inpatient*/
                  or ((substr(claim.bil_typ_cd, 1, 2) in ("12", "13", "43", "71", "73", "76", "77", "85") or claim.bil_typ_cd ='')
                     and  cms_proc.hcpcs_cpt_code is not null
                    ) /*Outpatient and Professional*/
              then 1 else 0 end as cms_eligible_encounter_flag

            ,case when
                  (claim.bil_typ_cd in ("111","117")
                     or (claim.srvc_typ_cd='ip' and claim.bil_typ_cd = '')
                     ) /*Inpatient*/
                 or ((claim.bil_typ_cd in ("131","137","711","717","761","767","771","777","851","857") or claim.bil_typ_cd = '')
                     and  hhs_proc.hcpcs_cpt_code is not null
                   ) /*Outpatient and Professional*/
              then 1 else 0 end as hhs_eligible_encounter_flag

            ,CASE WHEN claim.clm_dt = ip_days.ip_confined_dt THEN 'ip'
                  WHEN claim.hce_srvc_typ_desc IN ('er', 'emergency room') THEN 'er' --claim already lower(trim())
                  ELSE claim.srvc_typ_cd END AS deriv_srvc_typ

      FROM `research-01-217611.df_ucd_stage.udd_medical_claim_consolidated` AS claim
        JOIN `research-01-217611.df_ucd_stage.dim_date`		                  AS dt	 ON claim.clm_dt = dt.full_dt
        LEFT JOIN `research-01-217611.df_ucd_stage.wkg_member_detail_member_month_src_type`   AS dtl ON claim.savvy_pid = dtl.savvy_pid AND
                                                                                                     claim.src_type = dtl.src_type AND
                                                                                                     dt.year_mo = dtl.year_mo
        LEFT JOIN `research-01-217611.df_ucd_stage.dim_revenue_code` AS rvnu ON claim.rvnu_cd = rvnu.rvnu_cd
        LEFT JOIN `research-01-217611.df_ucd_stage.dim_drg_code` AS drg ON claim.drg_cd = drg.drg_cd
        LEFT JOIN `research-01-217611.df_ucd_stage.dim_discharge_status_code` AS dschrg_stts ON claim.dschrg_sts_cd = dschrg_stts.dschrg_sts_cd
        LEFT JOIN `research-01-217611.df_enrichment.cms_raf_reportable_physician_procedure_code` cms_proc  on claim.proc_cd = cms_proc.hcpcs_cpt_code
        LEFT JOIN `research-01-217611.df_enrichment.hhs_raf_reportable_physician_procedure_code` hhs_proc  on claim.proc_cd = hhs_proc.hcpcs_cpt_code
        LEFT JOIN `research-01-217611.df_ucd_stage.wkg_member_ip_confinement_date` AS ip_days ON  claim.savvy_pid = ip_days.savvy_pid
                                                                                              AND claim.clm_dt = ip_confined_dt
  --WHERE claim.savvy_pid IN (4923534,24539754,19784768,25619013,27012159,20887453,513199555,21950682,33067494,163438041) --SAMPLE
      ;

  /* ===================================================================================================== */
  /* Logs successful creation of the staging tables*/
  /* ===================================================================================================== */

      insert into `research-01-217611.df_ucd_stage.logging`(
        success_flag, job, message_datetime)
      select
        1 as success_flag
        , 'load medical_claim_enriched staging tables' as job
        , current_datetime as message_datetime
      ;

  /* ===================================================================================================== */
  /* Insert data into `research-01-217611.df_ucd_stage.udd_medical_claim_enriched`, looping through each   */
  /* year */
  /* ===================================================================================================== */

  WHILE yr_start <= yr_stop DO

    INSERT INTO `research-01-217611.df_ucd_stage.udd_medical_claim_enriched`
      (uuid, savvy_pid, savvy_did, is_restricted, src_type, business_line, fi_flag, mapd_flag, clm_aud_nbr, line_number, data_source, claim_sub_type, clm_dt, month_id, month_nbr, day_nbr, year_qtr, year_nbr, year_mo, deriv_srvc_type, icd_ver_cd, dx1_diag_cd, dx1_diag_desc, dx1_diag_full_desc, dx1_diag_fst4_cd, dx1_diag_fst4_desc, dx1_diag_fst3_cd, dx1_diag_fst3_desc, dx1_diag_decm_cd, dx1_ahrq_diag_genl_catgy_cd, dx1_ahrq_diag_genl_catgy_nm, dx1_ahrq_diag_dtl_catgy_cd, dx1_ahrq_diag_dtl_catgy_nm, dx1_chrnc_flg_nm, dx2_diag_cd, dx2_diag_desc, dx2_diag_full_desc, dx2_diag_fst4_cd, dx2_diag_fst4_desc, dx2_diag_fst3_cd, dx2_diag_fst3_desc, dx2_diag_decm_cd, dx2_ahrq_diag_genl_catgy_cd, dx2_ahrq_diag_genl_catgy_nm, dx2_ahrq_diag_dtl_catgy_cd, dx2_ahrq_diag_dtl_catgy_nm, dx2_chrnc_flg_nm, dx3_diag_cd, dx3_diag_desc, dx3_diag_full_desc, dx3_diag_fst4_cd, dx3_diag_fst4_desc, dx3_diag_fst3_cd, dx3_diag_fst3_desc, dx3_diag_decm_cd, dx3_ahrq_diag_genl_catgy_cd, dx3_ahrq_diag_genl_catgy_nm, dx3_ahrq_diag_dtl_catgy_cd, dx3_ahrq_diag_dtl_catgy_nm, dx3_chrnc_flg_nm, dx4_diag_cd, dx5_diag_cd, dx6_diag_cd, dx7_diag_cd, dx8_diag_cd, dx9_diag_cd, dx10_diag_cd, dx11_diag_cd, dx12_diag_cd, rvnu_cd, rvnu_desc, optnt_catgy_txt, iptnt_catgy_txt, proc_cd, proc_desc, proc_decm_cd, ahrq_proc_genl_catgy_cd, ahrq_proc_genl_catgy_desc, ahrq_proc_dtl_catgy_cd, ahrq_proc_dtl_catgy_desc, gdr_lmt_cd, proc_typ_cd, prc1_proc_cd, prc1_proc_desc, prc1_proc_decm_cd, prc1_ahrq_proc_genl_catgy_cd, prc1_ahrq_proc_genl_catgy_desc, prc1_ahrq_proc_dtl_catgy_cd, prc1_ahrq_proc_dtl_catgy_desc, prc1_gdr_lmt_cd, prc1_proc_typ_cd, prc2_proc_cd, prc3_proc_cd, prc4_proc_cd, prc5_proc_cd, prc6_proc_cd, drg_cd, drg_desc, drg_rate, drg_wgt_fct, mdc_cd, mdc_desc, dschrg_sts_cd, dschrg_sts_cd_desc, dschrg_sts_catgy_txt, proc_mod_1_cd, proc_mod_1_desc, proc_mod_1_grp_cd, proc_mod_1_grp_desc, proc_mod_2_cd, proc_mod_2_desc, proc_mod_2_grp_cd, proc_mod_2_grp_desc, proc_mod_3_cd, proc_mod_3_desc, proc_mod_3_grp_cd, proc_mod_3_grp_desc, srvc_typ_cd, prov_mpin, prov_tin, prov_fst_nm, prov_lst_nm, prov_zip_cd, prov_state, npi, pcp_flag, provtype, spec_typ_nm, hp_prov_cat_typ_nm, ama_pl_of_srvc_cd, ama_pl_of_srvc_desc, prov_prtcp_sts_cd, hp_prov_sts_rllp_desc, hlth_pln_srvc_typ_cd, hce_srvc_typ_desc, bil_typ_cd, bil_amt, allw_amt, net_pd_amt, oop_amt, copay_amt, ded_amt, coins_amt, disallow_amt, cob_amt, admit_cnt, day_cnt, srvc_unit_cnt, adjudication_dt, admit_dt, discharge_dt, cms_eligible_encounter_flag, hhs_eligible_encounter_flag
      )

    SELECT claim.uuid
          ,claim.savvy_pid
          ,claim.savvy_did
          ,claim.is_restricted
          ,claim.src_type
          ,ox.business_line
          ,ox.fi_flag
    --       ,(CASE WHEN .src_sys_cd = 'co' THEN 1 ELSE 0  END) AS co_flag [Flags COSMOS data, was in UCD 1.0, field needed to calculate value is not currently available]
          ,ox.mapd_flag
          ,claim.clm_aud_nbr
          ,claim.line_number
          ,claim.data_source
          ,claim.claim_sub_type
          ,claim.clm_dt
          ,ox.month_id
          ,ox.month_nbr
          ,ox.day_nbr
          ,ox.year_qtr
          ,ox.year_nbr
          ,ox.year_mo
          ,ox.deriv_srvc_typ
          ,claim.icd_ver_cd
          ,claim.dx1_diag_cd
          ,dx1.dx1_diag_desc
          ,dx1.dx1_diag_full_desc
          ,dx1.dx1_diag_fst4_cd
          ,dx1.dx1_diag_fst4_desc
          ,dx1.dx1_diag_fst3_cd
          ,dx1.dx1_diag_fst3_desc
          ,dx1.dx1_diag_decm_cd
          ,dx1.dx1_ahrq_diag_genl_catgy_cd
          ,dx1.dx1_ahrq_diag_genl_catgy_nm
          ,dx1.dx1_ahrq_diag_dtl_catgy_cd
          ,dx1.dx1_ahrq_diag_dtl_catgy_nm
          ,dx1.dx1_chrnc_flg_nm
          ,claim.dx2_diag_cd
          ,dx2.dx2_diag_desc
          ,dx2.dx2_diag_full_desc
          ,dx2.dx2_diag_fst4_cd
          ,dx2.dx2_diag_fst4_desc
          ,dx2.dx2_diag_fst3_cd
          ,dx2.dx2_diag_fst3_desc
          ,dx2.dx2_diag_decm_cd
          ,dx2.dx2_ahrq_diag_genl_catgy_cd
          ,dx2.dx2_ahrq_diag_genl_catgy_nm
          ,dx2.dx2_ahrq_diag_dtl_catgy_cd
          ,dx2.dx2_ahrq_diag_dtl_catgy_nm
          ,dx2.dx2_chrnc_flg_nm
          ,claim.dx3_diag_cd
          ,dx3.dx3_diag_desc
          ,dx3.dx3_diag_full_desc
          ,dx3.dx3_diag_fst4_cd
          ,dx3.dx3_diag_fst4_desc
          ,dx3.dx3_diag_fst3_cd
          ,dx3.dx3_diag_fst3_desc
          ,dx3.dx3_diag_decm_cd
          ,dx3.dx3_ahrq_diag_genl_catgy_cd
          ,dx3.dx3_ahrq_diag_genl_catgy_nm
          ,dx3.dx3_ahrq_diag_dtl_catgy_cd
          ,dx3.dx3_ahrq_diag_dtl_catgy_nm
          ,dx3.dx3_chrnc_flg_nm
          ,claim.dx4_diag_cd
          ,claim.dx5_diag_cd
          ,claim.dx6_diag_cd
          ,claim.dx7_diag_cd
          ,claim.dx8_diag_cd
          ,claim.dx9_diag_cd
          ,claim.dx10_diag_cd
          ,claim.dx11_diag_cd
          ,claim.dx12_diag_cd
          ,claim.rvnu_cd
          ,ox.rvnu_desc
          ,ox.optnt_catgy_txt
          ,ox.iptnt_catgy_txt
    --       ,claim.srvc_catgy_cd [was present in version 1.0, not currently available]
    --       ,claim.srvc_catgy_desc[was present in version 1.0, not currently available]
          ,claim.proc_cd
          ,px.proc_desc
          ,px.proc_decm_cd
          ,px.ahrq_proc_genl_catgy_cd
          ,px.ahrq_proc_genl_catgy_desc
          ,px.ahrq_proc_dtl_catgy_cd
          ,px.ahrq_proc_dtl_catgy_desc
          ,px.gdr_lmt_cd
          ,px.proc_typ_cd
          ,claim.prc1_proc_cd
          ,px.prc1_proc_desc
          ,px.prc1_proc_decm_cd
          ,px.prc1_ahrq_proc_genl_catgy_cd
          ,px.prc1_ahrq_proc_genl_catgy_desc
          ,px.prc1_ahrq_proc_dtl_catgy_cd
          ,px.prc1_ahrq_proc_dtl_catgy_desc
          ,px.prc1_gdr_lmt_cd
          ,px.prc1_proc_typ_cd
          ,claim.prc2_proc_cd
          ,claim.prc3_proc_cd
          ,claim.prc4_proc_cd
          ,claim.prc5_proc_cd
          ,claim.prc6_proc_cd
          ,claim.drg_cd
          ,ox.drg_desc
          ,ox.drg_rate
          ,ox.drg_wgt_fct
          ,ox.mdc_cd
          ,ox.mdc_desc
          ,claim.dschrg_sts_cd
          ,ox.dschrg_sts_cd_desc
          ,ox.dschrg_sts_catgy_txt
          ,claim.proc_mod_1_cd
          ,px.proc_mod_1_desc
          ,px.proc_mod_1_grp_cd
          ,px.proc_mod_1_grp_desc
          ,claim.proc_mod_2_cd
          ,px.proc_mod_2_desc
          ,px.proc_mod_2_grp_cd
          ,px.proc_mod_2_grp_desc
          ,claim.proc_mod_3_cd
          ,px.proc_mod_3_desc
          ,px.proc_mod_3_grp_cd
          ,px.proc_mod_3_grp_desc
          ,claim.srvc_typ_cd
          ,prov.prov_mpin
          ,claim.prov_tin
          ,claim.prov_fst_nm
          ,claim.prov_lst_nm
          ,claim.prov_zip_cd
          ,claim.prov_state
          ,prov.npi
          ,prov.pcp_flag
          ,prov.provtype
          ,prov.spec_typ_nm
          ,claim.hp_prov_cat_typ_nm
          ,claim.ama_pl_of_srvc_cd
          ,claim.ama_pl_of_srvc_desc
          ,claim.prov_prtcp_sts_cd
          ,claim.hp_prov_sts_rllp_desc
          ,claim.hlth_pln_srvc_typ_cd
          ,claim.hce_srvc_typ_desc
          ,claim.bil_typ_cd
          ,claim.bil_amt
          ,claim.allw_amt
          ,claim.net_pd_amt
          ,claim.oop_amt
          ,claim.copay_amt
          ,claim.ded_amt
          ,claim.coins_amt
          ,claim.disallow_amt
          ,claim.cob_amt
          ,claim.admit_cnt
          ,claim.day_cnt
          ,claim.srvc_unit_cnt
          ,claim.adjudication_dt
          ,claim.admit_dt
          ,claim.discharge_dt
          ,ox.cms_eligible_encounter_flag
          ,ox.hhs_eligible_encounter_flag

    FROM `research-01-217611.df_ucd_stage.udd_medical_claim_consolidated`                     AS claim
      JOIN `research-01-217611.df_ucd_stage.wkg_medical_claim_enriched_diag1_columns`         AS dx1	 ON claim.uuid = dx1.uuid AND dx1.year_nbr = yr_start
      JOIN `research-01-217611.df_ucd_stage.wkg_medical_claim_enriched_diag2_columns`	        AS dx2	 ON claim.uuid = dx2.uuid AND dx2.year_nbr = yr_start
      JOIN `research-01-217611.df_ucd_stage.wkg_medical_claim_enriched_diag3_columns`	        AS dx3	 ON claim.uuid = dx3.uuid AND dx3.year_nbr = yr_start
      JOIN `research-01-217611.df_ucd_stage.wkg_medical_claim_enriched_proc_columns`	        AS px	 ON claim.uuid = px.uuid  AND px.year_nbr = yr_start
      JOIN `research-01-217611.df_ucd_stage.wkg_medical_claim_enriched_prov_columns`	        AS prov	 ON claim.uuid = prov.uuid  AND prov.year_nbr = yr_start
      JOIN `research-01-217611.df_ucd_stage.wkg_medical_claim_enriched_other_join_columns`	  AS ox	 ON claim.uuid = ox.uuid  AND ox.year_nbr = yr_start
    ;

      insert into `research-01-217611.df_ucd_stage.logging`(
        success_flag, job, message_datetime)
      select
        1 as success_flag
        , 'load medical_claim_enriched loop-' || cast(yr_start as string) as job
        , current_datetime as message_datetime
      ;

    SET yr_start = yr_start + 1;

  END WHILE;

  /* ===================================================================================================== */
  /* Create working tables */
  /* ===================================================================================================== */

    SET yr_start = 2016;--reinitialize looping variable

    CREATE OR replace TABLE `research-01-217611.df_ucd_stage.wkg_medical_claim_ihr_enriched_diag1_columns`
    PARTITION BY range_bucket(year_nbr, generate_array(yr_start, yr_stop, 1)) AS
    SELECT claim.uuid
            ,EXTRACT(YEAR FROM claim.clm_dt) AS year_nbr
            ,claim.dx1_diag_cd
            ,dx1.diag_desc AS dx1_diag_desc
            ,dx1.diag_full_desc AS dx1_diag_full_desc
            ,dx1.diag_fst4_cd AS dx1_diag_fst4_cd
            ,dx1.diag_fst4_desc AS dx1_diag_fst4_desc
            ,dx1.diag_fst3_cd AS dx1_diag_fst3_cd
            ,dx1.diag_fst3_desc AS dx1_diag_fst3_desc
            ,dx1.diag_decm_cd AS dx1_diag_decm_cd
            ,dx1.ahrq_diag_genl_catgy_cd AS dx1_ahrq_diag_genl_catgy_cd
            ,dx1.ahrq_diag_genl_catgy_nm AS dx1_ahrq_diag_genl_catgy_nm
            ,dx1.ahrq_diag_dtl_catgy_cd AS dx1_ahrq_diag_dtl_catgy_cd
            ,dx1.ahrq_diag_dtl_catgy_nm AS dx1_ahrq_diag_dtl_catgy_nm
            ,dx1.chrnc_flg_nm AS dx1_chrnc_flg_nm
      FROM `research-01-217611.df_ucd_stage.udd_medical_claim_ihr` AS claim
        LEFT JOIN `research-01-217611.df_ucd_stage.wkg_dim_diagnosis_code_in_use` AS dx1 ON claim.dx1_diag_cd = dx1.diag_cd and claim.icd_ver_cd = dx1.icd_ver_cd
    --WHERE savvy_pid IN (4923534,24539754,19784768,25619013,27012159,20887453,513199555,21950682,33067494,163438041) --SAMPLE
    ;

    create or replace table `research-01-217611.df_ucd_stage.wkg_medical_claim_ihr_enriched_diag2_columns`
    PARTITION BY range_bucket(year_nbr, generate_array(yr_start, yr_stop, 1)) AS
    SELECT claim.uuid
            ,EXTRACT(YEAR FROM claim.clm_dt) AS year_nbr
            ,claim.dx2_diag_cd
            ,dx2.diag_desc AS dx2_diag_desc
            ,dx2.diag_full_desc AS dx2_diag_full_desc
            ,dx2.diag_fst4_cd AS dx2_diag_fst4_cd
            ,dx2.diag_fst4_desc AS dx2_diag_fst4_desc
            ,dx2.diag_fst3_cd AS dx2_diag_fst3_cd
            ,dx2.diag_fst3_desc AS dx2_diag_fst3_desc
            ,dx2.diag_decm_cd AS dx2_diag_decm_cd
            ,dx2.ahrq_diag_genl_catgy_cd AS dx2_ahrq_diag_genl_catgy_cd
            ,dx2.ahrq_diag_genl_catgy_nm AS dx2_ahrq_diag_genl_catgy_nm
            ,dx2.ahrq_diag_dtl_catgy_cd AS dx2_ahrq_diag_dtl_catgy_cd
            ,dx2.ahrq_diag_dtl_catgy_nm AS dx2_ahrq_diag_dtl_catgy_nm
            ,dx2.chrnc_flg_nm AS dx2_chrnc_flg_nm
      FROM `research-01-217611.df_ucd_stage.udd_medical_claim_ihr` AS claim
        LEFT JOIN `research-01-217611.df_ucd_stage.wkg_dim_diagnosis_code_in_use` AS dx2 ON claim.dx2_diag_cd = dx2.diag_cd and claim.icd_ver_cd = dx2.icd_ver_cd
    --WHERE savvy_pid IN (4923534,24539754,19784768,25619013,27012159,20887453,513199555,21950682,33067494,163438041) --SAMPLE
    ;

    create or replace table `research-01-217611.df_ucd_stage.wkg_medical_claim_ihr_enriched_diag3_columns`
    PARTITION BY range_bucket(year_nbr, generate_array(yr_start, yr_stop, 1)) AS
    SELECT claim.uuid
            ,EXTRACT(YEAR FROM claim.clm_dt) AS year_nbr
            ,claim.dx3_diag_cd
            ,dx3.diag_desc AS dx3_diag_desc
            ,dx3.diag_full_desc AS dx3_diag_full_desc
            ,dx3.diag_fst4_cd AS dx3_diag_fst4_cd
            ,dx3.diag_fst4_desc AS dx3_diag_fst4_desc
            ,dx3.diag_fst3_cd AS dx3_diag_fst3_cd
            ,dx3.diag_fst3_desc AS dx3_diag_fst3_desc
            ,dx3.diag_decm_cd AS dx3_diag_decm_cd
            ,dx3.ahrq_diag_genl_catgy_cd AS dx3_ahrq_diag_genl_catgy_cd
            ,dx3.ahrq_diag_genl_catgy_nm AS dx3_ahrq_diag_genl_catgy_nm
            ,dx3.ahrq_diag_dtl_catgy_cd AS dx3_ahrq_diag_dtl_catgy_cd
            ,dx3.ahrq_diag_dtl_catgy_nm AS dx3_ahrq_diag_dtl_catgy_nm
            ,dx3.chrnc_flg_nm AS dx3_chrnc_flg_nm
      FROM `research-01-217611.df_ucd_stage.udd_medical_claim_ihr` AS claim
        LEFT JOIN `research-01-217611.df_ucd_stage.wkg_dim_diagnosis_code_in_use` AS dx3 ON claim.dx3_diag_cd = dx3.diag_cd and claim.icd_ver_cd = dx3.icd_ver_cd
  --WHERE savvy_pid IN (4923534,24539754,19784768,25619013,27012159,20887453,513199555,21950682,33067494,163438041) --SAMPLE
    ;

    create or replace table `research-01-217611.df_ucd_stage.wkg_medical_claim_ihr_enriched_proc_columns`
    PARTITION BY range_bucket(year_nbr, generate_array(yr_start, yr_stop, 1)) AS
    SELECT claim.uuid
            ,EXTRACT(YEAR FROM claim.clm_dt) AS year_nbr
            ,claim.proc_cd
            ,px0.proc_desc
            ,px0.proc_decm_cd
            ,px0.ahrq_proc_genl_catgy_cd
            ,px0.ahrq_proc_genl_catgy_desc
            ,px0.ahrq_proc_dtl_catgy_cd
            ,px0.ahrq_proc_dtl_catgy_desc
            ,px0.gdr_lmt_cd
            ,px0.proc_typ_cd
            ,prc1_proc_cd
            ,px1.proc_desc AS prc1_proc_desc
            ,px1.proc_decm_cd AS prc1_proc_decm_cd
            ,px1.ahrq_proc_genl_catgy_cd AS prc1_ahrq_proc_genl_catgy_cd
            ,px1.ahrq_proc_genl_catgy_desc AS prc1_ahrq_proc_genl_catgy_desc
            ,px1.ahrq_proc_dtl_catgy_cd AS prc1_ahrq_proc_dtl_catgy_cd
            ,px1.ahrq_proc_dtl_catgy_desc AS prc1_ahrq_proc_dtl_catgy_desc
            ,px1.gdr_lmt_cd AS prc1_gdr_lmt_cd
            ,px1.proc_typ_cd AS prc1_proc_typ_cd
            ,claim.proc_mod_1_cd
            ,proc_mod1.proc_mod_desc AS proc_mod_1_desc
            ,proc_mod1.proc_mod_grp_cd AS proc_mod_1_grp_cd
            ,proc_mod1.proc_mod_grp_desc AS proc_mod_1_grp_desc
            ,claim.proc_mod_2_cd
            ,proc_mod2.proc_mod_desc AS proc_mod_2_desc
            ,proc_mod2.proc_mod_grp_cd AS proc_mod_2_grp_cd
            ,proc_mod2.proc_mod_grp_desc AS proc_mod_2_grp_desc
            ,claim.proc_mod_3_cd
            ,proc_mod3.proc_mod_desc AS proc_mod_3_desc
            ,proc_mod3.proc_mod_grp_cd AS proc_mod_3_grp_cd
            ,proc_mod3.proc_mod_grp_desc AS proc_mod_3_grp_desc
      FROM `research-01-217611.df_ucd_stage.udd_medical_claim_ihr` AS claim
        LEFT JOIN `research-01-217611.df_ucd_stage.wkg_dim_procedure_code_in_use` AS px0 ON claim.proc_cd = px0.proc_cd
        LEFT JOIN `research-01-217611.df_ucd_stage.wkg_dim_procedure_code_in_use` AS px1 ON claim.prc1_proc_cd = px1.proc_cd
        LEFT JOIN `research-01-217611.df_ucd_stage.dim_procedure_modifier_code` AS proc_mod1 ON claim.proc_mod_1_cd = proc_mod1.proc_mod_cd
        LEFT JOIN `research-01-217611.df_ucd_stage.dim_procedure_modifier_code` AS proc_mod2 ON claim.proc_mod_2_cd = proc_mod2.proc_mod_cd
        LEFT JOIN `research-01-217611.df_ucd_stage.dim_procedure_modifier_code` AS proc_mod3 ON claim.proc_mod_3_cd = proc_mod3.proc_mod_cd
  --WHERE savvy_pid IN (4923534,24539754,19784768,25619013,27012159,20887453,513199555,21950682,33067494,163438041) --SAMPLE
      ;


    create or replace table `research-01-217611.df_ucd_stage.wkg_medical_claim_ihr_enriched_prov_columns_mpin`
    PARTITION BY range_bucket(year_nbr, generate_array(yr_start, yr_stop, 1)) AS
    SELECT claim.uuid
            ,EXTRACT(YEAR FROM claim.clm_dt) AS year_nbr
            ,prov.prov_type AS provtype
            ,prov.mpin AS prov_mpin
            ,prov.npi AS npi
            ,prov.specialty_1_longdesc AS spec_typ_nm
            ,prov.pcp_flag AS pcp_flag

      FROM `research-01-217611.df_ucd_stage.udd_medical_claim_ihr` AS claim
         JOIN `research-01-217611.df_ucd_stage.wkg_dim_provider_in_use` AS prov ON claim.prov_mpin = prov.mpin --already filters out mpin=0
    ;

    create or replace table `research-01-217611.df_ucd_stage.wkg_medical_claim_ihr_enriched_prov_columns_npi`
    PARTITION BY range_bucket(year_nbr, generate_array(yr_start, yr_stop, 1)) AS
    SELECT claim.uuid
            ,EXTRACT(YEAR FROM claim.clm_dt) AS year_nbr
            ,npi.prov_type AS provtype
            ,npi.mpin AS prov_mpin
            ,npi.npi AS npi
            ,npi.specialty_1_longdesc AS spec_typ_nm
      FROM `research-01-217611.df_ucd_stage.udd_medical_claim_ihr` AS claim
         JOIN `research-01-217611.df_ucd_stage.wkg_dim_provider_npi_in_use` as npi on claim.npi = npi.npi --already filters out npi=0
    ;


    create or replace table `research-01-217611.df_ucd_stage.wkg_medical_claim_ihr_enriched_prov_columns`
    PARTITION BY range_bucket(year_nbr, generate_array(yr_start, yr_stop, 1)) AS
    SELECT claim.uuid
            ,EXTRACT(YEAR FROM claim.clm_dt) AS year_nbr
            ,COALESCE(mpin.provtype, npi.provtype, claim.provtype) AS provtype
            ,COALESCE(mpin.prov_mpin, npi.prov_mpin, claim.prov_mpin) AS prov_mpin
            ,COALESCE(npi.npi, mpin.npi, claim.npi) AS npi
            ,COALESCE(mpin.spec_typ_nm, npi.spec_typ_nm, claim.spec_typ_nm) AS spec_typ_nm
            ,COALESCE(mpin.pcp_flag, claim.pcp_flag) AS pcp_flag
      FROM `research-01-217611.df_ucd_stage.udd_medical_claim_ihr` AS claim
        LEFT JOIN `research-01-217611.df_ucd_stage.wkg_medical_claim_ihr_enriched_prov_columns_mpin` AS mpin ON claim.uuid = mpin.uuid and EXTRACT(YEAR FROM claim.clm_dt) = mpin.year_nbr
        LEFT JOIN `research-01-217611.df_ucd_stage.wkg_medical_claim_ihr_enriched_prov_columns_npi`  AS npi  ON claim.uuid = npi.uuid  and EXTRACT(YEAR FROM claim.clm_dt) = npi.year_nbr
    ;


    CREATE OR REPLACE TABLE `research-01-217611.df_ucd_stage.wkg_member_ihr_ip_confinement_date`
    CLUSTER BY savvy_pid, ip_confined_dt
    AS
    SELECT DISTINCT ip.savvy_pid , dt.full_dt AS ip_confined_dt
    FROM `research-01-217611.df_ucd_stage.udd_medical_claim_ihr` AS ip
      JOIN `research-01-217611.df_ucd_stage.dim_date` AS dt ON dt.full_dt = ip.admit_dt --BETWEEN ip.admit_dt AND ip.discharge_dt, but currently ip.dscharge_dt is always 12/31/9999...setting it to ip.admit_dt will at least let derived service type generally be the same as service type for ihr
    WHERE admit_cnt = 1 --identifies valid confinements
    ;

    create or replace table `research-01-217611.df_ucd_stage.wkg_medical_claim_ihr_enriched_other_join_columns`
    PARTITION BY range_bucket(year_nbr, generate_array(yr_start, yr_stop, 1)) AS
    SELECT claim.uuid
            ,IFNULL(dtl.business_line, '') AS business_line
            ,IFNULL(dtl.fi_flag, 0) AS fi_flag
      --       ,(CASE WHEN .src_sys_cd = 'co' THEN 1 ELSE 0  END) AS co_flag [Flags COSMOS data, was in UCD 1.0, field needed to calculate value is not currently available]
            ,IFNULL(dtl.mapd_flag, 0) as mapd_flag
            ,dt.month_id
            ,dt.month_nbr
            ,dt.day_nbr
            ,dt.year_qtr
            ,dt.year_nbr
            ,dt.year_mo
            ,claim.rvnu_cd
            ,rvnu.rvnu_desc
            ,rvnu.optnt_catgy_txt
            ,rvnu.iptnt_catgy_txt
      --       ,claim.srvc_catgy_cd [was present in version 1.0, not currently available]
      --       ,claim.srvc_catgy_desc[was present in version 1.0, not currently available]
            ,claim.drg_cd
            ,drg.drg_desc
            ,drg.drg_rate
            ,drg.drg_wgt_fct
            ,drg.mdc_cd
            ,drg.mdc_desc
            ,claim.dschrg_sts_cd
            ,dschrg_stts.dschrg_sts_cd_desc
            ,dschrg_stts.dschrg_sts_catgy_txt


            ,case when
                  (substr(claim.bil_typ_cd, 1, 2) in ("11", "41")
                     or (claim.srvc_typ_cd='ip' and claim.bil_typ_cd ='')
                     ) /*Inpatient*/
                  or ((substr(claim.bil_typ_cd, 1, 2) in ("12", "13", "43", "71", "73", "76", "77", "85") or claim.bil_typ_cd ='')
                     and  cms_proc.hcpcs_cpt_code is not null
                    ) /*Outpatient and Professional*/
              then 1 else 0 end as cms_eligible_encounter_flag

            ,case when
                  (claim.bil_typ_cd in ("111","117")
                     or (claim.srvc_typ_cd='ip' and claim.bil_typ_cd = '')
                     ) /*Inpatient*/
                 or ((claim.bil_typ_cd in ("131","137","711","717","761","767","771","777","851","857") or claim.bil_typ_cd = '')
                     and  hhs_proc.hcpcs_cpt_code is not null
                   ) /*Outpatient and Professional*/
              then 1 else 0 end as hhs_eligible_encounter_flag

            ,CASE WHEN claim.clm_dt = ip_days.ip_confined_dt THEN 'ip'
                  WHEN claim.hce_srvc_typ_desc IN ('er', 'emergency room') THEN 'er' --claim already lower(trim())
                  ELSE claim.srvc_typ_cd END AS deriv_srvc_typ

      FROM `research-01-217611.df_ucd_stage.udd_medical_claim_ihr` AS claim
        JOIN `research-01-217611.df_ucd_stage.dim_date`		                  AS dt	 ON claim.clm_dt = dt.full_dt
        LEFT JOIN `research-01-217611.df_ucd_stage.wkg_member_detail_member_month_src_type`   AS dtl ON claim.savvy_pid = dtl.savvy_pid AND
                                                                                                     claim.src_type = dtl.src_type AND
                                                                                                     dt.year_mo = dtl.year_mo
        LEFT JOIN `research-01-217611.df_ucd_stage.dim_revenue_code` AS rvnu ON claim.rvnu_cd = rvnu.rvnu_cd
        LEFT JOIN `research-01-217611.df_ucd_stage.dim_drg_code` AS drg ON claim.drg_cd = drg.drg_cd
        LEFT JOIN `research-01-217611.df_ucd_stage.dim_discharge_status_code` AS dschrg_stts ON claim.dschrg_sts_cd = dschrg_stts.dschrg_sts_cd
        LEFT JOIN `research-01-217611.df_enrichment.cms_raf_reportable_physician_procedure_code` cms_proc  on claim.proc_cd = cms_proc.hcpcs_cpt_code
        LEFT JOIN `research-01-217611.df_enrichment.hhs_raf_reportable_physician_procedure_code` hhs_proc  on claim.proc_cd = hhs_proc.hcpcs_cpt_code
        LEFT JOIN `research-01-217611.df_ucd_stage.wkg_member_ip_confinement_date` AS ip_days ON  claim.savvy_pid = ip_days.savvy_pid
                                                                                              AND claim.clm_dt = ip_days.ip_confined_dt
  --WHERE claim.savvy_pid IN (4923534,24539754,19784768,25619013,27012159,20887453,513199555,21950682,33067494,163438041) --SAMPLE
      ;

  /* ===================================================================================================== */
  /* Logs successful creation of the staging tables*/
  /* ===================================================================================================== */

      insert into `research-01-217611.df_ucd_stage.logging`(
        success_flag, job, message_datetime)
      select
        1 as success_flag
        , 'load medical_claim_ihr_enriched staging tables' as job
        , current_datetime as message_datetime
      ;

  /* ===================================================================================================== */
  /* Insert data into `research-01-217611.df_ucd_stage.udd_medical_claim_enriched`, looping through each   */
  /* year */
  /* ===================================================================================================== */

  WHILE yr_start <= yr_stop DO

    INSERT INTO `research-01-217611.df_ucd_stage.udd_medical_claim_ihr_enriched`
      (uuid, savvy_pid, savvy_did, is_restricted, src_type, business_line, fi_flag, mapd_flag, clm_aud_nbr, line_number, data_source, claim_sub_type, clm_dt, month_id, month_nbr, day_nbr, year_qtr, year_nbr, year_mo, deriv_srvc_type, icd_ver_cd, dx1_diag_cd, dx1_diag_desc, dx1_diag_full_desc, dx1_diag_fst4_cd, dx1_diag_fst4_desc, dx1_diag_fst3_cd, dx1_diag_fst3_desc, dx1_diag_decm_cd, dx1_ahrq_diag_genl_catgy_cd, dx1_ahrq_diag_genl_catgy_nm, dx1_ahrq_diag_dtl_catgy_cd, dx1_ahrq_diag_dtl_catgy_nm, dx1_chrnc_flg_nm, dx2_diag_cd, dx2_diag_desc, dx2_diag_full_desc, dx2_diag_fst4_cd, dx2_diag_fst4_desc, dx2_diag_fst3_cd, dx2_diag_fst3_desc, dx2_diag_decm_cd, dx2_ahrq_diag_genl_catgy_cd, dx2_ahrq_diag_genl_catgy_nm, dx2_ahrq_diag_dtl_catgy_cd, dx2_ahrq_diag_dtl_catgy_nm, dx2_chrnc_flg_nm, dx3_diag_cd, dx3_diag_desc, dx3_diag_full_desc, dx3_diag_fst4_cd, dx3_diag_fst4_desc, dx3_diag_fst3_cd, dx3_diag_fst3_desc, dx3_diag_decm_cd, dx3_ahrq_diag_genl_catgy_cd, dx3_ahrq_diag_genl_catgy_nm, dx3_ahrq_diag_dtl_catgy_cd, dx3_ahrq_diag_dtl_catgy_nm, dx3_chrnc_flg_nm, dx4_diag_cd, dx5_diag_cd, dx6_diag_cd, dx7_diag_cd, dx8_diag_cd, dx9_diag_cd, dx10_diag_cd, dx11_diag_cd, dx12_diag_cd, rvnu_cd, rvnu_desc, optnt_catgy_txt, iptnt_catgy_txt, proc_cd, proc_desc, proc_decm_cd, ahrq_proc_genl_catgy_cd, ahrq_proc_genl_catgy_desc, ahrq_proc_dtl_catgy_cd, ahrq_proc_dtl_catgy_desc, gdr_lmt_cd, proc_typ_cd, prc1_proc_cd, prc1_proc_desc, prc1_proc_decm_cd, prc1_ahrq_proc_genl_catgy_cd, prc1_ahrq_proc_genl_catgy_desc, prc1_ahrq_proc_dtl_catgy_cd, prc1_ahrq_proc_dtl_catgy_desc, prc1_gdr_lmt_cd, prc1_proc_typ_cd, prc2_proc_cd, prc3_proc_cd, prc4_proc_cd, prc5_proc_cd, prc6_proc_cd, drg_cd, drg_desc, drg_rate, drg_wgt_fct, mdc_cd, mdc_desc, dschrg_sts_cd, dschrg_sts_cd_desc, dschrg_sts_catgy_txt, proc_mod_1_cd, proc_mod_1_desc, proc_mod_1_grp_cd, proc_mod_1_grp_desc, proc_mod_2_cd, proc_mod_2_desc, proc_mod_2_grp_cd, proc_mod_2_grp_desc, proc_mod_3_cd, proc_mod_3_desc, proc_mod_3_grp_cd, proc_mod_3_grp_desc, srvc_typ_cd, prov_mpin, prov_tin, prov_fst_nm, prov_lst_nm, prov_zip_cd, prov_state, npi, pcp_flag, provtype, spec_typ_nm, hp_prov_cat_typ_nm, ama_pl_of_srvc_cd, ama_pl_of_srvc_desc, prov_prtcp_sts_cd, hp_prov_sts_rllp_desc, hlth_pln_srvc_typ_cd, hce_srvc_typ_desc, bil_typ_cd, bil_amt, allw_amt, net_pd_amt, oop_amt, copay_amt, ded_amt, coins_amt, disallow_amt, cob_amt, admit_cnt, day_cnt, srvc_unit_cnt, adjudication_dt, admit_dt, discharge_dt, cms_eligible_encounter_flag, hhs_eligible_encounter_flag
      )

    SELECT claim.uuid
          ,claim.savvy_pid
          ,claim.savvy_did
          ,claim.is_restricted
          ,claim.src_type
          ,ox.business_line
          ,ox.fi_flag
    --       ,(CASE WHEN .src_sys_cd = 'co' THEN 1 ELSE 0  END) AS co_flag [Flags COSMOS data, was in UCD 1.0, field needed to calculate value is not currently available]
          ,ox.mapd_flag
          ,claim.clm_aud_nbr
          ,claim.line_number
          ,claim.data_source
          ,claim.claim_sub_type
          ,claim.clm_dt
          ,ox.month_id
          ,ox.month_nbr
          ,ox.day_nbr
          ,ox.year_qtr
          ,ox.year_nbr
          ,ox.year_mo
          ,ox.deriv_srvc_typ
          ,claim.icd_ver_cd
          ,claim.dx1_diag_cd
          ,dx1.dx1_diag_desc
          ,dx1.dx1_diag_full_desc
          ,dx1.dx1_diag_fst4_cd
          ,dx1.dx1_diag_fst4_desc
          ,dx1.dx1_diag_fst3_cd
          ,dx1.dx1_diag_fst3_desc
          ,dx1.dx1_diag_decm_cd
          ,dx1.dx1_ahrq_diag_genl_catgy_cd
          ,dx1.dx1_ahrq_diag_genl_catgy_nm
          ,dx1.dx1_ahrq_diag_dtl_catgy_cd
          ,dx1.dx1_ahrq_diag_dtl_catgy_nm
          ,dx1.dx1_chrnc_flg_nm
          ,claim.dx2_diag_cd
          ,dx2.dx2_diag_desc
          ,dx2.dx2_diag_full_desc
          ,dx2.dx2_diag_fst4_cd
          ,dx2.dx2_diag_fst4_desc
          ,dx2.dx2_diag_fst3_cd
          ,dx2.dx2_diag_fst3_desc
          ,dx2.dx2_diag_decm_cd
          ,dx2.dx2_ahrq_diag_genl_catgy_cd
          ,dx2.dx2_ahrq_diag_genl_catgy_nm
          ,dx2.dx2_ahrq_diag_dtl_catgy_cd
          ,dx2.dx2_ahrq_diag_dtl_catgy_nm
          ,dx2.dx2_chrnc_flg_nm
          ,claim.dx3_diag_cd
          ,dx3.dx3_diag_desc
          ,dx3.dx3_diag_full_desc
          ,dx3.dx3_diag_fst4_cd
          ,dx3.dx3_diag_fst4_desc
          ,dx3.dx3_diag_fst3_cd
          ,dx3.dx3_diag_fst3_desc
          ,dx3.dx3_diag_decm_cd
          ,dx3.dx3_ahrq_diag_genl_catgy_cd
          ,dx3.dx3_ahrq_diag_genl_catgy_nm
          ,dx3.dx3_ahrq_diag_dtl_catgy_cd
          ,dx3.dx3_ahrq_diag_dtl_catgy_nm
          ,dx3.dx3_chrnc_flg_nm
          ,claim.dx4_diag_cd
          ,claim.dx5_diag_cd
          ,claim.dx6_diag_cd
          ,claim.dx7_diag_cd
          ,claim.dx8_diag_cd
          ,claim.dx9_diag_cd
          ,claim.dx10_diag_cd
          ,claim.dx11_diag_cd
          ,claim.dx12_diag_cd
          ,claim.rvnu_cd
          ,ox.rvnu_desc
          ,ox.optnt_catgy_txt
          ,ox.iptnt_catgy_txt
    --       ,claim.srvc_catgy_cd [was present in version 1.0, not currently available]
    --       ,claim.srvc_catgy_desc[was present in version 1.0, not currently available]
          ,claim.proc_cd
          ,px.proc_desc
          ,px.proc_decm_cd
          ,px.ahrq_proc_genl_catgy_cd
          ,px.ahrq_proc_genl_catgy_desc
          ,px.ahrq_proc_dtl_catgy_cd
          ,px.ahrq_proc_dtl_catgy_desc
          ,px.gdr_lmt_cd
          ,px.proc_typ_cd
          ,claim.prc1_proc_cd
          ,px.prc1_proc_desc
          ,px.prc1_proc_decm_cd
          ,px.prc1_ahrq_proc_genl_catgy_cd
          ,px.prc1_ahrq_proc_genl_catgy_desc
          ,px.prc1_ahrq_proc_dtl_catgy_cd
          ,px.prc1_ahrq_proc_dtl_catgy_desc
          ,px.prc1_gdr_lmt_cd
          ,px.prc1_proc_typ_cd
          ,claim.prc2_proc_cd
          ,claim.prc3_proc_cd
          ,claim.prc4_proc_cd
          ,claim.prc5_proc_cd
          ,claim.prc6_proc_cd
          ,claim.drg_cd
          ,ox.drg_desc
          ,ox.drg_rate
          ,ox.drg_wgt_fct
          ,ox.mdc_cd
          ,ox.mdc_desc
          ,claim.dschrg_sts_cd
          ,ox.dschrg_sts_cd_desc
          ,ox.dschrg_sts_catgy_txt
          ,claim.proc_mod_1_cd
          ,px.proc_mod_1_desc
          ,px.proc_mod_1_grp_cd
          ,px.proc_mod_1_grp_desc
          ,claim.proc_mod_2_cd
          ,px.proc_mod_2_desc
          ,px.proc_mod_2_grp_cd
          ,px.proc_mod_2_grp_desc
          ,claim.proc_mod_3_cd
          ,px.proc_mod_3_desc
          ,px.proc_mod_3_grp_cd
          ,px.proc_mod_3_grp_desc
          ,claim.srvc_typ_cd
          ,prov.prov_mpin
          ,claim.prov_tin
          ,claim.prov_fst_nm
          ,claim.prov_lst_nm
          ,claim.prov_zip_cd
          ,claim.prov_state
          ,prov.npi
          ,prov.pcp_flag
          ,prov.provtype
          ,prov.spec_typ_nm
          ,claim.hp_prov_cat_typ_nm
          ,claim.ama_pl_of_srvc_cd
          ,claim.ama_pl_of_srvc_desc
          ,claim.prov_prtcp_sts_cd
          ,claim.hp_prov_sts_rllp_desc
          ,claim.hlth_pln_srvc_typ_cd
          ,claim.hce_srvc_typ_desc
          ,claim.bil_typ_cd
          ,claim.bil_amt
          ,claim.allw_amt
          ,claim.net_pd_amt
          ,claim.oop_amt
          ,claim.copay_amt
          ,claim.ded_amt
          ,claim.coins_amt
          ,claim.disallow_amt
          ,claim.cob_amt
          ,claim.admit_cnt
          ,claim.day_cnt
          ,claim.srvc_unit_cnt
          ,claim.adjudication_dt
          ,claim.admit_dt
          ,claim.discharge_dt
          ,ox.cms_eligible_encounter_flag
          ,ox.hhs_eligible_encounter_flag

    FROM `research-01-217611.df_ucd_stage.udd_medical_claim_ihr`                                  AS claim
      JOIN `research-01-217611.df_ucd_stage.wkg_medical_claim_ihr_enriched_diag1_columns`         AS dx1	 ON claim.uuid = dx1.uuid AND dx1.year_nbr = yr_start
      JOIN `research-01-217611.df_ucd_stage.wkg_medical_claim_ihr_enriched_diag2_columns`	        AS dx2	 ON claim.uuid = dx2.uuid AND dx2.year_nbr = yr_start
      JOIN `research-01-217611.df_ucd_stage.wkg_medical_claim_ihr_enriched_diag3_columns`	        AS dx3	 ON claim.uuid = dx3.uuid AND dx3.year_nbr = yr_start
      JOIN `research-01-217611.df_ucd_stage.wkg_medical_claim_ihr_enriched_proc_columns`	        AS px	 ON claim.uuid = px.uuid  AND px.year_nbr = yr_start
      JOIN `research-01-217611.df_ucd_stage.wkg_medical_claim_ihr_enriched_prov_columns`	        AS prov	 ON claim.uuid = prov.uuid  AND prov.year_nbr = yr_start
      JOIN `research-01-217611.df_ucd_stage.wkg_medical_claim_ihr_enriched_other_join_columns`	  AS ox	 ON claim.uuid = ox.uuid  AND ox.year_nbr = yr_start
    ;

      insert into `research-01-217611.df_ucd_stage.logging`(
        success_flag, job, message_datetime)
      select
        1 as success_flag
        , 'load medical_claim_ihr_enriched loop-' || cast(yr_start as string) as job
        , current_datetime as message_datetime
      ;

    SET yr_start = yr_start + 1;

  END WHILE;

    insert into `research-01-217611.df_ucd_stage.logging`(
      success_flag, job, message_datetime)
    select
      1 as success_flag
      , 'load medical_claim_enriched tables' as job
      , current_datetime as message_datetime
    ;


    EXCEPTION WHEN ERROR THEN
      insert into `research-01-217611.df_ucd_stage.logging`(
        success_flag, job, error_message, statement_text, formatted_stack_trace, message_datetime)
      select
        0 as success_flag
        , 'load medical_claim_enriched tables' as job
        , @@error.message as error_message
        , @@error.statement_text as statement_text
        , @@error.formatted_stack_trace as formatted_stack_trace
        , current_datetime as message_datetime
      ;

  -- DROP TABLE `research-01-217611.df_ucd_stage.wkg_member_detail_member_month_src_type` ;
  -- DROP TABLE `research-01-217611.df_ucd_stage.wkg_medical_claim_enriched_diag1_columns`;
  -- DROP TABLE `research-01-217611.df_ucd_stage.wkg_medical_claim_enriched_diag2_columns`	;
  -- DROP TABLE `research-01-217611.df_ucd_stage.wkg_medical_claim_enriched_diag3_columns`;
  -- DROP TABLE `research-01-217611.df_ucd_stage.wkg_medical_claim_enriched_proc_columns`;
  -- DROP TABLE `research-01-217611.df_ucd_stage.wkg_medical_claim_enriched_other_join_columns`;

END
;
