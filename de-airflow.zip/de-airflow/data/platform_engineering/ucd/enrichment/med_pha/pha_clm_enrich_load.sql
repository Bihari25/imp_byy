BEGIN

/* ===================================================================================================== */
/* Create dimension tables to use */
    --one big cause of performance problems is joining to large dimension tables, so we'll create working
    --copies of just what we need.
/* ===================================================================================================== */

  create or replace table `research-01-217611.df_ucd_stage.wkg_dim_ndc_drug_in_use`
    cluster by ndc
    as
    (
    select ndc.*
    from
        `research-01-217611.df_ucd_stage.dim_ndc_drug`                ndc
        join (select distinct ndc from `research-01-217611.df_ucd_stage.udd_pharmacy_claim_consolidated`
              union DISTINCT
              select distinct ndc from `research-01-217611.df_ucd_stage.udd_pharmacy_claim_ihr`
              )                                                       clm  on clm.ndc = ndc.ndc
    );



  insert into `research-01-217611.df_ucd_stage.ucd_pharmacy_claim_enriched`
    (uuid, pharmacy_claim_uuid, savvy_pid, savvy_did, is_restricted, drg_strgth_unit_desc, drg_strgth_nbr, brnd_nm, gnrc_nm, ndc, dosage_fm_desc, ext_ahfs_thrptc_clss_cd, ext_ahfs_thrptc_clss_desc, genericindicator, maint_drug_ind, gpi, drug_group_name, drug_class_name, drug_subclass_name, drug_basic_name, drug_extended_name, drug_dosage_form_id, sbmt_full_dt, sbmt_year_mo, sbmt_year_nbr, usual_and_customary_cost, allw_amt, net_pd_amt, oop_amt, copay_amt, ded_amt, coins_amt, day_cnt, qty_cnt, scrpt_cnt, fill_dt, month_id, month_nbr, day_nbr, year_qtr, year_nbr, year_mo, pharmacy_name, pharmacy_claim_id, pharmacy_address, pharmacy_city, pharmacy_state, pharmacy_zip, prescription_number, prescriber_id, prescriber_first_name, prescriber_last_name, drug_manufacturer, label_name, otc_indicator, prior_authorization_number, rx_network_id, plan_drug_status, product_id, business_line, prov_id, prov_mpin, prov_fst_nm, prov_lst_nm, prov_tin, site_cd, prov_zip_cd, prov_typ_nm, spec_typ_nm, refill, src_type, script_end_date, allw_amt_rx, net_pd_amt_rx, source, claim_status, create_datetime, update_datetime, age, is_ahfs_unknown, is_ahfs_ethanolamine_derivatives, is_ahfs_ethylenediamine_derivatives, is_ahfs_phenothiazine_derivatives, is_ahfs_piperazine_derivatives, is_ahfs_propylamine_derivatives, is_ahfs_first_gen_antihist_derivatives_misc, is_ahfs_second_generation_antihistamines, is_ahfs_other_antihistamines, is_ahfs_anthelmintics, is_ahfs_aminoglycoside_antibiotics, is_ahfs_1st_generation_cephalosporin_antibiotics, is_ahfs_2nd_generation_cephalosporin_antibiotics, is_ahfs_3rd_generation_cephalosporin_antibiotics, is_ahfs_4th_generation_cephalosporin_antibiotics, is_ahfs_5th_generation_cephalosporin_antibiotics, is_ahfs_carbacephem_antibiotics, is_ahfs_carbapenem_antibiotics, is_ahfs_cephamycin_antibiotics, is_ahfs_monobactam_antibiotics, is_ahfs_chloramphenicol_antibiotics, is_ahfs_macrolide_antibiotics, is_ahfs_erythromycin_antibiotics, is_ahfs_ketolide_antibiotics, is_ahfs_other_macrolide_antibiotics, is_ahfs_natural_penicillin_antibiotics, is_ahfs_aminopenicillin_antibiotics, is_ahfs_penicillinase_resistant_penicillins, is_ahfs_extended_spectrum_penicillins, is_ahfs_quinolone_antibiotics, is_ahfs_sulfonamide_antibiotics_systemic, is_ahfs_tetracycline_antibiotics, is_ahfs_aminomethylcyclines, is_ahfs_fluorocyclines, is_ahfs_glycylcycline_antibiotics, is_ahfs_bacitracin_antibiotics, is_ahfs_cyclic_lipopeptide_antibiotics, is_ahfs_glycopeptide_antibiotics, is_ahfs_lincomycin_antibiotics, is_ahfs_oxazolidinone_antibiotics, is_ahfs_pleuromutilins, is_ahfs_polymyxin_antibiotics, is_ahfs_rifamycin_antibiotics, is_ahfs_streptogramin_antibiotics, is_ahfs_other_misc_antibacterial_agents, is_ahfs_allylamine_antifungals, is_ahfs_azole_antifungals, is_ahfs_echinocandin_antifungals, is_ahfs_polyene_antifungals, is_ahfs_pyrimidine_antifungals, is_ahfs_antifungals_miscellaneous, is_ahfs_antituberculosis_agents, is_ahfs_antimycobacterials_miscellaneous, is_ahfs_adamantane_antivirals, is_ahfs_hiv_entry_and_fusion_inhibitors, is_ahfs_hiv_protease_inhibitor_antiretrovirals, is_ahfs_hiv_integrase_inhibitor_antiretrovirals, is_ahfs_hiv_nonnucleoside_revtranscrip_inhib, is_ahfs_hiv_nucleoside_nucleotide_rt_inhibitors, is_ahfs_interferon_antivirals, is_ahfs_monoclonal_antibody_antivirals, is_ahfs_neuraminidase_inhibitor_antivirals, is_ahfs_nucleoside_and_nucleotide_antivirals, is_ahfs_hcv_polymerase_inhibitor_antivirals, is_ahfs_hcv_protease_inhibitor_antivirals, is_ahfs_hcv_replication_complex_inhibitors, is_ahfs_antivirals_miscellaneous, is_ahfs_amebicides, is_ahfs_antimalarials, is_ahfs_antiprotozoals_miscellaneous, is_ahfs_urinary_anti_infectives, is_ahfs_anti_infectives_systemic_misc, is_ahfs_antineoplastic_agents, is_ahfs_parasympathomimetic_cholinergic_agents, is_ahfs_antimuscarinics_antispasmodics, is_ahfs_sympathomimetic_adrenergic_agents, is_ahfs_alpha_adrenergic_agonists, is_ahfs_non_selective_beta_adrenergic_agonists, is_ahfs_selective_beta_1_adrenergic_agonists, is_ahfs_selective_beta_2_adrenergic_agonists, is_ahfs_alpha_and_beta_adrenergic_agonists, is_ahfs_sympatholytic_adrenergic_blocking_agents, is_ahfs_alpha_adrenergic_blocking_agentsympath, is_ahfs_non_selalpha_adrenergic_blocking_agents, is_ahfs_selective_alpha_1_adrenergic_blockagent, is_ahfs_selective_beta_adrenergic_blocking_agent, is_ahfs_centrally_acting_skeletal_muscle_relaxnt, is_ahfs_direct_acting_skeletal_muscle_relaxants, is_ahfs_gaba_derivative_skeletal_muscle_relaxant, is_ahfs_neuromuscular_blocking_agents, is_ahfs_skeletal_muscle_relaxants_miscellaneous, is_ahfs_autonomic_drugs_miscellaneous, is_ahfs_blood_derivatives, is_ahfs_iron_preparations, is_ahfs_liver_and_stomach_preparations, is_ahfs_anticoagulants, is_ahfs_coumarin_derivatives, is_ahfs_direct_thrombin_inhibitors, is_ahfs_direct_factor_xa_inhibitors, is_ahfs_heparins, is_ahfs_anticoagulants_miscellaneous, is_ahfs_platelet_reducing_agents, is_ahfs_platelet_aggregation_inhibitors, is_ahfs_thrombolytic_agents, is_ahfs_antithrombotic_agents_miscellaneous, is_ahfs_hematopoietic_agents, is_ahfs_hemorrheologic_agents, is_ahfs_antiheparin_agents, is_ahfs_hemostatics, is_ahfs_antihemorrhagic_agents_miscellaneous, is_ahfs_blood_form_coag_thrombosis_agents_misc, is_ahfs_antiarrhythmic_agents, is_ahfs_class_ia_antiarrhythmics, is_ahfs_class_ib_antiarrhythmics, is_ahfs_class_ic_antiarrhythmics, is_ahfs_class_iii_antiarrhythmics, is_ahfs_class_iv_antiarrhythmics, is_ahfs_cardiotonic_agents, is_ahfs_cardiac_drugs_miscellaneous, is_ahfs_bile_acid_sequestrants, is_ahfs_cholesterol_absorption_inhibitors, is_ahfs_fibric_acid_derivatives, is_ahfs_hmg_coa_reductase_inhibitors, is_ahfs_pcsk9_inhibitors, is_ahfs_antilipemic_agents_miscellaneous, is_ahfs_central_alpha_agonists, is_ahfs_direct_vasodilators, is_ahfs_peripheral_adrenergic_inhibitors, is_ahfs_hypotensive_agents_miscellaneous, is_ahfs_vasodilating_agents, is_ahfs_nitrates_and_nitrites, is_ahfs_phosphodiesterase_type_5_inhibitors, is_ahfs_vasodilating_agents_miscellaneous, is_ahfs_sclerosing_agents, is_ahfs_alpha_adrenergic_blocking_agents, is_ahfs_beta_adrenergic_blocking_agents, is_ahfs_dihydropyridines, is_ahfs_calcium_channel_blocking_agents_misc, is_ahfs_angiotensin_converting_enzyme_inhibitors, is_ahfs_angiotensin_ii_receptor_antagonists, is_ahfs_mineralocorticoid_aldosterone_antagnts, is_ahfs_renin_inhibitors, is_ahfs_cellular_therapy, is_ahfs_gene_therapy, is_ahfs_barbiturates_general_anesthetics, is_ahfs_inhalation_anesthetics, is_ahfs_general_anesthetics_miscellaneous, is_ahfs_cyclooxygenase_2_cox_2_inhibitors, is_ahfs_salicylates, is_ahfs_other_nonsteroidal_anti_inflam_agents, is_ahfs_opiate_agonists, is_ahfs_opiate_partial_agonists, is_ahfs_analgesics_and_antipyretics_misc, is_ahfs_opiate_antagonists, is_ahfs_barbiturates_anticonvulsants, is_ahfs_benzodiazepines_anticonvulsants, is_ahfs_hydantoins, is_ahfs_succinimides, is_ahfs_anticonvulsants_miscellaneous, is_ahfs_monoamine_oxidase_inhibitors, is_ahfs_selserotonin_norepi_reuptake_inhibitor, is_ahfs_selective_serotonin_reuptake_inhibitors, is_ahfs_serotonin_modulators, is_ahfs_tricyclics_other_norepi_ru_inhibitors, is_ahfs_antidepressants_miscellaneous, is_ahfs_atypical_antipsychotics, is_ahfs_butyrophenones, is_ahfs_phenothiazines, is_ahfs_thioxanthenes, is_ahfs_antipsychotics_miscellaneous, is_ahfs_amphetamines, is_ahfs_amphetamine_derivatives, is_ahfs_selective_serotonin_receptor_agonists, is_ahfs_anorexigenic_agents_miscellaneous, is_ahfs_respiratory_and_cns_stimulants, is_ahfs_wakefulness_promoting_agents, is_ahfs_anorexigenic_agents_and_stimulants_misc, is_ahfs_barbiturates_anxiolytic_sedative_hyp, is_ahfs_benzodiazepines_anxiolytic_sedativ_hyp, is_ahfs_anxiolytics_sedatives_and_hypnotics_misc, is_ahfs_antimanic_agents, is_ahfs_calcitonin_gene_related_peptide_antag, is_ahfs_selective_serotonin_agonists, is_ahfs_adamantanes_cns, is_ahfs_anticholinergic_agents_cns, is_ahfs_catechol_o_methyltransferasecomtinhib, is_ahfs_dopamine_precursors, is_ahfs_ergot_deriv_dopamine_receptor_agonists, is_ahfs_nonergot_derivdopamine_receptor_agonist, is_ahfs_monoamine_oxidase_b_inhibitors, is_ahfs_fibromyalgia_agents, is_ahfs_vesicular_monoamine_transport2_inhibitor, is_ahfs_central_nervous_system_agents_misc, is_ahfs_contraceptives_eg_foams_devices, is_ahfs_dental_agents, is_ahfs_diagnostic_agents, is_ahfs_adrenocortical_insufficiency, is_ahfs_allergenic_extracts_diagnostic, is_ahfs_cardiac_function, is_ahfs_diabetes_mellitus, is_ahfs_drug_hypersensitivity, is_ahfs_fungi, is_ahfs_gallbladder_function, is_ahfs_gastric_function, is_ahfs_intestinal_absorption, is_ahfs_kidney_function, is_ahfs_liver_function, is_ahfs_lymphatic_system, is_ahfs_myasthenia_gravis, is_ahfs_ocular_disorders, is_ahfs_thyroid_function, is_ahfs_pancreatic_function, is_ahfs_pheochromocytoma, is_ahfs_pituitary_function, is_ahfs_roentgenography_and_other_imaging_agents, is_ahfs_respiratory_function, is_ahfs_tuberculosis, is_ahfs_urine_and_feces_contents, is_ahfs_ketones, is_ahfs_occult_blood, is_ahfs_ph, is_ahfs_protein, is_ahfs_sugar, is_ahfs_disinfectants_for_non_dermatologic_use, is_ahfs_acidifying_agents, is_ahfs_alkalinizing_agents, is_ahfs_ammonia_detoxicants, is_ahfs_replacement_preparations, is_ahfs_ion_removing_agents, is_ahfs_potassium_removing_agents, is_ahfs_phosphate_removing_agents, is_ahfs_other_ion_removing_agents, is_ahfs_caloric_agents, is_ahfs_salt_and_sugar_substitutes, is_ahfs_loop_diuretics, is_ahfs_osmotic_diuretics, is_ahfs_potassium_sparing_diuretics, is_ahfs_thiazide_diuretics, is_ahfs_thiazide_like_diuretics, is_ahfs_vasopressin_antagonists, is_ahfs_diuretics_miscellaneous, is_ahfs_irrigating_solutions, is_ahfs_uricosuric_agents, is_ahfs_electrolytic_caloric_water_balance_misc, is_ahfs_enzymes, is_ahfs_antifibrotic_agents, is_ahfs_first_generation_antihistrespir_tract, is_ahfs_antitussives, is_ahfs_orally_inhaled_preparations_steroids, is_ahfs_interleukin_antagonists, is_ahfs_leukotriene_modifiers, is_ahfs_mast_cell_stabilizers, is_ahfs_cystic_fibrosis_cftr_correctors, is_ahfs_cystic_fibrosis_cftr_potentiators, is_ahfs_expectorants, is_ahfs_mucolytic_agents, is_ahfs_phosphodiesterase_type_4_inhibitors, is_ahfs_pulmonary_surfactants, is_ahfs_vasodilating_agents_respiratory_tract, is_ahfs_respiratory_tract_agents_miscellaneous, is_ahfs_antiallergic_agents, is_ahfs_antibacterials_eent, is_ahfs_antifungals_eent, is_ahfs_antivirals_eent, is_ahfs_eent_anti_infectives_miscellaneous, is_ahfs_corticosteroids_eent, is_ahfs_eent_nonsteroidal_anti_inflam_agents, is_ahfs_eent_anti_inflammatory_agents_misc, is_ahfs_contact_lens_solutions, is_ahfs_local_anesthetics_eent, is_ahfs_mydriatics, is_ahfs_mouthwashes_and_gargles, is_ahfs_vasoconstrictors, is_ahfs_alpha_adrenergic_agonists_eent, is_ahfs_beta_adrenergic_blocking_agents_eent, is_ahfs_carbonic_anhydrase_inhibitors_eent, is_ahfs_miotics, is_ahfs_prostaglandin_analogs, is_ahfs_rho_kinase_inhibitors, is_ahfs_antiglaucoma_agents_miscellaneous, is_ahfs_eent_drugs_miscellaneous, is_ahfs_antacids_and_adsorbents, is_ahfs_antidiarrhea_agents, is_ahfs_antiflatulents, is_ahfs_cathartics_and_laxatives, is_ahfs_cholelitholytic_agents, is_ahfs_digestants, is_ahfs_emetics, is_ahfs_antihistamines_gi_drugs, is_ahfs_5_ht3_receptor_antagonists, is_ahfs_neurokinin_1_receptor_antagonists, is_ahfs_antiemetics_miscellaneous, is_ahfs_lipotropic_agents, is_ahfs_histamine_h2_antagonists, is_ahfs_prostaglandins, is_ahfs_protectants, is_ahfs_proton_pump_inhibitors, is_ahfs_prokinetic_agents, is_ahfs_anti_inflammatory_agents_gi_drugs, is_ahfs_gi_drugs_miscellaneous, is_ahfs_gold_compounds, is_ahfs_heavy_metal_antagonists, is_ahfs_adrenals, is_ahfs_androgens, is_ahfs_contraceptives, is_ahfs_estrogens, is_ahfs_antiestrogens, is_ahfs_estrogen_agonist_antagonists, is_ahfs_gonadotropins_and_antigonadotropins, is_ahfs_antigonadtropins, is_ahfs_gonadotropins, is_ahfs_alpha_glucosidase_inhibitors, is_ahfs_amylinomimetics, is_ahfs_biguanides, is_ahfs_dipeptidyl_peptidase_4dpp_4_inhibitors, is_ahfs_incretin_mimetics, is_ahfs_insulins, is_ahfs_rapid_acting_insulins, is_ahfs_short_acting_insulins, is_ahfs_intermediate_acting_insulins, is_ahfs_long_acting_insulins, is_ahfs_meglitinides, is_ahfs_sodium_gluc_cotransport_2_sglt2_inhib, is_ahfs_sulfonylureas, is_ahfs_thiazolidinediones, is_ahfs_antidiabetic_agents_miscellaneous, is_ahfs_glycogenolytic_agents, is_ahfs_antihypoglycemic_agents_miscellaneous, is_ahfs_parathyroid_and_antiparathyroid_agents, is_ahfs_antiparathyroid_agents, is_ahfs_parathyroid_agents, is_ahfs_pituitary, is_ahfs_somatostatin_agonists, is_ahfs_somatotropin_agonists, is_ahfs_somatotropin_antagonists, is_ahfs_progestins, is_ahfs_thyroid_agents, is_ahfs_antithyroid_agents, is_ahfs_leptins, is_ahfs_renin_angiotensin_aldosterone_systraas, is_ahfs_local_anesthetics_parenteral, is_ahfs_oxytocics, is_ahfs_radioactive_agents, is_ahfs_allergenic_extracts_therapeutic, is_ahfs_antitoxins_and_immune_globulins, is_ahfs_toxoids, is_ahfs_vaccines, is_ahfs_antibacterials_skin_mucous_membrane, is_ahfs_antivirals_skin_and_mucous_membrane, is_ahfs_antifungals_skin_and_mucous_membrane, is_ahfs_allylamines_skin_and_mucous_membrane, is_ahfs_azoles_skin_and_mucous_membrane, is_ahfs_benzylamines_skin_and_mucous_membrane, is_ahfs_hydroxypyridones_skin_mucous_membrane, is_ahfs_oxaboroles, is_ahfs_polyenes_skin_and_mucous_membrane, is_ahfs_thiocarbamatesskin_and_mucous_membrane, is_ahfs_antifulgals_skin_mucous_membrane_misc, is_ahfs_scabicides_and_pediculicides, is_ahfs_local_anti_infectives_miscellaneous, is_ahfs_anti_inflammatory_agents_skin_mucous, is_ahfs_corticosteroids_skin_mucous_membrane, is_ahfs_nonsteroidal_anti_inflammatagentsskin, is_ahfs_anti_inflammatory_agents_misc_skin, is_ahfs_antipruritics_and_local_anesthetics, is_ahfs_astringents, is_ahfs_cell_stimulants_and_proliferants, is_ahfs_detergents, is_ahfs_emollients_demulcents_and_protectants, is_ahfs_basic_lotions_and_liniments, is_ahfs_basic_oils_and_other_solvents, is_ahfs_basic_ointments_and_protectants, is_ahfs_basic_powders_and_demulcents, is_ahfs_keratolytic_agents, is_ahfs_keratoplastic_agents, is_ahfs_depigmenting_agents, is_ahfs_pigmenting_agents, is_ahfs_sunscreen_agents, is_ahfs_skin_and_mucous_membrane_agents_misc, is_ahfs_genitourinary_smooth_muscle_relaxants, is_ahfs_antimuscarinics, is_ahfs_selective_beta_3_adrenergic_agonists, is_ahfs_respiratory_smooth_muscle_relaxants, is_ahfs_vitamin_a, is_ahfs_vitamin_b_complex, is_ahfs_vitamin_c, is_ahfs_vitamin_d, is_ahfs_vitamin_e, is_ahfs_vitamin_k_activity, is_ahfs_multivitamin_preparations, is_ahfs_miscellaneous_therapeutic_agents, is_ahfs_alcohol_deterrents, is_ahfs_5_alpha_reductase_inhibitors, is_ahfs_antidotes, is_ahfs_antigout_agents, is_ahfs_antisense_oligonucleotides, is_ahfs_immunomodulatory_agents, is_ahfs_bone_anabolic_agents, is_ahfs_bone_resorption_inhibitors, is_ahfs_carbonic_anhydrase_inhibitors_misc, is_ahfs_cariostatic_agents, is_ahfs_complement_inhibitors, is_ahfs_disease_modifying_antirheumatic_agents, is_ahfs_gonadotropin_releasing_hormone_antagnts, is_ahfs_immunosuppressive_agents, is_ahfs_protective_agents, is_ahfs_other_miscellaneous_therapeutic_agents, is_ahfs_devices, is_ahfs_pharmaceutical_aids
    )

  with
    /*
    mbr as
      (--could be more than one record per member per year_mo, so let's get a single birth year to use for age computation
        select savvy_pid, savvy_did, max(is_restricted) as is_restricted, year_mo,
          max(birth_year) as birth_year
        from `research-01-217611.df_ucd_stage.udd_member_detail_consolidated`
        group by savvy_pid, savvy_did, year_mo
      ),
    */
    clm as
      (--if the ndc exists in dim_ndc_drug use values from there instead of from the claim so that we use consistent descriptions, etc for scripts from different sources
      select
        clm.uuid
        ,	clm.savvy_pid
        , clm.savvy_did
        , clm.is_restricted
        ,	clm.fill_dt
        ,	clm.pharmacy_name
        ,	clm.pharmacy_claim_id
        ,	clm.pharmacy_address
        ,	clm.pharmacy_city
        ,	clm.pharmacy_state
        ,	clm.pharmacy_zip
        ,	clm.prescription_number
        ,	clm.prescriber_id
        ,	clm.prescriber_first_name
        ,	clm.prescriber_last_name
        ,	ifnull(ndc.drug_manufacturer_name, clm.drug_manufacturer) as drug_manufacturer
        ,	ifnull(ndc.drug_label_name, clm.label_name) as label_name
        ,	clm.otc_indicator
        ,	clm.prior_authorization_number
        ,	clm.rx_network_id
        ,	clm.plan_drug_status
        ,	clm.product_id
        ,	clm.business_line
        ,	clm.prov_id
        ,	clm.prov_fst_nm
        ,	clm.prov_lst_nm
        ,	clm.prov_tin
        ,	clm.site_cd
        ,	clm.prov_mpin
        ,	clm.prov_zip_cd
        ,	clm.prov_typ_nm
        ,	COALESCE(prov.specialty_1_longdesc, clm.spec_typ_nm) AS spec_typ_nm
        ,	clm.refill
        ,	ifnull(ndc.drg_strgth_unit_desc, clm.drg_strgth_unit_desc) as drg_strgth_unit_desc
        ,	ifnull(ndc.drg_strgth_nbr, clm.drg_strgth_nbr) as drg_strgth_nbr
        ,	ifnull(ndc.brnd_nm, clm.brnd_nm) as brnd_nm
        ,	ifnull(ndc.gnrc_nm, clm.gnrc_nm) as gnrc_nm
        , clm.ndc
        ,	ifnull(ndc.dosage_fm_desc, clm.dosage_fm_desc) as dosage_fm_desc
        ,	ifnull(safe_cast(ndc.ext_ahfs_thrptc_class_cd as int64), clm.ext_ahfs_thrptc_clss_cd) as ext_ahfs_thrptc_clss_cd
        , ifnull(ndc.ext_ahfs_thrptc_class_desc, clm.ext_ahfs_thrptc_clss_desc) as ext_ahfs_thrptc_clss_desc
        ,	ifnull(ndc.gnrc_ind, clm.genericindicator) as genericindicator
        ,	clm.maint_drug_ind
        ,	(case when current_flag = 'y' then ndc.gpi_number else clm.gpi end) as gpi
        , ndc.drug_group_name
        , ndc.drug_class_name
        , ndc.drug_subclass_name
        , ndc.drug_basic_name
        , ndc.drug_extended_name
        , ndc.drug_dosage_form_id
        ,	clm.sbmt_full_dt
        ,	clm.qty_cnt
        ,	clm.scrpt_cnt
        ,	clm.day_cnt
        ,	clm.usual_and_customary_cost
        ,	clm.allw_amt
        ,	clm.net_pd_amt
        ,	clm.oop_amt
        ,	clm.copay_amt
        ,	clm.ded_amt
        ,	clm.coins_amt
        ,	clm.src_type
        ,	clm.source
        ,	clm.claim_status
        , clm.create_datetime
        , clm.update_datetime
      from `research-01-217611.df_ucd_stage.udd_pharmacy_claim_consolidated`      clm
          left join `research-01-217611.df_ucd_stage.wkg_dim_ndc_drug_in_use`     ndc  on clm.ndc = ndc.ndc
          left join `research-01-217611.df_ucd_stage.dim_provider`                prov ON clm.prov_mpin = prov.mpin
      )
  select
        GENERATE_UUID() uuid
        , clm.uuid pharmacy_claim_uuid
        , clm.savvy_pid
        , clm.savvy_did
        , ifnull(mbr.is_restricted, clm.is_restricted)
        , drg_strgth_unit_desc
        , drg_strgth_nbr
        , brnd_nm
        , gnrc_nm
        , ndc
        , dosage_fm_desc
        , ext_ahfs_thrptc_clss_cd
        , ext_ahfs_thrptc_clss_desc
        , clm.genericindicator
        , clm.maint_drug_ind
        , clm.gpi
        , clm.drug_group_name
        , clm.drug_class_name
        , clm.drug_subclass_name
        , clm.drug_basic_name
        , clm.drug_extended_name
        , clm.drug_dosage_form_id
        , clm.sbmt_full_dt
        , sdt.year_mo as sbmt_year_mo
        , sdt.year_nbr as sbmt_year_nbr
        , clm.usual_and_customary_cost
        , allw_amt
        , net_pd_amt
        , oop_amt
        , copay_amt
        , ded_amt
        , clm.coins_amt
        , day_cnt
        , qty_cnt
        , scrpt_cnt
        , fill_dt
        , dt.month_id
        , dt.month_nbr
        , dt.day_nbr
        , dt.year_qtr
        , dt.year_nbr
        , dt.year_mo
        , clm.pharmacy_name
        , clm.pharmacy_claim_id
        , clm.pharmacy_address
        , clm.pharmacy_city
        , clm.pharmacy_state
        , clm.pharmacy_zip
        , clm.prescription_number
        , clm.prescriber_id
        , clm.prescriber_first_name
        , clm.prescriber_last_name
        , clm.drug_manufacturer
        , clm.label_name
        , clm.otc_indicator
        , clm.prior_authorization_number
        , clm.rx_network_id
        , clm.plan_drug_status
        , clm.product_id
        , ifnull(mbr.business_line, clm.business_line) as business_line
        , clm.prov_id
        , prov_mpin
        , prov_fst_nm
        , prov_lst_nm
        , clm.prov_tin
        , clm.site_cd
        , prov_zip_cd
        , prov_typ_nm
        , spec_typ_nm
        , clm.refill
        , clm.src_type
        , date_add(clm.fill_dt, interval greatest(0, day_cnt - 1) DAY) script_end_date
        , clm.allw_amt allw_amt_rx
        , clm.net_pd_amt  net_pd_amt_rx
        , clm.source
        , clm.claim_status
        , clm.create_datetime
        , clm.update_datetime
        , greatest(0, `research-01-217611.df_enrichment.FN_AGE`(clm.fill_dt, concat(mbr.birth_year, '-07-01'))) AS age --assume July 1 dob
        , case when ext_ahfs_thrptc_clss_cd is null then 1 else 0 end 	as	is_ahfs_unknown
        , case when ext_ahfs_thrptc_clss_cd = 4040400 then 1 else 0 end	as	is_ahfs_ethanolamine_derivatives
        , case when ext_ahfs_thrptc_clss_cd = 4040800 then 1 else 0 end	as	is_ahfs_ethylenediamine_derivatives
        , case when ext_ahfs_thrptc_clss_cd = 4041200 then 1 else 0 end	as	is_ahfs_phenothiazine_derivatives
        , case when ext_ahfs_thrptc_clss_cd = 4041600 then 1 else 0 end	as	is_ahfs_piperazine_derivatives
        , case when ext_ahfs_thrptc_clss_cd = 4042000 then 1 else 0 end	as	is_ahfs_propylamine_derivatives
        , case when ext_ahfs_thrptc_clss_cd = 4049200 then 1 else 0 end	as	is_ahfs_first_gen_antihist_derivatives_misc
        , case when ext_ahfs_thrptc_clss_cd = 4080000 then 1 else 0 end	as	is_ahfs_second_generation_antihistamines
        , case when ext_ahfs_thrptc_clss_cd = 4920000 then 1 else 0 end	as	is_ahfs_other_antihistamines
        , case when ext_ahfs_thrptc_clss_cd = 8080000 then 1 else 0 end	as	is_ahfs_anthelmintics
        , case when ext_ahfs_thrptc_clss_cd = 8120200 then 1 else 0 end	as	is_ahfs_aminoglycoside_antibiotics
        , case when ext_ahfs_thrptc_clss_cd = 8120604 then 1 else 0 end	as	is_ahfs_1st_generation_cephalosporin_antibiotics
        , case when ext_ahfs_thrptc_clss_cd = 8120608 then 1 else 0 end	as	is_ahfs_2nd_generation_cephalosporin_antibiotics
        , case when ext_ahfs_thrptc_clss_cd = 8120612 then 1 else 0 end	as	is_ahfs_3rd_generation_cephalosporin_antibiotics
        , case when ext_ahfs_thrptc_clss_cd = 8120616 then 1 else 0 end	as	is_ahfs_4th_generation_cephalosporin_antibiotics
        , case when ext_ahfs_thrptc_clss_cd = 8120620 then 1 else 0 end	as	is_ahfs_5th_generation_cephalosporin_antibiotics
        , case when ext_ahfs_thrptc_clss_cd = 8120704 then 1 else 0 end	as	is_ahfs_carbacephem_antibiotics
        , case when ext_ahfs_thrptc_clss_cd = 8120708 then 1 else 0 end	as	is_ahfs_carbapenem_antibiotics
        , case when ext_ahfs_thrptc_clss_cd = 8120712 then 1 else 0 end	as	is_ahfs_cephamycin_antibiotics
        , case when ext_ahfs_thrptc_clss_cd = 8120716 then 1 else 0 end	as	is_ahfs_monobactam_antibiotics
        , case when ext_ahfs_thrptc_clss_cd = 8120800 then 1 else 0 end	as	is_ahfs_chloramphenicol_antibiotics
        , case when ext_ahfs_thrptc_clss_cd = 8121200 then 1 else 0 end	as	is_ahfs_macrolide_antibiotics
        , case when ext_ahfs_thrptc_clss_cd = 8121204 then 1 else 0 end	as	is_ahfs_erythromycin_antibiotics
        , case when ext_ahfs_thrptc_clss_cd = 8121212 then 1 else 0 end	as	is_ahfs_ketolide_antibiotics
        , case when ext_ahfs_thrptc_clss_cd = 8121292 then 1 else 0 end	as	is_ahfs_other_macrolide_antibiotics
        , case when ext_ahfs_thrptc_clss_cd = 8121604 then 1 else 0 end	as	is_ahfs_natural_penicillin_antibiotics
        , case when ext_ahfs_thrptc_clss_cd = 8121608 then 1 else 0 end	as	is_ahfs_aminopenicillin_antibiotics
        , case when ext_ahfs_thrptc_clss_cd = 8121612 then 1 else 0 end	as	is_ahfs_penicillinase_resistant_penicillins
        , case when ext_ahfs_thrptc_clss_cd = 8121616 then 1 else 0 end	as	is_ahfs_extended_spectrum_penicillins
        , case when ext_ahfs_thrptc_clss_cd = 8121800 then 1 else 0 end	as	is_ahfs_quinolone_antibiotics
        , case when ext_ahfs_thrptc_clss_cd = 8122000 then 1 else 0 end	as	is_ahfs_sulfonamide_antibiotics_systemic
        , case when ext_ahfs_thrptc_clss_cd = 8122400 then 1 else 0 end	as	is_ahfs_tetracycline_antibiotics
        , case when ext_ahfs_thrptc_clss_cd = 8122404 then 1 else 0 end	as	is_ahfs_aminomethylcyclines
        , case when ext_ahfs_thrptc_clss_cd = 8122408 then 1 else 0 end	as	is_ahfs_fluorocyclines
        , case when ext_ahfs_thrptc_clss_cd = 8122412 then 1 else 0 end	as	is_ahfs_glycylcycline_antibiotics
        , case when ext_ahfs_thrptc_clss_cd = 8122808 then 1 else 0 end	as	is_ahfs_bacitracin_antibiotics
        , case when ext_ahfs_thrptc_clss_cd = 8122812 then 1 else 0 end	as	is_ahfs_cyclic_lipopeptide_antibiotics
        , case when ext_ahfs_thrptc_clss_cd = 8122816 then 1 else 0 end	as	is_ahfs_glycopeptide_antibiotics
        , case when ext_ahfs_thrptc_clss_cd = 8122820 then 1 else 0 end	as	is_ahfs_lincomycin_antibiotics
        , case when ext_ahfs_thrptc_clss_cd = 8122824 then 1 else 0 end	as	is_ahfs_oxazolidinone_antibiotics
        , case when ext_ahfs_thrptc_clss_cd = 8122826 then 1 else 0 end	as	is_ahfs_pleuromutilins
        , case when ext_ahfs_thrptc_clss_cd = 8122828 then 1 else 0 end	as	is_ahfs_polymyxin_antibiotics
        , case when ext_ahfs_thrptc_clss_cd = 8122830 then 1 else 0 end	as	is_ahfs_rifamycin_antibiotics
        , case when ext_ahfs_thrptc_clss_cd = 8122832 then 1 else 0 end	as	is_ahfs_streptogramin_antibiotics
        , case when ext_ahfs_thrptc_clss_cd = 8122892 then 1 else 0 end	as	is_ahfs_other_misc_antibacterial_agents
        , case when ext_ahfs_thrptc_clss_cd = 8140400 then 1 else 0 end	as	is_ahfs_allylamine_antifungals
        , case when ext_ahfs_thrptc_clss_cd = 8140800 then 1 else 0 end	as	is_ahfs_azole_antifungals
        , case when ext_ahfs_thrptc_clss_cd = 8141600 then 1 else 0 end	as	is_ahfs_echinocandin_antifungals
        , case when ext_ahfs_thrptc_clss_cd = 8142800 then 1 else 0 end	as	is_ahfs_polyene_antifungals
        , case when ext_ahfs_thrptc_clss_cd = 8143200 then 1 else 0 end	as	is_ahfs_pyrimidine_antifungals
        , case when ext_ahfs_thrptc_clss_cd = 8149200 then 1 else 0 end	as	is_ahfs_antifungals_miscellaneous
        , case when ext_ahfs_thrptc_clss_cd = 8160400 then 1 else 0 end	as	is_ahfs_antituberculosis_agents
        , case when ext_ahfs_thrptc_clss_cd = 8169200 then 1 else 0 end	as	is_ahfs_antimycobacterials_miscellaneous
        , case when ext_ahfs_thrptc_clss_cd = 8180400 then 1 else 0 end	as	is_ahfs_adamantane_antivirals
        , case when ext_ahfs_thrptc_clss_cd = 8180804 then 1 else 0 end	as	is_ahfs_hiv_entry_and_fusion_inhibitors
        , case when ext_ahfs_thrptc_clss_cd = 8180808 then 1 else 0 end	as	is_ahfs_hiv_protease_inhibitor_antiretrovirals
        , case when ext_ahfs_thrptc_clss_cd = 8180812 then 1 else 0 end	as	is_ahfs_hiv_integrase_inhibitor_antiretrovirals
        , case when ext_ahfs_thrptc_clss_cd = 8180816 then 1 else 0 end	as	is_ahfs_hiv_nonnucleoside_revtranscrip_inhib
        , case when ext_ahfs_thrptc_clss_cd = 8180820 then 1 else 0 end	as	is_ahfs_hiv_nucleoside_nucleotide_rt_inhibitors
        , case when ext_ahfs_thrptc_clss_cd = 8182000 then 1 else 0 end	as	is_ahfs_interferon_antivirals
        , case when ext_ahfs_thrptc_clss_cd = 8182400 then 1 else 0 end	as	is_ahfs_monoclonal_antibody_antivirals
        , case when ext_ahfs_thrptc_clss_cd = 8182800 then 1 else 0 end	as	is_ahfs_neuraminidase_inhibitor_antivirals
        , case when ext_ahfs_thrptc_clss_cd = 8183200 then 1 else 0 end	as	is_ahfs_nucleoside_and_nucleotide_antivirals
        , case when ext_ahfs_thrptc_clss_cd = 8184016 then 1 else 0 end	as	is_ahfs_hcv_polymerase_inhibitor_antivirals
        , case when ext_ahfs_thrptc_clss_cd = 8184020 then 1 else 0 end	as	is_ahfs_hcv_protease_inhibitor_antivirals
        , case when ext_ahfs_thrptc_clss_cd = 8184024 then 1 else 0 end	as	is_ahfs_hcv_replication_complex_inhibitors
        , case when ext_ahfs_thrptc_clss_cd = 8189200 then 1 else 0 end	as	is_ahfs_antivirals_miscellaneous
        , case when ext_ahfs_thrptc_clss_cd = 8300400 then 1 else 0 end	as	is_ahfs_amebicides
        , case when ext_ahfs_thrptc_clss_cd = 8300800 then 1 else 0 end	as	is_ahfs_antimalarials
        , case when ext_ahfs_thrptc_clss_cd = 8309200 then 1 else 0 end	as	is_ahfs_antiprotozoals_miscellaneous
        , case when ext_ahfs_thrptc_clss_cd = 8360000 then 1 else 0 end	as	is_ahfs_urinary_anti_infectives
        , case when ext_ahfs_thrptc_clss_cd = 8920000 then 1 else 0 end	as	is_ahfs_anti_infectives_systemic_misc
        , case when ext_ahfs_thrptc_clss_cd = 10000000 then 1 else 0 end	as	is_ahfs_antineoplastic_agents
        , case when ext_ahfs_thrptc_clss_cd = 12040000 then 1 else 0 end	as	is_ahfs_parasympathomimetic_cholinergic_agents
        , case when ext_ahfs_thrptc_clss_cd = 12080800 then 1 else 0 end	as	is_ahfs_antimuscarinics_antispasmodics
        , case when ext_ahfs_thrptc_clss_cd = 12120000 then 1 else 0 end	as	is_ahfs_sympathomimetic_adrenergic_agents
        , case when ext_ahfs_thrptc_clss_cd = 12120400 then 1 else 0 end	as	is_ahfs_alpha_adrenergic_agonists
        , case when ext_ahfs_thrptc_clss_cd = 12120804 then 1 else 0 end	as	is_ahfs_non_selective_beta_adrenergic_agonists
        , case when ext_ahfs_thrptc_clss_cd = 12120808 then 1 else 0 end	as	is_ahfs_selective_beta_1_adrenergic_agonists
        , case when ext_ahfs_thrptc_clss_cd = 12120812 then 1 else 0 end	as	is_ahfs_selective_beta_2_adrenergic_agonists
        , case when ext_ahfs_thrptc_clss_cd = 12121200 then 1 else 0 end	as	is_ahfs_alpha_and_beta_adrenergic_agonists
        , case when ext_ahfs_thrptc_clss_cd = 12160000 then 1 else 0 end	as	is_ahfs_sympatholytic_adrenergic_blocking_agents
        , case when ext_ahfs_thrptc_clss_cd = 12160400 then 1 else 0 end	as	is_ahfs_alpha_adrenergic_blocking_agentsympath
        , case when ext_ahfs_thrptc_clss_cd = 12160404 then 1 else 0 end	as	is_ahfs_non_selalpha_adrenergic_blocking_agents
        , case when ext_ahfs_thrptc_clss_cd = 12160412 then 1 else 0 end	as	is_ahfs_selective_alpha_1_adrenergic_blockagent
        , case when ext_ahfs_thrptc_clss_cd = 12160808 then 1 else 0 end	as	is_ahfs_selective_beta_adrenergic_blocking_agent
        , case when ext_ahfs_thrptc_clss_cd = 12200400 then 1 else 0 end	as	is_ahfs_centrally_acting_skeletal_muscle_relaxnt
        , case when ext_ahfs_thrptc_clss_cd = 12200800 then 1 else 0 end	as	is_ahfs_direct_acting_skeletal_muscle_relaxants
        , case when ext_ahfs_thrptc_clss_cd = 12201200 then 1 else 0 end	as	is_ahfs_gaba_derivative_skeletal_muscle_relaxant
        , case when ext_ahfs_thrptc_clss_cd = 12202000 then 1 else 0 end	as	is_ahfs_neuromuscular_blocking_agents
        , case when ext_ahfs_thrptc_clss_cd = 12209200 then 1 else 0 end	as	is_ahfs_skeletal_muscle_relaxants_miscellaneous
        , case when ext_ahfs_thrptc_clss_cd = 12920000 then 1 else 0 end	as	is_ahfs_autonomic_drugs_miscellaneous
        , case when ext_ahfs_thrptc_clss_cd = 16000000 then 1 else 0 end	as	is_ahfs_blood_derivatives
        , case when ext_ahfs_thrptc_clss_cd = 20040400 then 1 else 0 end	as	is_ahfs_iron_preparations
        , case when ext_ahfs_thrptc_clss_cd = 20040800 then 1 else 0 end	as	is_ahfs_liver_and_stomach_preparations
        , case when ext_ahfs_thrptc_clss_cd = 20120400 then 1 else 0 end	as	is_ahfs_anticoagulants
        , case when ext_ahfs_thrptc_clss_cd = 20120408 then 1 else 0 end	as	is_ahfs_coumarin_derivatives
        , case when ext_ahfs_thrptc_clss_cd = 20120412 then 1 else 0 end	as	is_ahfs_direct_thrombin_inhibitors
        , case when ext_ahfs_thrptc_clss_cd = 20120414 then 1 else 0 end	as	is_ahfs_direct_factor_xa_inhibitors
        , case when ext_ahfs_thrptc_clss_cd = 20120416 then 1 else 0 end	as	is_ahfs_heparins
        , case when ext_ahfs_thrptc_clss_cd = 20120492 then 1 else 0 end	as	is_ahfs_anticoagulants_miscellaneous
        , case when ext_ahfs_thrptc_clss_cd = 20121400 then 1 else 0 end	as	is_ahfs_platelet_reducing_agents
        , case when ext_ahfs_thrptc_clss_cd = 20121800 then 1 else 0 end	as	is_ahfs_platelet_aggregation_inhibitors
        , case when ext_ahfs_thrptc_clss_cd = 20122000 then 1 else 0 end	as	is_ahfs_thrombolytic_agents
        , case when ext_ahfs_thrptc_clss_cd = 20129200 then 1 else 0 end	as	is_ahfs_antithrombotic_agents_miscellaneous
        , case when ext_ahfs_thrptc_clss_cd = 20160000 then 1 else 0 end	as	is_ahfs_hematopoietic_agents
        , case when ext_ahfs_thrptc_clss_cd = 20240000 then 1 else 0 end	as	is_ahfs_hemorrheologic_agents
        , case when ext_ahfs_thrptc_clss_cd = 20280800 then 1 else 0 end	as	is_ahfs_antiheparin_agents
        , case when ext_ahfs_thrptc_clss_cd = 20281600 then 1 else 0 end	as	is_ahfs_hemostatics
        , case when ext_ahfs_thrptc_clss_cd = 20289200 then 1 else 0 end	as	is_ahfs_antihemorrhagic_agents_miscellaneous
        , case when ext_ahfs_thrptc_clss_cd = 20920000 then 1 else 0 end	as	is_ahfs_blood_form_coag_thrombosis_agents_misc
        , case when ext_ahfs_thrptc_clss_cd = 24040400 then 1 else 0 end	as	is_ahfs_antiarrhythmic_agents
        , case when ext_ahfs_thrptc_clss_cd = 24040404 then 1 else 0 end	as	is_ahfs_class_ia_antiarrhythmics
        , case when ext_ahfs_thrptc_clss_cd = 24040408 then 1 else 0 end	as	is_ahfs_class_ib_antiarrhythmics
        , case when ext_ahfs_thrptc_clss_cd = 24040412 then 1 else 0 end	as	is_ahfs_class_ic_antiarrhythmics
        , case when ext_ahfs_thrptc_clss_cd = 24040420 then 1 else 0 end	as	is_ahfs_class_iii_antiarrhythmics
        , case when ext_ahfs_thrptc_clss_cd = 24040424 then 1 else 0 end	as	is_ahfs_class_iv_antiarrhythmics
        , case when ext_ahfs_thrptc_clss_cd = 24040800 then 1 else 0 end	as	is_ahfs_cardiotonic_agents
        , case when ext_ahfs_thrptc_clss_cd = 24049200 then 1 else 0 end	as	is_ahfs_cardiac_drugs_miscellaneous
        , case when ext_ahfs_thrptc_clss_cd = 24060400 then 1 else 0 end	as	is_ahfs_bile_acid_sequestrants
        , case when ext_ahfs_thrptc_clss_cd = 24060500 then 1 else 0 end	as	is_ahfs_cholesterol_absorption_inhibitors
        , case when ext_ahfs_thrptc_clss_cd = 24060600 then 1 else 0 end	as	is_ahfs_fibric_acid_derivatives
        , case when ext_ahfs_thrptc_clss_cd = 24060800 then 1 else 0 end	as	is_ahfs_hmg_coa_reductase_inhibitors
        , case when ext_ahfs_thrptc_clss_cd = 24062400 then 1 else 0 end	as	is_ahfs_pcsk9_inhibitors
        , case when ext_ahfs_thrptc_clss_cd = 24069200 then 1 else 0 end	as	is_ahfs_antilipemic_agents_miscellaneous
        , case when ext_ahfs_thrptc_clss_cd = 24081600 then 1 else 0 end	as	is_ahfs_central_alpha_agonists
        , case when ext_ahfs_thrptc_clss_cd = 24082000 then 1 else 0 end	as	is_ahfs_direct_vasodilators
        , case when ext_ahfs_thrptc_clss_cd = 24083200 then 1 else 0 end	as	is_ahfs_peripheral_adrenergic_inhibitors
        , case when ext_ahfs_thrptc_clss_cd = 24089200 then 1 else 0 end	as	is_ahfs_hypotensive_agents_miscellaneous
        , case when ext_ahfs_thrptc_clss_cd = 24120000 then 1 else 0 end	as	is_ahfs_vasodilating_agents
        , case when ext_ahfs_thrptc_clss_cd = 24120800 then 1 else 0 end	as	is_ahfs_nitrates_and_nitrites
        , case when ext_ahfs_thrptc_clss_cd = 24121200 then 1 else 0 end	as	is_ahfs_phosphodiesterase_type_5_inhibitors
        , case when ext_ahfs_thrptc_clss_cd = 24129200 then 1 else 0 end	as	is_ahfs_vasodilating_agents_miscellaneous
        , case when ext_ahfs_thrptc_clss_cd = 24160000 then 1 else 0 end	as	is_ahfs_sclerosing_agents
        , case when ext_ahfs_thrptc_clss_cd = 24200000 then 1 else 0 end	as	is_ahfs_alpha_adrenergic_blocking_agents
        , case when ext_ahfs_thrptc_clss_cd = 24240000 then 1 else 0 end	as	is_ahfs_beta_adrenergic_blocking_agents
        , case when ext_ahfs_thrptc_clss_cd = 24280800 then 1 else 0 end	as	is_ahfs_dihydropyridines
        , case when ext_ahfs_thrptc_clss_cd = 24289200 then 1 else 0 end	as	is_ahfs_calcium_channel_blocking_agents_misc
        , case when ext_ahfs_thrptc_clss_cd = 24320400 then 1 else 0 end	as	is_ahfs_angiotensin_converting_enzyme_inhibitors
        , case when ext_ahfs_thrptc_clss_cd = 24320800 then 1 else 0 end	as	is_ahfs_angiotensin_ii_receptor_antagonists
        , case when ext_ahfs_thrptc_clss_cd = 24322000 then 1 else 0 end	as	is_ahfs_mineralocorticoid_aldosterone_antagnts
        , case when ext_ahfs_thrptc_clss_cd = 24324000 then 1 else 0 end	as	is_ahfs_renin_inhibitors
        , case when ext_ahfs_thrptc_clss_cd = 26040000 then 1 else 0 end	as	is_ahfs_cellular_therapy
        , case when ext_ahfs_thrptc_clss_cd = 26120000 then 1 else 0 end	as	is_ahfs_gene_therapy
        , case when ext_ahfs_thrptc_clss_cd = 28040400 then 1 else 0 end	as	is_ahfs_barbiturates_general_anesthetics
        , case when ext_ahfs_thrptc_clss_cd = 28041600 then 1 else 0 end	as	is_ahfs_inhalation_anesthetics
        , case when ext_ahfs_thrptc_clss_cd = 28049200 then 1 else 0 end	as	is_ahfs_general_anesthetics_miscellaneous
        , case when ext_ahfs_thrptc_clss_cd = 28080408 then 1 else 0 end	as	is_ahfs_cyclooxygenase_2_cox_2_inhibitors
        , case when ext_ahfs_thrptc_clss_cd = 28080424 then 1 else 0 end	as	is_ahfs_salicylates
        , case when ext_ahfs_thrptc_clss_cd = 28080492 then 1 else 0 end	as	is_ahfs_other_nonsteroidal_anti_inflam_agents
        , case when ext_ahfs_thrptc_clss_cd = 28080800 then 1 else 0 end	as	is_ahfs_opiate_agonists
        , case when ext_ahfs_thrptc_clss_cd = 28081200 then 1 else 0 end	as	is_ahfs_opiate_partial_agonists
        , case when ext_ahfs_thrptc_clss_cd = 28089200 then 1 else 0 end	as	is_ahfs_analgesics_and_antipyretics_misc
        , case when ext_ahfs_thrptc_clss_cd = 28100000 then 1 else 0 end	as	is_ahfs_opiate_antagonists
        , case when ext_ahfs_thrptc_clss_cd = 28120400 then 1 else 0 end	as	is_ahfs_barbiturates_anticonvulsants
        , case when ext_ahfs_thrptc_clss_cd = 28120800 then 1 else 0 end	as	is_ahfs_benzodiazepines_anticonvulsants
        , case when ext_ahfs_thrptc_clss_cd = 28121200 then 1 else 0 end	as	is_ahfs_hydantoins
        , case when ext_ahfs_thrptc_clss_cd = 28122000 then 1 else 0 end	as	is_ahfs_succinimides
        , case when ext_ahfs_thrptc_clss_cd = 28129200 then 1 else 0 end	as	is_ahfs_anticonvulsants_miscellaneous
        , case when ext_ahfs_thrptc_clss_cd = 28160412 then 1 else 0 end	as	is_ahfs_monoamine_oxidase_inhibitors
        , case when ext_ahfs_thrptc_clss_cd = 28160416 then 1 else 0 end	as	is_ahfs_selserotonin_norepi_reuptake_inhibitor
        , case when ext_ahfs_thrptc_clss_cd = 28160420 then 1 else 0 end	as	is_ahfs_selective_serotonin_reuptake_inhibitors
        , case when ext_ahfs_thrptc_clss_cd = 28160424 then 1 else 0 end	as	is_ahfs_serotonin_modulators
        , case when ext_ahfs_thrptc_clss_cd = 28160428 then 1 else 0 end	as	is_ahfs_tricyclics_other_norepi_ru_inhibitors
        , case when ext_ahfs_thrptc_clss_cd = 28160492 then 1 else 0 end	as	is_ahfs_antidepressants_miscellaneous
        , case when ext_ahfs_thrptc_clss_cd = 28160804 then 1 else 0 end	as	is_ahfs_atypical_antipsychotics
        , case when ext_ahfs_thrptc_clss_cd = 28160808 then 1 else 0 end	as	is_ahfs_butyrophenones
        , case when ext_ahfs_thrptc_clss_cd = 28160824 then 1 else 0 end	as	is_ahfs_phenothiazines
        , case when ext_ahfs_thrptc_clss_cd = 28160832 then 1 else 0 end	as	is_ahfs_thioxanthenes
        , case when ext_ahfs_thrptc_clss_cd = 28160892 then 1 else 0 end	as	is_ahfs_antipsychotics_miscellaneous
        , case when ext_ahfs_thrptc_clss_cd = 28200400 then 1 else 0 end	as	is_ahfs_amphetamines
        , case when ext_ahfs_thrptc_clss_cd = 28200804 then 1 else 0 end	as	is_ahfs_amphetamine_derivatives
        , case when ext_ahfs_thrptc_clss_cd = 28200832 then 1 else 0 end	as	is_ahfs_selective_serotonin_receptor_agonists
        , case when ext_ahfs_thrptc_clss_cd = 28200892 then 1 else 0 end	as	is_ahfs_anorexigenic_agents_miscellaneous
        , case when ext_ahfs_thrptc_clss_cd = 28203200 then 1 else 0 end	as	is_ahfs_respiratory_and_cns_stimulants
        , case when ext_ahfs_thrptc_clss_cd = 28208000 then 1 else 0 end	as	is_ahfs_wakefulness_promoting_agents
        , case when ext_ahfs_thrptc_clss_cd = 28209200 then 1 else 0 end	as	is_ahfs_anorexigenic_agents_and_stimulants_misc
        , case when ext_ahfs_thrptc_clss_cd = 28240400 then 1 else 0 end	as	is_ahfs_barbiturates_anxiolytic_sedative_hyp
        , case when ext_ahfs_thrptc_clss_cd = 28240800 then 1 else 0 end	as	is_ahfs_benzodiazepines_anxiolytic_sedativ_hyp
        , case when ext_ahfs_thrptc_clss_cd = 28249200 then 1 else 0 end	as	is_ahfs_anxiolytics_sedatives_and_hypnotics_misc
        , case when ext_ahfs_thrptc_clss_cd = 28280000 then 1 else 0 end	as	is_ahfs_antimanic_agents
        , case when ext_ahfs_thrptc_clss_cd = 28321200 then 1 else 0 end	as	is_ahfs_calcitonin_gene_related_peptide_antag
        , case when ext_ahfs_thrptc_clss_cd = 28322800 then 1 else 0 end	as	is_ahfs_selective_serotonin_agonists
        , case when ext_ahfs_thrptc_clss_cd = 28360400 then 1 else 0 end	as	is_ahfs_adamantanes_cns
        , case when ext_ahfs_thrptc_clss_cd = 28360800 then 1 else 0 end	as	is_ahfs_anticholinergic_agents_cns
        , case when ext_ahfs_thrptc_clss_cd = 28361200 then 1 else 0 end	as	is_ahfs_catechol_o_methyltransferasecomtinhib
        , case when ext_ahfs_thrptc_clss_cd = 28361600 then 1 else 0 end	as	is_ahfs_dopamine_precursors
        , case when ext_ahfs_thrptc_clss_cd = 28362004 then 1 else 0 end	as	is_ahfs_ergot_deriv_dopamine_receptor_agonists
        , case when ext_ahfs_thrptc_clss_cd = 28362008 then 1 else 0 end	as	is_ahfs_nonergot_derivdopamine_receptor_agonist
        , case when ext_ahfs_thrptc_clss_cd = 28363200 then 1 else 0 end	as	is_ahfs_monoamine_oxidase_b_inhibitors
        , case when ext_ahfs_thrptc_clss_cd = 28400000 then 1 else 0 end	as	is_ahfs_fibromyalgia_agents
        , case when ext_ahfs_thrptc_clss_cd = 28560000 then 1 else 0 end	as	is_ahfs_vesicular_monoamine_transport2_inhibitor
        , case when ext_ahfs_thrptc_clss_cd = 28920000 then 1 else 0 end	as	is_ahfs_central_nervous_system_agents_misc
        , case when ext_ahfs_thrptc_clss_cd = 32000000 then 1 else 0 end	as	is_ahfs_contraceptives_eg_foams_devices
        , case when ext_ahfs_thrptc_clss_cd = 34000000 then 1 else 0 end	as	is_ahfs_dental_agents
        , case when ext_ahfs_thrptc_clss_cd = 36000000 then 1 else 0 end	as	is_ahfs_diagnostic_agents
        , case when ext_ahfs_thrptc_clss_cd = 36040000 then 1 else 0 end	as	is_ahfs_adrenocortical_insufficiency
        , case when ext_ahfs_thrptc_clss_cd = 36060000 then 1 else 0 end	as	is_ahfs_allergenic_extracts_diagnostic
        , case when ext_ahfs_thrptc_clss_cd = 36180000 then 1 else 0 end	as	is_ahfs_cardiac_function
        , case when ext_ahfs_thrptc_clss_cd = 36260000 then 1 else 0 end	as	is_ahfs_diabetes_mellitus
        , case when ext_ahfs_thrptc_clss_cd = 36300000 then 1 else 0 end	as	is_ahfs_drug_hypersensitivity
        , case when ext_ahfs_thrptc_clss_cd = 36320000 then 1 else 0 end	as	is_ahfs_fungi
        , case when ext_ahfs_thrptc_clss_cd = 36340000 then 1 else 0 end	as	is_ahfs_gallbladder_function
        , case when ext_ahfs_thrptc_clss_cd = 36360000 then 1 else 0 end	as	is_ahfs_gastric_function
        , case when ext_ahfs_thrptc_clss_cd = 36380000 then 1 else 0 end	as	is_ahfs_intestinal_absorption
        , case when ext_ahfs_thrptc_clss_cd = 36400000 then 1 else 0 end	as	is_ahfs_kidney_function
        , case when ext_ahfs_thrptc_clss_cd = 36440000 then 1 else 0 end	as	is_ahfs_liver_function
        , case when ext_ahfs_thrptc_clss_cd = 36460000 then 1 else 0 end	as	is_ahfs_lymphatic_system
        , case when ext_ahfs_thrptc_clss_cd = 36560000 then 1 else 0 end	as	is_ahfs_myasthenia_gravis
        , case when ext_ahfs_thrptc_clss_cd = 36580000 then 1 else 0 end	as	is_ahfs_ocular_disorders
        , case when ext_ahfs_thrptc_clss_cd = 36600000 then 1 else 0 end	as	is_ahfs_thyroid_function
        , case when ext_ahfs_thrptc_clss_cd = 36610000 then 1 else 0 end	as	is_ahfs_pancreatic_function
        , case when ext_ahfs_thrptc_clss_cd = 36640000 then 1 else 0 end	as	is_ahfs_pheochromocytoma
        , case when ext_ahfs_thrptc_clss_cd = 36660000 then 1 else 0 end	as	is_ahfs_pituitary_function
        , case when ext_ahfs_thrptc_clss_cd = 36680000 then 1 else 0 end	as	is_ahfs_roentgenography_and_other_imaging_agents
        , case when ext_ahfs_thrptc_clss_cd = 36700000 then 1 else 0 end	as	is_ahfs_respiratory_function
        , case when ext_ahfs_thrptc_clss_cd = 36840000 then 1 else 0 end	as	is_ahfs_tuberculosis
        , case when ext_ahfs_thrptc_clss_cd = 36880000 then 1 else 0 end	as	is_ahfs_urine_and_feces_contents
        , case when ext_ahfs_thrptc_clss_cd = 36881200 then 1 else 0 end	as	is_ahfs_ketones
        , case when ext_ahfs_thrptc_clss_cd = 36882000 then 1 else 0 end	as	is_ahfs_occult_blood
        , case when ext_ahfs_thrptc_clss_cd = 36882400 then 1 else 0 end	as	is_ahfs_ph
        , case when ext_ahfs_thrptc_clss_cd = 36882800 then 1 else 0 end	as	is_ahfs_protein
        , case when ext_ahfs_thrptc_clss_cd = 36884000 then 1 else 0 end	as	is_ahfs_sugar
        , case when ext_ahfs_thrptc_clss_cd = 38000000 then 1 else 0 end	as	is_ahfs_disinfectants_for_non_dermatologic_use
        , case when ext_ahfs_thrptc_clss_cd = 40040000 then 1 else 0 end	as	is_ahfs_acidifying_agents
        , case when ext_ahfs_thrptc_clss_cd = 40080000 then 1 else 0 end	as	is_ahfs_alkalinizing_agents
        , case when ext_ahfs_thrptc_clss_cd = 40100000 then 1 else 0 end	as	is_ahfs_ammonia_detoxicants
        , case when ext_ahfs_thrptc_clss_cd = 40120000 then 1 else 0 end	as	is_ahfs_replacement_preparations
        , case when ext_ahfs_thrptc_clss_cd = 40180000 then 1 else 0 end	as	is_ahfs_ion_removing_agents
        , case when ext_ahfs_thrptc_clss_cd = 40181800 then 1 else 0 end	as	is_ahfs_potassium_removing_agents
        , case when ext_ahfs_thrptc_clss_cd = 40181900 then 1 else 0 end	as	is_ahfs_phosphate_removing_agents
        , case when ext_ahfs_thrptc_clss_cd = 40189200 then 1 else 0 end	as	is_ahfs_other_ion_removing_agents
        , case when ext_ahfs_thrptc_clss_cd = 40200000 then 1 else 0 end	as	is_ahfs_caloric_agents
        , case when ext_ahfs_thrptc_clss_cd = 40240000 then 1 else 0 end	as	is_ahfs_salt_and_sugar_substitutes
        , case when ext_ahfs_thrptc_clss_cd = 40280800 then 1 else 0 end	as	is_ahfs_loop_diuretics
        , case when ext_ahfs_thrptc_clss_cd = 40281200 then 1 else 0 end	as	is_ahfs_osmotic_diuretics
        , case when ext_ahfs_thrptc_clss_cd = 40281600 then 1 else 0 end	as	is_ahfs_potassium_sparing_diuretics
        , case when ext_ahfs_thrptc_clss_cd = 40282000 then 1 else 0 end	as	is_ahfs_thiazide_diuretics
        , case when ext_ahfs_thrptc_clss_cd = 40282400 then 1 else 0 end	as	is_ahfs_thiazide_like_diuretics
        , case when ext_ahfs_thrptc_clss_cd = 40282800 then 1 else 0 end	as	is_ahfs_vasopressin_antagonists
        , case when ext_ahfs_thrptc_clss_cd = 40289200 then 1 else 0 end	as	is_ahfs_diuretics_miscellaneous
        , case when ext_ahfs_thrptc_clss_cd = 40360000 then 1 else 0 end	as	is_ahfs_irrigating_solutions
        , case when ext_ahfs_thrptc_clss_cd = 40400000 then 1 else 0 end	as	is_ahfs_uricosuric_agents
        , case when ext_ahfs_thrptc_clss_cd = 40920000 then 1 else 0 end	as	is_ahfs_electrolytic_caloric_water_balance_misc
        , case when ext_ahfs_thrptc_clss_cd = 44000000 then 1 else 0 end	as	is_ahfs_enzymes
        , case when ext_ahfs_thrptc_clss_cd = 48020000 then 1 else 0 end	as	is_ahfs_antifibrotic_agents
        , case when ext_ahfs_thrptc_clss_cd = 48040400 then 1 else 0 end	as	is_ahfs_first_generation_antihistrespir_tract
        , case when ext_ahfs_thrptc_clss_cd = 48080000 then 1 else 0 end	as	is_ahfs_antitussives
        , case when ext_ahfs_thrptc_clss_cd = 48100808 then 1 else 0 end	as	is_ahfs_orally_inhaled_preparations_steroids
        , case when ext_ahfs_thrptc_clss_cd = 48102000 then 1 else 0 end	as	is_ahfs_interleukin_antagonists
        , case when ext_ahfs_thrptc_clss_cd = 48102400 then 1 else 0 end	as	is_ahfs_leukotriene_modifiers
        , case when ext_ahfs_thrptc_clss_cd = 48103200 then 1 else 0 end	as	is_ahfs_mast_cell_stabilizers
        , case when ext_ahfs_thrptc_clss_cd = 48140400 then 1 else 0 end	as	is_ahfs_cystic_fibrosis_cftr_correctors
        , case when ext_ahfs_thrptc_clss_cd = 48141200 then 1 else 0 end	as	is_ahfs_cystic_fibrosis_cftr_potentiators
        , case when ext_ahfs_thrptc_clss_cd = 48160000 then 1 else 0 end	as	is_ahfs_expectorants
        , case when ext_ahfs_thrptc_clss_cd = 48240000 then 1 else 0 end	as	is_ahfs_mucolytic_agents
        , case when ext_ahfs_thrptc_clss_cd = 48320000 then 1 else 0 end	as	is_ahfs_phosphodiesterase_type_4_inhibitors
        , case when ext_ahfs_thrptc_clss_cd = 48360000 then 1 else 0 end	as	is_ahfs_pulmonary_surfactants
        , case when ext_ahfs_thrptc_clss_cd = 48480000 then 1 else 0 end	as	is_ahfs_vasodilating_agents_respiratory_tract
        , case when ext_ahfs_thrptc_clss_cd = 48920000 then 1 else 0 end	as	is_ahfs_respiratory_tract_agents_miscellaneous
        , case when ext_ahfs_thrptc_clss_cd = 52020000 then 1 else 0 end	as	is_ahfs_antiallergic_agents
        , case when ext_ahfs_thrptc_clss_cd = 52040400 then 1 else 0 end	as	is_ahfs_antibacterials_eent
        , case when ext_ahfs_thrptc_clss_cd = 52041600 then 1 else 0 end	as	is_ahfs_antifungals_eent
        , case when ext_ahfs_thrptc_clss_cd = 52042000 then 1 else 0 end	as	is_ahfs_antivirals_eent
        , case when ext_ahfs_thrptc_clss_cd = 52049200 then 1 else 0 end	as	is_ahfs_eent_anti_infectives_miscellaneous
        , case when ext_ahfs_thrptc_clss_cd = 52080800 then 1 else 0 end	as	is_ahfs_corticosteroids_eent
        , case when ext_ahfs_thrptc_clss_cd = 52082000 then 1 else 0 end	as	is_ahfs_eent_nonsteroidal_anti_inflam_agents
        , case when ext_ahfs_thrptc_clss_cd = 52089200 then 1 else 0 end	as	is_ahfs_eent_anti_inflammatory_agents_misc
        , case when ext_ahfs_thrptc_clss_cd = 52120000 then 1 else 0 end	as	is_ahfs_contact_lens_solutions
        , case when ext_ahfs_thrptc_clss_cd = 52160000 then 1 else 0 end	as	is_ahfs_local_anesthetics_eent
        , case when ext_ahfs_thrptc_clss_cd = 52240000 then 1 else 0 end	as	is_ahfs_mydriatics
        , case when ext_ahfs_thrptc_clss_cd = 52280000 then 1 else 0 end	as	is_ahfs_mouthwashes_and_gargles
        , case when ext_ahfs_thrptc_clss_cd = 52320000 then 1 else 0 end	as	is_ahfs_vasoconstrictors
        , case when ext_ahfs_thrptc_clss_cd = 52400400 then 1 else 0 end	as	is_ahfs_alpha_adrenergic_agonists_eent
        , case when ext_ahfs_thrptc_clss_cd = 52400800 then 1 else 0 end	as	is_ahfs_beta_adrenergic_blocking_agents_eent
        , case when ext_ahfs_thrptc_clss_cd = 52401200 then 1 else 0 end	as	is_ahfs_carbonic_anhydrase_inhibitors_eent
        , case when ext_ahfs_thrptc_clss_cd = 52402000 then 1 else 0 end	as	is_ahfs_miotics
        , case when ext_ahfs_thrptc_clss_cd = 52402800 then 1 else 0 end	as	is_ahfs_prostaglandin_analogs
        , case when ext_ahfs_thrptc_clss_cd = 52403200 then 1 else 0 end	as	is_ahfs_rho_kinase_inhibitors
        , case when ext_ahfs_thrptc_clss_cd = 52409200 then 1 else 0 end	as	is_ahfs_antiglaucoma_agents_miscellaneous
        , case when ext_ahfs_thrptc_clss_cd = 52920000 then 1 else 0 end	as	is_ahfs_eent_drugs_miscellaneous
        , case when ext_ahfs_thrptc_clss_cd = 56040000 then 1 else 0 end	as	is_ahfs_antacids_and_adsorbents
        , case when ext_ahfs_thrptc_clss_cd = 56080000 then 1 else 0 end	as	is_ahfs_antidiarrhea_agents
        , case when ext_ahfs_thrptc_clss_cd = 56100000 then 1 else 0 end	as	is_ahfs_antiflatulents
        , case when ext_ahfs_thrptc_clss_cd = 56120000 then 1 else 0 end	as	is_ahfs_cathartics_and_laxatives
        , case when ext_ahfs_thrptc_clss_cd = 56140000 then 1 else 0 end	as	is_ahfs_cholelitholytic_agents
        , case when ext_ahfs_thrptc_clss_cd = 56160000 then 1 else 0 end	as	is_ahfs_digestants
        , case when ext_ahfs_thrptc_clss_cd = 56200000 then 1 else 0 end	as	is_ahfs_emetics
        , case when ext_ahfs_thrptc_clss_cd = 56220800 then 1 else 0 end	as	is_ahfs_antihistamines_gi_drugs
        , case when ext_ahfs_thrptc_clss_cd = 56222000 then 1 else 0 end	as	is_ahfs_5_ht3_receptor_antagonists
        , case when ext_ahfs_thrptc_clss_cd = 56223200 then 1 else 0 end	as	is_ahfs_neurokinin_1_receptor_antagonists
        , case when ext_ahfs_thrptc_clss_cd = 56229200 then 1 else 0 end	as	is_ahfs_antiemetics_miscellaneous
        , case when ext_ahfs_thrptc_clss_cd = 56240000 then 1 else 0 end	as	is_ahfs_lipotropic_agents
        , case when ext_ahfs_thrptc_clss_cd = 56281200 then 1 else 0 end	as	is_ahfs_histamine_h2_antagonists
        , case when ext_ahfs_thrptc_clss_cd = 56282800 then 1 else 0 end	as	is_ahfs_prostaglandins
        , case when ext_ahfs_thrptc_clss_cd = 56283200 then 1 else 0 end	as	is_ahfs_protectants
        , case when ext_ahfs_thrptc_clss_cd = 56283600 then 1 else 0 end	as	is_ahfs_proton_pump_inhibitors
        , case when ext_ahfs_thrptc_clss_cd = 56320000 then 1 else 0 end	as	is_ahfs_prokinetic_agents
        , case when ext_ahfs_thrptc_clss_cd = 56360000 then 1 else 0 end	as	is_ahfs_anti_inflammatory_agents_gi_drugs
        , case when ext_ahfs_thrptc_clss_cd = 56920000 then 1 else 0 end	as	is_ahfs_gi_drugs_miscellaneous
        , case when ext_ahfs_thrptc_clss_cd = 60000000 then 1 else 0 end	as	is_ahfs_gold_compounds
        , case when ext_ahfs_thrptc_clss_cd = 64000000 then 1 else 0 end	as	is_ahfs_heavy_metal_antagonists
        , case when ext_ahfs_thrptc_clss_cd = 68040000 then 1 else 0 end	as	is_ahfs_adrenals
        , case when ext_ahfs_thrptc_clss_cd = 68080000 then 1 else 0 end	as	is_ahfs_androgens
        , case when ext_ahfs_thrptc_clss_cd = 68120000 then 1 else 0 end	as	is_ahfs_contraceptives
        , case when ext_ahfs_thrptc_clss_cd = 68160400 then 1 else 0 end	as	is_ahfs_estrogens
        , case when ext_ahfs_thrptc_clss_cd = 68160800 then 1 else 0 end	as	is_ahfs_antiestrogens
        , case when ext_ahfs_thrptc_clss_cd = 68161200 then 1 else 0 end	as	is_ahfs_estrogen_agonist_antagonists
        , case when ext_ahfs_thrptc_clss_cd = 68180000 then 1 else 0 end	as	is_ahfs_gonadotropins_and_antigonadotropins
        , case when ext_ahfs_thrptc_clss_cd = 68180400 then 1 else 0 end	as	is_ahfs_antigonadtropins
        , case when ext_ahfs_thrptc_clss_cd = 68180800 then 1 else 0 end	as	is_ahfs_gonadotropins
        , case when ext_ahfs_thrptc_clss_cd = 68200200 then 1 else 0 end	as	is_ahfs_alpha_glucosidase_inhibitors
        , case when ext_ahfs_thrptc_clss_cd = 68200300 then 1 else 0 end	as	is_ahfs_amylinomimetics
        , case when ext_ahfs_thrptc_clss_cd = 68200400 then 1 else 0 end	as	is_ahfs_biguanides
        , case when ext_ahfs_thrptc_clss_cd = 68200500 then 1 else 0 end	as	is_ahfs_dipeptidyl_peptidase_4dpp_4_inhibitors
        , case when ext_ahfs_thrptc_clss_cd = 68200600 then 1 else 0 end	as	is_ahfs_incretin_mimetics
        , case when ext_ahfs_thrptc_clss_cd = 68200800 then 1 else 0 end	as	is_ahfs_insulins
        , case when ext_ahfs_thrptc_clss_cd = 68200804 then 1 else 0 end	as	is_ahfs_rapid_acting_insulins
        , case when ext_ahfs_thrptc_clss_cd = 68200808 then 1 else 0 end	as	is_ahfs_short_acting_insulins
        , case when ext_ahfs_thrptc_clss_cd = 68200812 then 1 else 0 end	as	is_ahfs_intermediate_acting_insulins
        , case when ext_ahfs_thrptc_clss_cd = 68200816 then 1 else 0 end	as	is_ahfs_long_acting_insulins
        , case when ext_ahfs_thrptc_clss_cd = 68201600 then 1 else 0 end	as	is_ahfs_meglitinides
        , case when ext_ahfs_thrptc_clss_cd = 68201800 then 1 else 0 end	as	is_ahfs_sodium_gluc_cotransport_2_sglt2_inhib
        , case when ext_ahfs_thrptc_clss_cd = 68202000 then 1 else 0 end	as	is_ahfs_sulfonylureas
        , case when ext_ahfs_thrptc_clss_cd = 68202800 then 1 else 0 end	as	is_ahfs_thiazolidinediones
        , case when ext_ahfs_thrptc_clss_cd = 68209200 then 1 else 0 end	as	is_ahfs_antidiabetic_agents_miscellaneous
        , case when ext_ahfs_thrptc_clss_cd = 68221200 then 1 else 0 end	as	is_ahfs_glycogenolytic_agents
        , case when ext_ahfs_thrptc_clss_cd = 68229200 then 1 else 0 end	as	is_ahfs_antihypoglycemic_agents_miscellaneous
        , case when ext_ahfs_thrptc_clss_cd = 68240000 then 1 else 0 end	as	is_ahfs_parathyroid_and_antiparathyroid_agents
        , case when ext_ahfs_thrptc_clss_cd = 68240400 then 1 else 0 end	as	is_ahfs_antiparathyroid_agents
        , case when ext_ahfs_thrptc_clss_cd = 68240800 then 1 else 0 end	as	is_ahfs_parathyroid_agents
        , case when ext_ahfs_thrptc_clss_cd = 68280000 then 1 else 0 end	as	is_ahfs_pituitary
        , case when ext_ahfs_thrptc_clss_cd = 68290400 then 1 else 0 end	as	is_ahfs_somatostatin_agonists
        , case when ext_ahfs_thrptc_clss_cd = 68300400 then 1 else 0 end	as	is_ahfs_somatotropin_agonists
        , case when ext_ahfs_thrptc_clss_cd = 68300800 then 1 else 0 end	as	is_ahfs_somatotropin_antagonists
        , case when ext_ahfs_thrptc_clss_cd = 68320000 then 1 else 0 end	as	is_ahfs_progestins
        , case when ext_ahfs_thrptc_clss_cd = 68360400 then 1 else 0 end	as	is_ahfs_thyroid_agents
        , case when ext_ahfs_thrptc_clss_cd = 68360800 then 1 else 0 end	as	is_ahfs_antithyroid_agents
        , case when ext_ahfs_thrptc_clss_cd = 68400000 then 1 else 0 end	as	is_ahfs_leptins
        , case when ext_ahfs_thrptc_clss_cd = 68440000 then 1 else 0 end	as	is_ahfs_renin_angiotensin_aldosterone_systraas
        , case when ext_ahfs_thrptc_clss_cd = 72000000 then 1 else 0 end	as	is_ahfs_local_anesthetics_parenteral
        , case when ext_ahfs_thrptc_clss_cd = 76000000 then 1 else 0 end	as	is_ahfs_oxytocics
        , case when ext_ahfs_thrptc_clss_cd = 78000000 then 1 else 0 end	as	is_ahfs_radioactive_agents
        , case when ext_ahfs_thrptc_clss_cd = 80020000 then 1 else 0 end	as	is_ahfs_allergenic_extracts_therapeutic
        , case when ext_ahfs_thrptc_clss_cd = 80040000 then 1 else 0 end	as	is_ahfs_antitoxins_and_immune_globulins
        , case when ext_ahfs_thrptc_clss_cd = 80080000 then 1 else 0 end	as	is_ahfs_toxoids
        , case when ext_ahfs_thrptc_clss_cd = 80120000 then 1 else 0 end	as	is_ahfs_vaccines
        , case when ext_ahfs_thrptc_clss_cd = 84040400 then 1 else 0 end	as	is_ahfs_antibacterials_skin_mucous_membrane
        , case when ext_ahfs_thrptc_clss_cd = 84040600 then 1 else 0 end	as	is_ahfs_antivirals_skin_and_mucous_membrane
        , case when ext_ahfs_thrptc_clss_cd = 84040800 then 1 else 0 end	as	is_ahfs_antifungals_skin_and_mucous_membrane
        , case when ext_ahfs_thrptc_clss_cd = 84040804 then 1 else 0 end	as	is_ahfs_allylamines_skin_and_mucous_membrane
        , case when ext_ahfs_thrptc_clss_cd = 84040808 then 1 else 0 end	as	is_ahfs_azoles_skin_and_mucous_membrane
        , case when ext_ahfs_thrptc_clss_cd = 84040812 then 1 else 0 end	as	is_ahfs_benzylamines_skin_and_mucous_membrane
        , case when ext_ahfs_thrptc_clss_cd = 84040820 then 1 else 0 end	as	is_ahfs_hydroxypyridones_skin_mucous_membrane
        , case when ext_ahfs_thrptc_clss_cd = 84040824 then 1 else 0 end	as	is_ahfs_oxaboroles
        , case when ext_ahfs_thrptc_clss_cd = 84040828 then 1 else 0 end	as	is_ahfs_polyenes_skin_and_mucous_membrane
        , case when ext_ahfs_thrptc_clss_cd = 84040840 then 1 else 0 end	as	is_ahfs_thiocarbamatesskin_and_mucous_membrane
        , case when ext_ahfs_thrptc_clss_cd = 84040892 then 1 else 0 end	as	is_ahfs_antifulgals_skin_mucous_membrane_misc
        , case when ext_ahfs_thrptc_clss_cd = 84041200 then 1 else 0 end	as	is_ahfs_scabicides_and_pediculicides
        , case when ext_ahfs_thrptc_clss_cd = 84049200 then 1 else 0 end	as	is_ahfs_local_anti_infectives_miscellaneous
        , case when ext_ahfs_thrptc_clss_cd = 84060000 then 1 else 0 end	as	is_ahfs_anti_inflammatory_agents_skin_mucous
        , case when ext_ahfs_thrptc_clss_cd = 84060800 then 1 else 0 end	as	is_ahfs_corticosteroids_skin_mucous_membrane
        , case when ext_ahfs_thrptc_clss_cd = 84062000 then 1 else 0 end	as	is_ahfs_nonsteroidal_anti_inflammatagentsskin
        , case when ext_ahfs_thrptc_clss_cd = 84069200 then 1 else 0 end	as	is_ahfs_anti_inflammatory_agents_misc_skin
        , case when ext_ahfs_thrptc_clss_cd = 84080000 then 1 else 0 end	as	is_ahfs_antipruritics_and_local_anesthetics
        , case when ext_ahfs_thrptc_clss_cd = 84120000 then 1 else 0 end	as	is_ahfs_astringents
        , case when ext_ahfs_thrptc_clss_cd = 84160000 then 1 else 0 end	as	is_ahfs_cell_stimulants_and_proliferants
        , case when ext_ahfs_thrptc_clss_cd = 84200000 then 1 else 0 end	as	is_ahfs_detergents
        , case when ext_ahfs_thrptc_clss_cd = 84240000 then 1 else 0 end	as	is_ahfs_emollients_demulcents_and_protectants
        , case when ext_ahfs_thrptc_clss_cd = 84240400 then 1 else 0 end	as	is_ahfs_basic_lotions_and_liniments
        , case when ext_ahfs_thrptc_clss_cd = 84240800 then 1 else 0 end	as	is_ahfs_basic_oils_and_other_solvents
        , case when ext_ahfs_thrptc_clss_cd = 84241200 then 1 else 0 end	as	is_ahfs_basic_ointments_and_protectants
        , case when ext_ahfs_thrptc_clss_cd = 84241600 then 1 else 0 end	as	is_ahfs_basic_powders_and_demulcents
        , case when ext_ahfs_thrptc_clss_cd = 84280000 then 1 else 0 end	as	is_ahfs_keratolytic_agents
        , case when ext_ahfs_thrptc_clss_cd = 84320000 then 1 else 0 end	as	is_ahfs_keratoplastic_agents
        , case when ext_ahfs_thrptc_clss_cd = 84500400 then 1 else 0 end	as	is_ahfs_depigmenting_agents
        , case when ext_ahfs_thrptc_clss_cd = 84500600 then 1 else 0 end	as	is_ahfs_pigmenting_agents
        , case when ext_ahfs_thrptc_clss_cd = 84800000 then 1 else 0 end	as	is_ahfs_sunscreen_agents
        , case when ext_ahfs_thrptc_clss_cd = 84920000 then 1 else 0 end	as	is_ahfs_skin_and_mucous_membrane_agents_misc
        , case when ext_ahfs_thrptc_clss_cd = 86120000 then 1 else 0 end	as	is_ahfs_genitourinary_smooth_muscle_relaxants
        , case when ext_ahfs_thrptc_clss_cd = 86120400 then 1 else 0 end	as	is_ahfs_antimuscarinics
        , case when ext_ahfs_thrptc_clss_cd = 86120812 then 1 else 0 end	as	is_ahfs_selective_beta_3_adrenergic_agonists
        , case when ext_ahfs_thrptc_clss_cd = 86160000 then 1 else 0 end	as	is_ahfs_respiratory_smooth_muscle_relaxants
        , case when ext_ahfs_thrptc_clss_cd = 88040000 then 1 else 0 end	as	is_ahfs_vitamin_a
        , case when ext_ahfs_thrptc_clss_cd = 88080000 then 1 else 0 end	as	is_ahfs_vitamin_b_complex
        , case when ext_ahfs_thrptc_clss_cd = 88120000 then 1 else 0 end	as	is_ahfs_vitamin_c
        , case when ext_ahfs_thrptc_clss_cd = 88160000 then 1 else 0 end	as	is_ahfs_vitamin_d
        , case when ext_ahfs_thrptc_clss_cd = 88200000 then 1 else 0 end	as	is_ahfs_vitamin_e
        , case when ext_ahfs_thrptc_clss_cd = 88240000 then 1 else 0 end	as	is_ahfs_vitamin_k_activity
        , case when ext_ahfs_thrptc_clss_cd = 88280000 then 1 else 0 end	as	is_ahfs_multivitamin_preparations
        , case when ext_ahfs_thrptc_clss_cd = 92000000 then 1 else 0 end	as	is_ahfs_miscellaneous_therapeutic_agents
        , case when ext_ahfs_thrptc_clss_cd = 92040000 then 1 else 0 end	as	is_ahfs_alcohol_deterrents
        , case when ext_ahfs_thrptc_clss_cd = 92080000 then 1 else 0 end	as	is_ahfs_5_alpha_reductase_inhibitors
        , case when ext_ahfs_thrptc_clss_cd = 92120000 then 1 else 0 end	as	is_ahfs_antidotes
        , case when ext_ahfs_thrptc_clss_cd = 92160000 then 1 else 0 end	as	is_ahfs_antigout_agents
        , case when ext_ahfs_thrptc_clss_cd = 92180000 then 1 else 0 end	as	is_ahfs_antisense_oligonucleotides
        , case when ext_ahfs_thrptc_clss_cd = 92200000 then 1 else 0 end	as	is_ahfs_immunomodulatory_agents
        , case when ext_ahfs_thrptc_clss_cd = 92220000 then 1 else 0 end	as	is_ahfs_bone_anabolic_agents
        , case when ext_ahfs_thrptc_clss_cd = 92240000 then 1 else 0 end	as	is_ahfs_bone_resorption_inhibitors
        , case when ext_ahfs_thrptc_clss_cd = 92260000 then 1 else 0 end	as	is_ahfs_carbonic_anhydrase_inhibitors_misc
        , case when ext_ahfs_thrptc_clss_cd = 92280000 then 1 else 0 end	as	is_ahfs_cariostatic_agents
        , case when ext_ahfs_thrptc_clss_cd = 92320000 then 1 else 0 end	as	is_ahfs_complement_inhibitors
        , case when ext_ahfs_thrptc_clss_cd = 92360000 then 1 else 0 end	as	is_ahfs_disease_modifying_antirheumatic_agents
        , case when ext_ahfs_thrptc_clss_cd = 92400000 then 1 else 0 end	as	is_ahfs_gonadotropin_releasing_hormone_antagnts
        , case when ext_ahfs_thrptc_clss_cd = 92440000 then 1 else 0 end	as	is_ahfs_immunosuppressive_agents
        , case when ext_ahfs_thrptc_clss_cd = 92560000 then 1 else 0 end	as	is_ahfs_protective_agents
        , case when ext_ahfs_thrptc_clss_cd = 92920000 then 1 else 0 end	as	is_ahfs_other_miscellaneous_therapeutic_agents
        , case when ext_ahfs_thrptc_clss_cd = 94000000 then 1 else 0 end	as	is_ahfs_devices
        , case when ext_ahfs_thrptc_clss_cd = 96000000 then 1 else 0 end	as	is_ahfs_pharmaceutical_aids

      from

  --     create or replace table `research-01-217611.df_sandbox.wkg_udd_pharmacy_claim_ugap`  as select * from `research-01-217611.df_sandbox.udd_pharmacy_claim_ugap`   order by rand() limit 10000   clm
                                                                                 clm
          join `research-01-217611.df_ucd_stage.dim_date`		                     dt	  on clm.fill_dt = dt.full_dt
          join `research-01-217611.df_ucd_stage.dim_date`		                     sdt	on clm.sbmt_full_dt = sdt.full_dt
          --left join `research-01-217611.df_enrichment.medispan_drug`             mp   on clm.ndc = mp.product_id    --needed fields are incoporated to dim_ndc_drug already
          --                                                                            and mp.current_flag='y'

          left join `research-01-217611.df_ucd_stage.wkg_member_detail_member_month_src_type`   AS mbr ON clm.savvy_pid = mbr.savvy_pid AND
                                                                                                       clm.src_type = mbr.src_type AND
                                                                                                       dt.year_mo = mbr.year_mo
  ;

  insert into `research-01-217611.df_ucd_stage.ucd_pharmacy_claim_ihr_enriched`
    (uuid, pharmacy_claim_uuid, savvy_pid, savvy_did, is_restricted, drg_strgth_unit_desc, drg_strgth_nbr, brnd_nm, gnrc_nm, ndc, dosage_fm_desc, ext_ahfs_thrptc_clss_cd, ext_ahfs_thrptc_clss_desc, genericindicator, maint_drug_ind, gpi, drug_group_name, drug_class_name, drug_subclass_name, drug_basic_name, drug_extended_name, drug_dosage_form_id, sbmt_full_dt, sbmt_year_mo, sbmt_year_nbr, usual_and_customary_cost, allw_amt, net_pd_amt, oop_amt, copay_amt, ded_amt, coins_amt, day_cnt, qty_cnt, scrpt_cnt, fill_dt, month_id, month_nbr, day_nbr, year_qtr, year_nbr, year_mo, pharmacy_name, pharmacy_claim_id, pharmacy_address, pharmacy_city, pharmacy_state, pharmacy_zip, prescription_number, prescriber_id, prescriber_first_name, prescriber_last_name, drug_manufacturer, label_name, otc_indicator, prior_authorization_number, rx_network_id, plan_drug_status, product_id, business_line, prov_id, prov_mpin, prov_fst_nm, prov_lst_nm, prov_tin, site_cd, prov_zip_cd, prov_typ_nm, spec_typ_nm, refill, src_type, script_end_date, allw_amt_rx, net_pd_amt_rx, source, claim_status, create_datetime, update_datetime, age, is_ahfs_unknown, is_ahfs_ethanolamine_derivatives, is_ahfs_ethylenediamine_derivatives, is_ahfs_phenothiazine_derivatives, is_ahfs_piperazine_derivatives, is_ahfs_propylamine_derivatives, is_ahfs_first_gen_antihist_derivatives_misc, is_ahfs_second_generation_antihistamines, is_ahfs_other_antihistamines, is_ahfs_anthelmintics, is_ahfs_aminoglycoside_antibiotics, is_ahfs_1st_generation_cephalosporin_antibiotics, is_ahfs_2nd_generation_cephalosporin_antibiotics, is_ahfs_3rd_generation_cephalosporin_antibiotics, is_ahfs_4th_generation_cephalosporin_antibiotics, is_ahfs_5th_generation_cephalosporin_antibiotics, is_ahfs_carbacephem_antibiotics, is_ahfs_carbapenem_antibiotics, is_ahfs_cephamycin_antibiotics, is_ahfs_monobactam_antibiotics, is_ahfs_chloramphenicol_antibiotics, is_ahfs_macrolide_antibiotics, is_ahfs_erythromycin_antibiotics, is_ahfs_ketolide_antibiotics, is_ahfs_other_macrolide_antibiotics, is_ahfs_natural_penicillin_antibiotics, is_ahfs_aminopenicillin_antibiotics, is_ahfs_penicillinase_resistant_penicillins, is_ahfs_extended_spectrum_penicillins, is_ahfs_quinolone_antibiotics, is_ahfs_sulfonamide_antibiotics_systemic, is_ahfs_tetracycline_antibiotics, is_ahfs_aminomethylcyclines, is_ahfs_fluorocyclines, is_ahfs_glycylcycline_antibiotics, is_ahfs_bacitracin_antibiotics, is_ahfs_cyclic_lipopeptide_antibiotics, is_ahfs_glycopeptide_antibiotics, is_ahfs_lincomycin_antibiotics, is_ahfs_oxazolidinone_antibiotics, is_ahfs_pleuromutilins, is_ahfs_polymyxin_antibiotics, is_ahfs_rifamycin_antibiotics, is_ahfs_streptogramin_antibiotics, is_ahfs_other_misc_antibacterial_agents, is_ahfs_allylamine_antifungals, is_ahfs_azole_antifungals, is_ahfs_echinocandin_antifungals, is_ahfs_polyene_antifungals, is_ahfs_pyrimidine_antifungals, is_ahfs_antifungals_miscellaneous, is_ahfs_antituberculosis_agents, is_ahfs_antimycobacterials_miscellaneous, is_ahfs_adamantane_antivirals, is_ahfs_hiv_entry_and_fusion_inhibitors, is_ahfs_hiv_protease_inhibitor_antiretrovirals, is_ahfs_hiv_integrase_inhibitor_antiretrovirals, is_ahfs_hiv_nonnucleoside_revtranscrip_inhib, is_ahfs_hiv_nucleoside_nucleotide_rt_inhibitors, is_ahfs_interferon_antivirals, is_ahfs_monoclonal_antibody_antivirals, is_ahfs_neuraminidase_inhibitor_antivirals, is_ahfs_nucleoside_and_nucleotide_antivirals, is_ahfs_hcv_polymerase_inhibitor_antivirals, is_ahfs_hcv_protease_inhibitor_antivirals, is_ahfs_hcv_replication_complex_inhibitors, is_ahfs_antivirals_miscellaneous, is_ahfs_amebicides, is_ahfs_antimalarials, is_ahfs_antiprotozoals_miscellaneous, is_ahfs_urinary_anti_infectives, is_ahfs_anti_infectives_systemic_misc, is_ahfs_antineoplastic_agents, is_ahfs_parasympathomimetic_cholinergic_agents, is_ahfs_antimuscarinics_antispasmodics, is_ahfs_sympathomimetic_adrenergic_agents, is_ahfs_alpha_adrenergic_agonists, is_ahfs_non_selective_beta_adrenergic_agonists, is_ahfs_selective_beta_1_adrenergic_agonists, is_ahfs_selective_beta_2_adrenergic_agonists, is_ahfs_alpha_and_beta_adrenergic_agonists, is_ahfs_sympatholytic_adrenergic_blocking_agents, is_ahfs_alpha_adrenergic_blocking_agentsympath, is_ahfs_non_selalpha_adrenergic_blocking_agents, is_ahfs_selective_alpha_1_adrenergic_blockagent, is_ahfs_selective_beta_adrenergic_blocking_agent, is_ahfs_centrally_acting_skeletal_muscle_relaxnt, is_ahfs_direct_acting_skeletal_muscle_relaxants, is_ahfs_gaba_derivative_skeletal_muscle_relaxant, is_ahfs_neuromuscular_blocking_agents, is_ahfs_skeletal_muscle_relaxants_miscellaneous, is_ahfs_autonomic_drugs_miscellaneous, is_ahfs_blood_derivatives, is_ahfs_iron_preparations, is_ahfs_liver_and_stomach_preparations, is_ahfs_anticoagulants, is_ahfs_coumarin_derivatives, is_ahfs_direct_thrombin_inhibitors, is_ahfs_direct_factor_xa_inhibitors, is_ahfs_heparins, is_ahfs_anticoagulants_miscellaneous, is_ahfs_platelet_reducing_agents, is_ahfs_platelet_aggregation_inhibitors, is_ahfs_thrombolytic_agents, is_ahfs_antithrombotic_agents_miscellaneous, is_ahfs_hematopoietic_agents, is_ahfs_hemorrheologic_agents, is_ahfs_antiheparin_agents, is_ahfs_hemostatics, is_ahfs_antihemorrhagic_agents_miscellaneous, is_ahfs_blood_form_coag_thrombosis_agents_misc, is_ahfs_antiarrhythmic_agents, is_ahfs_class_ia_antiarrhythmics, is_ahfs_class_ib_antiarrhythmics, is_ahfs_class_ic_antiarrhythmics, is_ahfs_class_iii_antiarrhythmics, is_ahfs_class_iv_antiarrhythmics, is_ahfs_cardiotonic_agents, is_ahfs_cardiac_drugs_miscellaneous, is_ahfs_bile_acid_sequestrants, is_ahfs_cholesterol_absorption_inhibitors, is_ahfs_fibric_acid_derivatives, is_ahfs_hmg_coa_reductase_inhibitors, is_ahfs_pcsk9_inhibitors, is_ahfs_antilipemic_agents_miscellaneous, is_ahfs_central_alpha_agonists, is_ahfs_direct_vasodilators, is_ahfs_peripheral_adrenergic_inhibitors, is_ahfs_hypotensive_agents_miscellaneous, is_ahfs_vasodilating_agents, is_ahfs_nitrates_and_nitrites, is_ahfs_phosphodiesterase_type_5_inhibitors, is_ahfs_vasodilating_agents_miscellaneous, is_ahfs_sclerosing_agents, is_ahfs_alpha_adrenergic_blocking_agents, is_ahfs_beta_adrenergic_blocking_agents, is_ahfs_dihydropyridines, is_ahfs_calcium_channel_blocking_agents_misc, is_ahfs_angiotensin_converting_enzyme_inhibitors, is_ahfs_angiotensin_ii_receptor_antagonists, is_ahfs_mineralocorticoid_aldosterone_antagnts, is_ahfs_renin_inhibitors, is_ahfs_cellular_therapy, is_ahfs_gene_therapy, is_ahfs_barbiturates_general_anesthetics, is_ahfs_inhalation_anesthetics, is_ahfs_general_anesthetics_miscellaneous, is_ahfs_cyclooxygenase_2_cox_2_inhibitors, is_ahfs_salicylates, is_ahfs_other_nonsteroidal_anti_inflam_agents, is_ahfs_opiate_agonists, is_ahfs_opiate_partial_agonists, is_ahfs_analgesics_and_antipyretics_misc, is_ahfs_opiate_antagonists, is_ahfs_barbiturates_anticonvulsants, is_ahfs_benzodiazepines_anticonvulsants, is_ahfs_hydantoins, is_ahfs_succinimides, is_ahfs_anticonvulsants_miscellaneous, is_ahfs_monoamine_oxidase_inhibitors, is_ahfs_selserotonin_norepi_reuptake_inhibitor, is_ahfs_selective_serotonin_reuptake_inhibitors, is_ahfs_serotonin_modulators, is_ahfs_tricyclics_other_norepi_ru_inhibitors, is_ahfs_antidepressants_miscellaneous, is_ahfs_atypical_antipsychotics, is_ahfs_butyrophenones, is_ahfs_phenothiazines, is_ahfs_thioxanthenes, is_ahfs_antipsychotics_miscellaneous, is_ahfs_amphetamines, is_ahfs_amphetamine_derivatives, is_ahfs_selective_serotonin_receptor_agonists, is_ahfs_anorexigenic_agents_miscellaneous, is_ahfs_respiratory_and_cns_stimulants, is_ahfs_wakefulness_promoting_agents, is_ahfs_anorexigenic_agents_and_stimulants_misc, is_ahfs_barbiturates_anxiolytic_sedative_hyp, is_ahfs_benzodiazepines_anxiolytic_sedativ_hyp, is_ahfs_anxiolytics_sedatives_and_hypnotics_misc, is_ahfs_antimanic_agents, is_ahfs_calcitonin_gene_related_peptide_antag, is_ahfs_selective_serotonin_agonists, is_ahfs_adamantanes_cns, is_ahfs_anticholinergic_agents_cns, is_ahfs_catechol_o_methyltransferasecomtinhib, is_ahfs_dopamine_precursors, is_ahfs_ergot_deriv_dopamine_receptor_agonists, is_ahfs_nonergot_derivdopamine_receptor_agonist, is_ahfs_monoamine_oxidase_b_inhibitors, is_ahfs_fibromyalgia_agents, is_ahfs_vesicular_monoamine_transport2_inhibitor, is_ahfs_central_nervous_system_agents_misc, is_ahfs_contraceptives_eg_foams_devices, is_ahfs_dental_agents, is_ahfs_diagnostic_agents, is_ahfs_adrenocortical_insufficiency, is_ahfs_allergenic_extracts_diagnostic, is_ahfs_cardiac_function, is_ahfs_diabetes_mellitus, is_ahfs_drug_hypersensitivity, is_ahfs_fungi, is_ahfs_gallbladder_function, is_ahfs_gastric_function, is_ahfs_intestinal_absorption, is_ahfs_kidney_function, is_ahfs_liver_function, is_ahfs_lymphatic_system, is_ahfs_myasthenia_gravis, is_ahfs_ocular_disorders, is_ahfs_thyroid_function, is_ahfs_pancreatic_function, is_ahfs_pheochromocytoma, is_ahfs_pituitary_function, is_ahfs_roentgenography_and_other_imaging_agents, is_ahfs_respiratory_function, is_ahfs_tuberculosis, is_ahfs_urine_and_feces_contents, is_ahfs_ketones, is_ahfs_occult_blood, is_ahfs_ph, is_ahfs_protein, is_ahfs_sugar, is_ahfs_disinfectants_for_non_dermatologic_use, is_ahfs_acidifying_agents, is_ahfs_alkalinizing_agents, is_ahfs_ammonia_detoxicants, is_ahfs_replacement_preparations, is_ahfs_ion_removing_agents, is_ahfs_potassium_removing_agents, is_ahfs_phosphate_removing_agents, is_ahfs_other_ion_removing_agents, is_ahfs_caloric_agents, is_ahfs_salt_and_sugar_substitutes, is_ahfs_loop_diuretics, is_ahfs_osmotic_diuretics, is_ahfs_potassium_sparing_diuretics, is_ahfs_thiazide_diuretics, is_ahfs_thiazide_like_diuretics, is_ahfs_vasopressin_antagonists, is_ahfs_diuretics_miscellaneous, is_ahfs_irrigating_solutions, is_ahfs_uricosuric_agents, is_ahfs_electrolytic_caloric_water_balance_misc, is_ahfs_enzymes, is_ahfs_antifibrotic_agents, is_ahfs_first_generation_antihistrespir_tract, is_ahfs_antitussives, is_ahfs_orally_inhaled_preparations_steroids, is_ahfs_interleukin_antagonists, is_ahfs_leukotriene_modifiers, is_ahfs_mast_cell_stabilizers, is_ahfs_cystic_fibrosis_cftr_correctors, is_ahfs_cystic_fibrosis_cftr_potentiators, is_ahfs_expectorants, is_ahfs_mucolytic_agents, is_ahfs_phosphodiesterase_type_4_inhibitors, is_ahfs_pulmonary_surfactants, is_ahfs_vasodilating_agents_respiratory_tract, is_ahfs_respiratory_tract_agents_miscellaneous, is_ahfs_antiallergic_agents, is_ahfs_antibacterials_eent, is_ahfs_antifungals_eent, is_ahfs_antivirals_eent, is_ahfs_eent_anti_infectives_miscellaneous, is_ahfs_corticosteroids_eent, is_ahfs_eent_nonsteroidal_anti_inflam_agents, is_ahfs_eent_anti_inflammatory_agents_misc, is_ahfs_contact_lens_solutions, is_ahfs_local_anesthetics_eent, is_ahfs_mydriatics, is_ahfs_mouthwashes_and_gargles, is_ahfs_vasoconstrictors, is_ahfs_alpha_adrenergic_agonists_eent, is_ahfs_beta_adrenergic_blocking_agents_eent, is_ahfs_carbonic_anhydrase_inhibitors_eent, is_ahfs_miotics, is_ahfs_prostaglandin_analogs, is_ahfs_rho_kinase_inhibitors, is_ahfs_antiglaucoma_agents_miscellaneous, is_ahfs_eent_drugs_miscellaneous, is_ahfs_antacids_and_adsorbents, is_ahfs_antidiarrhea_agents, is_ahfs_antiflatulents, is_ahfs_cathartics_and_laxatives, is_ahfs_cholelitholytic_agents, is_ahfs_digestants, is_ahfs_emetics, is_ahfs_antihistamines_gi_drugs, is_ahfs_5_ht3_receptor_antagonists, is_ahfs_neurokinin_1_receptor_antagonists, is_ahfs_antiemetics_miscellaneous, is_ahfs_lipotropic_agents, is_ahfs_histamine_h2_antagonists, is_ahfs_prostaglandins, is_ahfs_protectants, is_ahfs_proton_pump_inhibitors, is_ahfs_prokinetic_agents, is_ahfs_anti_inflammatory_agents_gi_drugs, is_ahfs_gi_drugs_miscellaneous, is_ahfs_gold_compounds, is_ahfs_heavy_metal_antagonists, is_ahfs_adrenals, is_ahfs_androgens, is_ahfs_contraceptives, is_ahfs_estrogens, is_ahfs_antiestrogens, is_ahfs_estrogen_agonist_antagonists, is_ahfs_gonadotropins_and_antigonadotropins, is_ahfs_antigonadtropins, is_ahfs_gonadotropins, is_ahfs_alpha_glucosidase_inhibitors, is_ahfs_amylinomimetics, is_ahfs_biguanides, is_ahfs_dipeptidyl_peptidase_4dpp_4_inhibitors, is_ahfs_incretin_mimetics, is_ahfs_insulins, is_ahfs_rapid_acting_insulins, is_ahfs_short_acting_insulins, is_ahfs_intermediate_acting_insulins, is_ahfs_long_acting_insulins, is_ahfs_meglitinides, is_ahfs_sodium_gluc_cotransport_2_sglt2_inhib, is_ahfs_sulfonylureas, is_ahfs_thiazolidinediones, is_ahfs_antidiabetic_agents_miscellaneous, is_ahfs_glycogenolytic_agents, is_ahfs_antihypoglycemic_agents_miscellaneous, is_ahfs_parathyroid_and_antiparathyroid_agents, is_ahfs_antiparathyroid_agents, is_ahfs_parathyroid_agents, is_ahfs_pituitary, is_ahfs_somatostatin_agonists, is_ahfs_somatotropin_agonists, is_ahfs_somatotropin_antagonists, is_ahfs_progestins, is_ahfs_thyroid_agents, is_ahfs_antithyroid_agents, is_ahfs_leptins, is_ahfs_renin_angiotensin_aldosterone_systraas, is_ahfs_local_anesthetics_parenteral, is_ahfs_oxytocics, is_ahfs_radioactive_agents, is_ahfs_allergenic_extracts_therapeutic, is_ahfs_antitoxins_and_immune_globulins, is_ahfs_toxoids, is_ahfs_vaccines, is_ahfs_antibacterials_skin_mucous_membrane, is_ahfs_antivirals_skin_and_mucous_membrane, is_ahfs_antifungals_skin_and_mucous_membrane, is_ahfs_allylamines_skin_and_mucous_membrane, is_ahfs_azoles_skin_and_mucous_membrane, is_ahfs_benzylamines_skin_and_mucous_membrane, is_ahfs_hydroxypyridones_skin_mucous_membrane, is_ahfs_oxaboroles, is_ahfs_polyenes_skin_and_mucous_membrane, is_ahfs_thiocarbamatesskin_and_mucous_membrane, is_ahfs_antifulgals_skin_mucous_membrane_misc, is_ahfs_scabicides_and_pediculicides, is_ahfs_local_anti_infectives_miscellaneous, is_ahfs_anti_inflammatory_agents_skin_mucous, is_ahfs_corticosteroids_skin_mucous_membrane, is_ahfs_nonsteroidal_anti_inflammatagentsskin, is_ahfs_anti_inflammatory_agents_misc_skin, is_ahfs_antipruritics_and_local_anesthetics, is_ahfs_astringents, is_ahfs_cell_stimulants_and_proliferants, is_ahfs_detergents, is_ahfs_emollients_demulcents_and_protectants, is_ahfs_basic_lotions_and_liniments, is_ahfs_basic_oils_and_other_solvents, is_ahfs_basic_ointments_and_protectants, is_ahfs_basic_powders_and_demulcents, is_ahfs_keratolytic_agents, is_ahfs_keratoplastic_agents, is_ahfs_depigmenting_agents, is_ahfs_pigmenting_agents, is_ahfs_sunscreen_agents, is_ahfs_skin_and_mucous_membrane_agents_misc, is_ahfs_genitourinary_smooth_muscle_relaxants, is_ahfs_antimuscarinics, is_ahfs_selective_beta_3_adrenergic_agonists, is_ahfs_respiratory_smooth_muscle_relaxants, is_ahfs_vitamin_a, is_ahfs_vitamin_b_complex, is_ahfs_vitamin_c, is_ahfs_vitamin_d, is_ahfs_vitamin_e, is_ahfs_vitamin_k_activity, is_ahfs_multivitamin_preparations, is_ahfs_miscellaneous_therapeutic_agents, is_ahfs_alcohol_deterrents, is_ahfs_5_alpha_reductase_inhibitors, is_ahfs_antidotes, is_ahfs_antigout_agents, is_ahfs_antisense_oligonucleotides, is_ahfs_immunomodulatory_agents, is_ahfs_bone_anabolic_agents, is_ahfs_bone_resorption_inhibitors, is_ahfs_carbonic_anhydrase_inhibitors_misc, is_ahfs_cariostatic_agents, is_ahfs_complement_inhibitors, is_ahfs_disease_modifying_antirheumatic_agents, is_ahfs_gonadotropin_releasing_hormone_antagnts, is_ahfs_immunosuppressive_agents, is_ahfs_protective_agents, is_ahfs_other_miscellaneous_therapeutic_agents, is_ahfs_devices, is_ahfs_pharmaceutical_aids
    )
  with
    mbr as
      (--could be more than one record per member per year_mo, so let's get a single birth year to use for age computation
        select savvy_pid, savvy_did, max(is_restricted) as is_restricted, year_mo,
          max(birth_year) as birth_year
        from `research-01-217611.df_ucd_stage.udd_member_detail_udw`
        group by savvy_pid, savvy_did, year_mo
      )
    , clm as
      (--if the ndc exists in dim_ndc_drug use values from there instead of from the claim so that we use consistent descriptions, etc for scripts from different sources
      select
        clm.uuid
        ,	clm.savvy_pid
        , clm.savvy_did
        , clm.is_restricted
        ,	clm.fill_dt
        ,	clm.pharmacy_name
        ,	clm.pharmacy_claim_id
        ,	clm.pharmacy_address
        ,	clm.pharmacy_city
        ,	clm.pharmacy_state
        ,	clm.pharmacy_zip
        ,	clm.prescription_number
        ,	clm.prescriber_id
        ,	clm.prescriber_first_name
        ,	clm.prescriber_last_name
        ,	ifnull(ndc.drug_manufacturer_name, clm.drug_manufacturer) as drug_manufacturer
        ,	ifnull(ndc.drug_label_name, clm.label_name) as label_name
        ,	clm.otc_indicator
        ,	clm.prior_authorization_number
        ,	clm.rx_network_id
        ,	clm.plan_drug_status
        ,	clm.product_id
        ,	clm.business_line
        ,	clm.prov_id
        ,	clm.prov_fst_nm
        ,	clm.prov_lst_nm
        ,	clm.prov_tin
        ,	clm.site_cd
        ,	clm.prov_mpin
        ,	clm.prov_zip_cd
        ,	clm.prov_typ_nm
        ,	COALESCE(prov.specialty_1_longdesc, clm.spec_typ_nm) AS spec_typ_nm
        ,	clm.refill
        ,	ifnull(ndc.drg_strgth_unit_desc, clm.drg_strgth_unit_desc) as drg_strgth_unit_desc
        ,	ifnull(ndc.drg_strgth_nbr, clm.drg_strgth_nbr) as drg_strgth_nbr
        ,	ifnull(ndc.brnd_nm, clm.brnd_nm) as brnd_nm
        ,	ifnull(ndc.gnrc_nm, clm.gnrc_nm) as gnrc_nm
        , clm.ndc
        ,	ifnull(ndc.dosage_fm_desc, clm.dosage_fm_desc) as dosage_fm_desc
        ,	ifnull(safe_cast(ndc.ext_ahfs_thrptc_class_cd as int64), clm.ext_ahfs_thrptc_clss_cd) as ext_ahfs_thrptc_clss_cd
        , ifnull(ndc.ext_ahfs_thrptc_class_desc, clm.ext_ahfs_thrptc_clss_desc) as ext_ahfs_thrptc_clss_desc
        ,	ifnull(ndc.gnrc_ind, clm.genericindicator) as genericindicator
        ,	clm.maint_drug_ind
        ,	(case when current_flag = 'y' then ndc.gpi_number else clm.gpi end) as gpi
        , ndc.drug_group_name
        , ndc.drug_class_name
        , ndc.drug_subclass_name
        , ndc.drug_basic_name
        , ndc.drug_extended_name
        , ndc.drug_dosage_form_id
        ,	clm.sbmt_full_dt
        ,	clm.qty_cnt
        ,	clm.scrpt_cnt
        ,	clm.day_cnt
        ,	clm.usual_and_customary_cost
        ,	clm.allw_amt
        ,	clm.net_pd_amt
        ,	clm.oop_amt
        ,	clm.copay_amt
        ,	clm.ded_amt
        ,	clm.coins_amt
        ,	clm.src_type
        ,	clm.source
        ,	clm.claim_status
        , clm.create_datetime
        , clm.update_datetime
      from `research-01-217611.df_ucd_stage.udd_pharmacy_claim_ihr`               clm
          left join `research-01-217611.df_ucd_stage.wkg_dim_ndc_drug_in_use`     ndc  on clm.ndc = ndc.ndc
          left join `research-01-217611.df_ucd_stage.dim_provider`                prov ON clm.prov_mpin = prov.mpin
      )
  select
        GENERATE_UUID() uuid
        , clm.uuid pharmacy_claim_uuid
        , clm.savvy_pid
        , clm.savvy_did
        , ifnull(mbr.is_restricted, clm.is_restricted)
        , drg_strgth_unit_desc
        , drg_strgth_nbr
        , brnd_nm
        , gnrc_nm
        , ndc
        , dosage_fm_desc
        , ext_ahfs_thrptc_clss_cd
        , ext_ahfs_thrptc_clss_desc
        , clm.genericindicator
        , clm.maint_drug_ind
        , clm.gpi
        , clm.drug_group_name
        , clm.drug_class_name
        , clm.drug_subclass_name
        , clm.drug_basic_name
        , clm.drug_extended_name
        , clm.drug_dosage_form_id
        , clm.sbmt_full_dt
        , sdt.year_mo as sbmt_year_mo
        , sdt.year_nbr as sbmt_year_nbr
        , clm.usual_and_customary_cost
        , allw_amt
        , net_pd_amt
        , oop_amt
        , copay_amt
        , ded_amt
        , clm.coins_amt
        , day_cnt
        , qty_cnt
        , scrpt_cnt
        , fill_dt
        , dt.month_id
        , dt.month_nbr
        , dt.day_nbr
        , dt.year_qtr
        , dt.year_nbr
        , dt.year_mo
        , clm.pharmacy_name
        , clm.pharmacy_claim_id
        , clm.pharmacy_address
        , clm.pharmacy_city
        , clm.pharmacy_state
        , clm.pharmacy_zip
        , clm.prescription_number
        , clm.prescriber_id
        , clm.prescriber_first_name
        , clm.prescriber_last_name
        , clm.drug_manufacturer
        , clm.label_name
        , clm.otc_indicator
        , clm.prior_authorization_number
        , clm.rx_network_id
        , clm.plan_drug_status
        , clm.product_id
        , clm.business_line
        , clm.prov_id
        , prov_mpin
        , prov_fst_nm
        , prov_lst_nm
        , clm.prov_tin
        , clm.site_cd
        , prov_zip_cd
        , prov_typ_nm
        , spec_typ_nm
        , clm.refill
        , clm.src_type
        , date_add(clm.fill_dt, interval greatest(0, day_cnt - 1) DAY) script_end_date
        , clm.allw_amt allw_amt_rx
        , clm.net_pd_amt  net_pd_amt_rx
        , clm.source
        , clm.claim_status
        , clm.create_datetime
        , clm.update_datetime
        , greatest(0, `research-01-217611.df_enrichment.FN_AGE`(clm.fill_dt, concat(mbr.birth_year, '-07-01'))) AS age --assume July 1 dob
        , case when ext_ahfs_thrptc_clss_cd is null then 1 else 0 end 	as	is_ahfs_unknown
        , case when ext_ahfs_thrptc_clss_cd = 4040400 then 1 else 0 end	as	is_ahfs_ethanolamine_derivatives
        , case when ext_ahfs_thrptc_clss_cd = 4040800 then 1 else 0 end	as	is_ahfs_ethylenediamine_derivatives
        , case when ext_ahfs_thrptc_clss_cd = 4041200 then 1 else 0 end	as	is_ahfs_phenothiazine_derivatives
        , case when ext_ahfs_thrptc_clss_cd = 4041600 then 1 else 0 end	as	is_ahfs_piperazine_derivatives
        , case when ext_ahfs_thrptc_clss_cd = 4042000 then 1 else 0 end	as	is_ahfs_propylamine_derivatives
        , case when ext_ahfs_thrptc_clss_cd = 4049200 then 1 else 0 end	as	is_ahfs_first_gen_antihist_derivatives_misc
        , case when ext_ahfs_thrptc_clss_cd = 4080000 then 1 else 0 end	as	is_ahfs_second_generation_antihistamines
        , case when ext_ahfs_thrptc_clss_cd = 4920000 then 1 else 0 end	as	is_ahfs_other_antihistamines
        , case when ext_ahfs_thrptc_clss_cd = 8080000 then 1 else 0 end	as	is_ahfs_anthelmintics
        , case when ext_ahfs_thrptc_clss_cd = 8120200 then 1 else 0 end	as	is_ahfs_aminoglycoside_antibiotics
        , case when ext_ahfs_thrptc_clss_cd = 8120604 then 1 else 0 end	as	is_ahfs_1st_generation_cephalosporin_antibiotics
        , case when ext_ahfs_thrptc_clss_cd = 8120608 then 1 else 0 end	as	is_ahfs_2nd_generation_cephalosporin_antibiotics
        , case when ext_ahfs_thrptc_clss_cd = 8120612 then 1 else 0 end	as	is_ahfs_3rd_generation_cephalosporin_antibiotics
        , case when ext_ahfs_thrptc_clss_cd = 8120616 then 1 else 0 end	as	is_ahfs_4th_generation_cephalosporin_antibiotics
        , case when ext_ahfs_thrptc_clss_cd = 8120620 then 1 else 0 end	as	is_ahfs_5th_generation_cephalosporin_antibiotics
        , case when ext_ahfs_thrptc_clss_cd = 8120704 then 1 else 0 end	as	is_ahfs_carbacephem_antibiotics
        , case when ext_ahfs_thrptc_clss_cd = 8120708 then 1 else 0 end	as	is_ahfs_carbapenem_antibiotics
        , case when ext_ahfs_thrptc_clss_cd = 8120712 then 1 else 0 end	as	is_ahfs_cephamycin_antibiotics
        , case when ext_ahfs_thrptc_clss_cd = 8120716 then 1 else 0 end	as	is_ahfs_monobactam_antibiotics
        , case when ext_ahfs_thrptc_clss_cd = 8120800 then 1 else 0 end	as	is_ahfs_chloramphenicol_antibiotics
        , case when ext_ahfs_thrptc_clss_cd = 8121200 then 1 else 0 end	as	is_ahfs_macrolide_antibiotics
        , case when ext_ahfs_thrptc_clss_cd = 8121204 then 1 else 0 end	as	is_ahfs_erythromycin_antibiotics
        , case when ext_ahfs_thrptc_clss_cd = 8121212 then 1 else 0 end	as	is_ahfs_ketolide_antibiotics
        , case when ext_ahfs_thrptc_clss_cd = 8121292 then 1 else 0 end	as	is_ahfs_other_macrolide_antibiotics
        , case when ext_ahfs_thrptc_clss_cd = 8121604 then 1 else 0 end	as	is_ahfs_natural_penicillin_antibiotics
        , case when ext_ahfs_thrptc_clss_cd = 8121608 then 1 else 0 end	as	is_ahfs_aminopenicillin_antibiotics
        , case when ext_ahfs_thrptc_clss_cd = 8121612 then 1 else 0 end	as	is_ahfs_penicillinase_resistant_penicillins
        , case when ext_ahfs_thrptc_clss_cd = 8121616 then 1 else 0 end	as	is_ahfs_extended_spectrum_penicillins
        , case when ext_ahfs_thrptc_clss_cd = 8121800 then 1 else 0 end	as	is_ahfs_quinolone_antibiotics
        , case when ext_ahfs_thrptc_clss_cd = 8122000 then 1 else 0 end	as	is_ahfs_sulfonamide_antibiotics_systemic
        , case when ext_ahfs_thrptc_clss_cd = 8122400 then 1 else 0 end	as	is_ahfs_tetracycline_antibiotics
        , case when ext_ahfs_thrptc_clss_cd = 8122404 then 1 else 0 end	as	is_ahfs_aminomethylcyclines
        , case when ext_ahfs_thrptc_clss_cd = 8122408 then 1 else 0 end	as	is_ahfs_fluorocyclines
        , case when ext_ahfs_thrptc_clss_cd = 8122412 then 1 else 0 end	as	is_ahfs_glycylcycline_antibiotics
        , case when ext_ahfs_thrptc_clss_cd = 8122808 then 1 else 0 end	as	is_ahfs_bacitracin_antibiotics
        , case when ext_ahfs_thrptc_clss_cd = 8122812 then 1 else 0 end	as	is_ahfs_cyclic_lipopeptide_antibiotics
        , case when ext_ahfs_thrptc_clss_cd = 8122816 then 1 else 0 end	as	is_ahfs_glycopeptide_antibiotics
        , case when ext_ahfs_thrptc_clss_cd = 8122820 then 1 else 0 end	as	is_ahfs_lincomycin_antibiotics
        , case when ext_ahfs_thrptc_clss_cd = 8122824 then 1 else 0 end	as	is_ahfs_oxazolidinone_antibiotics
        , case when ext_ahfs_thrptc_clss_cd = 8122826 then 1 else 0 end	as	is_ahfs_pleuromutilins
        , case when ext_ahfs_thrptc_clss_cd = 8122828 then 1 else 0 end	as	is_ahfs_polymyxin_antibiotics
        , case when ext_ahfs_thrptc_clss_cd = 8122830 then 1 else 0 end	as	is_ahfs_rifamycin_antibiotics
        , case when ext_ahfs_thrptc_clss_cd = 8122832 then 1 else 0 end	as	is_ahfs_streptogramin_antibiotics
        , case when ext_ahfs_thrptc_clss_cd = 8122892 then 1 else 0 end	as	is_ahfs_other_misc_antibacterial_agents
        , case when ext_ahfs_thrptc_clss_cd = 8140400 then 1 else 0 end	as	is_ahfs_allylamine_antifungals
        , case when ext_ahfs_thrptc_clss_cd = 8140800 then 1 else 0 end	as	is_ahfs_azole_antifungals
        , case when ext_ahfs_thrptc_clss_cd = 8141600 then 1 else 0 end	as	is_ahfs_echinocandin_antifungals
        , case when ext_ahfs_thrptc_clss_cd = 8142800 then 1 else 0 end	as	is_ahfs_polyene_antifungals
        , case when ext_ahfs_thrptc_clss_cd = 8143200 then 1 else 0 end	as	is_ahfs_pyrimidine_antifungals
        , case when ext_ahfs_thrptc_clss_cd = 8149200 then 1 else 0 end	as	is_ahfs_antifungals_miscellaneous
        , case when ext_ahfs_thrptc_clss_cd = 8160400 then 1 else 0 end	as	is_ahfs_antituberculosis_agents
        , case when ext_ahfs_thrptc_clss_cd = 8169200 then 1 else 0 end	as	is_ahfs_antimycobacterials_miscellaneous
        , case when ext_ahfs_thrptc_clss_cd = 8180400 then 1 else 0 end	as	is_ahfs_adamantane_antivirals
        , case when ext_ahfs_thrptc_clss_cd = 8180804 then 1 else 0 end	as	is_ahfs_hiv_entry_and_fusion_inhibitors
        , case when ext_ahfs_thrptc_clss_cd = 8180808 then 1 else 0 end	as	is_ahfs_hiv_protease_inhibitor_antiretrovirals
        , case when ext_ahfs_thrptc_clss_cd = 8180812 then 1 else 0 end	as	is_ahfs_hiv_integrase_inhibitor_antiretrovirals
        , case when ext_ahfs_thrptc_clss_cd = 8180816 then 1 else 0 end	as	is_ahfs_hiv_nonnucleoside_revtranscrip_inhib
        , case when ext_ahfs_thrptc_clss_cd = 8180820 then 1 else 0 end	as	is_ahfs_hiv_nucleoside_nucleotide_rt_inhibitors
        , case when ext_ahfs_thrptc_clss_cd = 8182000 then 1 else 0 end	as	is_ahfs_interferon_antivirals
        , case when ext_ahfs_thrptc_clss_cd = 8182400 then 1 else 0 end	as	is_ahfs_monoclonal_antibody_antivirals
        , case when ext_ahfs_thrptc_clss_cd = 8182800 then 1 else 0 end	as	is_ahfs_neuraminidase_inhibitor_antivirals
        , case when ext_ahfs_thrptc_clss_cd = 8183200 then 1 else 0 end	as	is_ahfs_nucleoside_and_nucleotide_antivirals
        , case when ext_ahfs_thrptc_clss_cd = 8184016 then 1 else 0 end	as	is_ahfs_hcv_polymerase_inhibitor_antivirals
        , case when ext_ahfs_thrptc_clss_cd = 8184020 then 1 else 0 end	as	is_ahfs_hcv_protease_inhibitor_antivirals
        , case when ext_ahfs_thrptc_clss_cd = 8184024 then 1 else 0 end	as	is_ahfs_hcv_replication_complex_inhibitors
        , case when ext_ahfs_thrptc_clss_cd = 8189200 then 1 else 0 end	as	is_ahfs_antivirals_miscellaneous
        , case when ext_ahfs_thrptc_clss_cd = 8300400 then 1 else 0 end	as	is_ahfs_amebicides
        , case when ext_ahfs_thrptc_clss_cd = 8300800 then 1 else 0 end	as	is_ahfs_antimalarials
        , case when ext_ahfs_thrptc_clss_cd = 8309200 then 1 else 0 end	as	is_ahfs_antiprotozoals_miscellaneous
        , case when ext_ahfs_thrptc_clss_cd = 8360000 then 1 else 0 end	as	is_ahfs_urinary_anti_infectives
        , case when ext_ahfs_thrptc_clss_cd = 8920000 then 1 else 0 end	as	is_ahfs_anti_infectives_systemic_misc
        , case when ext_ahfs_thrptc_clss_cd = 10000000 then 1 else 0 end	as	is_ahfs_antineoplastic_agents
        , case when ext_ahfs_thrptc_clss_cd = 12040000 then 1 else 0 end	as	is_ahfs_parasympathomimetic_cholinergic_agents
        , case when ext_ahfs_thrptc_clss_cd = 12080800 then 1 else 0 end	as	is_ahfs_antimuscarinics_antispasmodics
        , case when ext_ahfs_thrptc_clss_cd = 12120000 then 1 else 0 end	as	is_ahfs_sympathomimetic_adrenergic_agents
        , case when ext_ahfs_thrptc_clss_cd = 12120400 then 1 else 0 end	as	is_ahfs_alpha_adrenergic_agonists
        , case when ext_ahfs_thrptc_clss_cd = 12120804 then 1 else 0 end	as	is_ahfs_non_selective_beta_adrenergic_agonists
        , case when ext_ahfs_thrptc_clss_cd = 12120808 then 1 else 0 end	as	is_ahfs_selective_beta_1_adrenergic_agonists
        , case when ext_ahfs_thrptc_clss_cd = 12120812 then 1 else 0 end	as	is_ahfs_selective_beta_2_adrenergic_agonists
        , case when ext_ahfs_thrptc_clss_cd = 12121200 then 1 else 0 end	as	is_ahfs_alpha_and_beta_adrenergic_agonists
        , case when ext_ahfs_thrptc_clss_cd = 12160000 then 1 else 0 end	as	is_ahfs_sympatholytic_adrenergic_blocking_agents
        , case when ext_ahfs_thrptc_clss_cd = 12160400 then 1 else 0 end	as	is_ahfs_alpha_adrenergic_blocking_agentsympath
        , case when ext_ahfs_thrptc_clss_cd = 12160404 then 1 else 0 end	as	is_ahfs_non_selalpha_adrenergic_blocking_agents
        , case when ext_ahfs_thrptc_clss_cd = 12160412 then 1 else 0 end	as	is_ahfs_selective_alpha_1_adrenergic_blockagent
        , case when ext_ahfs_thrptc_clss_cd = 12160808 then 1 else 0 end	as	is_ahfs_selective_beta_adrenergic_blocking_agent
        , case when ext_ahfs_thrptc_clss_cd = 12200400 then 1 else 0 end	as	is_ahfs_centrally_acting_skeletal_muscle_relaxnt
        , case when ext_ahfs_thrptc_clss_cd = 12200800 then 1 else 0 end	as	is_ahfs_direct_acting_skeletal_muscle_relaxants
        , case when ext_ahfs_thrptc_clss_cd = 12201200 then 1 else 0 end	as	is_ahfs_gaba_derivative_skeletal_muscle_relaxant
        , case when ext_ahfs_thrptc_clss_cd = 12202000 then 1 else 0 end	as	is_ahfs_neuromuscular_blocking_agents
        , case when ext_ahfs_thrptc_clss_cd = 12209200 then 1 else 0 end	as	is_ahfs_skeletal_muscle_relaxants_miscellaneous
        , case when ext_ahfs_thrptc_clss_cd = 12920000 then 1 else 0 end	as	is_ahfs_autonomic_drugs_miscellaneous
        , case when ext_ahfs_thrptc_clss_cd = 16000000 then 1 else 0 end	as	is_ahfs_blood_derivatives
        , case when ext_ahfs_thrptc_clss_cd = 20040400 then 1 else 0 end	as	is_ahfs_iron_preparations
        , case when ext_ahfs_thrptc_clss_cd = 20040800 then 1 else 0 end	as	is_ahfs_liver_and_stomach_preparations
        , case when ext_ahfs_thrptc_clss_cd = 20120400 then 1 else 0 end	as	is_ahfs_anticoagulants
        , case when ext_ahfs_thrptc_clss_cd = 20120408 then 1 else 0 end	as	is_ahfs_coumarin_derivatives
        , case when ext_ahfs_thrptc_clss_cd = 20120412 then 1 else 0 end	as	is_ahfs_direct_thrombin_inhibitors
        , case when ext_ahfs_thrptc_clss_cd = 20120414 then 1 else 0 end	as	is_ahfs_direct_factor_xa_inhibitors
        , case when ext_ahfs_thrptc_clss_cd = 20120416 then 1 else 0 end	as	is_ahfs_heparins
        , case when ext_ahfs_thrptc_clss_cd = 20120492 then 1 else 0 end	as	is_ahfs_anticoagulants_miscellaneous
        , case when ext_ahfs_thrptc_clss_cd = 20121400 then 1 else 0 end	as	is_ahfs_platelet_reducing_agents
        , case when ext_ahfs_thrptc_clss_cd = 20121800 then 1 else 0 end	as	is_ahfs_platelet_aggregation_inhibitors
        , case when ext_ahfs_thrptc_clss_cd = 20122000 then 1 else 0 end	as	is_ahfs_thrombolytic_agents
        , case when ext_ahfs_thrptc_clss_cd = 20129200 then 1 else 0 end	as	is_ahfs_antithrombotic_agents_miscellaneous
        , case when ext_ahfs_thrptc_clss_cd = 20160000 then 1 else 0 end	as	is_ahfs_hematopoietic_agents
        , case when ext_ahfs_thrptc_clss_cd = 20240000 then 1 else 0 end	as	is_ahfs_hemorrheologic_agents
        , case when ext_ahfs_thrptc_clss_cd = 20280800 then 1 else 0 end	as	is_ahfs_antiheparin_agents
        , case when ext_ahfs_thrptc_clss_cd = 20281600 then 1 else 0 end	as	is_ahfs_hemostatics
        , case when ext_ahfs_thrptc_clss_cd = 20289200 then 1 else 0 end	as	is_ahfs_antihemorrhagic_agents_miscellaneous
        , case when ext_ahfs_thrptc_clss_cd = 20920000 then 1 else 0 end	as	is_ahfs_blood_form_coag_thrombosis_agents_misc
        , case when ext_ahfs_thrptc_clss_cd = 24040400 then 1 else 0 end	as	is_ahfs_antiarrhythmic_agents
        , case when ext_ahfs_thrptc_clss_cd = 24040404 then 1 else 0 end	as	is_ahfs_class_ia_antiarrhythmics
        , case when ext_ahfs_thrptc_clss_cd = 24040408 then 1 else 0 end	as	is_ahfs_class_ib_antiarrhythmics
        , case when ext_ahfs_thrptc_clss_cd = 24040412 then 1 else 0 end	as	is_ahfs_class_ic_antiarrhythmics
        , case when ext_ahfs_thrptc_clss_cd = 24040420 then 1 else 0 end	as	is_ahfs_class_iii_antiarrhythmics
        , case when ext_ahfs_thrptc_clss_cd = 24040424 then 1 else 0 end	as	is_ahfs_class_iv_antiarrhythmics
        , case when ext_ahfs_thrptc_clss_cd = 24040800 then 1 else 0 end	as	is_ahfs_cardiotonic_agents
        , case when ext_ahfs_thrptc_clss_cd = 24049200 then 1 else 0 end	as	is_ahfs_cardiac_drugs_miscellaneous
        , case when ext_ahfs_thrptc_clss_cd = 24060400 then 1 else 0 end	as	is_ahfs_bile_acid_sequestrants
        , case when ext_ahfs_thrptc_clss_cd = 24060500 then 1 else 0 end	as	is_ahfs_cholesterol_absorption_inhibitors
        , case when ext_ahfs_thrptc_clss_cd = 24060600 then 1 else 0 end	as	is_ahfs_fibric_acid_derivatives
        , case when ext_ahfs_thrptc_clss_cd = 24060800 then 1 else 0 end	as	is_ahfs_hmg_coa_reductase_inhibitors
        , case when ext_ahfs_thrptc_clss_cd = 24062400 then 1 else 0 end	as	is_ahfs_pcsk9_inhibitors
        , case when ext_ahfs_thrptc_clss_cd = 24069200 then 1 else 0 end	as	is_ahfs_antilipemic_agents_miscellaneous
        , case when ext_ahfs_thrptc_clss_cd = 24081600 then 1 else 0 end	as	is_ahfs_central_alpha_agonists
        , case when ext_ahfs_thrptc_clss_cd = 24082000 then 1 else 0 end	as	is_ahfs_direct_vasodilators
        , case when ext_ahfs_thrptc_clss_cd = 24083200 then 1 else 0 end	as	is_ahfs_peripheral_adrenergic_inhibitors
        , case when ext_ahfs_thrptc_clss_cd = 24089200 then 1 else 0 end	as	is_ahfs_hypotensive_agents_miscellaneous
        , case when ext_ahfs_thrptc_clss_cd = 24120000 then 1 else 0 end	as	is_ahfs_vasodilating_agents
        , case when ext_ahfs_thrptc_clss_cd = 24120800 then 1 else 0 end	as	is_ahfs_nitrates_and_nitrites
        , case when ext_ahfs_thrptc_clss_cd = 24121200 then 1 else 0 end	as	is_ahfs_phosphodiesterase_type_5_inhibitors
        , case when ext_ahfs_thrptc_clss_cd = 24129200 then 1 else 0 end	as	is_ahfs_vasodilating_agents_miscellaneous
        , case when ext_ahfs_thrptc_clss_cd = 24160000 then 1 else 0 end	as	is_ahfs_sclerosing_agents
        , case when ext_ahfs_thrptc_clss_cd = 24200000 then 1 else 0 end	as	is_ahfs_alpha_adrenergic_blocking_agents
        , case when ext_ahfs_thrptc_clss_cd = 24240000 then 1 else 0 end	as	is_ahfs_beta_adrenergic_blocking_agents
        , case when ext_ahfs_thrptc_clss_cd = 24280800 then 1 else 0 end	as	is_ahfs_dihydropyridines
        , case when ext_ahfs_thrptc_clss_cd = 24289200 then 1 else 0 end	as	is_ahfs_calcium_channel_blocking_agents_misc
        , case when ext_ahfs_thrptc_clss_cd = 24320400 then 1 else 0 end	as	is_ahfs_angiotensin_converting_enzyme_inhibitors
        , case when ext_ahfs_thrptc_clss_cd = 24320800 then 1 else 0 end	as	is_ahfs_angiotensin_ii_receptor_antagonists
        , case when ext_ahfs_thrptc_clss_cd = 24322000 then 1 else 0 end	as	is_ahfs_mineralocorticoid_aldosterone_antagnts
        , case when ext_ahfs_thrptc_clss_cd = 24324000 then 1 else 0 end	as	is_ahfs_renin_inhibitors
        , case when ext_ahfs_thrptc_clss_cd = 26040000 then 1 else 0 end	as	is_ahfs_cellular_therapy
        , case when ext_ahfs_thrptc_clss_cd = 26120000 then 1 else 0 end	as	is_ahfs_gene_therapy
        , case when ext_ahfs_thrptc_clss_cd = 28040400 then 1 else 0 end	as	is_ahfs_barbiturates_general_anesthetics
        , case when ext_ahfs_thrptc_clss_cd = 28041600 then 1 else 0 end	as	is_ahfs_inhalation_anesthetics
        , case when ext_ahfs_thrptc_clss_cd = 28049200 then 1 else 0 end	as	is_ahfs_general_anesthetics_miscellaneous
        , case when ext_ahfs_thrptc_clss_cd = 28080408 then 1 else 0 end	as	is_ahfs_cyclooxygenase_2_cox_2_inhibitors
        , case when ext_ahfs_thrptc_clss_cd = 28080424 then 1 else 0 end	as	is_ahfs_salicylates
        , case when ext_ahfs_thrptc_clss_cd = 28080492 then 1 else 0 end	as	is_ahfs_other_nonsteroidal_anti_inflam_agents
        , case when ext_ahfs_thrptc_clss_cd = 28080800 then 1 else 0 end	as	is_ahfs_opiate_agonists
        , case when ext_ahfs_thrptc_clss_cd = 28081200 then 1 else 0 end	as	is_ahfs_opiate_partial_agonists
        , case when ext_ahfs_thrptc_clss_cd = 28089200 then 1 else 0 end	as	is_ahfs_analgesics_and_antipyretics_misc
        , case when ext_ahfs_thrptc_clss_cd = 28100000 then 1 else 0 end	as	is_ahfs_opiate_antagonists
        , case when ext_ahfs_thrptc_clss_cd = 28120400 then 1 else 0 end	as	is_ahfs_barbiturates_anticonvulsants
        , case when ext_ahfs_thrptc_clss_cd = 28120800 then 1 else 0 end	as	is_ahfs_benzodiazepines_anticonvulsants
        , case when ext_ahfs_thrptc_clss_cd = 28121200 then 1 else 0 end	as	is_ahfs_hydantoins
        , case when ext_ahfs_thrptc_clss_cd = 28122000 then 1 else 0 end	as	is_ahfs_succinimides
        , case when ext_ahfs_thrptc_clss_cd = 28129200 then 1 else 0 end	as	is_ahfs_anticonvulsants_miscellaneous
        , case when ext_ahfs_thrptc_clss_cd = 28160412 then 1 else 0 end	as	is_ahfs_monoamine_oxidase_inhibitors
        , case when ext_ahfs_thrptc_clss_cd = 28160416 then 1 else 0 end	as	is_ahfs_selserotonin_norepi_reuptake_inhibitor
        , case when ext_ahfs_thrptc_clss_cd = 28160420 then 1 else 0 end	as	is_ahfs_selective_serotonin_reuptake_inhibitors
        , case when ext_ahfs_thrptc_clss_cd = 28160424 then 1 else 0 end	as	is_ahfs_serotonin_modulators
        , case when ext_ahfs_thrptc_clss_cd = 28160428 then 1 else 0 end	as	is_ahfs_tricyclics_other_norepi_ru_inhibitors
        , case when ext_ahfs_thrptc_clss_cd = 28160492 then 1 else 0 end	as	is_ahfs_antidepressants_miscellaneous
        , case when ext_ahfs_thrptc_clss_cd = 28160804 then 1 else 0 end	as	is_ahfs_atypical_antipsychotics
        , case when ext_ahfs_thrptc_clss_cd = 28160808 then 1 else 0 end	as	is_ahfs_butyrophenones
        , case when ext_ahfs_thrptc_clss_cd = 28160824 then 1 else 0 end	as	is_ahfs_phenothiazines
        , case when ext_ahfs_thrptc_clss_cd = 28160832 then 1 else 0 end	as	is_ahfs_thioxanthenes
        , case when ext_ahfs_thrptc_clss_cd = 28160892 then 1 else 0 end	as	is_ahfs_antipsychotics_miscellaneous
        , case when ext_ahfs_thrptc_clss_cd = 28200400 then 1 else 0 end	as	is_ahfs_amphetamines
        , case when ext_ahfs_thrptc_clss_cd = 28200804 then 1 else 0 end	as	is_ahfs_amphetamine_derivatives
        , case when ext_ahfs_thrptc_clss_cd = 28200832 then 1 else 0 end	as	is_ahfs_selective_serotonin_receptor_agonists
        , case when ext_ahfs_thrptc_clss_cd = 28200892 then 1 else 0 end	as	is_ahfs_anorexigenic_agents_miscellaneous
        , case when ext_ahfs_thrptc_clss_cd = 28203200 then 1 else 0 end	as	is_ahfs_respiratory_and_cns_stimulants
        , case when ext_ahfs_thrptc_clss_cd = 28208000 then 1 else 0 end	as	is_ahfs_wakefulness_promoting_agents
        , case when ext_ahfs_thrptc_clss_cd = 28209200 then 1 else 0 end	as	is_ahfs_anorexigenic_agents_and_stimulants_misc
        , case when ext_ahfs_thrptc_clss_cd = 28240400 then 1 else 0 end	as	is_ahfs_barbiturates_anxiolytic_sedative_hyp
        , case when ext_ahfs_thrptc_clss_cd = 28240800 then 1 else 0 end	as	is_ahfs_benzodiazepines_anxiolytic_sedativ_hyp
        , case when ext_ahfs_thrptc_clss_cd = 28249200 then 1 else 0 end	as	is_ahfs_anxiolytics_sedatives_and_hypnotics_misc
        , case when ext_ahfs_thrptc_clss_cd = 28280000 then 1 else 0 end	as	is_ahfs_antimanic_agents
        , case when ext_ahfs_thrptc_clss_cd = 28321200 then 1 else 0 end	as	is_ahfs_calcitonin_gene_related_peptide_antag
        , case when ext_ahfs_thrptc_clss_cd = 28322800 then 1 else 0 end	as	is_ahfs_selective_serotonin_agonists
        , case when ext_ahfs_thrptc_clss_cd = 28360400 then 1 else 0 end	as	is_ahfs_adamantanes_cns
        , case when ext_ahfs_thrptc_clss_cd = 28360800 then 1 else 0 end	as	is_ahfs_anticholinergic_agents_cns
        , case when ext_ahfs_thrptc_clss_cd = 28361200 then 1 else 0 end	as	is_ahfs_catechol_o_methyltransferasecomtinhib
        , case when ext_ahfs_thrptc_clss_cd = 28361600 then 1 else 0 end	as	is_ahfs_dopamine_precursors
        , case when ext_ahfs_thrptc_clss_cd = 28362004 then 1 else 0 end	as	is_ahfs_ergot_deriv_dopamine_receptor_agonists
        , case when ext_ahfs_thrptc_clss_cd = 28362008 then 1 else 0 end	as	is_ahfs_nonergot_derivdopamine_receptor_agonist
        , case when ext_ahfs_thrptc_clss_cd = 28363200 then 1 else 0 end	as	is_ahfs_monoamine_oxidase_b_inhibitors
        , case when ext_ahfs_thrptc_clss_cd = 28400000 then 1 else 0 end	as	is_ahfs_fibromyalgia_agents
        , case when ext_ahfs_thrptc_clss_cd = 28560000 then 1 else 0 end	as	is_ahfs_vesicular_monoamine_transport2_inhibitor
        , case when ext_ahfs_thrptc_clss_cd = 28920000 then 1 else 0 end	as	is_ahfs_central_nervous_system_agents_misc
        , case when ext_ahfs_thrptc_clss_cd = 32000000 then 1 else 0 end	as	is_ahfs_contraceptives_eg_foams_devices
        , case when ext_ahfs_thrptc_clss_cd = 34000000 then 1 else 0 end	as	is_ahfs_dental_agents
        , case when ext_ahfs_thrptc_clss_cd = 36000000 then 1 else 0 end	as	is_ahfs_diagnostic_agents
        , case when ext_ahfs_thrptc_clss_cd = 36040000 then 1 else 0 end	as	is_ahfs_adrenocortical_insufficiency
        , case when ext_ahfs_thrptc_clss_cd = 36060000 then 1 else 0 end	as	is_ahfs_allergenic_extracts_diagnostic
        , case when ext_ahfs_thrptc_clss_cd = 36180000 then 1 else 0 end	as	is_ahfs_cardiac_function
        , case when ext_ahfs_thrptc_clss_cd = 36260000 then 1 else 0 end	as	is_ahfs_diabetes_mellitus
        , case when ext_ahfs_thrptc_clss_cd = 36300000 then 1 else 0 end	as	is_ahfs_drug_hypersensitivity
        , case when ext_ahfs_thrptc_clss_cd = 36320000 then 1 else 0 end	as	is_ahfs_fungi
        , case when ext_ahfs_thrptc_clss_cd = 36340000 then 1 else 0 end	as	is_ahfs_gallbladder_function
        , case when ext_ahfs_thrptc_clss_cd = 36360000 then 1 else 0 end	as	is_ahfs_gastric_function
        , case when ext_ahfs_thrptc_clss_cd = 36380000 then 1 else 0 end	as	is_ahfs_intestinal_absorption
        , case when ext_ahfs_thrptc_clss_cd = 36400000 then 1 else 0 end	as	is_ahfs_kidney_function
        , case when ext_ahfs_thrptc_clss_cd = 36440000 then 1 else 0 end	as	is_ahfs_liver_function
        , case when ext_ahfs_thrptc_clss_cd = 36460000 then 1 else 0 end	as	is_ahfs_lymphatic_system
        , case when ext_ahfs_thrptc_clss_cd = 36560000 then 1 else 0 end	as	is_ahfs_myasthenia_gravis
        , case when ext_ahfs_thrptc_clss_cd = 36580000 then 1 else 0 end	as	is_ahfs_ocular_disorders
        , case when ext_ahfs_thrptc_clss_cd = 36600000 then 1 else 0 end	as	is_ahfs_thyroid_function
        , case when ext_ahfs_thrptc_clss_cd = 36610000 then 1 else 0 end	as	is_ahfs_pancreatic_function
        , case when ext_ahfs_thrptc_clss_cd = 36640000 then 1 else 0 end	as	is_ahfs_pheochromocytoma
        , case when ext_ahfs_thrptc_clss_cd = 36660000 then 1 else 0 end	as	is_ahfs_pituitary_function
        , case when ext_ahfs_thrptc_clss_cd = 36680000 then 1 else 0 end	as	is_ahfs_roentgenography_and_other_imaging_agents
        , case when ext_ahfs_thrptc_clss_cd = 36700000 then 1 else 0 end	as	is_ahfs_respiratory_function
        , case when ext_ahfs_thrptc_clss_cd = 36840000 then 1 else 0 end	as	is_ahfs_tuberculosis
        , case when ext_ahfs_thrptc_clss_cd = 36880000 then 1 else 0 end	as	is_ahfs_urine_and_feces_contents
        , case when ext_ahfs_thrptc_clss_cd = 36881200 then 1 else 0 end	as	is_ahfs_ketones
        , case when ext_ahfs_thrptc_clss_cd = 36882000 then 1 else 0 end	as	is_ahfs_occult_blood
        , case when ext_ahfs_thrptc_clss_cd = 36882400 then 1 else 0 end	as	is_ahfs_ph
        , case when ext_ahfs_thrptc_clss_cd = 36882800 then 1 else 0 end	as	is_ahfs_protein
        , case when ext_ahfs_thrptc_clss_cd = 36884000 then 1 else 0 end	as	is_ahfs_sugar
        , case when ext_ahfs_thrptc_clss_cd = 38000000 then 1 else 0 end	as	is_ahfs_disinfectants_for_non_dermatologic_use
        , case when ext_ahfs_thrptc_clss_cd = 40040000 then 1 else 0 end	as	is_ahfs_acidifying_agents
        , case when ext_ahfs_thrptc_clss_cd = 40080000 then 1 else 0 end	as	is_ahfs_alkalinizing_agents
        , case when ext_ahfs_thrptc_clss_cd = 40100000 then 1 else 0 end	as	is_ahfs_ammonia_detoxicants
        , case when ext_ahfs_thrptc_clss_cd = 40120000 then 1 else 0 end	as	is_ahfs_replacement_preparations
        , case when ext_ahfs_thrptc_clss_cd = 40180000 then 1 else 0 end	as	is_ahfs_ion_removing_agents
        , case when ext_ahfs_thrptc_clss_cd = 40181800 then 1 else 0 end	as	is_ahfs_potassium_removing_agents
        , case when ext_ahfs_thrptc_clss_cd = 40181900 then 1 else 0 end	as	is_ahfs_phosphate_removing_agents
        , case when ext_ahfs_thrptc_clss_cd = 40189200 then 1 else 0 end	as	is_ahfs_other_ion_removing_agents
        , case when ext_ahfs_thrptc_clss_cd = 40200000 then 1 else 0 end	as	is_ahfs_caloric_agents
        , case when ext_ahfs_thrptc_clss_cd = 40240000 then 1 else 0 end	as	is_ahfs_salt_and_sugar_substitutes
        , case when ext_ahfs_thrptc_clss_cd = 40280800 then 1 else 0 end	as	is_ahfs_loop_diuretics
        , case when ext_ahfs_thrptc_clss_cd = 40281200 then 1 else 0 end	as	is_ahfs_osmotic_diuretics
        , case when ext_ahfs_thrptc_clss_cd = 40281600 then 1 else 0 end	as	is_ahfs_potassium_sparing_diuretics
        , case when ext_ahfs_thrptc_clss_cd = 40282000 then 1 else 0 end	as	is_ahfs_thiazide_diuretics
        , case when ext_ahfs_thrptc_clss_cd = 40282400 then 1 else 0 end	as	is_ahfs_thiazide_like_diuretics
        , case when ext_ahfs_thrptc_clss_cd = 40282800 then 1 else 0 end	as	is_ahfs_vasopressin_antagonists
        , case when ext_ahfs_thrptc_clss_cd = 40289200 then 1 else 0 end	as	is_ahfs_diuretics_miscellaneous
        , case when ext_ahfs_thrptc_clss_cd = 40360000 then 1 else 0 end	as	is_ahfs_irrigating_solutions
        , case when ext_ahfs_thrptc_clss_cd = 40400000 then 1 else 0 end	as	is_ahfs_uricosuric_agents
        , case when ext_ahfs_thrptc_clss_cd = 40920000 then 1 else 0 end	as	is_ahfs_electrolytic_caloric_water_balance_misc
        , case when ext_ahfs_thrptc_clss_cd = 44000000 then 1 else 0 end	as	is_ahfs_enzymes
        , case when ext_ahfs_thrptc_clss_cd = 48020000 then 1 else 0 end	as	is_ahfs_antifibrotic_agents
        , case when ext_ahfs_thrptc_clss_cd = 48040400 then 1 else 0 end	as	is_ahfs_first_generation_antihistrespir_tract
        , case when ext_ahfs_thrptc_clss_cd = 48080000 then 1 else 0 end	as	is_ahfs_antitussives
        , case when ext_ahfs_thrptc_clss_cd = 48100808 then 1 else 0 end	as	is_ahfs_orally_inhaled_preparations_steroids
        , case when ext_ahfs_thrptc_clss_cd = 48102000 then 1 else 0 end	as	is_ahfs_interleukin_antagonists
        , case when ext_ahfs_thrptc_clss_cd = 48102400 then 1 else 0 end	as	is_ahfs_leukotriene_modifiers
        , case when ext_ahfs_thrptc_clss_cd = 48103200 then 1 else 0 end	as	is_ahfs_mast_cell_stabilizers
        , case when ext_ahfs_thrptc_clss_cd = 48140400 then 1 else 0 end	as	is_ahfs_cystic_fibrosis_cftr_correctors
        , case when ext_ahfs_thrptc_clss_cd = 48141200 then 1 else 0 end	as	is_ahfs_cystic_fibrosis_cftr_potentiators
        , case when ext_ahfs_thrptc_clss_cd = 48160000 then 1 else 0 end	as	is_ahfs_expectorants
        , case when ext_ahfs_thrptc_clss_cd = 48240000 then 1 else 0 end	as	is_ahfs_mucolytic_agents
        , case when ext_ahfs_thrptc_clss_cd = 48320000 then 1 else 0 end	as	is_ahfs_phosphodiesterase_type_4_inhibitors
        , case when ext_ahfs_thrptc_clss_cd = 48360000 then 1 else 0 end	as	is_ahfs_pulmonary_surfactants
        , case when ext_ahfs_thrptc_clss_cd = 48480000 then 1 else 0 end	as	is_ahfs_vasodilating_agents_respiratory_tract
        , case when ext_ahfs_thrptc_clss_cd = 48920000 then 1 else 0 end	as	is_ahfs_respiratory_tract_agents_miscellaneous
        , case when ext_ahfs_thrptc_clss_cd = 52020000 then 1 else 0 end	as	is_ahfs_antiallergic_agents
        , case when ext_ahfs_thrptc_clss_cd = 52040400 then 1 else 0 end	as	is_ahfs_antibacterials_eent
        , case when ext_ahfs_thrptc_clss_cd = 52041600 then 1 else 0 end	as	is_ahfs_antifungals_eent
        , case when ext_ahfs_thrptc_clss_cd = 52042000 then 1 else 0 end	as	is_ahfs_antivirals_eent
        , case when ext_ahfs_thrptc_clss_cd = 52049200 then 1 else 0 end	as	is_ahfs_eent_anti_infectives_miscellaneous
        , case when ext_ahfs_thrptc_clss_cd = 52080800 then 1 else 0 end	as	is_ahfs_corticosteroids_eent
        , case when ext_ahfs_thrptc_clss_cd = 52082000 then 1 else 0 end	as	is_ahfs_eent_nonsteroidal_anti_inflam_agents
        , case when ext_ahfs_thrptc_clss_cd = 52089200 then 1 else 0 end	as	is_ahfs_eent_anti_inflammatory_agents_misc
        , case when ext_ahfs_thrptc_clss_cd = 52120000 then 1 else 0 end	as	is_ahfs_contact_lens_solutions
        , case when ext_ahfs_thrptc_clss_cd = 52160000 then 1 else 0 end	as	is_ahfs_local_anesthetics_eent
        , case when ext_ahfs_thrptc_clss_cd = 52240000 then 1 else 0 end	as	is_ahfs_mydriatics
        , case when ext_ahfs_thrptc_clss_cd = 52280000 then 1 else 0 end	as	is_ahfs_mouthwashes_and_gargles
        , case when ext_ahfs_thrptc_clss_cd = 52320000 then 1 else 0 end	as	is_ahfs_vasoconstrictors
        , case when ext_ahfs_thrptc_clss_cd = 52400400 then 1 else 0 end	as	is_ahfs_alpha_adrenergic_agonists_eent
        , case when ext_ahfs_thrptc_clss_cd = 52400800 then 1 else 0 end	as	is_ahfs_beta_adrenergic_blocking_agents_eent
        , case when ext_ahfs_thrptc_clss_cd = 52401200 then 1 else 0 end	as	is_ahfs_carbonic_anhydrase_inhibitors_eent
        , case when ext_ahfs_thrptc_clss_cd = 52402000 then 1 else 0 end	as	is_ahfs_miotics
        , case when ext_ahfs_thrptc_clss_cd = 52402800 then 1 else 0 end	as	is_ahfs_prostaglandin_analogs
        , case when ext_ahfs_thrptc_clss_cd = 52403200 then 1 else 0 end	as	is_ahfs_rho_kinase_inhibitors
        , case when ext_ahfs_thrptc_clss_cd = 52409200 then 1 else 0 end	as	is_ahfs_antiglaucoma_agents_miscellaneous
        , case when ext_ahfs_thrptc_clss_cd = 52920000 then 1 else 0 end	as	is_ahfs_eent_drugs_miscellaneous
        , case when ext_ahfs_thrptc_clss_cd = 56040000 then 1 else 0 end	as	is_ahfs_antacids_and_adsorbents
        , case when ext_ahfs_thrptc_clss_cd = 56080000 then 1 else 0 end	as	is_ahfs_antidiarrhea_agents
        , case when ext_ahfs_thrptc_clss_cd = 56100000 then 1 else 0 end	as	is_ahfs_antiflatulents
        , case when ext_ahfs_thrptc_clss_cd = 56120000 then 1 else 0 end	as	is_ahfs_cathartics_and_laxatives
        , case when ext_ahfs_thrptc_clss_cd = 56140000 then 1 else 0 end	as	is_ahfs_cholelitholytic_agents
        , case when ext_ahfs_thrptc_clss_cd = 56160000 then 1 else 0 end	as	is_ahfs_digestants
        , case when ext_ahfs_thrptc_clss_cd = 56200000 then 1 else 0 end	as	is_ahfs_emetics
        , case when ext_ahfs_thrptc_clss_cd = 56220800 then 1 else 0 end	as	is_ahfs_antihistamines_gi_drugs
        , case when ext_ahfs_thrptc_clss_cd = 56222000 then 1 else 0 end	as	is_ahfs_5_ht3_receptor_antagonists
        , case when ext_ahfs_thrptc_clss_cd = 56223200 then 1 else 0 end	as	is_ahfs_neurokinin_1_receptor_antagonists
        , case when ext_ahfs_thrptc_clss_cd = 56229200 then 1 else 0 end	as	is_ahfs_antiemetics_miscellaneous
        , case when ext_ahfs_thrptc_clss_cd = 56240000 then 1 else 0 end	as	is_ahfs_lipotropic_agents
        , case when ext_ahfs_thrptc_clss_cd = 56281200 then 1 else 0 end	as	is_ahfs_histamine_h2_antagonists
        , case when ext_ahfs_thrptc_clss_cd = 56282800 then 1 else 0 end	as	is_ahfs_prostaglandins
        , case when ext_ahfs_thrptc_clss_cd = 56283200 then 1 else 0 end	as	is_ahfs_protectants
        , case when ext_ahfs_thrptc_clss_cd = 56283600 then 1 else 0 end	as	is_ahfs_proton_pump_inhibitors
        , case when ext_ahfs_thrptc_clss_cd = 56320000 then 1 else 0 end	as	is_ahfs_prokinetic_agents
        , case when ext_ahfs_thrptc_clss_cd = 56360000 then 1 else 0 end	as	is_ahfs_anti_inflammatory_agents_gi_drugs
        , case when ext_ahfs_thrptc_clss_cd = 56920000 then 1 else 0 end	as	is_ahfs_gi_drugs_miscellaneous
        , case when ext_ahfs_thrptc_clss_cd = 60000000 then 1 else 0 end	as	is_ahfs_gold_compounds
        , case when ext_ahfs_thrptc_clss_cd = 64000000 then 1 else 0 end	as	is_ahfs_heavy_metal_antagonists
        , case when ext_ahfs_thrptc_clss_cd = 68040000 then 1 else 0 end	as	is_ahfs_adrenals
        , case when ext_ahfs_thrptc_clss_cd = 68080000 then 1 else 0 end	as	is_ahfs_androgens
        , case when ext_ahfs_thrptc_clss_cd = 68120000 then 1 else 0 end	as	is_ahfs_contraceptives
        , case when ext_ahfs_thrptc_clss_cd = 68160400 then 1 else 0 end	as	is_ahfs_estrogens
        , case when ext_ahfs_thrptc_clss_cd = 68160800 then 1 else 0 end	as	is_ahfs_antiestrogens
        , case when ext_ahfs_thrptc_clss_cd = 68161200 then 1 else 0 end	as	is_ahfs_estrogen_agonist_antagonists
        , case when ext_ahfs_thrptc_clss_cd = 68180000 then 1 else 0 end	as	is_ahfs_gonadotropins_and_antigonadotropins
        , case when ext_ahfs_thrptc_clss_cd = 68180400 then 1 else 0 end	as	is_ahfs_antigonadtropins
        , case when ext_ahfs_thrptc_clss_cd = 68180800 then 1 else 0 end	as	is_ahfs_gonadotropins
        , case when ext_ahfs_thrptc_clss_cd = 68200200 then 1 else 0 end	as	is_ahfs_alpha_glucosidase_inhibitors
        , case when ext_ahfs_thrptc_clss_cd = 68200300 then 1 else 0 end	as	is_ahfs_amylinomimetics
        , case when ext_ahfs_thrptc_clss_cd = 68200400 then 1 else 0 end	as	is_ahfs_biguanides
        , case when ext_ahfs_thrptc_clss_cd = 68200500 then 1 else 0 end	as	is_ahfs_dipeptidyl_peptidase_4dpp_4_inhibitors
        , case when ext_ahfs_thrptc_clss_cd = 68200600 then 1 else 0 end	as	is_ahfs_incretin_mimetics
        , case when ext_ahfs_thrptc_clss_cd = 68200800 then 1 else 0 end	as	is_ahfs_insulins
        , case when ext_ahfs_thrptc_clss_cd = 68200804 then 1 else 0 end	as	is_ahfs_rapid_acting_insulins
        , case when ext_ahfs_thrptc_clss_cd = 68200808 then 1 else 0 end	as	is_ahfs_short_acting_insulins
        , case when ext_ahfs_thrptc_clss_cd = 68200812 then 1 else 0 end	as	is_ahfs_intermediate_acting_insulins
        , case when ext_ahfs_thrptc_clss_cd = 68200816 then 1 else 0 end	as	is_ahfs_long_acting_insulins
        , case when ext_ahfs_thrptc_clss_cd = 68201600 then 1 else 0 end	as	is_ahfs_meglitinides
        , case when ext_ahfs_thrptc_clss_cd = 68201800 then 1 else 0 end	as	is_ahfs_sodium_gluc_cotransport_2_sglt2_inhib
        , case when ext_ahfs_thrptc_clss_cd = 68202000 then 1 else 0 end	as	is_ahfs_sulfonylureas
        , case when ext_ahfs_thrptc_clss_cd = 68202800 then 1 else 0 end	as	is_ahfs_thiazolidinediones
        , case when ext_ahfs_thrptc_clss_cd = 68209200 then 1 else 0 end	as	is_ahfs_antidiabetic_agents_miscellaneous
        , case when ext_ahfs_thrptc_clss_cd = 68221200 then 1 else 0 end	as	is_ahfs_glycogenolytic_agents
        , case when ext_ahfs_thrptc_clss_cd = 68229200 then 1 else 0 end	as	is_ahfs_antihypoglycemic_agents_miscellaneous
        , case when ext_ahfs_thrptc_clss_cd = 68240000 then 1 else 0 end	as	is_ahfs_parathyroid_and_antiparathyroid_agents
        , case when ext_ahfs_thrptc_clss_cd = 68240400 then 1 else 0 end	as	is_ahfs_antiparathyroid_agents
        , case when ext_ahfs_thrptc_clss_cd = 68240800 then 1 else 0 end	as	is_ahfs_parathyroid_agents
        , case when ext_ahfs_thrptc_clss_cd = 68280000 then 1 else 0 end	as	is_ahfs_pituitary
        , case when ext_ahfs_thrptc_clss_cd = 68290400 then 1 else 0 end	as	is_ahfs_somatostatin_agonists
        , case when ext_ahfs_thrptc_clss_cd = 68300400 then 1 else 0 end	as	is_ahfs_somatotropin_agonists
        , case when ext_ahfs_thrptc_clss_cd = 68300800 then 1 else 0 end	as	is_ahfs_somatotropin_antagonists
        , case when ext_ahfs_thrptc_clss_cd = 68320000 then 1 else 0 end	as	is_ahfs_progestins
        , case when ext_ahfs_thrptc_clss_cd = 68360400 then 1 else 0 end	as	is_ahfs_thyroid_agents
        , case when ext_ahfs_thrptc_clss_cd = 68360800 then 1 else 0 end	as	is_ahfs_antithyroid_agents
        , case when ext_ahfs_thrptc_clss_cd = 68400000 then 1 else 0 end	as	is_ahfs_leptins
        , case when ext_ahfs_thrptc_clss_cd = 68440000 then 1 else 0 end	as	is_ahfs_renin_angiotensin_aldosterone_systraas
        , case when ext_ahfs_thrptc_clss_cd = 72000000 then 1 else 0 end	as	is_ahfs_local_anesthetics_parenteral
        , case when ext_ahfs_thrptc_clss_cd = 76000000 then 1 else 0 end	as	is_ahfs_oxytocics
        , case when ext_ahfs_thrptc_clss_cd = 78000000 then 1 else 0 end	as	is_ahfs_radioactive_agents
        , case when ext_ahfs_thrptc_clss_cd = 80020000 then 1 else 0 end	as	is_ahfs_allergenic_extracts_therapeutic
        , case when ext_ahfs_thrptc_clss_cd = 80040000 then 1 else 0 end	as	is_ahfs_antitoxins_and_immune_globulins
        , case when ext_ahfs_thrptc_clss_cd = 80080000 then 1 else 0 end	as	is_ahfs_toxoids
        , case when ext_ahfs_thrptc_clss_cd = 80120000 then 1 else 0 end	as	is_ahfs_vaccines
        , case when ext_ahfs_thrptc_clss_cd = 84040400 then 1 else 0 end	as	is_ahfs_antibacterials_skin_mucous_membrane
        , case when ext_ahfs_thrptc_clss_cd = 84040600 then 1 else 0 end	as	is_ahfs_antivirals_skin_and_mucous_membrane
        , case when ext_ahfs_thrptc_clss_cd = 84040800 then 1 else 0 end	as	is_ahfs_antifungals_skin_and_mucous_membrane
        , case when ext_ahfs_thrptc_clss_cd = 84040804 then 1 else 0 end	as	is_ahfs_allylamines_skin_and_mucous_membrane
        , case when ext_ahfs_thrptc_clss_cd = 84040808 then 1 else 0 end	as	is_ahfs_azoles_skin_and_mucous_membrane
        , case when ext_ahfs_thrptc_clss_cd = 84040812 then 1 else 0 end	as	is_ahfs_benzylamines_skin_and_mucous_membrane
        , case when ext_ahfs_thrptc_clss_cd = 84040820 then 1 else 0 end	as	is_ahfs_hydroxypyridones_skin_mucous_membrane
        , case when ext_ahfs_thrptc_clss_cd = 84040824 then 1 else 0 end	as	is_ahfs_oxaboroles
        , case when ext_ahfs_thrptc_clss_cd = 84040828 then 1 else 0 end	as	is_ahfs_polyenes_skin_and_mucous_membrane
        , case when ext_ahfs_thrptc_clss_cd = 84040840 then 1 else 0 end	as	is_ahfs_thiocarbamatesskin_and_mucous_membrane
        , case when ext_ahfs_thrptc_clss_cd = 84040892 then 1 else 0 end	as	is_ahfs_antifulgals_skin_mucous_membrane_misc
        , case when ext_ahfs_thrptc_clss_cd = 84041200 then 1 else 0 end	as	is_ahfs_scabicides_and_pediculicides
        , case when ext_ahfs_thrptc_clss_cd = 84049200 then 1 else 0 end	as	is_ahfs_local_anti_infectives_miscellaneous
        , case when ext_ahfs_thrptc_clss_cd = 84060000 then 1 else 0 end	as	is_ahfs_anti_inflammatory_agents_skin_mucous
        , case when ext_ahfs_thrptc_clss_cd = 84060800 then 1 else 0 end	as	is_ahfs_corticosteroids_skin_mucous_membrane
        , case when ext_ahfs_thrptc_clss_cd = 84062000 then 1 else 0 end	as	is_ahfs_nonsteroidal_anti_inflammatagentsskin
        , case when ext_ahfs_thrptc_clss_cd = 84069200 then 1 else 0 end	as	is_ahfs_anti_inflammatory_agents_misc_skin
        , case when ext_ahfs_thrptc_clss_cd = 84080000 then 1 else 0 end	as	is_ahfs_antipruritics_and_local_anesthetics
        , case when ext_ahfs_thrptc_clss_cd = 84120000 then 1 else 0 end	as	is_ahfs_astringents
        , case when ext_ahfs_thrptc_clss_cd = 84160000 then 1 else 0 end	as	is_ahfs_cell_stimulants_and_proliferants
        , case when ext_ahfs_thrptc_clss_cd = 84200000 then 1 else 0 end	as	is_ahfs_detergents
        , case when ext_ahfs_thrptc_clss_cd = 84240000 then 1 else 0 end	as	is_ahfs_emollients_demulcents_and_protectants
        , case when ext_ahfs_thrptc_clss_cd = 84240400 then 1 else 0 end	as	is_ahfs_basic_lotions_and_liniments
        , case when ext_ahfs_thrptc_clss_cd = 84240800 then 1 else 0 end	as	is_ahfs_basic_oils_and_other_solvents
        , case when ext_ahfs_thrptc_clss_cd = 84241200 then 1 else 0 end	as	is_ahfs_basic_ointments_and_protectants
        , case when ext_ahfs_thrptc_clss_cd = 84241600 then 1 else 0 end	as	is_ahfs_basic_powders_and_demulcents
        , case when ext_ahfs_thrptc_clss_cd = 84280000 then 1 else 0 end	as	is_ahfs_keratolytic_agents
        , case when ext_ahfs_thrptc_clss_cd = 84320000 then 1 else 0 end	as	is_ahfs_keratoplastic_agents
        , case when ext_ahfs_thrptc_clss_cd = 84500400 then 1 else 0 end	as	is_ahfs_depigmenting_agents
        , case when ext_ahfs_thrptc_clss_cd = 84500600 then 1 else 0 end	as	is_ahfs_pigmenting_agents
        , case when ext_ahfs_thrptc_clss_cd = 84800000 then 1 else 0 end	as	is_ahfs_sunscreen_agents
        , case when ext_ahfs_thrptc_clss_cd = 84920000 then 1 else 0 end	as	is_ahfs_skin_and_mucous_membrane_agents_misc
        , case when ext_ahfs_thrptc_clss_cd = 86120000 then 1 else 0 end	as	is_ahfs_genitourinary_smooth_muscle_relaxants
        , case when ext_ahfs_thrptc_clss_cd = 86120400 then 1 else 0 end	as	is_ahfs_antimuscarinics
        , case when ext_ahfs_thrptc_clss_cd = 86120812 then 1 else 0 end	as	is_ahfs_selective_beta_3_adrenergic_agonists
        , case when ext_ahfs_thrptc_clss_cd = 86160000 then 1 else 0 end	as	is_ahfs_respiratory_smooth_muscle_relaxants
        , case when ext_ahfs_thrptc_clss_cd = 88040000 then 1 else 0 end	as	is_ahfs_vitamin_a
        , case when ext_ahfs_thrptc_clss_cd = 88080000 then 1 else 0 end	as	is_ahfs_vitamin_b_complex
        , case when ext_ahfs_thrptc_clss_cd = 88120000 then 1 else 0 end	as	is_ahfs_vitamin_c
        , case when ext_ahfs_thrptc_clss_cd = 88160000 then 1 else 0 end	as	is_ahfs_vitamin_d
        , case when ext_ahfs_thrptc_clss_cd = 88200000 then 1 else 0 end	as	is_ahfs_vitamin_e
        , case when ext_ahfs_thrptc_clss_cd = 88240000 then 1 else 0 end	as	is_ahfs_vitamin_k_activity
        , case when ext_ahfs_thrptc_clss_cd = 88280000 then 1 else 0 end	as	is_ahfs_multivitamin_preparations
        , case when ext_ahfs_thrptc_clss_cd = 92000000 then 1 else 0 end	as	is_ahfs_miscellaneous_therapeutic_agents
        , case when ext_ahfs_thrptc_clss_cd = 92040000 then 1 else 0 end	as	is_ahfs_alcohol_deterrents
        , case when ext_ahfs_thrptc_clss_cd = 92080000 then 1 else 0 end	as	is_ahfs_5_alpha_reductase_inhibitors
        , case when ext_ahfs_thrptc_clss_cd = 92120000 then 1 else 0 end	as	is_ahfs_antidotes
        , case when ext_ahfs_thrptc_clss_cd = 92160000 then 1 else 0 end	as	is_ahfs_antigout_agents
        , case when ext_ahfs_thrptc_clss_cd = 92180000 then 1 else 0 end	as	is_ahfs_antisense_oligonucleotides
        , case when ext_ahfs_thrptc_clss_cd = 92200000 then 1 else 0 end	as	is_ahfs_immunomodulatory_agents
        , case when ext_ahfs_thrptc_clss_cd = 92220000 then 1 else 0 end	as	is_ahfs_bone_anabolic_agents
        , case when ext_ahfs_thrptc_clss_cd = 92240000 then 1 else 0 end	as	is_ahfs_bone_resorption_inhibitors
        , case when ext_ahfs_thrptc_clss_cd = 92260000 then 1 else 0 end	as	is_ahfs_carbonic_anhydrase_inhibitors_misc
        , case when ext_ahfs_thrptc_clss_cd = 92280000 then 1 else 0 end	as	is_ahfs_cariostatic_agents
        , case when ext_ahfs_thrptc_clss_cd = 92320000 then 1 else 0 end	as	is_ahfs_complement_inhibitors
        , case when ext_ahfs_thrptc_clss_cd = 92360000 then 1 else 0 end	as	is_ahfs_disease_modifying_antirheumatic_agents
        , case when ext_ahfs_thrptc_clss_cd = 92400000 then 1 else 0 end	as	is_ahfs_gonadotropin_releasing_hormone_antagnts
        , case when ext_ahfs_thrptc_clss_cd = 92440000 then 1 else 0 end	as	is_ahfs_immunosuppressive_agents
        , case when ext_ahfs_thrptc_clss_cd = 92560000 then 1 else 0 end	as	is_ahfs_protective_agents
        , case when ext_ahfs_thrptc_clss_cd = 92920000 then 1 else 0 end	as	is_ahfs_other_miscellaneous_therapeutic_agents
        , case when ext_ahfs_thrptc_clss_cd = 94000000 then 1 else 0 end	as	is_ahfs_devices
        , case when ext_ahfs_thrptc_clss_cd = 96000000 then 1 else 0 end	as	is_ahfs_pharmaceutical_aids

      from

  --     create or replace table `research-01-217611.df_sandbox.wkg_udd_pharmacy_claim_ugap`  as select * from `research-01-217611.df_sandbox.udd_pharmacy_claim_ugap`   order by rand() limit 10000   clm
                                                                                 clm
          join `research-01-217611.df_ucd_stage.dim_date`		                     dt	  on clm.fill_dt = dt.full_dt
          join `research-01-217611.df_ucd_stage.dim_date`		                     sdt	on clm.sbmt_full_dt = sdt.full_dt
          --left join `research-01-217611.df_enrichment.medispan_drug`             mp   on clm.ndc = mp.product_id
          --                                                                            and mp.current_flag='y'
          left join /* member */                                                 mbr  on clm.savvy_pid = mbr.savvy_pid
                                                                                      and dt.year_mo = mbr.year_mo
  ;

  --if successful, we'll get here!
  insert into `research-01-217611.df_ucd_stage.logging`(
    success_flag, job, message_datetime)
  select
    1 as success_flag
    , 'create enriched pharmacy claim tables' as job
    , current_datetime as message_datetime
  ;

  EXCEPTION WHEN ERROR THEN
    insert into `research-01-217611.df_ucd_stage.logging`(
      success_flag, job, error_message, statement_text, formatted_stack_trace, message_datetime)
    select
      0 as success_flag
      , 'create enriched pharmacy claim tables' as job
      , @@error.message as error_message
      , @@error.statement_text as statement_text
      , @@error.formatted_stack_trace as formatted_stack_trace
      , current_datetime as message_datetime
    ;


END
;
