/***
Universal Claims Data - Member Summary

Date Created: 29 October 2020
***/

BEGIN

insert into `research-01-217611.df_ucd_stage.member_summary`
  (src_type, business_line, savvy_pid, savvy_did, is_restricted, birth_year, age, gender, death_flag, death_date, family_id, sbscr_ind, rel_cd, orec, dual_elig,
    mapd_flag, medicare_part_d_only_flag, medicare_advantage_flag, medicaid_flag, hlth_pln_fund_cd, finc_arng_cd, co_nm, phrm_cov_ind, phrm_cov_flag, med_cov_ind, med_cov_flag, zip, st_cd, county, msa, zcta, fips, usr_class, division, region,
    last_ym, mm, mm_2016, mm_2017, mm_2018, mm_2019, mm_2020, mm_fi, mm_aso, mm_rxcov, mm_medcov, mm_dual_elig, mm_mapd, mm_pdponly, mm_ma, mm_medicaid
  )
with cte_dem as (
    select src_type, business_line, savvy_pid, savvy_did, is_restricted, birth_year, age, gender, death_flag, death_date, family_id, sbscr_ind, rel_cd, orec
      , dual_elig, mapd_flag, medicare_part_d_only_flag, medicare_advantage_flag, medicaid_flag, hlth_pln_fund_cd, finc_arng_cd, co_nm, phrm_cov_ind, phrm_cov_flag, med_cov_ind, med_cov_flag
      , zip, st_cd, county, msa, zcta, fips, usr_class, division, region
      , year_mo as last_ym
      , row_number() over(partition by savvy_pid
                          order by year_mo desc                                       --most recent data first
                                  , case when src_type = 'galaxy' then 1
                                        when src_type = 'ugap'   then 2
                                        when src_type = 'miniov' then 3
                                        when src_type = 'sma'    then 4 else 5 end   --source next
                          ) as rn
    from  `research-01-217611.df_ucd_stage.member_detail_enriched`
  )
, cte_mm as (
    select savvy_pid
      , count(distinct year_mo) as mm
      , count(distinct case when year_nbr = 2016 then year_mo end) as mm_2016
      , count(distinct case when year_nbr = 2017 then year_mo end) as mm_2017
      , count(distinct case when year_nbr = 2018 then year_mo end) as mm_2018
      , count(distinct case when year_nbr = 2019 then year_mo end) as mm_2019
      , count(distinct case when year_nbr = 2020 then year_mo end) as mm_2020   --insert new years here

      , count(distinct case when hlth_pln_fund_cd = 'fi'  or finc_arng_cd = 'f' then year_mo end) as mm_fi
      , count(distinct case when hlth_pln_fund_cd = 'aso' or finc_arng_cd = 'a' then year_mo end) as mm_aso
      , count(distinct case when phrm_cov_ind = 'y' then year_mo end) as mm_rxcov
      , count(distinct case when med_cov_ind = 'y' then year_mo end) as mm_medcov
      , count(distinct case when dual_elig = 1 then year_mo end) as mm_dual_elig
      , count(distinct case when mapd_flag = 1 then year_mo end) as mm_mapd
      , count(distinct case when medicare_part_d_only_flag = 1 then year_mo end) as mm_pdponly
      , count(distinct case when medicare_advantage_flag = 1 then year_mo end) as mm_ma
      , count(distinct case when medicaid_flag = 1 then year_mo end) as mm_medicaid
    from `research-01-217611.df_ucd_stage.member_detail_enriched`
    group by savvy_pid
  )
select a.* except(rn)
  , b.* except(savvy_pid)
from cte_dem a
inner join cte_mm b using (savvy_pid)
where rn = 1                                --all of the values from cte_dem are the most recent for the member
;

  --if successful, we'll get here!
  insert into `research-01-217611.df_ucd_stage.logging`(
    success_flag, job, message_datetime)
  select
    1 as success_flag
    , 'create member summary table' as job
    , current_datetime as message_datetime
  ;

  EXCEPTION WHEN ERROR THEN
    insert into `research-01-217611.df_ucd_stage.logging`(
      success_flag, job, error_message, statement_text, formatted_stack_trace, message_datetime)
    select
      0 as success_flag
      , 'create member summary table' as job
      , @@error.message as error_message
      , @@error.statement_text as statement_text
      , @@error.formatted_stack_trace as formatted_stack_trace
      , current_datetime as message_datetime
    ;

END
;
