 /* Project: Universal Claims Database (UCD )
   Business Partner: Matt Holst
   Input: df_ucd_staging.medical_claim
   Created By: Kiara
   Created Date:
   Modified By: Sachin
   Modified Dates:10/29
   10/27 - Sourced from df_ucd (2.0)
   Note: This query is depended on `research-01-217611.df_ucd_stage.ucd_ipconf_pqi_cs`.
   '01_ip_confinement_pqi_cs.sql' creates above table, so has to be run prior to this query.

   Granularity: One record per member/admit_dt/diagnosis code                          */


BEGIN

  /* ddl moved to template */

insert into `research-01-217611.df_ucd_stage.ip_confinement`
  (uuid, savvy_pid, savvy_did, is_restricted, src_type, business_line, gender, admit_age, ip_episode_id, admit_ym, admit_dt, discharge_dt, lengthofstay, prov_zip, prov_stcd, prov_mpin, provtype, surgery_flag, readmit_flag, discharge_status, hospital_flag, snf_flag, otherfacility_flag, transferred_to_snf_flag, transferred_from_snf_flag, er_flag, icu_flag, total_allow, ip_allow, dr_allow, rx_allow, drg_cd, drg_desc, mdc_cd, mdc_desc, surgical_drg_flag, primary_diagcd, primary_diagdesc, ahrq_diag_dtl_catgy_cd, ahrq_diag_dtl_catgy_nm, rvnu_cd, rvnu_desc, pqi_01, pqi_03, pqi_05, pqi_07, pqi_08, pqi_11, pqi_12, pqi_14, pqi_15, pqi_16, charl_flag_aids, charl_flag_chf, charl_flag_cpd, charl_flag_cvd, charl_flag_dem, charl_flag_dm, charl_flag_dmx, charl_flag_liver, charl_flag_liverserv, charl_flag_malig, charl_flag_mi, charl_flag_plegia, charl_flag_pud, charl_flag_pvd, charl_flag_renal, charl_flag_rheum, charl_flag_tumor, charl_score, comorbidity_list, create_datetime, update_datetime
  )
  
select GENERATE_UUID() as uuid,savvy_pid, savvy_did, is_restricted,src_type,business_line,gender,admit_age,ip_episode_id,admit_ym,admit_dt,discharge_dt,	lengthofstay,prov_zip,prov_stcd,mpin,prov_typ_nm,surgery_flag,readmit_flag,discharge_status,hospital_flag,snf_flag,	otherfacility_flag,transferred_tosnf_flag,transferred_fromsnf_flag,er_flag,icu_flag,total_allow,ip_allow,dr_allow,rx_allow,drg_cd,	drg_desc,mdc_cd,mdc_desc,surgical_drg_flag,primary_diagcd,primary_diagdesc,cast(ahrq_diag_dtl_catgy_cd as string),	ahrq_diag_dtl_catgy_nm,rvnu_cd,rvnu_desc,pqi_01,pqi_03,pqi_05,pqi_07,pqi_08,pqi_11,pqi_12,pqi_14,pqi_15,pqi_16,charl_flag_aids,	charl_flag_chf,charl_flag_cpd,charl_flag_cvd,charl_flag_dem,charl_flag_dm,charl_flag_dmx,charl_flag_liver,charl_flag_liversev,	charl_flag_malig,charl_flag_mi,charl_flag_plegia,charl_flag_pud,charl_flag_pvd,charl_flag_renal,charl_flag_rheum,charl_flag_tumor,	charl_score,trim(lower(comorbidity_list)) as comorbidity_list,current_datetime() as create_datetime, current_datetime() as update_datetime
from
(

with cte_ipconf as (
    select src_type, savvy_pid, grp, row_number() over(partition by savvy_pid, src_type order by min(full_dt)) as ip_episode_id,
       min(full_dt) as admit_dt,
       max(full_dt) as discharge_dt,
       count(distinct case when lower(trim(ama_pl_of_srvc_desc)) = 'inpatient hospital' then full_dt end)  as ip_hospital_day_cnt,
       count(distinct case when lower(trim(ama_pl_of_srvc_desc)) = 'skilled nursing facility' then full_dt end)  as snf_day_cnt,
       count(distinct case when lower(trim(ama_pl_of_srvc_desc)) not in ('inpatient hospital', 'skilled nursing facility') then full_dt end) as other_day_cnt,
       count(distinct full_dt) as total_day_cnt
    from  (
            --groupings
              select a.savvy_pid, a.admit_dt, a.discharge_dt, a.day_cnt, a.ama_pl_of_srvc_desc, a.full_dt, a.step
                , countif(step > 1) over(partition by savvy_pid, src_type order by full_dt) as grp
                , src_type
              from  (
                      --admits
                      select a.savvy_pid,
                             --a.year_mo as admit_ym,
                             cast(a.clm_dt as date) as admit_dt,
                             date_add(cast(a.clm_dt as date), INTERVAL day_cnt DAY) as discharge_dt,
                             a.day_cnt,
                             a.ama_pl_of_srvc_desc,
                             b.full_dt,
                             date_diff(b.full_dt, lag(b.full_dt) over(partition by a.savvy_pid, a.src_type order by b.full_dt), day) step,
                             a.src_type
                      from `research-01-217611.df_ucd_stage.udd_medical_claim_consolidated` as a   --change to actual ucd medical claim table name
                      inner join `research-01-217611.df_ucd_stage.dim_date` as b on b.full_dt between cast(a.clm_dt as date) and date_add(cast(a.clm_dt as date), INTERVAL day_cnt DAY) --between admit and discharge
                      where admit_cnt = 1
                        --and a.src_type = 'sma'
                    ) as a
            ) a
    group by src_type, savvy_pid, grp
  ) --select * from cte_ipconf
, cte_readmit as (
    select a.*
      , (case when date_diff(a.admit_dt, b.discharge_dt, day) <= 30 then 1 else 0  end) as readmit_flag
    from cte_ipconf a
    left join cte_ipconf b on a.savvy_pid = b.savvy_pid
                           and a.src_type = b.src_type
                           and a.ip_episode_id = (b.ip_episode_id + 1)
  ) --select * from cte_readmit where savvy_pid = 321  --321 2685
, cte_claim as (
    select a.savvy_pid, a.savvy_did, a.is_restricted, b.src_type, a.business_line, a.gender
      --, date_diff(c.full_dt, mbr.birthdate, year) as admit_age
      , (extract(year from c.clm_dt) - a.birth_year) as admit_age
      , b.ip_episode_id
      , cast(format_date('%Y%m', b.admit_dt) AS INT64) as admit_ym
      , b.admit_dt, b.discharge_dt, b.total_day_cnt
      , (case when c.admit_cnt = 1 and c.clm_dt = b.admit_dt  then c.prov_zip_cd end) as prov_zip
      , (case when c.admit_cnt = 1 and c.clm_dt = b.admit_dt  then c.prov_state end) as prov_stcd
      , (case when c.admit_cnt = 1 and c.clm_dt = b.admit_dt  then c.npi end) as npi
      , (case when c.admit_cnt = 1 and c.clm_dt = b.admit_dt  then c.prov_mpin end) as mpin
      , (case when c.admit_cnt = 1 and c.clm_dt = b.admit_dt  then provtype end) as hp_prov_cat_prov_typ_nm
      /*used to be prov_typ_nm (changed from c.hp_prov_cat_prov_typ_nm to provtype (ucd)*/
      , (case when lower(trim(c.hce_srvc_typ_desc)) like '%ip surgery%'  then 1  else 0  end) as surgery_flag
      , (case when c.admit_cnt = 1 and c.clm_dt = b.admit_dt then (case when lower(trim(ds.dschrg_sts_catgy_txt)) like '%transferred%'	then 'transferred'
																											                 when lower(trim(ds.dschrg_sts_catgy_txt)) like '%expired%'		    then 'expired'
																											                 when lower(trim(ds.dschrg_sts_catgy_txt)) like '%admitted%'		  then 'admitted'
																											                 when lower(trim(ds.dschrg_sts_catgy_txt)) like '%left%'			    then 'left'
																											                 when lower(trim(ds.dschrg_sts_catgy_txt)) like '%unknown%'		    then 'unknown'
																										                 else 'discharged'	end)
           end) as discharge_status
      , (case when lower(trim(c.provtype)) = 'general hospital' then 1 else 0 end) as hospital_flag
      , (case when upper(trim(c.hce_srvc_typ_desc)) = 'SKILLED NURSING' or trim(c.bil_typ_cd) in ('211', '212', '213', '214', '216', '217')	then 1 else 0	end) as snf_flag
      , (case when upper(trim(c.provtype)) in ('EXTENDED CARE FACILITY', 'REHABILITATION FACILITY/NURSING HOME')
															and upper(trim(c.hce_srvc_typ_desc)) <> 'SKILLED NURSING'	then 1	else 0	end) as otherfacility_flag
      , (case when lower(trim(c.dschrg_sts_cd)) = '03'	then 1	else 0	end) as transferred_toSNF_flag
      , (case when lower(trim(ds.dschrg_sts_catgy_txt)) like '%transferred%' and upper(trim(c.hce_srvc_typ_desc)) = 'SKILLED NURSING'	then 1	else 0	end) as transferred_fromSNF_flag
      , (case when lower(trim(c.hce_srvc_typ_desc)) in ('er', 'emergency room')	then 1	else 0	end) as er_flag
      , (case when lower(trim(rv.rvnu_desc)) like '%intensive care%' then 1	else 0	end) as icu_flag
      , c.allw_amt
      , (case when lower(trim(c.srvc_typ_cd)) in ('ip', 'op')  then 'ip' else lower(trim(c.srvc_typ_cd)) end) as derived_srvc_typ_cd
      , (case when c.admit_cnt = 1 and c.clm_dt = b.admit_dt  then c.drg_cd end) as drg_cd
      , (case when c.admit_cnt = 1 and c.clm_dt = b.admit_dt  then drg.drg_desc end) as drg_desc
      , (case when c.admit_cnt = 1 and c.clm_dt = b.admit_dt  then drg.mdc_cd end) as mdc_cd
      , (case when c.admit_cnt = 1 and c.clm_dt = b.admit_dt  then drg.mdc_desc end) as mdc_desc
      , (case when c.admit_Cnt = 1 and c.clm_dt = b.admit_dt then (case when (trim(drg.drg_cd) between '00020' and '00042')
                                                                          or (trim(drg.drg_cd) in ('00113', '00114', '00116', '00117', '00507', '00508', '00749', '00750', '00927', '00933', '00928', '00929', '00934'))
                                                                          or (trim(drg.drg_cd) between '00129' and '00138')
                                                                          or (trim(drg.drg_cd) between '00163' and '00168')
                                                                          or (trim(drg.drg_cd) between '00216' and '00244') or (trim(drg.drg_cd) between '00246' and '00262')
                                                                          or (trim(drg.drg_cd) between '00326' and '00358') or (trim(drg.drg_cd) between '00405' and '00425')
                                                                          or (trim(drg.drg_cd) between '00453' and '00505') or (trim(drg.drg_cd) between '00510' and '00517')
                                                                          or (trim(drg.drg_cd) between '00573' and '00585') or (trim(drg.drg_cd) between '00616' and '00630')
                                                                          or (trim(drg.drg_cd) between '00653' and '00675') or (trim(drg.drg_cd) between '00707' and '00718')
                                                                          or (trim(drg.drg_cd) between '00734' and '00747') or (trim(drg.drg_cd) between '00765' and '00768')
                                                                          or (trim(drg.drg_cd) between '00799' and '00804') or (trim(drg.drg_cd) between '00820' and '00830')
                                                                          or (trim(drg.drg_cd) between '00853' and '00858') or (trim(drg.drg_cd) between '00901' and '00905')
                                                                          or (trim(drg.drg_cd) between '00907' and '00909') or (trim(drg.drg_cd) between '00939' and '00941')
                                                                          or (trim(drg.drg_cd) between '00957' and '00959') or (trim(drg.drg_cd) between '00969' and '00970')
																										                    then 1	else 0	end)		--reference: https://www.cms.gov/icd10manual/fullcode_cms/P0372.html
										end) as surgical_drg_flag
      , (case when c.admit_cnt = 1 and c.clm_dt = b.admit_dt  then c.dx1_diag_cd  end) as primary_diagcd
      , (case when c.admit_cnt = 1 and c.clm_dt = b.admit_dt  then diag.diag_desc  end) as primary_diagdesc
      , (case when c.admit_cnt = 1 and c.clm_dt = b.admit_dt  then diag.ahrq_diag_dtl_catgy_cd  end) as ahrq_diag_dtl_catgy_cd
      , (case when c.admit_cnt = 1 and c.clm_dt = b.admit_dt  then diag.ahrq_diag_dtl_catgy_nm  end) as ahrq_diag_dtl_catgy_nm
      , (case when c.admit_cnt = 1 and c.clm_dt = b.admit_dt  then c.rvnu_cd  end) as rvnu_cd
      , (case when c.admit_cnt = 1 and c.clm_dt = b.admit_dt  then rv.rvnu_desc end) as rvnu_desc
      , ifnull(e.rx_allw, 0) as rx_allw
    from (select savvy_pid,savvy_did,is_restricted,year_mo,gender,birth_year,zip,business_line,
                  (case
                  when trim(src_type) in ('ugap','miniov') then 'ugap'
                  else src_type
                  end) as src_type
                  from `research-01-217611.df_ucd_stage.udd_member_detail_consolidated`)           a
/*commented this out becauase member_summary uses a tiebreaker logic - galaxy,ugap, sma, which means
we cannot summary with member_detail by src_type **/
/*inner join `research-01-217611.df_ucd_stage.member_summary`    mbr on a.savvy_pid = mbr.savvy_pid and a.src_type = mbr.src_type  */

    inner join cte_ipconf                         b on a.savvy_pid = b.savvy_pid
                                                    and a.src_type = b.src_type
                                                    and a.year_mo = cast(format_date('%Y%m', b.admit_dt) AS INT64)
    inner join `research-01-217611.df_ucd_stage.udd_medical_claim_consolidated`  c on b.savvy_pid = c.savvy_pid     --change to actual ucd medical claim table name
                                                    and c.clm_dt between b.admit_dt and b.discharge_dt
                                                    and b.src_type = c.src_type
                                                    and a.year_mo = cast(format_date('%Y%m', c.clm_dt) AS INT64)
    left join `research-01-217611.df_enrichment.zip_to_zcta_2018` d on lower(trim(a.zip)) = lower(trim(d.zip))
    left join (
                select a.savvy_pid, a.src_type, b.ip_episode_id, sum(a.allw_amt) as rx_allw
                from `research-01-217611.df_ucd_stage.udd_pharmacy_claim_consolidated`    a
                inner join cte_ipconf                   b on a.savvy_pid = b.savvy_pid
                                                          and a.fill_dt between b.admit_dt and b.discharge_dt
                                                          and a.src_type = b.src_type
                --where b.src_type = 'minihpdm'
                group by a.savvy_pid, a.src_type, b.ip_episode_id
              ) e on b.savvy_pid = e.savvy_pid
                  and b.ip_episode_id = e.ip_episode_id
                  and b.src_type = e.src_type
      left join `research-01-217611.df_ucd_stage.dim_discharge_status_code` ds on c.dschrg_sts_cd=ds.dschrg_sts_cd
      left join `research-01-217611.df_ucd_stage.dim_revenue_code` rv on c.rvnu_cd=rv.rvnu_cd
      left join `research-01-217611.df_ucd_stage.dim_drg_code` drg on safe_cast(drg.drg_cd as int64)=safe_cast(c.drg_cd as int64)
      left join `research-01-217611.df_ucd_stage.dim_diagnosis_code` diag on c.dx1_diag_cd=diag.diag_cd
  )
select a.savvy_pid, a.savvy_did, a.is_restricted, a.src_type, a.business_line, a.gender, a.admit_age, a.ip_episode_id, a.admit_ym, a.admit_dt, a.discharge_dt, a.total_day_cnt as lengthofstay
  , max(prov_zip) as prov_zip
  , max(prov_stcd) as prov_stcd
  , max(mpin) as mpin
  , max(hp_prov_cat_prov_typ_nm) as prov_typ_nm
  , max(surgery_flag) as surgery_flag
  , max(readmit_flag) as readmit_flag
  , max(discharge_status) as discharge_status
  , max(hospital_flag) as hospital_flag
  , max(snf_flag) as snf_flag
  , max(otherfacility_flag) as otherfacility_flag
  , max(transferred_toSNF_flag) as transferred_toSNF_flag
  , max(transferred_fromSNF_flag) as transferred_fromSNF_flag
  , max(er_flag) as er_flag
  , max(icu_flag) as icu_flag
  , round((sum(allw_amt) + max(ifnull(rx_allw, 0))), 2) as total_allow
  , round(sum(case when trim(derived_srvc_typ_cd) = 'ip' then allw_amt  else 0  end), 2) as ip_allow
  , round(sum(case when trim(derived_srvc_typ_cd) = 'dr' then allw_amt  else 0  end), 2) as dr_allow
  , round(max(case when rx_allw is not null then rx_allw else 0 end), 2) as rx_allow
  , max(drg_cd) as drg_cd
  , max(drg_desc) as drg_desc
  , max(mdc_cd) as mdc_cd
  , max(mdc_desc) as mdc_desc
  , max(surgical_drg_flag) as surgical_drg_flag
  , max(primary_diagcd) as primary_diagcd
  , max(primary_diagdesc) as primary_diagdesc
  , max(ahrq_diag_dtl_catgy_cd) as ahrq_diag_dtl_catgy_cd
  , max(ahrq_diag_dtl_catgy_nm) as ahrq_diag_dtl_catgy_nm
  , max(rvnu_cd) as rvnu_cd
  , max(rvnu_desc) as rvnu_desc
  , max(c.pqi_01) as pqi_01
  --, max(c.pqi_02) as pqi_02
  , max(c.pqi_03) as pqi_03
  , max(c.pqi_05) as pqi_05
  , max(c.pqi_07) as pqi_07
  , max(c.pqi_08) as pqi_08
  --, max(c.pqi_09) as pqi_09
  --, max(c.pqi_10) as pqi_10
  , max(c.pqi_11) as pqi_11
  , max(c.pqi_12) as pqi_12
  , max(c.pqi_14) as pqi_14
  , max(c.pqi_15) as pqi_15
  , max(c.pqi_16) as pqi_16
  , max(c.charl_flag_AIDS) as charl_flag_AIDS
  , max(c.charl_flag_CHF)  as charl_flag_CHF
  , max(c.charl_flag_CPD)  as charl_flag_CPD
  , max(c.charl_flag_CVD)  as charl_flag_CVD
  , max(c.charl_flag_DEM)  as charl_flag_DEM
  , max(c.charl_flag_DM)   as charl_flag_DM
  , max(c.charl_flag_DMX)  as charl_flag_DMX
  , max(c.charl_flag_LIVER) as charl_flag_LIVER
  , max(c.charl_flag_LIVERSEV) as charl_flag_LIVERSEV
  , max(c.charl_flag_MALIG) as charl_flag_MALIG
  , max(c.charl_flag_MI) as charl_flag_MI
  , max(c.charl_flag_PLEGIA) as charl_flag_PLEGIA
  , max(c.charl_flag_PUD) as charl_flag_PUD
  , max(c.charl_flag_PVD) as charl_flag_PVD
  , max(c.charl_flag_RENAL) as charl_flag_RENAL
  , max(c.charl_flag_RHEUM) as charl_flag_RHEUM
  , max(c.charl_flag_TUMOR) as charl_flag_TUMOR
  , max(c.charl_score) as charl_score
  , max(comorbidity_list) as comorbidity_list
from cte_claim  a
left join cte_readmit b on a.savvy_pid = b.savvy_pid
                        and a.src_type = b.src_type
                        and a.ip_episode_id = b.ip_episode_id
left join `research-01-217611.df_ucd_stage.ucd_ipconf_pqi_cs` c on a.savvy_pid = c.savvy_pid       --build this table first prior to running this script
                                           and a.src_type = c.src_type
                                           and a.ip_episode_id = c.ip_episode_id
--here a.savvy_pid = 120869271
group by a.savvy_pid, a.savvy_did, a.is_restricted, a.src_type, a.business_line, a.gender, a.admit_age, a.ip_episode_id, a.admit_ym, a.admit_dt, a.discharge_dt, a.total_day_cnt
);
 /**Code from Seth - add this all queries with appropriate description for 'job' */
insert into `research-01-217611.df_ucd_stage.logging`(
    success_flag, job, message_datetime)
  select
    1 as success_flag
    , 'Load ip confinement table' as job
    , current_datetime as message_datetime
  ;

  EXCEPTION WHEN ERROR THEN
    insert into `research-01-217611.df_ucd_stage.logging`(
      success_flag, job, error_message, statement_text, formatted_stack_trace, message_datetime)
    select
      0 as success_flag
      , 'Load ip confinement table' as job
      , @@error.message as error_message
      , @@error.statement_text as statement_text
      , @@error.formatted_stack_trace as formatted_stack_trace
      , current_datetime as message_datetime
    ;
END;
