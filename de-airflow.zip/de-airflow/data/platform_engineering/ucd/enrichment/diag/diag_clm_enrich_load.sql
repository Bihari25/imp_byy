/* Project: Universal Claims Database (UCD )
   Business Partner: Matt Holst
   Input: df_ucd_staging.medical_claim
   Created By: Seth
   Created Date:
   Modified By: Sachin
   Modified Dates:10/27
   10/27 - Sourced from df_ucd
   Granularity: One record per member/claim_dt/diagnosis code                          */

BEGIN

/*
Note that these are equivalent:

    ******************* version with unnest/structs *******************
    select
      a.field_1, b.x. b.y
    from some_table                                                 a
      cross join (unnest(
                          [
                          STRUCT(a.field_2 as x, a.field_3 as y),
                          STRUCT(a.field_4 as x, a.field_5 as y)
                          ]
                  )                                                 b
    ******************* version with unnest/structs *******************

and

    ********************* version with union all *********************
    select field_1, field_2 as x, field_3 as y
    from some_table
    union all
    select field_1, field_4 as x, field_5 as y
    from some_table
    ********************* version with union all *********************

*/

    insert into `research-01-217611.df_ucd_stage.ucd_diagnosis_claim`
        (uuid, medical_claim_uuid, medical_claim_uuid_array, src_type, savvy_pid, savvy_did, is_restricted, clm_dt, month_id, month_nbr, day_nbr, year_qtr, year_nbr, year_mo, clm_aud_nbr, diag_cd, dx_seq_nbr, icd_ver_cd, mdc_cd, maj_diag_grp_nbr, maj_diag_grp_cd, maj_diag_grp_desc, genl_caus_txt, gdr_spec_desc, gdr_spec_cd, diag_fst4_desc, diag_fst4_cd, diag_fst3_desc, diag_fst3_cd, diag_desc, diag_decm_cd, chrnc_flg_nm, hlth_pln_diag_cd, hlth_pln_diag_desc, ahrq_diag_genl_catgy_cd, ahrq_diag_genl_catgy_nm, ahrq_diag_dtl_catgy_cd, ahrq_diag_dtl_catgy_nm, diag_full_desc, diag_lng_desc, sens_cond_ind, sens_cond_catgy, cms_eligible_encounter_flag, hhs_eligible_encounter_flag, create_datetime, update_datetime
        )

    with
      cte_claim_diag as
        (select
          clm.src_type
          , clm.savvy_pid
          , clm.savvy_did
          , clm.is_restricted
          , clm.clm_dt
          , clm.month_id
          , clm.month_nbr
          , clm.day_nbr
          , clm.year_qtr
          , clm.year_nbr
          , clm.year_mo
          , clm.clm_aud_nbr
          , dx.diag_cd
          , dx.dx_seq_nbr
          , clm.icd_ver_cd
          , clm.cms_eligible_encounter_flag
          , clm.hhs_eligible_encounter_flag
          , min(clm.uuid)                       as medical_claim_uuid           --just pick one uuid for which we know the rest of the claims details...should probably be an array, but...later
          , array_agg(clm.uuid)                 as medical_claim_uuid_array     --should already be distinct, so no reason to add to the processing by enforcing it
        from
          `research-01-217611.df_ucd_stage.udd_medical_claim_enriched`                 clm
          cross join unnest(
                            [
                                STRUCT(clm.dx1_diag_cd AS diag_cd, 1 as dx_seq_nbr),
                                STRUCT(clm.dx2_diag_cd AS diag_cd, 2 as dx_seq_nbr),
                                STRUCT(clm.dx3_diag_cd AS diag_cd, 3 as dx_seq_nbr),
                                STRUCT(clm.dx4_diag_cd AS diag_cd, 4 as dx_seq_nbr),
                                STRUCT(clm.dx5_diag_cd AS diag_cd, 5 as dx_seq_nbr),
                                STRUCT(clm.dx6_diag_cd AS diag_cd, 6 as dx_seq_nbr),
                                STRUCT(clm.dx7_diag_cd AS diag_cd, 7 as dx_seq_nbr),
                                STRUCT(clm.dx8_diag_cd AS diag_cd, 8 as dx_seq_nbr),
                                STRUCT(clm.dx9_diag_cd AS diag_cd, 9 as dx_seq_nbr),
                                STRUCT(clm.dx10_diag_cd AS diag_cd, 10 as dx_seq_nbr),
                                STRUCT(clm.dx11_diag_cd AS diag_cd, 11 as dx_seq_nbr),
                                STRUCT(clm.dx12_diag_cd AS diag_cd, 12 as dx_seq_nbr)
                            ]
                            ) as                                                       dx
        where
          dx.diag_cd <> ''
        group by
          clm.src_type
          , clm.savvy_pid
          , clm.savvy_did
          , clm.is_restricted
          , clm.clm_dt
          , clm.month_id
          , clm.month_nbr
          , clm.day_nbr
          , clm.year_qtr
          , clm.year_nbr
          , clm.year_mo
          , clm.clm_aud_nbr
          , dx.diag_cd
          , dx.dx_seq_nbr
          , clm.icd_ver_cd
          , clm.cms_eligible_encounter_flag
          , clm.hhs_eligible_encounter_flag
        )
    select
        GENERATE_UUID() uuid
        , clm.medical_claim_uuid
        , clm.medical_claim_uuid_array
        , clm.src_type
        , clm.savvy_pid
        , clm.savvy_did
        , clm.is_restricted
        , clm.clm_dt
        , clm.month_id
        , clm.month_nbr
        , clm.day_nbr
        , clm.year_qtr
        , clm.year_nbr
        , clm.year_mo
        , clm.clm_aud_nbr
        , clm.diag_cd
        , clm.dx_seq_nbr
        , clm.icd_ver_cd
        , ifnull(dc.mdc_cd, '') as mdc_cd
        , ifnull(dc.maj_diag_grp_nbr, '') as maj_diag_grp_nbr
        , ifnull(dc.maj_diag_grp_cd, '') as maj_diag_grp_cd
        , ifnull(dc.maj_diag_grp_desc, '') as maj_diag_grp_desc
        , ifnull(dc.genl_caus_txt, '') as genl_caus_txt
        , ifnull(dc.gdr_spec_desc, '') as gdr_spec_desc
        , ifnull(dc.gdr_spec_cd, '') as gdr_spec_cd
        , ifnull(dc.diag_fst4_desc, '') as diag_fst4_desc
        , ifnull(dc.diag_fst4_cd, '') as diag_fst4_cd
        , ifnull(dc.diag_fst3_desc, '') as diag_fst3_desc
        , ifnull(dc.diag_fst3_cd, '') as diag_fst3_cd
        , ifnull(dc.diag_desc, '') as diag_desc
        , ifnull(dc.diag_decm_cd, '') as diag_decm_cd
        , ifnull(dc.chrnc_flg_nm, '') as chrnc_flg_nm
        , ifnull(dc.hlth_pln_diag_cd, '') as hlth_pln_diag_cd
        , ifnull(dc.hlth_pln_diag_desc, '') as hlth_pln_diag_desc
        , ifnull(dc.ahrq_diag_genl_catgy_cd, 0) as ahrq_diag_genl_catgy_cd
        , ifnull(dc.ahrq_diag_genl_catgy_nm, '') as ahrq_diag_genl_catgy_nm
        , ifnull(dc.ahrq_diag_dtl_catgy_cd, 0) as ahrq_diag_dtl_catgy_cd
        , ifnull(dc.ahrq_diag_dtl_catgy_nm, '') as ahrq_diag_dtl_catgy_nm
        , ifnull(dc.diag_full_desc, '') as diag_full_desc
        , ifnull(dc.diag_lng_desc, '') as diag_lng_desc
        , ifnull(dc.sens_cond_ind, '') as sens_cond_ind
        , ifnull(dc.sens_cond_catgy, '') as sens_cond_catgy
        , clm.cms_eligible_encounter_flag
        , clm.hhs_eligible_encounter_flag
        , current_datetime() as create_datetime
        , current_datetime() as update_datetime
      from
          cte_claim_diag                                                               clm
          left join `research-01-217611.df_ucd_stage.dim_diagnosis_code`               dc on clm.diag_cd      =   dc.diag_cd     --this table's already 1 record per (diag_cd, icd_ver_cd)
                                                                                          and clm.icd_ver_cd  =   dc.icd_ver_cd
          --and clm.savvy_pid between 1 and 100000
          --and diag_cd is not null       --handled in mapping process
          --and trim(diag_cd)<>'hpdmx'    --if we want to exclude these we should handle it in the mapping process...there aren't many of them, in any case
      ;


    insert into `research-01-217611.df_ucd_stage.ucd_diagnosis_claim_ihr`
      (uuid, medical_claim_uuid, medical_claim_uuid_array, src_type, savvy_pid, savvy_did, is_restricted, clm_dt, month_id, month_nbr, day_nbr, year_qtr, year_nbr, year_mo, clm_aud_nbr, diag_cd, dx_seq_nbr, icd_ver_cd, mdc_cd, maj_diag_grp_nbr, maj_diag_grp_cd, maj_diag_grp_desc, genl_caus_txt, gdr_spec_desc, gdr_spec_cd, diag_fst4_desc, diag_fst4_cd, diag_fst3_desc, diag_fst3_cd, diag_desc, diag_decm_cd, chrnc_flg_nm, hlth_pln_diag_cd, hlth_pln_diag_desc, ahrq_diag_genl_catgy_cd, ahrq_diag_genl_catgy_nm, ahrq_diag_dtl_catgy_cd, ahrq_diag_dtl_catgy_nm, diag_full_desc, diag_lng_desc, sens_cond_ind, sens_cond_catgy, cms_eligible_encounter_flag, hhs_eligible_encounter_flag, create_datetime, update_datetime
      )
    with
      cte_claim_diag as
        (select
          clm.src_type
          , clm.savvy_pid
          , clm.savvy_did
          , clm.is_restricted
          , clm.clm_dt
          , clm.month_id
          , clm.month_nbr
          , clm.day_nbr
          , clm.year_qtr
          , clm.year_nbr
          , clm.year_mo
          , clm.clm_aud_nbr
          , dx.diag_cd
          , dx.dx_seq_nbr
          , clm.icd_ver_cd
          , clm.cms_eligible_encounter_flag
          , clm.hhs_eligible_encounter_flag
          , min(clm.uuid)                       as medical_claim_uuid         --just pick one uuid for which we know the rest of the claims details
          , array_agg(clm.uuid)                 as medical_claim_uuid_array   --should already be distinct, so no reason to add to the processing by enforcing it
        from
          `research-01-217611.df_ucd_stage.udd_medical_claim_ihr_enriched`             clm
          cross join unnest(
                            [
                                STRUCT(clm.dx1_diag_cd AS diag_cd, 1 as dx_seq_nbr),
                                STRUCT(clm.dx2_diag_cd AS diag_cd, 2 as dx_seq_nbr),
                                STRUCT(clm.dx3_diag_cd AS diag_cd, 3 as dx_seq_nbr),
                                STRUCT(clm.dx4_diag_cd AS diag_cd, 4 as dx_seq_nbr),
                                STRUCT(clm.dx5_diag_cd AS diag_cd, 5 as dx_seq_nbr),
                                STRUCT(clm.dx6_diag_cd AS diag_cd, 6 as dx_seq_nbr),
                                STRUCT(clm.dx7_diag_cd AS diag_cd, 7 as dx_seq_nbr),
                                STRUCT(clm.dx8_diag_cd AS diag_cd, 8 as dx_seq_nbr),
                                STRUCT(clm.dx9_diag_cd AS diag_cd, 9 as dx_seq_nbr),
                                STRUCT(clm.dx10_diag_cd AS diag_cd, 10 as dx_seq_nbr),
                                STRUCT(clm.dx11_diag_cd AS diag_cd, 11 as dx_seq_nbr),
                                STRUCT(clm.dx12_diag_cd AS diag_cd, 12 as dx_seq_nbr)
                            ]
                            ) as                                                       dx
        where
          dx.diag_cd <> ''
        group by
          clm.src_type
          , clm.savvy_pid
          , clm.savvy_did
          , clm.is_restricted
          , clm.clm_dt
          , clm.month_id
          , clm.month_nbr
          , clm.day_nbr
          , clm.year_qtr
          , clm.year_nbr
          , clm.year_mo
          , clm.clm_aud_nbr
          , dx.diag_cd
          , dx.dx_seq_nbr
          , clm.icd_ver_cd
          , clm.cms_eligible_encounter_flag
          , clm.hhs_eligible_encounter_flag
        )
    select
        GENERATE_UUID() uuid
        , clm.medical_claim_uuid
        , clm.medical_claim_uuid_array
        , clm.src_type
        , clm.savvy_pid
        , clm.savvy_did
        , clm.is_restricted
        , clm.clm_dt
        , clm.month_id
        , clm.month_nbr
        , clm.day_nbr
        , clm.year_qtr
        , clm.year_nbr
        , clm.year_mo
        , clm.clm_aud_nbr
        , clm.diag_cd
        , clm.dx_seq_nbr
        , clm.icd_ver_cd
        , ifnull(dc.mdc_cd, '') as mdc_cd
        , ifnull(dc.maj_diag_grp_nbr, '') as maj_diag_grp_nbr
        , ifnull(dc.maj_diag_grp_cd, '') as maj_diag_grp_cd
        , ifnull(dc.maj_diag_grp_desc, '') as maj_diag_grp_desc
        , ifnull(dc.genl_caus_txt, '') as genl_caus_txt
        , ifnull(dc.gdr_spec_desc, '') as gdr_spec_desc
        , ifnull(dc.gdr_spec_cd, '') as gdr_spec_cd
        , ifnull(dc.diag_fst4_desc, '') as diag_fst4_desc
        , ifnull(dc.diag_fst4_cd, '') as diag_fst4_cd
        , ifnull(dc.diag_fst3_desc, '') as diag_fst3_desc
        , ifnull(dc.diag_fst3_cd, '') as diag_fst3_cd
        , ifnull(dc.diag_desc, '') as diag_desc
        , ifnull(dc.diag_decm_cd, '') as diag_decm_cd
        , ifnull(dc.chrnc_flg_nm, '') as chrnc_flg_nm
        , ifnull(dc.hlth_pln_diag_cd, '') as hlth_pln_diag_cd
        , ifnull(dc.hlth_pln_diag_desc, '') as hlth_pln_diag_desc
        , ifnull(dc.ahrq_diag_genl_catgy_cd, 0) as ahrq_diag_genl_catgy_cd
        , ifnull(dc.ahrq_diag_genl_catgy_nm, '') as ahrq_diag_genl_catgy_nm
        , ifnull(dc.ahrq_diag_dtl_catgy_cd, 0) as ahrq_diag_dtl_catgy_cd
        , ifnull(dc.ahrq_diag_dtl_catgy_nm, '') as ahrq_diag_dtl_catgy_nm
        , ifnull(dc.diag_full_desc, '') as diag_full_desc
        , ifnull(dc.diag_lng_desc, '') as diag_lng_desc
        , ifnull(dc.sens_cond_ind, '') as sens_cond_ind
        , ifnull(dc.sens_cond_catgy, '') as sens_cond_catgy
        , clm.cms_eligible_encounter_flag
        , clm.hhs_eligible_encounter_flag
        , current_datetime() as create_datetime
        , current_datetime() as update_datetime
      from
          cte_claim_diag                                                               clm
          left join `research-01-217611.df_ucd_stage.dim_diagnosis_code`               dc on clm.diag_cd      =   dc.diag_cd     --this table's already 1 record per (diag_cd, icd_ver_cd)
                                                                                          and clm.icd_ver_cd  =   dc.icd_ver_cd
          --and clm.savvy_pid between 1 and 100000
          --and diag_cd is not null       --handled in mapping process
          --and trim(diag_cd)<>'hpdmx'    --if we want to exclude these we should handle it in the mapping process...there aren't many of them, in any case
      ;


    /**Code from Seth - add this all queries with appropriate description for 'job' */
insert into `research-01-217611.df_ucd_stage.logging`(
    success_flag, job, message_datetime)
  select
    1 as success_flag
    , 'create diagnosis claim table (sourced from df_ucd_stage.udd_medical_claim_enriched)' as job
    , current_datetime as message_datetime
  ;

  EXCEPTION WHEN ERROR THEN
    insert into `research-01-217611.df_ucd_stage.logging`(
      success_flag, job, error_message, statement_text, formatted_stack_trace, message_datetime)
    select
      0 as success_flag
      , 'create diagnosis claim table (sourced from df_ucd_stage.udd_medical_claim_enriched)' as job
      , @@error.message as error_message
      , @@error.statement_text as statement_text
      , @@error.formatted_stack_trace as formatted_stack_trace
      , current_datetime as message_datetime

;

END;

/* validation */
/*noticed many records (sourced from allsavers, ugap) with diag cd - 'hpdmx' */
/*see 2nd query below*/

/*select diag_cd,count(*) as records
from `research-01-217611.df_ucd_stage.ucd_diagnosis_claim`
group by diag_cd
order by records desc

select diag_cd,src_type,count(*) as records
from `research-01-217611.df_ucd_stage.ucd_diagnosis_claim` d
inner join `research-01-217611.df_ucd.medical_claim` m on
 d.ucd_medical_claim_uuid=m.uuid
where diag_cd='hpdmx'
group by diag_cd,src_type */
