/***
Universal Claims Data Model - SMA Pharmacy Claim Mapping (new paradigm)

Date Created: 22 October 2020
***/

BEGIN

  -- delete
  -- from `research-01-217611.df_ucd_stage.udd_pharmacy_claim_sma`
  -- where 1=1
  -- ;

  insert into `research-01-217611.df_ucd_stage.udd_pharmacy_claim_sma`
    (uuid, savvy_pid, savvy_did, is_restricted, fill_dt, pharmacy_name, pharmacy_claim_id, pharmacy_address, pharmacy_city, pharmacy_state, pharmacy_zip, prescription_number,
      prescriber_id, prescriber_first_name, prescriber_last_name, drug_manufacturer, label_name, otc_indicator, prior_authorization_number, rx_network_id, plan_drug_status,
      product_id, business_line, prov_id, prov_fst_nm, prov_lst_nm, prov_tin, site_cd, prov_mpin, prov_zip_cd, prov_typ_nm, spec_typ_nm,
      refill, drg_strgth_unit_desc, drg_strgth_nbr, brnd_nm, gnrc_nm, ndc, dosage_fm_desc, ext_ahfs_thrptc_clss_cd, ext_ahfs_thrptc_clss_desc, genericindicator, maint_drug_ind, gpi,
      sbmt_full_dt, qty_cnt, scrpt_cnt, day_cnt,
      usual_and_customary_cost, allw_amt, net_pd_amt, oop_amt, copay_amt, ded_amt, coins_amt, src_type, source, claim_status, create_datetime, update_datetime
    )
  select GENERATE_UUID() uuid
    , a.savvy_pid
    , a.savvy_did
    , a.is_restricted
    , a.fill_date as fill_dt
    , ifnull(lower(trim(b.pharmacy_name)), '') AS pharmacy_name
    , ifnull(lower(trim(a.rxclaim_id)), '') AS pharmacy_claim_id
    , ifnull(lower(trim(b.pharmacy_address)), '') AS pharmacy_address
    , ifnull(lower(trim(b.pharmacy_city)), '') AS pharmacy_city
    , ifnull(lower(trim(b.pharmacy_state)), '') AS pharmacy_state
    , ifnull(lower(trim(b.pharmacy_zip)), '') AS pharmacy_zip
    , ifnull(lower(trim(a.prescription_number)), '') AS prescription_number
    , ifnull(lower(trim(a.prescriber_id)), '') AS prescriber_id
    , ifnull(lower(trim(a.prescriber_first_name)), '') AS prescriber_first_name
    , ifnull(lower(trim(a.prescriber_last_name)), '') AS prescriber_last_name
    , ifnull(lower(trim(a.drug_manufacturer)), '') AS drug_manufacturer
    , ifnull(lower(trim(a.label_name)), '') AS label_name
    , ifnull(lower(trim(a.otc_indicator)), '') AS otc_indicator
    , ifnull(lower(trim(a.prior_auth_nbr)), '') AS prior_authorization_number
    , ifnull(lower(trim(a.rx_network)), '') AS rx_network_id
    , ifnull(lower(trim(a.plan_drug_status)), '') AS plan_drug_status
    , ifnull(lower(trim(a.facets_product_id)), '') AS product_id
    , ifnull(lower(trim(a.business_line)), '') AS business_line
    , '' as prov_id
    , '' as prov_fst_nm
    , '' as prov_lst_nm
    , '' as prov_tin
    , '' as site_cd
    , 0 as prov_mpin
    , '' as prov_zip_cd
    , '' as prov_typ_nm
    , '' as spec_typ_nm
    , ifnull(lower(trim(a.refill)), '') AS refill
    , '' AS drg_strgth_unit_desc
    , 0 AS drg_strgth_nbr
    , '' AS brnd_nm
    , '' AS gnrc_nm
    , ifnull(lower(trim(a.ndc)), '') AS ndc
    , ifnull(lower(trim(a.route_of_admin)), '') AS dosage_fm_desc
    , ifnull(safe_cast(lower(trim(a.thera_class)) as int64), 0) as ext_ahfs_thrptc_clss_cd
    , '' as ext_ahfs_thrptc_clss_desc
    , ifnull(lower(trim(a.generic_indicator)), '') AS genericindicator
    , 0 as maint_drug_ind
    , ifnull(lower(trim(a.gpi)), '') as gpi
    , a.submit_date
    , ifnull(a.metric_quantity, 0) as qty_cnt
    , 1 as scrpt_cnt
    , ifnull(a.days_supply, 0) as day_cnt
    , safe_cast(a.usual_and_customary_cost as numeric) as usual_and_customary_cost
    , safe_cast(a.patient_pay_amt + a.plan_pay_amt as numeric) as allw_amt
    , safe_cast(a.plan_pay_amt as numeric) as net_pd_amt  --I'm not sure of this....
    , safe_cast(a.patient_pay_amt as numeric) as oop_amt
    , 0 as copay_amt
    , 0 as ded_amt
    , 0 as coins_amt
    , 'sma' as src_type
    , '' as source
    , lower(trim(a.claim_status)) as claim_status
    , current_datetime() as create_datetime
    , current_datetime() as update_datetime
  from `ds-00-191017.sierrahealth_sma_final.pharmacy` a
  left join `ds-00-191017.sierrahealth_sma_final.pharmacy_ref` b on lower(trim(a.pharmacy_id)) = lower(trim(b.pharmacy_number))
  where date_add(a.fill_date, interval greatest(0, days_supply - 1) day) >= '2016-01-01'
    -- and a.is_restricted = 0
  --86,700,488
  --47,206,159
  ;


    --if successful, we'll get here!
    insert into `research-01-217611.df_ucd_stage.logging`(
      success_flag, job, message_datetime)
    select
      1 as success_flag
      , 'map sma pharmacy claims' as job
      , current_datetime as message_datetime
    ;

    EXCEPTION WHEN ERROR THEN
      insert into `research-01-217611.df_ucd_stage.logging`(
        success_flag, job, error_message, statement_text, formatted_stack_trace, message_datetime)
      select
        0 as success_flag
        , 'map sma pharmacy claims' as job
        , @@error.message as error_message
        , @@error.statement_text as statement_text
        , @@error.formatted_stack_trace as formatted_stack_trace
        , current_datetime as message_datetime
      ;
END
;
