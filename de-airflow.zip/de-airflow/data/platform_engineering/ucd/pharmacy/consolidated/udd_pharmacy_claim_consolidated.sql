/* Project: Universal Claims Database (UCD )
   Business Partner: Matt Holst
   Input: udd_pharmacy_claim_galaxy;udd_pharmacy_claim_ugap;udd_pharmacy_claim_sma;udd_pharmacy_claim_miniov
   Created By: Sachin
   Created Date:6/29/2020
   Granularity:  Member/fill dt/NDC/$$ (Jan 2016 thru most recent,except galaxy claims, which has fills from 2017 onwards)
   Modified By: Sachin
   Modified Date: 7/16/2020
   Change: Modified query to append Miniov claims.
   Description: This query uses below logic to pull pharmacy claims from UDD tables (see Input).
   Tiebreaker logic is determined by source hierarchy (#1-UGAP, #2- SMA and #3-Galaxy) based on SPID, fill date, and NDC code.
   If a member has the same information from UGAP and Galaxy then the record from UGAP is kept because it takes precedence over Galaxy in hierarchy order.*/

BEGIN

  -- delete
  -- from `research-01-217611.df_ucd_stage.udd_pharmacy_claim_consolidated`
  -- where 1=1
  -- ;

  insert into `research-01-217611.df_ucd_stage.udd_pharmacy_claim_consolidated`

    (uuid, savvy_pid, savvy_did, is_restricted, fill_dt, pharmacy_name, pharmacy_claim_id, pharmacy_address, pharmacy_city, pharmacy_state, pharmacy_zip, prescription_number,
      prescriber_id, prescriber_first_name, prescriber_last_name, drug_manufacturer, label_name, otc_indicator, prior_authorization_number, rx_network_id, plan_drug_status,
      product_id, business_line, prov_id, prov_fst_nm, prov_lst_nm, prov_tin, site_cd, prov_mpin, prov_zip_cd, prov_typ_nm, spec_typ_nm,
      refill, drg_strgth_unit_desc, drg_strgth_nbr, brnd_nm, gnrc_nm, ndc, dosage_fm_desc, ext_ahfs_thrptc_clss_cd, ext_ahfs_thrptc_clss_desc, genericindicator, maint_drug_ind, gpi,
      sbmt_full_dt, qty_cnt, scrpt_cnt, day_cnt,
      usual_and_customary_cost, allw_amt, net_pd_amt, oop_amt, copay_amt, ded_amt, coins_amt, src_type, source, claim_status, create_datetime, update_datetime
    )
    --column contents and order the same in udd_pharmacy_claim_consolidated and each source table
    with
      priority_claim_source as
          (select distinct
            udd.savvy_pid
            , udd.fill_dt
            , udd.ndc
            , udd.src_tbl
            , prty.include_all_claims
            , prty.tiebreaker_priority
            , row_number() over( partition by udd.savvy_pid , udd.fill_dt, udd.ndc
                                 order by prty.tiebreaker_priority
                               ) src_priority_rn
          from `research-01-217611.df_ucd_stage.vw_udd_pharmacy_claim`         udd
            join `research-01-217611.df_ucd_stage.dim_pharmacy_claim_source`   prty  using (src_tbl)
          where prty.include_in_consolidated_table = 1

-- /****************************************/
-- --TEMPORARY FLAG TO FILTER OUT RESTRICTED DATA UNTIL WE HAVE PROCESSES IN PLACE TO SEGREGATE IT
--            and is_restricted = 0
-- /****************************************/

          group by udd.savvy_pid
            , udd.fill_dt
            , udd.ndc
            , udd.src_tbl
            , prty.include_all_claims
            , prty.tiebreaker_priority
          )
    select
      udd.uuid, udd.savvy_pid, udd.savvy_did, udd.is_restricted, udd.fill_dt, udd.pharmacy_name, udd.pharmacy_claim_id, udd.pharmacy_address, udd.pharmacy_city, udd.pharmacy_state, udd.pharmacy_zip, udd.prescription_number,
      udd.prescriber_id, udd.prescriber_first_name, udd.prescriber_last_name, udd.drug_manufacturer, udd.label_name, udd.otc_indicator, udd.prior_authorization_number, udd.rx_network_id, udd.plan_drug_status,
      udd.product_id, udd.business_line, udd.prov_id, udd.prov_fst_nm, udd.prov_lst_nm, udd.prov_tin, udd.site_cd, udd.prov_mpin, udd.prov_zip_cd, udd.prov_typ_nm, udd.spec_typ_nm,
      udd.refill, udd.drg_strgth_unit_desc, udd.drg_strgth_nbr, udd.brnd_nm, udd.gnrc_nm, udd.ndc, udd.dosage_fm_desc, udd.ext_ahfs_thrptc_clss_cd, udd.ext_ahfs_thrptc_clss_desc, udd.genericindicator, udd.maint_drug_ind, udd.gpi,
      udd.sbmt_full_dt, udd.qty_cnt, udd.scrpt_cnt, udd.day_cnt,
      udd.usual_and_customary_cost, udd.allw_amt, udd.net_pd_amt, udd.oop_amt, udd.copay_amt, udd.ded_amt, udd.coins_amt, udd.src_type, udd.source, udd.claim_status, udd.create_datetime, udd.update_datetime
    from
      `research-01-217611.df_ucd_stage.vw_udd_pharmacy_claim`  udd
      join priority_claim_source          prty--using (savvy_pid, fill_dt, ndc, src_tbl) --need to account for missing ndc
                                          on udd.savvy_pid          = prty.savvy_pid
                                          and udd.fill_dt           = prty.fill_dt
                                          and udd.ndc               = prty.ndc            --ensured that these aren't null in the mapping logic
                                          and udd.src_tbl           = prty.src_tbl
    where
      prty.src_priority_rn = 1
      OR
      prty.include_all_claims = 1
    ;

    --if successful, we'll get here!
    insert into `research-01-217611.df_ucd_stage.logging`(
      success_flag, job, message_datetime)
    select
      1 as success_flag
      , 'create consolidated pharmacy claim tables' as job
      , current_datetime as message_datetime
    ;

    EXCEPTION WHEN ERROR THEN
      insert into `research-01-217611.df_ucd_stage.logging`(
        success_flag, job, error_message, statement_text, formatted_stack_trace, message_datetime)
      select
        0 as success_flag
        , 'create consolidated pharmacy claim tables' as job
        , @@error.message as error_message
        , @@error.statement_text as statement_text
        , @@error.formatted_stack_trace as formatted_stack_trace
        , current_datetime as message_datetime
      ;
END
;
