/* Project: Universal Claims Database (UCD )
   Business Partner: Matt Holst
   Input: bind_final
   Created By: Prerana
   Reference : Seth (https://code.savvysherpa.com/DataOperations/UCD-version-2.0/blob/master/Unified_Data_Model/UGAP%20Mapping/udd_pharmacy_claims_ugap.sql)
   Created Date: 11/23/2020
   Granularity:  Claim/line detail                                    */

  /**Used placeholders (null) for fields that are not currently not available in UGAP claim table **/

BEGIN

  -- delete
  -- from `research-01-217611.df_ucd_stage.udd_pharmacy_claim_bind`
  -- where 1=1
  -- ;

  insert into `research-01-217611.df_ucd_stage.udd_pharmacy_claim_bind`
    (uuid, savvy_pid, savvy_did, is_restricted, fill_dt, pharmacy_name, pharmacy_claim_id, pharmacy_address, pharmacy_city, pharmacy_state, pharmacy_zip, prescription_number,
      prescriber_id, prescriber_first_name, prescriber_last_name, drug_manufacturer, label_name, otc_indicator, prior_authorization_number, rx_network_id, plan_drug_status,
      product_id, business_line, prov_id, prov_fst_nm, prov_lst_nm, prov_tin, site_cd, prov_mpin, prov_zip_cd, prov_typ_nm, spec_typ_nm,
      refill, drg_strgth_unit_desc, drg_strgth_nbr, brnd_nm, gnrc_nm, ndc, dosage_fm_desc, ext_ahfs_thrptc_clss_cd, ext_ahfs_thrptc_clss_desc, genericindicator, maint_drug_ind, gpi,
      sbmt_full_dt, qty_cnt, scrpt_cnt, day_cnt,
      usual_and_customary_cost, allw_amt, net_pd_amt, oop_amt, copay_amt, ded_amt, coins_amt, src_type, source, claim_status, create_datetime, update_datetime
    )
  select
    uuid, savvy_pid, savvy_did, is_restricted, fill_dt, pharmacy_name, pharmacy_claim_id, pharmacy_address, pharmacy_city, pharmacy_state, pharmacy_zip, prescription_number,
    prescriber_id, prescriber_first_name, prescriber_last_name, drug_manufacturer, label_name, otc_indicator, prior_authorization_number, rx_network_id, plan_drug_status,
    product_id, business_line, prov_id, prov_fst_nm, prov_lst_nm, prov_tin, site_cd, prov_mpin, prov_zip_cd, prov_typ_nm, spec_typ_nm,
    refill, drg_strgth_unit_desc, drg_strgth_nbr, brnd_nm, gnrc_nm, ndc, dosage_fm_desc, ext_ahfs_thrptc_clss_cd, ext_ahfs_thrptc_clss_desc, genericindicator, maint_drug_ind, gpi,
    sbmt_full_dt, qty_cnt, scrpt_cnt, day_cnt,
    usual_and_customary_cost, allw_amt, net_pd_amt, oop_amt, copay_amt, ded_amt, coins_amt, src_type, source, claim_status,

    current_datetime() as create_datetime,
    current_datetime() as update_datetime
  from
   (select
      GENERATE_UUID() uuid
      , savvy_pid AS savvy_pid
      , savvy_did AS savvy_did
      , is_restricted AS is_restricted
      , date_of_service  AS fill_dt

      , ifnull(lower(trim(clm.pharmacy_name)),'') AS pharmacy_name
      , ifnull(lower(trim(clm.claim_id)),'') AS pharmacy_claim_id
      , ifnull(trim  (concat(ifnull(lower(trim(clm.pharmacy_address_line1)),'')
                              ,' '
                              , ifnull(lower(trim(clm.pharmacy_address_line_2)),'')))
                ,'') AS pharmacy_address
      , ifnull(lower(trim(pharmacy_city)),'') AS pharmacy_city
      , ifnull(lower(trim(pharmacy_state)),'') AS pharmacy_state
      , ifnull(lower(trim(pharmacy_zip_code)),'') AS pharmacy_zip

      , ifnull(lower(trim(prescription_number)),'') AS prescription_number
      , ifnull(lower(trim(prescriber_id)),'') AS prescriber_id
      , array_length(split(lower(trim(prescriber_name)),'  ')) as pres
      , CASE WHEN prescriber_name is not null and array_length(split(lower(trim(prescriber_name)),'  '))=2
                  then trim(split(lower(trim(prescriber_name)),'  ')[offset(1)])
             else '' end as prescriber_first_name
      , CASE WHEN prescriber_name is not null
                  then trim(split(lower(trim(prescriber_name)),'  ')[offset(0)])
              else '' end as prescriber_last_name
     --FORBERG  JULIA MIKICH  YELENA
      , ''  AS drug_manufacturer
      , ''  AS label_name
      , '' AS otc_indicator
      , ifnull(lower(trim(clm.prior_authorization_number )),'') AS prior_authorization_number

      , '' AS rx_network_id
      , '' AS plan_drug_status
      , '' AS product_id
      , '' AS business_line
      , '' AS prov_id

      , '' AS prov_fst_nm
      , '' AS prov_lst_nm
      , '' AS prov_tin
      , '' AS site_cd
      , 0 AS prov_mpin
      , '' AS prov_zip_cd
      , '' AS prov_typ_nm
      , '' AS spec_typ_nm

      , ifnull(lower(trim(clm.fill_number)),'') AS refill

      , '' AS drg_strgth_unit_desc

      , ifnull(clm.drug_strength, 0) AS drg_strgth_nbr
      , ifnull(lower(trim(clm.brand_name)),'') AS brnd_nm
      , ifnull(lower(trim(clm.generic_product_name )),'') AS gnrc_nm
      , ifnull(lower(trim(clm.ndc_code)), '') AS ndc
      , ifnull(lower(trim(clm.dosage_form_code )), '') AS dosage_fm_desc

      , 0 AS ext_ahfs_thrptc_clss_cd
      , '' AS ext_ahfs_thrptc_clss_desc
      , case  when lower(trim(clm.brand_generic_indicator)) ='g' then 'y'
              when lower(trim(clm.brand_generic_indicator)) = 'b' then 'n'
              else '' end AS genericindicator
      -- select distinct maint_drug_ind from `df_ucd_stage.ucd_pharmacy_claim_enriched`
      , case  when lower(trim(clm.maintenance_drug_indicator)) ='y' then 1
              else 0 end AS maint_drug_ind
      , ifnull(lower(trim(clm.generic_product_identifier)),'') AS gpi
      , date(clm.submit_datetime) AS sbmt_full_dt
      , ifnull(clm.metric_decimal_quantity, 0) AS qty_cnt
      , 1 AS scrpt_cnt
      , cast(ifnull(clm.days_supply, 0) as int64) AS day_cnt
      , cast(case when lower(trim(clm.cost_description)) in ('u&c','billed') then clm.member_responsibility_amount
             else 0 end as numeric) AS usual_and_customary_cost

      , 0 as allw_amt --safe_cast(clm.member_responsibility_amount + clm.plan_paid_amount as numeric) AS allw_amt
      , safe_cast(clm.plan_paid_amount as numeric) AS net_pd_amt
      , 0 AS oop_amt
      , safe_cast(clm.member_responsibility_amount as numeric) AS copay_amt
      , 0 AS ded_amt
      , 0 AS coins_amt

      , "bind" AS src_type
      , 'ds-00-191017.bind_final.pharmacy_claim' AS source
      , case when trim(lower(claim_status)) = 'paid' then 'p'
             when trim(lower(claim_status)) = 'reversal' then 'x'
             else 'r' end AS claim_status
   from `ds-00-191017.bind_final.pharmacy_claim`          clm
    )
  ;
--433951
  --if successful, we'll get here!
  insert into `research-01-217611.df_ucd_stage.logging`(
    success_flag, job, message_datetime)
  select
    1 as success_flag
    , 'map bind pharmacy claims' as job
    , current_datetime as message_datetime
  ;

  EXCEPTION WHEN ERROR THEN
    insert into `research-01-217611.df_ucd_stage.logging`(
      success_flag, job, error_message, statement_text, formatted_stack_trace, message_datetime)
    select
      0 as success_flag
      , 'map bind pharmacy claims' as job
      , @@error.message as error_message
      , @@error.statement_text as statement_text
      , @@error.formatted_stack_trace as formatted_stack_trace
      , current_datetime as message_datetime
    ;

END
;
