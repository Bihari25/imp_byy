/* Project: Universal Claims Database (UCD )
   Business Partner: Matt Holst
   Created By: Seth
   Created Date: 11/23/2020
   Granularity:  match umr_final
*/

BEGIN

  -- delete
  -- from `research-01-217611.df_ucd_stage.udd_pharmacy_claim_umr`
  -- where 1=1
  -- ;

  insert into `research-01-217611.df_ucd_stage.udd_pharmacy_claim_umr`
    (uuid, savvy_pid, savvy_did, is_restricted, fill_dt, pharmacy_name, pharmacy_claim_id, pharmacy_address, pharmacy_city, pharmacy_state, pharmacy_zip, prescription_number,
      prescriber_id, prescriber_first_name, prescriber_last_name, drug_manufacturer, label_name, otc_indicator, prior_authorization_number, rx_network_id, plan_drug_status,
      product_id, business_line, prov_id, prov_fst_nm, prov_lst_nm, prov_tin, site_cd, prov_mpin, prov_zip_cd, prov_typ_nm, spec_typ_nm,
      refill, drg_strgth_unit_desc, drg_strgth_nbr, brnd_nm, gnrc_nm, ndc, dosage_fm_desc, ext_ahfs_thrptc_clss_cd, ext_ahfs_thrptc_clss_desc, genericindicator, maint_drug_ind, gpi,
      sbmt_full_dt, qty_cnt, scrpt_cnt, day_cnt,
      usual_and_customary_cost, allw_amt, net_pd_amt, oop_amt, copay_amt, ded_amt, coins_amt, src_type, source, claim_status, create_datetime, update_datetime
    )
     select
       uuid, savvy_pid, savvy_did, is_restricted, fill_dt, pharmacy_name, pharmacy_claim_id, pharmacy_address, pharmacy_city, pharmacy_state, pharmacy_zip, prescription_number,
       prescriber_id, prescriber_first_name, prescriber_last_name, drug_manufacturer, label_name, otc_indicator, prior_authorization_number, rx_network_id, plan_drug_status,
       product_id, business_line, prov_id, prov_fst_nm, prov_lst_nm, prov_tin, site_cd, prov_mpin, prov_zip_cd, prov_typ_nm, spec_typ_nm,
       refill, drg_strgth_unit_desc, drg_strgth_nbr, brnd_nm, gnrc_nm, ndc, dosage_fm_desc, ext_ahfs_thrptc_clss_cd, ext_ahfs_thrptc_clss_desc, genericindicator, maint_drug_ind, gpi,
       sbmt_full_dt, qty_cnt, scrpt_cnt, day_cnt,
       usual_and_customary_cost, allw_amt, net_pd_amt, oop_amt, copay_amt, ded_amt, coins_amt, src_type, source, claim_status,

       current_datetime() as create_datetime,
       current_datetime() as update_datetime
     from
       (select
         GENERATE_UUID() uuid
         , savvy_pid AS savvy_pid
         , savvy_did AS savvy_did
         , is_restricted AS is_restricted
         , dt.full_dt  AS fill_dt
         , '' AS pharmacy_name
         , '' AS pharmacy_claim_id
         , '' AS pharmacy_address
         , '' AS pharmacy_city
         , '' AS pharmacy_state
         , '' AS pharmacy_zip
         , '' AS prescription_number
         , '' AS prescriber_id
         , '' AS prescriber_first_name
         , '' AS prescriber_last_name
         , '' AS drug_manufacturer
         , '' AS label_name
         , '' AS otc_indicator
         , '' AS prior_authorization_number
         , '' AS rx_network_id
         , '' AS plan_drug_status
         , '' AS product_id
         , '' AS business_line
         , '' AS prov_id
         , ifnull(lower(trim(prov.prov_fst_nm)), '') AS prov_fst_nm
         , ifnull(lower(trim(prov.prov_lst_nm)), '') AS prov_lst_nm
         , ifnull(lower(trim(prov.tin)), '') AS prov_tin
         , ifnull(lower(trim(prov.site_cd)), '') AS site_cd
         , ifnull(prov.mpin, 0) AS prov_mpin
         , ifnull(lower(trim(prov.zip_cd)), '') AS prov_zip_cd
         , '' AS prov_typ_nm
         , '' AS spec_typ_nm
         , '' AS refill
         , ifnull(lower(trim(ndc.drg_strgth_unit_desc)), '') AS drg_strgth_unit_desc
         , ifnull(ndc.drg_strgth_nbr, 0) AS drg_strgth_nbr
         , ifnull(lower(trim(ndc.brnd_nm)), '') AS brnd_nm
         , ifnull(lower(trim(ndc.gnrc_nm)), '') AS gnrc_nm
         , ifnull(lower(trim(ndc.ndc)), '') AS ndc
         , ifnull(lower(trim(ndc.dosage_fm_desc)), '') AS dosage_fm_desc
         , ifnull(safe_cast(ndc.ext_ahfs_thrptc_clss_cd as int64), 0) AS ext_ahfs_thrptc_clss_cd
         , ifnull(lower(trim(ndc.ext_ahfs_thrptc_clss_desc)), '') AS ext_ahfs_thrptc_clss_desc
         , ifnull(lower(trim(clm.brnd_gnrc_cd)), '') AS genericindicator
         , 0 AS maint_drug_ind
         , '' AS gpi
         , dt.full_dt AS sbmt_full_dt
         , ifnull(clm.qty_cnt, 0) AS qty_cnt
         , ifnull(clm.scrpt_cnt, 1) AS scrpt_cnt
         , ifnull(clm.day_spl_cnt, 0) AS day_cnt
         , 0 AS usual_and_customary_cost
         , safe_cast(clm.allw_amt as numeric) AS allw_amt
         , safe_cast(clm.pd_amt as numeric) AS net_pd_amt
         , 0 AS oop_amt
         , safe_cast(clm.copay_amt as numeric) AS copay_amt
         , safe_cast(clm.ded_amt as numeric) AS ded_amt
         , 0 AS coins_amt
         , "umr" AS src_type
         , 'ds-00-191017.umr_final.umr_pharmacy' AS source
         , case when allw_amt < 0 then 'x' else 'p' end AS claim_status
       from `ds-00-191017.umr_final.umr_pharmacy`          clm
         join `ds-00-191017.umr_final.hp_date`             dt    on clm.fill_dt_sys_id   =   dt.dt_sys_id
         left join `ds-00-191017.umr_final.provider`       prov  on clm.prov_sys_id      =   prov.prov_sys_id
         left join `ds-00-191017.umr_final.ndc_drug`       ndc   on clm.ndc_drg_sys_id   =   ndc.ndc_drg_sys_id
       -- where
       --   clm.is_restricted = 0
       )
     where
       date_add(fill_dt, interval greatest(0, day_cnt - 1) day) >= '2016-01-01' --scripts good through at least the beginning of 2016
                                                                                --this allows us to compute 2016 coverage for drugs prescribed in 2015
     ;


     --if successful, we'll get here!
     insert into `research-01-217611.df_ucd_stage.logging`(
       success_flag, job, message_datetime)
     select
       1 as success_flag
       , 'map umr pharmacy claims' as job
       , current_datetime as message_datetime
     ;

     EXCEPTION WHEN ERROR THEN
       insert into `research-01-217611.df_ucd_stage.logging`(
         success_flag, job, error_message, statement_text, formatted_stack_trace, message_datetime)
       select
         0 as success_flag
         , 'map umr pharmacy claims' as job
         , @@error.message as error_message
         , @@error.statement_text as statement_text
         , @@error.formatted_stack_trace as formatted_stack_trace
         , current_datetime as message_datetime
       ;
END
;
