/* Project: Universal Claims Database (UCD )
   Business Partner: Matt Holst
   Input:
   Created By: Seth
   Created Date: 6/08/2020
   Modified By: Dave
   Modified Date: 7/13/2020
   Modified input source and columns. Note savvy_pid with -1 values are excluded from
   _all table.
   Granularity:  One record per member/fill dt/ndc/$$/ w/ corrections & reversals                              */



BEGIN

  -- delete
  -- from `research-01-217611.df_ucd_stage.udd_pharmacy_claim_ihr`
  -- where 1=1
  -- ;

insert into `research-01-217611.df_ucd_stage.udd_pharmacy_claim_ihr`
  (uuid, savvy_pid, savvy_did, is_restricted, fill_dt, pharmacy_name, pharmacy_claim_id, pharmacy_address, pharmacy_city, pharmacy_state, pharmacy_zip, prescription_number,
    prescriber_id, prescriber_first_name, prescriber_last_name, drug_manufacturer, label_name, otc_indicator, prior_authorization_number, rx_network_id, plan_drug_status,
    product_id, business_line, prov_id, prov_fst_nm, prov_lst_nm, prov_tin, site_cd, prov_mpin, prov_zip_cd, prov_typ_nm, spec_typ_nm,
    refill, drg_strgth_unit_desc, drg_strgth_nbr, brnd_nm, gnrc_nm, ndc, dosage_fm_desc, ext_ahfs_thrptc_clss_cd, ext_ahfs_thrptc_clss_desc, genericindicator, maint_drug_ind, gpi,
    sbmt_full_dt, qty_cnt, scrpt_cnt, day_cnt,
    usual_and_customary_cost, allw_amt, net_pd_amt, oop_amt, copay_amt, ded_amt, coins_amt, src_type, source, claim_status, create_datetime, update_datetime
  )

WITH RXCLAIM

AS
(Select
   savvy_pid
	 , savvy_did
	 , is_restricted
  ,date_of_service AS fill_dt
  ,SAFE_CAST(FORMAT_DATE('%Y%m',date_of_service) AS INT64)  AS fill_year_mo
  ,ifnull(lower(trim(service_provider_name)), '') AS pharmacy_name
 ,CONCAT(ifnull(lower(trim(rx_claims_number)), ''),ifnull(lower(trim(sequence_number_of_claim)), '')) AS pharmacy_claim_id
 -- ,Null AS pharmacy_address
 -- ,Null AS  pharmacy_city
 -- ,Null AS pharmacy_state
 -- ,Null AS pharmacy_zip
  ,ifnull(lower(trim(prescription_service_reference_number)), '') AS prescription_number
  ,ifnull(lower(trim(prescriber_id)), '') AS prescriber_id
  ,ifnull(lower(trim(prescriber_first_name)), '') AS prescriber_first_name
  ,ifnull(lower(trim(prescriber_last_name)), '')  AS prescriber_last_name
  ,ifnull(lower(trim(product_manufacturer)), '') AS drug_manufacturer
  ,ifnull(lower(trim(product_label_name_with_dosage_form_and_strength)), '') AS label_name
  ,ifnull(lower(trim(drug_rx_otc_indicator)), '') AS otc_indicator
  ,ifnull(lower(trim(prior_authorization_id)), '') AS prior_authorization_number
  ,ifnull(lower(trim(pharmacy_network_code)), '') AS rx_network_id
  ,ifnull(lower(trim(plan_drug_status)), '') AS plan_drug_status
  ,ifnull(lower(trim(product_service_id)), '') AS product_id
  -- ,Null AS product_code
  ,ifnull(lower(trim(prescriber_id)), '') AS prov_id
 -- ,Null AS prov_fst_nm
 -- ,Null AS prov_lst_nm
 -- ,Null AS  prov_tin
 -- ,Null AS site_cd
 -- ,Null AS prov_mpin
 -- ,Null AS prov_zip_cd
 -- ,Null AS prov_typ_nm
 -- ,Null AS spec_typ_nm
  ,ifnull(lower(trim(new_refill_code)), '')  AS refill
  ,ifnull(lower(trim(unit_of_measure)), '') AS drg_strgth_unit_desc
  ,drug_strength AS drg_strgth_nbr
 -- ,NDC.brnd_nm
 -- ,NDC.gnrc_nm
  ,ifnull(lower(trim(product_service_id)), '') AS ndc
  ,ifnull(lower(trim(dosage_form)), '') AS dosage_fm_desc
  ,SAFE_CAST(ahfs_code AS INT64) AS ext_ahfs_thrptc_clss_cd
 -- ,NDC.ahfs_therapeutic_class_desc as ext_ahfs_thrptc_clss_desc
  ,ifnull(lower(trim(brand_name_code)), '') AS genericindicator
  ,SAFE_CAST(lower(maintenance_drug_code) AS INT64) AS maint_drug_ind
  ,ifnull(lower(trim(generic_product_index_gpi)), '') AS gpi
  ,submit_date_ofclaim AS sbmt_full_dt
  ,FORMAT_DATE('%Y%m',submit_date_ofclaim) AS sbmt_year_mo
  ,FORMAT_DATE('%Y',submit_date_ofclaim) AS sbmt_year_nbr
  ,ifnull(metric_decimal_quantity_dispensed_quantity, 0) AS qty_cnt
  ,CASE WHEN metric_decimal_quantity_dispensed_quantity < 0 THen -1 ELSE 1 END AS scrpt_cnt
  ,SAFE_CAST(days_supply AS INT64) AS day_cnt
  ,CAST(usual_and_customary_billing_amount AS NUMERIC) AS usual_and_customary_cost
  ,CAST(total_amount_billed + patient_pay_amount AS NUMERIC) AS allw_amt
  ,CAST(total_amount_billed AS NUMERIC) AS net_pd_amt
  ,CAST(net_patient_pay_out_of_pocket AS NUMERIC) AS oop_amt
  ,CAST(client_copay AS NUMERIC) as copay_amt
  ,CAST(patient_pay_amount_attributed_to_deductible AS NUMERIC) AS ded_amt
  ,CAST(patient_pay_amount - client_copay - patient_pay_amount_attributed_to_deductible AS NUMERIC) AS coins_amt
  ,ifnull(lower(trim(claim_status)), 'p') as claim_status
--	,lower(CONCAT('ihr - ',cast(MEMBER.commercial_flag as string), cast(MEMBER.medicare_flag as string), cast(MEMBER.medicaid_flag as string), cast(MEMBER.dual_flag as string))) as src_type
-- ,'ihr_final.rx' AS source)

    FROM `ds-00-191017`.`ihr_final`.`rx` RXCLAIM

    -- WHERE is_restricted = 0   -- remove claims where member is categorized as restricted

--    date_add(fill_dt, interval greatest(0, day_cnt - 1) day) >= '2017-01-01' --scripts good through at least the beginning of 2017

                                                                             --this allows us to compute 2016 coverage for drugs prescribed in 2015
)

SELECT
 GENERATE_UUID() AS uuid
  ,RXCLAIM.savvy_pid
	,RXCLAIM.savvy_did
	,RxCLAIM.is_restricted
  ,RXCLAIM.fill_dt
  ,RXCLAIM.pharmacy_name
  ,RxCLAIM.pharmacy_claim_id
  ,'' AS pharmacy_address
  ,'' AS  pharmacy_city
  ,'' AS pharmacy_state
  ,'' AS pharmacy_zip
  ,RXCLAIM.prescription_number
  ,RXCLAIM.prescriber_id
  ,RXCLAIM.prescriber_first_name
  ,RXCLAIM.prescriber_last_name
  ,RXCLAIM.drug_manufacturer
  ,RXCLAIM.label_name
  ,RXCLAIM.otc_indicator
  ,RXCLAIM.prior_authorization_number
  ,RXCLAIM.rx_network_id
  ,RXCLAIM.plan_drug_status
  ,RXCLAIM.product_id
 ,lower(CONCAT(cast(MEMBER.commercial_flag as string), cast(MEMBER.medicare_flag as string), cast(MEMBER.medicaid_flag as string), cast(MEMBER.dual_flag as string))) as business_line
  ,RXCLAIM.prov_id
  ,'' AS prov_fst_nm
  ,'' AS prov_lst_nm
  ,'' AS  prov_tin
  ,'' AS site_cd
  ,Null AS prov_mpin
  ,'' AS prov_zip_cd
  ,'' AS prov_typ_nm
  ,'' AS spec_typ_nm
  ,RXCLAIM.refill
  ,RXCLAIM.drg_strgth_unit_desc
  ,RXCLAIM.drg_strgth_nbr
  ,NDC.brnd_nm
  ,NDC.gnrc_nm
  ,RXCLAIM.ndc
  ,RXCLAIM.dosage_fm_desc
  ,RXCLAIM.ext_ahfs_thrptc_clss_cd
  ,NDC.ahfs_therapeutic_class_desc as ext_ahfs_thrptc_clss_desc
  ,RXCLAIM.genericindicator
  ,RXCLAIM.maint_drug_ind
  ,RXCLAIM.gpi
  ,RXCLAIM.sbmt_full_dt
 -- ,RXCLAIM.sbmt_year_mo
 -- ,RXCLAIM.sbmt_year_nbr
  ,RXCLAIM.qty_cnt
  ,RXCLAIM.scrpt_cnt
  ,RXCLAIM.day_cnt
  ,RXCLAIM.usual_and_customary_cost
  ,RXCLAIM.allw_amt
  ,RXCLAIM.net_pd_amt
  ,RXCLAIM.oop_amt
  ,RXCLAIM.copay_amt
  ,RXCLAIM.ded_amt
  ,RXCLAIM.coins_amt
  ,lower(CONCAT('ihr - ',cast(MEMBER.commercial_flag as string), cast(MEMBER.medicare_flag as string), cast(MEMBER.medicaid_flag as string), cast(MEMBER.dual_flag as string))) as src_type
  ,'ihr_final.rx' AS source
  ,RXCLAIM.claim_status

			--metadata columns
 ,current_datetime() as create_datetime


	,current_datetime() as update_datetime


 FROM RXCLAIM

    LEFT JOIN `research-01-217611`.`df_ucd_stage`.`dim_ndc_drug` NDC

    on RXCLAIM.ndc=NDC.ndc
    AND RXCLAIM.fill_dt BETWEEN NDC.ndc_drg_row_eff_dt AND NDC.ndc_drg_row_end_dt

       LEFT JOIN  `research-01-217611`.`df_ucd_stage`.`udw_member_month` MEMBER

	       on RXCLAIM.savvy_pid=MEMBER.savvy_pid AND RXCLAIM.fill_year_mo = MEMBER.year_mo

WHERE

    date_add(fill_dt, interval greatest(0, day_cnt - 1) day) >= '2017-01-01' --scripts good through at least the beginning of 2017

                                                                             --this allows us to compute 2017 coverage for drugs prescribed in 2016

	AND (medicaid_flag = 0 OR medicaid_flag is null)  AND (dual_flag = 0 OR dual_flag is null)-- Exclude Medicaid and allow data w/o member match																  AND (medicaid_flag = 0 OR medicaid_flag is null)  AND (dual_flag = 0 OR dual_flag is null)-- Exclude Medicaid


       -- AND substr(src_type,9,2) in('01','10','11')  -- INCLUDE Medicaid
    --     AND fill_dt = '2020-03-22'
      --   AND RXCLAIM.savvy_pid = 204300039

      --   order by fill_dt, prescription_number,refill

;

--if successful, we'll get here!
insert into `research-01-217611.df_ucd_stage.logging`(
	success_flag, job, message_datetime)
select
	1 as success_flag
	, 'map ihr pharmacy claims' as job
	, current_datetime as message_datetime
;

EXCEPTION WHEN ERROR THEN
	insert into `research-01-217611.df_ucd_stage.logging`(
		success_flag, job, error_message, statement_text, formatted_stack_trace, message_datetime)
	select
		0 as success_flag
		, 'map ihr pharmacy claims' as job
		, @@error.message as error_message
		, @@error.statement_text as statement_text
		, @@error.formatted_stack_trace as formatted_stack_trace
		, current_datetime as message_datetime
	;

END
;
