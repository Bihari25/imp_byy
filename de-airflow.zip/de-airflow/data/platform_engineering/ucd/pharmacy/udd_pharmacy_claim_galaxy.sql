 /* Project: Universal Claims Database (UCD )
   Business Partner: Matt Holst
   Input: galaxy_commercial_pharmacy_claim;df_enrichment.medispan_drug
   Created By: Sachin
   Created Date:6/3/2020
   Modified By: Sachin
   Modified Dates:7/13/2020, 10/21/2020
   7/13 Noticed that medispan table 'df_enrichment.medispan_drug' has multiple records for NDC,
   which might result in duplicates from the main source table(__pharmacy_claim).
   Changed the query to pick the current NDC record (current_flag='y').
  10/21 - Sourced from ds-00 (Per New Data Management Paradigm)
   Granularity: One record per member/fill_dt/ndc/$$                                      */

 BEGIN

  -- delete
  -- from `research-01-217611.df_ucd_stage.udd_pharmacy_claim_galaxy`
  -- where 1=1;

    insert into `research-01-217611.df_ucd_stage.udd_pharmacy_claim_galaxy`
      (uuid, savvy_pid, savvy_did, is_restricted, fill_dt, pharmacy_name, pharmacy_claim_id, pharmacy_address, pharmacy_city, pharmacy_state, pharmacy_zip, prescription_number,
        prescriber_id, prescriber_first_name, prescriber_last_name, drug_manufacturer, label_name, otc_indicator, prior_authorization_number, rx_network_id, plan_drug_status,
        product_id, business_line, prov_id, prov_fst_nm, prov_lst_nm, prov_tin, site_cd, prov_mpin, prov_zip_cd, prov_typ_nm, spec_typ_nm,
        refill, drg_strgth_unit_desc, drg_strgth_nbr, brnd_nm, gnrc_nm, ndc, dosage_fm_desc, ext_ahfs_thrptc_clss_cd, ext_ahfs_thrptc_clss_desc, genericindicator, maint_drug_ind, gpi,
        sbmt_full_dt, qty_cnt, scrpt_cnt, day_cnt,
        usual_and_customary_cost, allw_amt, net_pd_amt, oop_amt, copay_amt, ded_amt, coins_amt, src_type, source, claim_status, create_datetime, update_datetime
      )
    select
      uuid, savvy_pid, savvy_did, is_restricted, fill_dt, pharmacy_name, pharmacy_claim_id, pharmacy_address, pharmacy_city, pharmacy_state, pharmacy_zip, prescription_number,prescriber_id, prescriber_first_name, prescriber_last_name, drug_manufacturer, label_name, otc_indicator, prior_authorization_number, rx_network_id, plan_drug_status,product_id, business_line, prov_id, prov_fst_nm, prov_lst_nm, prov_tin, site_cd, prov_mpin, prov_zip_cd, prov_typ_nm, spec_typ_nm,
      refill, drg_strgth_unit_desc, drg_strgth_nbr, brnd_nm, gnrc_nm, ndc, dosage_fm_desc, ext_ahfs_thrptc_clss_cd, ext_ahfs_thrptc_clss_desc, genericindicator, maint_drug_ind, gpi, sbmt_full_dt, qty_cnt, scrpt_cnt, day_cnt,usual_and_customary_cost, allw_amt, net_pd_amt, oop_amt, copay_amt, ded_amt, coins_amt, src_type, source, claim_status,
      current_datetime() as create_datetime,current_datetime() as update_datetime
    from
      (
      select
          GENERATE_UUID() uuid,
          savvy_pid,
          savvy_did,
          is_restricted,
          fill_dt,
          ifnull(lower(trim(phrm_prov_nm)), '') as pharmacy_name,
          rxs_clm_nbr as pharmacy_claim_id,
          ifnull(lower(trim(prov.pharmacy_address)), '') as pharmacy_address,
          ifnull(lower(trim(prov.pharmacy_city)), '') as  pharmacy_city,
          ifnull(lower(trim(prov.pharmacy_state)), '') as   pharmacy_state,
          ifnull(lower(trim(prov.pharmacy_zip)), '') as  pharmacy_zip,
          prscn_nbr as prescription_number,
          prsc_npi_nbr as prescriber_id,
          '' as prescriber_first_name, /*Galaxy does not contain prescriber names */
          '' as prescriber_last_name,
          ifnull(mp.drug_manufacturer_name, '') as drug_manufacturer,
          ifnull(mp.drug_label_name, '') as label_name,
          '' as otc_indicator,
          prr_auth_nbr as prior_authorization_number,
          in_phrm_ntwk_ind  as rx_network_id,
          rxs_pln_drg_sts_cd as plan_drug_status,
          ifnull(cast(product_id as string), '') as product_id,
          'commercial' as business_line,
          rxs_srvc_prov_id as prov_id,
          '' as prov_fst_nm,
          '' as prov_lst_nm,
          ifnull(prov.fed_tax_id_nbr, '') as prov_tin,
          ifnull(lower(trim(site_cd)), '') as site_cd,
           0 as prov_mpin,
          '' as prov_zip_cd,
          '' as prov_typ_nm,
          '' as spec_typ_nm,
          '' as refill,
          ifnull(lower(trim(ndc.drg_strgth_unit_desc)), '') as drg_strgth_unit_desc,
          ifnull(ndc.drg_strgth_nbr, 0) as drg_strgth_nbr,
          ifnull(lower(trim(ndc.brnd_nm)), '') as brnd_nm,
          ifnull(lower(trim(ndc.gnrc_nm)), '') as gnrc_nm,
          ifnull(lower(trim(ndc.ndc)), '') as ndc,
           ifnull(lower(trim(dosage_fm_desc)), '') as dosage_fm_desc,
           ifnull(safe_cast(rx.ext_ahfs_thrptc_clss_cd as int64), 0) as ext_ahfs_thrptc_clss_cd,
           ifnull(lower(trim(ther.ext_ahfs_thrptc_class_desc)), '') as ext_ahfs_thrptc_clss_desc,
          (case
          when lower(trim(brnd_gnrc_cd))='g' then 'y'
          else ''
          end) as genericindicator,
          0 as maint_drug_ind,
          ifnull(mp.gpi_number, '') as gpi,
          fill_dt as sbmt_full_dt,
          ifnull(qty_cnt, 0) as qty_cnt,
          ifnull(prscn_cnt,1) as scrpt_cnt,
          ifnull(day_spl_cnt, 0) as day_cnt,
          0 as usual_and_customary_cost,
          safe_cast( ingredient_amt+ dspns_fee_amt+ sale_tax_amt as numeric) as allw_amt,
          safe_cast(pd_amt as numeric) as net_pd_amt,
          safe_cast( out_of_pkt_appl_amt as numeric) as oop_amt,
          safe_cast(copay_amt as numeric) as copay_amt,
          safe_cast(ded_amt as numeric) as ded_amt,
          0 as coins_amt,
          "galaxy" as src_type,
          "ds-00-191017.galaxy_final.pharmacy_claims" as source,
           ifnull(lower(trim(rxs_clm_sts_cd)), '') as claim_status
         /*It was requested that claim number and claim seq nbr to be added (Tool Factory ID-1915).Commenting it out
            until UCD team is ready to incorporate them into UDD  */
         /*,rxs_clm_nbr
         ,rxs_clm_seq_nbr  */

from  `ds-00-191017.galaxy_final.pharmacy_claims`  rx
left join (select product_id,drug_manufacturer_name,drug_label_name,gpi_number  from `research-01-217611.df_enrichment.medispan_drug`               where lower(current_flag)='y'
           ) mp
on rx.ndc=mp.product_id
left join (select * except(rn,load_dt) from
                     (select phrm_prov_sys_id,fed_tax_id_nbr,phrm_prov_nm,concat(adr_ln_1_txt,' ',adr_ln_2_txt) as                                             pharmacy_address,p.cty_nm as pharmacy_city,st_abbr_cd as pharmacy_state,p.zip_cd as pharmacy_zip, load_dt,
                       row_number() over (partition by phrm_prov_sys_id order by load_dt desc) as rn from
                       `ds-00-191017.galaxy_final.dim_pharmacy_npi_provider` p
                       left join `research-01-217611.df_enrichment.minihpdm_dim_zip` z

                        on p.zip_cd=z.zip_cd
                        ) where rn=1
            ) prov
on rx.phrm_prov_sys_id=prov.phrm_prov_sys_id
left join (select distinct ext_ahfs_thrptc_class_cd, ext_ahfs_thrptc_class_desc
           from `ds-00-191017.galaxy_final.dim_extended_ahfs_therapeutic_class_code`
           where length(ext_ahfs_thrptc_class_cd)>0
           )ther
on rx.ext_ahfs_thrptc_clss_cd=ther.ext_ahfs_thrptc_class_cd
left join `ds-00-191017.galaxy_final.dim_ndc_drug`  ndc
on trim(lower(ndc.ndc)) = trim(lower(rx.ndc))
and cast(ndc.ndc_drg_row_eff_dt as date) = rx.ndc_drg_row_eff_dt
-- where rx.is_restricted = 0
) rxs
  where date_add(fill_dt, interval greatest(0, day_cnt - 1) day) >= '2016-01-01'

   ;

   --if successful, we'll get here!
   insert into `research-01-217611.df_ucd_stage.logging`(
     success_flag, job, message_datetime)
   select
     1 as success_flag
     , 'map galaxy pharmacy claims' as job
     , current_datetime as message_datetime
   ;

   EXCEPTION WHEN ERROR THEN
     insert into `research-01-217611.df_ucd_stage.logging`(
       success_flag, job, error_message, statement_text, formatted_stack_trace, message_datetime)
     select
       0 as success_flag
       , 'map galaxy pharmacy claims' as job
       , @@error.message as error_message
       , @@error.statement_text as statement_text
       , @@error.formatted_stack_trace as formatted_stack_trace
       , current_datetime as message_datetime
     ;


 END
 ;
