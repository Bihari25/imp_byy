/*
Project: Safegraph Mobility Data
Created date: February 8, 2021
Supplier - ds-00-191017.safegraph_final
Input - neighborhood_panel_summary, cdb_geojson
Process - safeGraph_neighbrPanelSum_load
Output - final_neighborhood_panel_summary
Customer - research-01-217611.df_edp_safegraph_stage

BigQuery Processing time - 324.1MB

Frequency - Monthly
*/

CREATE OR REPLACE TABLE
  `research-01-217611.df_edp_safegraph_stage.final_neighborhood_panel_summary` (--metdata
    year_mo INT64 OPTIONS (description = 'Calendar year month that the first day of the weekly data is in'),
    census_block_group INT64 OPTIONS (description = 'FIPS code for this Census block group'),
    state STRING OPTIONS (description = 'Lowercase abbreviation of U.S. state or territory'),
    county_name STRING OPTIONS (description = 'county name for this CBG'),
    ttl_devices_residing INT64 OPTIONS (description = 'Number of distinct devices observed with a primary nighttime location in the specified census block group.') )
    OPTIONS (description = '') AS
SELECT
  CAST(CONCAT(a.year,'',FORMAT("%02d", a.month)) AS int64) AS year_mo,
  SAFE_CAST(a.census_block_group AS int64) AS census_block_group,
  LOWER(TRIM(a.state)) AS state,
  LOWER(TRIM(b.country)) AS county_name,
  SUM(a.number_devices_residing) AS ttl_devices_residing
FROM
  `ds-00-191017.safegraph_final.neighborhood_panel_summary` AS a
LEFT JOIN
  `ds-00-191017.safegraph_final.cbg_geojson` AS b
ON
  a.census_block_group = b.census_block_group
GROUP BY
  year_mo,
  a.census_block_group,
  a.state,
  county_name