/*
Project: Safegraph Mobility Data
Created date: February 8, 2021
Supplier - ds-00-191017.safegraph_final
Input - social_distancing_metrics, cbg_geojson
Process - safeGraph_socialDistancingMetrics_load
Output - final_social_distancing_metrics
Customer - research-01-217611.df_edp_safegraph_stage

BigQuery Processing time - 291.5GB

Frequency - Weekly (~monnday)
*/

CREATE OR REPLACE TABLE
  `research-01-217611.df_edp_safegraph.final_social_distancing_metrics` (--metadata
    origin_census_block_group INT64 OPTIONS (description = 'The unique 12-digit FIPS code for the Census Block Group. Please note that some CBGs have leading zeros.'),
    state STRING OPTIONS (description = 'state'),
    county_name STRING OPTIONS (description = 'county name'),
    date_range_start DATETIME OPTIONS (description = 'Start time for measurement period in ISO 8601 format of YYYY-MM-DDTHH:mm:SS±hh:mm (local time with offset from GMT). The start time will be 12 a.m. of any day.'),
    date_range_end DATETIME OPTIONS (description = 'End time for measurement period in ISO 8601 format of YYYY-MM-DDTHH:mm:SS±hh:mm (local time with offset from GMT). The end time will be the following 12 a.m.'),
    device_count INT64 OPTIONS (description = 'Number of devices seen in our panel during the date range whose home is in this census_block_group. Home is defined as the common nighttime location for the device over a 6 week period where nighttime is 6 pm - 7 am. Note that we do not include any census_block_groups where the count <5.'),
    distance_traveled_from_home INT64 OPTIONS (description = 'Median distance (in meters) traveled from the geohash-7 of the home by the devices included in the device_count during the time period (excluding any distances of 0). We first find the median for each device and then find the median across all of the devices.'),
    no_of_device_distance_traveled_0 INT64 OPTIONS (description = 'number of devices traveled in range of meters (from geohash-7 of home)'),
    no_of_device_distance_traveled_1_1000 INT64 OPTIONS (description = 'number of devices traveled in range of meters (from geohash-7 of home)'),
    no_of_device_distance_traveled_1001_2000 INT64 OPTIONS (description = 'number of devices traveled in range of meters (from geohash-7 of home)'),
    no_of_device_distance_traveled_12001_8000 INT64 OPTIONS (description = 'number of devices traveled in range of meters (from geohash-7 of home)'),
    no_of_device_distance_traveled_8001_16000 INT64 OPTIONS (description = 'number of devices traveled in range of meters (from geohash-7 of home)'),
    no_of_device_distance_traveled_16001_50000 INT64 OPTIONS (description = 'number of devices traveled in range of meters (from geohash-7 of home)'),
    no_of_device_distance_traveled_morethan50000 INT64 OPTIONS (description = 'number of devices traveled in range of meters (from geohash-7 of home)'),
    median_dwell_less1000 INT64 OPTIONS (description = 'Median dwell time in minutes of the devices that traveled the given distance from the geohash-7 of the home.'),
    median_dwell_1001_2000 INT64 OPTIONS (description = 'Median dwell time in minutes of the devices that traveled the given distance from the geohash-7 of the home.'),
    median_dwell_2001_8000 INT64 OPTIONS (description = 'Median dwell time in minutes of the devices that traveled the given distance from the geohash-7 of the home.'),
    median_dwell_8001_16000 INT64 OPTIONS (description = 'Median dwell time in minutes of the devices that traveled the given distance from the geohash-7 of the home.'),
    median_dwell_16001_50000 INT64 OPTIONS (description = 'Median dwell time in minutes of the devices that traveled the given distance from the geohash-7 of the home.'),
    median_dwell_morethan50000 INT64 OPTIONS (description = 'Median dwell time in minutes of the devices that traveled the given distance from the geohash-7 of the home.'),
    completely_home_device_count INT64 OPTIONS (description = 'Out of the device_count, the number of devices which did not leave the geohash-7 in which their home is located during the time period.'),
    median_home_dwell_time INT64 OPTIONS (description = 'Median dwell time at home geohash-7 ("home") in minutes for all devices in the device_count during the time period. For each device, we summed the observed minutes at home across the day (whether or not these were contiguous) to get the total minutes for each device. Then we calculate the median of all these devices. Beginning in v2, we include the portion of any stop within the time range regardless of whether the stop start time was in the time period.'),
    home_dwell_time_less60 INT64 OPTIONS (description = 'device count of devices that dwelled at geohash-7 of home for the given time period. For each device, we summed the observed minutes at home across the day (whether or not these were contiguous) to get the total minutes for each device this day. Then we count how many devices are in each bucket. Beginning in v2, we include the portion of any stop within the time range regardless of whether the stop start time was in the time period'),
    home_dwell_time_61_360 INT64 OPTIONS (description = 'device count of devices that dwelled at geohash-7 of home for the given time period. For each device, we summed the observed minutes at home across the day (whether or not these were contiguous) to get the total minutes for each device this day. Then we count how many devices are in each bucket. Beginning in v2, we include the portion of any stop within the time range regardless of whether the stop start time was in the time period'),
    home_dwell_time_361_720 INT64 OPTIONS (description = 'device count of devices that dwelled at geohash-7 of home for the given time period. For each device, we summed the observed minutes at home across the day (whether or not these were contiguous) to get the total minutes for each device this day. Then we count how many devices are in each bucket. Beginning in v2, we include the portion of any stop within the time range regardless of whether the stop start time was in the time period'),
    home_dwell_time_721_1080 INT64 OPTIONS (description = 'device count of devices that dwelled at geohash-7 of home for the given time period. For each device, we summed the observed minutes at home across the day (whether or not these were contiguous) to get the total minutes for each device this day. Then we count how many devices are in each bucket. Beginning in v2, we include the portion of any stop within the time range regardless of whether the stop start time was in the time period'),
    home_dwell_time_morethan1080 INT64 OPTIONS (description = 'device count of devices that dwelled at geohash-7 of home for the given time period. For each device, we summed the observed minutes at home across the day (whether or not these were contiguous) to get the total minutes for each device this day. Then we count how many devices are in each bucket. Beginning in v2, we include the portion of any stop within the time range regardless of whether the stop start time was in the time period'),
    device_at_home_by_12mn_1am INT64 OPTIONS (description = 'A mapping of hour of day to the number of devices at geohash-7 home in each hour over the course of the day in local time.'),
    device_at_home_by_1am_2am INT64 OPTIONS (description = 'A mapping of hour of day to the number of devices at geohash-7 home in each hour over the course of the day in local time.'),
    device_at_home_by_2am_3am INT64 OPTIONS (description = 'A mapping of hour of day to the number of devices at geohash-7 home in each hour over the course of the day in local time.'),
    device_at_home_by_3am_4am INT64 OPTIONS (description = 'A mapping of hour of day to the number of devices at geohash-7 home in each hour over the course of the day in local time.'),
    device_at_home_by_4am_5am INT64 OPTIONS (description = 'A mapping of hour of day to the number of devices at geohash-7 home in each hour over the course of the day in local time.'),
    device_at_home_by_5am_6am INT64 OPTIONS (description = 'A mapping of hour of day to the number of devices at geohash-7 home in each hour over the course of the day in local time.'),
    device_at_home_by_6am_7am INT64 OPTIONS (description = 'A mapping of hour of day to the number of devices at geohash-7 home in each hour over the course of the day in local time.'),
    device_at_home_by_7am_8am INT64 OPTIONS (description = 'A mapping of hour of day to the number of devices at geohash-7 home in each hour over the course of the day in local time.'),
    device_at_home_by_8am_9am INT64 OPTIONS (description = 'A mapping of hour of day to the number of devices at geohash-7 home in each hour over the course of the day in local time.'),
    device_at_home_by_9am_10am INT64 OPTIONS (description = 'A mapping of hour of day to the number of devices at geohash-7 home in each hour over the course of the day in local time.'),
    device_at_home_by_10am_11am INT64 OPTIONS (description = 'A mapping of hour of day to the number of devices at geohash-7 home in each hour over the course of the day in local time.'),
    device_at_home_by_11am_12nn INT64 OPTIONS (description = 'A mapping of hour of day to the number of devices at geohash-7 home in each hour over the course of the day in local time.'),
    device_at_home_by_12nn_1pm INT64 OPTIONS (description = 'A mapping of hour of day to the number of devices at geohash-7 home in each hour over the course of the day in local time.'),
    device_at_home_by_1pm_2pm INT64 OPTIONS (description = 'A mapping of hour of day to the number of devices at geohash-7 home in each hour over the course of the day in local time.'),
    device_at_home_by_2pm_3pm INT64 OPTIONS (description = 'A mapping of hour of day to the number of devices at geohash-7 home in each hour over the course of the day in local time.'),
    device_at_home_by_3pm_4pm INT64 OPTIONS (description = 'A mapping of hour of day to the number of devices at geohash-7 home in each hour over the course of the day in local time.'),
    device_at_home_by_4pm__5pm INT64 OPTIONS (description = 'A mapping of hour of day to the number of devices at geohash-7 home in each hour over the course of the day in local time.'),
    device_at_home_by_5pm_6pm INT64 OPTIONS (description = 'A mapping of hour of day to the number of devices at geohash-7 home in each hour over the course of the day in local time.'),
    device_at_home_by_6pm_7pm INT64 OPTIONS (description = 'A mapping of hour of day to the number of devices at geohash-7 home in each hour over the course of the day in local time.'),
    device_at_home_by_7pm_8pm INT64 OPTIONS (description = 'A mapping of hour of day to the number of devices at geohash-7 home in each hour over the course of the day in local time.'),
    device_at_home_by_8pm_9pm INT64 OPTIONS (description = 'A mapping of hour of day to the number of devices at geohash-7 home in each hour over the course of the day in local time.'),
    device_at_home_by_9pm_10pm INT64 OPTIONS (description = 'A mapping of hour of day to the number of devices at geohash-7 home in each hour over the course of the day in local time.'),
    device_at_home_by_10pm_11pm INT64 OPTIONS (description = 'A mapping of hour of day to the number of devices at geohash-7 home in each hour over the course of the day in local time.'),
    device_at_home_by_11pm_12mn INT64 OPTIONS (description = 'A mapping of hour of day to the number of devices at geohash-7 home in each hour over the course of the day in local time.'),
    part_time_work_behavior_devices INT64 OPTIONS (description = 'Out of the device_count, the number of devices that spent one period of between 3 and 6 hours at one location other than their geohash-7 home during the period of 8 am - 6 pm in local time. This does not include any device that spent 6 or more hours at a location other than home.'),
    full_time_work_behavior_devices INT64 OPTIONS (description = 'Out of the device_count, the number of devices that spent greater than 6 hours at a location other than their home geohash-7 during the period of 8 am - 6 pm in local time.'),
    destination_cbgs STRING OPTIONS (description = 'destination census block group and value is the number of devices with a home in census_block_group that stopped in the given destination census block group for >1 minute during the time period. Destination census block group will also include the origin_census_block_group (so would capture any device that stayed completely at home or were at least seen at some point in the time period within the origin_census_block_group). This means that the difference between the device_count and the count of devices with a destination_cbg that is the same as the origin_census_block_group represents the number of devices that originate from the origin_census_block group but are staying completely outside of it.'),
    delivery_behavior_devices INT64 OPTIONS (description = 'Out of the device_count, the number of devices that stopped for < 20 minutes at > 3 locations outside of their geohash-7 home.'),
    median_non_home_dwell_time INT64 OPTIONS (description = 'Median dwell time at places outside of geohash-7 home in minutes for all devices in the device_count during the time period. For each device, we summed the observed minutes outside of home across the day (whether or not these were contiguous) to get the total minutes for each device. Then we calculate the median of all these devices.'),
    candidate_device_count INT64 OPTIONS (description = 'Number of devices in our panel whose home is in this census_block_group regardless of whether we saw any activity for them in the time range. Home is defined as the common nighttime location for the device over a 6 week period where nighttime is 6 pm - 7 am.'),
    away_from_home_time_less20 INT64 OPTIONS (description = 'count of devices that dwelled anywhere outside of the geohash-7 of home for the given time period. For each device, we summed the observed minutes away from home across the day (whether or not these were contiguous) to get the total minutes for each device this day. Then we count how many devices are in each bucket.'),
    away_from_home_time_21_45 INT64 OPTIONS (description = 'count of devices that dwelled anywhere outside of the geohash-7 of home for the given time period. For each device, we summed the observed minutes away from home across the day (whether or not these were contiguous) to get the total minutes for each device this day. Then we count how many devices are in each bucket.'),
    away_from_home_time_46_60 INT64 OPTIONS (description = 'count of devices that dwelled anywhere outside of the geohash-7 of home for the given time period. For each device, we summed the observed minutes away from home across the day (whether or not these were contiguous) to get the total minutes for each device this day. Then we count how many devices are in each bucket.'),
    away_from_home_time_61_120 INT64 OPTIONS (description = 'count of devices that dwelled anywhere outside of the geohash-7 of home for the given time period. For each device, we summed the observed minutes away from home across the day (whether or not these were contiguous) to get the total minutes for each device this day. Then we count how many devices are in each bucket.'),
    away_from_home_time_121_180 INT64 OPTIONS (description = 'count of devices that dwelled anywhere outside of the geohash-7 of home for the given time period. For each device, we summed the observed minutes away from home across the day (whether or not these were contiguous) to get the total minutes for each device this day. Then we count how many devices are in each bucket.'),
    away_from_home_time_181_240 INT64 OPTIONS (description = 'count of devices that dwelled anywhere outside of the geohash-7 of home for the given time period. For each device, we summed the observed minutes away from home across the day (whether or not these were contiguous) to get the total minutes for each device this day. Then we count how many devices are in each bucket.'),
    away_from_home_time_241_300 INT64 OPTIONS (description = 'count of devices that dwelled anywhere outside of the geohash-7 of home for the given time period. For each device, we summed the observed minutes away from home across the day (whether or not these were contiguous) to get the total minutes for each device this day. Then we count how many devices are in each bucket.'),
    away_from_home_time_301_360 INT64 OPTIONS (description = 'count of devices that dwelled anywhere outside of the geohash-7 of home for the given time period. For each device, we summed the observed minutes away from home across the day (whether or not these were contiguous) to get the total minutes for each device this day. Then we count how many devices are in each bucket.'),
    away_from_home_time_361_420 INT64 OPTIONS (description = 'count of devices that dwelled anywhere outside of the geohash-7 of home for the given time period. For each device, we summed the observed minutes away from home across the day (whether or not these were contiguous) to get the total minutes for each device this day. Then we count how many devices are in each bucket.'),
    away_from_home_time_421_480 INT64 OPTIONS (description = 'count of devices that dwelled anywhere outside of the geohash-7 of home for the given time period. For each device, we summed the observed minutes away from home across the day (whether or not these were contiguous) to get the total minutes for each device this day. Then we count how many devices are in each bucket.'),
    away_from_home_time_481_540 INT64 OPTIONS (description = 'count of devices that dwelled anywhere outside of the geohash-7 of home for the given time period. For each device, we summed the observed minutes away from home across the day (whether or not these were contiguous) to get the total minutes for each device this day. Then we count how many devices are in each bucket.'),
    away_from_home_time_541_600 INT64 OPTIONS (description = 'count of devices that dwelled anywhere outside of the geohash-7 of home for the given time period. For each device, we summed the observed minutes away from home across the day (whether or not these were contiguous) to get the total minutes for each device this day. Then we count how many devices are in each bucket.'),
    away_from_home_time_601_660 INT64 OPTIONS (description = 'count of devices that dwelled anywhere outside of the geohash-7 of home for the given time period. For each device, we summed the observed minutes away from home across the day (whether or not these were contiguous) to get the total minutes for each device this day. Then we count how many devices are in each bucket.'),
    away_from_home_time_661_720 INT64 OPTIONS (description = 'count of devices that dwelled anywhere outside of the geohash-7 of home for the given time period. For each device, we summed the observed minutes away from home across the day (whether or not these were contiguous) to get the total minutes for each device this day. Then we count how many devices are in each bucket.'),
    away_from_home_time_721_840 INT64 OPTIONS (description = 'count of devices that dwelled anywhere outside of the geohash-7 of home for the given time period. For each device, we summed the observed minutes away from home across the day (whether or not these were contiguous) to get the total minutes for each device this day. Then we count how many devices are in each bucket.'),
    away_from_home_time_841_960 INT64 OPTIONS (description = 'count of devices that dwelled anywhere outside of the geohash-7 of home for the given time period. For each device, we summed the observed minutes away from home across the day (whether or not these were contiguous) to get the total minutes for each device this day. Then we count how many devices are in each bucket.'),
    away_from_home_time_961_1080 INT64 OPTIONS (description = 'count of devices that dwelled anywhere outside of the geohash-7 of home for the given time period. For each device, we summed the observed minutes away from home across the day (whether or not these were contiguous) to get the total minutes for each device this day. Then we count how many devices are in each bucket.'),
    away_from_home_time_1081_1200 INT64 OPTIONS (description = 'count of devices that dwelled anywhere outside of the geohash-7 of home for the given time period. For each device, we summed the observed minutes away from home across the day (whether or not these were contiguous) to get the total minutes for each device this day. Then we count how many devices are in each bucket.'),
    away_from_home_time_1201_1320 INT64 OPTIONS (description = 'count of devices that dwelled anywhere outside of the geohash-7 of home for the given time period. For each device, we summed the observed minutes away from home across the day (whether or not these were contiguous) to get the total minutes for each device this day. Then we count how many devices are in each bucket.'),
    away_from_home_time_1321_1440 INT64 OPTIONS (description = 'count of devices that dwelled anywhere outside of the geohash-7 of home for the given time period. For each device, we summed the observed minutes away from home across the day (whether or not these were contiguous) to get the total minutes for each device this day. Then we count how many devices are in each bucket.'),
    away_from_home_time_morethan1440 INT64 OPTIONS (description = 'count of devices that dwelled anywhere outside of the geohash-7 of home for the given time period. For each device, we summed the observed minutes away from home across the day (whether or not these were contiguous) to get the total minutes for each device this day. Then we count how many devices are in each bucket.'),
    median_percentage_time_home INT64 OPTIONS (description = 'Median percentage of time we observed devices home versus observed at all during the time period.'),
    percentage_time_home_0_25 INT64 OPTIONS (description = 'percentage of time a device was observed at home (numerator) out of total hours observed that day at any location (denominator). Value is the number of devices observed in this range.'),
    percentage_time_home_26_50 INT64 OPTIONS (description = 'percentage of time a device was observed at home (numerator) out of total hours observed that day at any location (denominator). Value is the number of devices observed in this range.'),
    percentage_time_home_51_75 INT64 OPTIONS (description = 'percentage of time a device was observed at home (numerator) out of total hours observed that day at any location (denominator). Value is the number of devices observed in this range.'),
    percentage_time_home_76_100 INT64 OPTIONS (description = 'percentage of time a device was observed at home (numerator) out of total hours observed that day at any location (denominator). Value is the number of devices observed in this range.'),
    percentage_time_home_morethan100 INT64 OPTIONS (description = 'percentage of time a device was observed at home (numerator) out of total hours observed that day at any location (denominator). Value is the number of devices observed in this range.'),
    mean_home_dwell_time INT64 OPTIONS (description = 'Mean dwell time at home geohash-7 ("home") in minutes for all devices in the device_count during the time period. For each device, we summed the observed minutes at home across the day (whether or not these were contiguous) to get the total minutes for each device. Then we calculate the mean of all these devices.'),
    mean_non_home_dwell_time INT64 OPTIONS (description = 'Mean dwell time at places outside of geohash-7 home in minutes for all devices in the device_count during the time period. For each device, we summed the observed minutes outside of home across the day (whether or not these were contiguous) to get the total minutes for each device. Then we calculate the mean of all these devices.'),
    mean_distance_traveled_from_home INT64 OPTIONS (description = 'Mean distance (in meters) traveled from the geohash-7 of the home by the devices included in the device_count during the time period. We first find all the distances traveled for each device. We filter out any distances that are > 1.5 x the interquartile range for that device. We do NOT filter on the low range since we were only concerned with long distance outliers. We then take the mean for each device using the non-filtered distances. Then we find the mean across all of the devices.') ) OPTIONS (description = 'SafeGraph is offering a temporary Social Distancing Metrics product. This product is delivered daily (3 days delayed from actual). Daily data is available going back to January 1, 2019. We used v2.1 to create the historical data from Jan 1, 2019 - Dec 31, 2019 (the backfill) as well as the data from May 10, 2020 forwards. However, the Jan 1-May 9, 2020 data is on v2.0.') AS
SELECT
  SAFE_CAST(a.origin_census_block_group AS int64) AS origin_census_block_group,
  LOWER(TRIM(b.state)) AS state,
  LOWER(TRIM(b.country)) AS county_name,
  SAFE_CAST(a.date_range_start AS datetime) AS date_range_start,
  SAFE_CAST(a.date_range_end AS datetime) AS date_range_end,
  SAFE_CAST(a.device_count AS int64) AS device_count,
  SAFE_CAST(a.distance_traveled_from_home AS int64) AS distance_traveled_from_home
  --functions like this aims to have its own placeholder for every value,
  --And therefore will be stored in different columns
  ,
  SAFE_CAST(REPLACE( REPLACE( REPLACE( json_EXTRACT(REPLACE(a.bucketed_distance_traveled,'>','greater'),
            '$.0'), '"', '')            --strip out quotes and brackets
        , '{', ''), '}', '') AS int64) AS no_of_device_distance_traveled_0,
  SAFE_CAST(REPLACE( REPLACE( REPLACE( json_EXTRACT(REPLACE(a.bucketed_distance_traveled,'>','greater'),
            '$.1-1000'), '"', '')            --strip out quotes and brackets
        , '{', ''), '}', '') AS int64) AS no_of_device_distance_traveled_1_1000,
  SAFE_CAST(REPLACE( REPLACE( REPLACE( json_EXTRACT(REPLACE(a.bucketed_distance_traveled,'>','greater'),
            '$.1001-2000'), '"', '')            --strip out quotes and brackets
        , '{', ''), '}', '') AS int64) AS no_of_device_distance_traveled_1001_2000,
  SAFE_CAST(REPLACE( REPLACE( REPLACE( json_EXTRACT(REPLACE(a.bucketed_distance_traveled,'>','greater'),
            '$.2001-8000'), '"', '')            --strip out quotes and brackets
        , '{', ''), '}', '') AS int64) AS no_of_device_distance_traveled_12001_8000,
  SAFE_CAST(REPLACE( REPLACE( REPLACE( json_EXTRACT(REPLACE(a.bucketed_distance_traveled,'>','greater'),
            '$.8001-16000'), '"', '')            --strip out quotes and brackets
        , '{', ''), '}', '') AS int64) AS no_of_device_distance_traveled_8001_16000,
  SAFE_CAST(REPLACE( REPLACE( REPLACE( json_EXTRACT(REPLACE(a.bucketed_distance_traveled,'>','greater'),
            '$.16001-50000'), '"', '')            --strip out quotes and brackets
        , '{', ''), '}', '') AS int64) AS no_of_device_distance_traveled_16001_50000,
  SAFE_CAST(REPLACE( REPLACE( REPLACE( json_EXTRACT(REPLACE(a.bucketed_distance_traveled,'>','greater'),
            '$.greater50000'), '"', '')            --strip out quotes and brackets
        , '{', ''), '}', '') AS int64) AS no_of_device_distance_traveled_morethan50000,
  SAFE_CAST(REPLACE( REPLACE( REPLACE( json_EXTRACT(REPLACE(REPLACE(a.median_dwell_at_bucketed_distance_traveled,'>','greater'),'<','less'),
            '$.less1000'), '"', '')            --strip out quotes and brackets
        , '{', ''), '}', '') AS int64) AS median_dwell_less1000,
  SAFE_CAST(REPLACE( REPLACE( REPLACE( json_EXTRACT(REPLACE(REPLACE(a.median_dwell_at_bucketed_distance_traveled,'>','greater'),'<','less'),
            '$.1001-2000'), '"', '')            --strip out quotes and brackets
        , '{', ''), '}', '') AS int64) AS median_dwell_1001_2000,
  SAFE_CAST(REPLACE( REPLACE( REPLACE( json_EXTRACT(REPLACE(REPLACE(a.median_dwell_at_bucketed_distance_traveled,'>','greater'),'<','less'),
            '$.2001-8000'), '"', '')            --strip out quotes and brackets
        , '{', ''), '}', '') AS int64) AS median_dwell_2001_8000,
  SAFE_CAST(REPLACE( REPLACE( REPLACE( json_EXTRACT(REPLACE(REPLACE(a.median_dwell_at_bucketed_distance_traveled,'>','greater'),'<','less'),
            '$.8001-16000'), '"', '')            --strip out quotes and brackets
        , '{', ''), '}', '') AS int64) AS median_dwell_8001_16000,
  SAFE_CAST(REPLACE( REPLACE( REPLACE( json_EXTRACT(REPLACE(REPLACE(a.median_dwell_at_bucketed_distance_traveled,'>','greater'),'<','less'),
            '$.16001-50000'), '"', '')            --strip out quotes and brackets
        , '{', ''), '}', '') AS int64) AS median_dwell_16001_50000,
  SAFE_CAST(REPLACE( REPLACE( REPLACE( json_EXTRACT(REPLACE(REPLACE(a.median_dwell_at_bucketed_distance_traveled,'>','greater'),'<','less'),
            '$.greater50000'), '"', '')            --strip out quotes and brackets
        , '{', ''), '}', '') AS int64) AS median_dwell_morethan50000,
  SAFE_CAST(a.completely_home_device_count AS int64) AS completely_home_device_count,
  SAFE_CAST(a.median_home_dwell_time AS int64) AS median_home_dwell_time,
  SAFE_CAST(REPLACE( REPLACE( REPLACE( json_EXTRACT(REPLACE(REPLACE(a.bucketed_home_dwell_time,'>','greater'),'<','less'),
            '$.less60'), '"', '')            --strip out quotes and brackets
        , '{', ''), '}', '') AS int64) AS home_dwell_time_less60,
  SAFE_CAST(REPLACE( REPLACE( REPLACE( json_EXTRACT(REPLACE(REPLACE(a.bucketed_home_dwell_time,'>','greater'),'<','less'),
            '$.61-360'), '"', '')            --strip out quotes and brackets
        , '{', ''), '}', '') AS int64) AS home_dwell_time_61_360,
  SAFE_CAST(REPLACE( REPLACE( REPLACE( json_EXTRACT(REPLACE(REPLACE(a.bucketed_home_dwell_time,'>','greater'),'<','less'),
            '$.361-720'), '"', '')            --strip out quotes and brackets
        , '{', ''), '}', '') AS int64) AS home_dwell_time_361_720,
  SAFE_CAST(REPLACE( REPLACE( REPLACE( json_EXTRACT(REPLACE(REPLACE(a.bucketed_home_dwell_time,'>','greater'),'<','less'),
            '$.721-1080'), '"', '')            --strip out quotes and brackets
        , '{', ''), '}', '') AS int64) AS home_dwell_time_721_1080,
  SAFE_CAST(REPLACE( REPLACE( REPLACE( json_EXTRACT(REPLACE(REPLACE(a.bucketed_home_dwell_time,'>','greater'),'<','less'),
            '$.greater1080'), '"', '')            --strip out quotes and brackets
        , '{', ''), '}', '') AS int64) AS home_dwell_time_morethan1080,
  SAFE_CAST(REPLACE(REPLACE(SPLIT(a.at_home_by_each_hour, ',')[ORDINAL(1)],"[",""),"]","") AS int64) AS device_at_home_by_12mn_1am,
  SAFE_CAST(REPLACE(REPLACE(SPLIT(a.at_home_by_each_hour, ',')[ORDINAL(2)],"[",""),"]","") AS int64) AS device_at_home_by_1am_2am,
  SAFE_CAST(REPLACE(REPLACE(SPLIT(a.at_home_by_each_hour, ',')[ORDINAL(3)],"[",""),"]","") AS int64) AS device_at_home_by_2am_3am,
  SAFE_CAST(REPLACE(REPLACE(SPLIT(a.at_home_by_each_hour, ',')[ORDINAL(4)],"[",""),"]","") AS int64) AS device_at_home_by_3am_4am,
  SAFE_CAST(REPLACE(REPLACE(SPLIT(a.at_home_by_each_hour, ',')[ORDINAL(5)],"[",""),"]","") AS int64) AS device_at_home_by_4am_5am,
  SAFE_CAST(REPLACE(REPLACE(SPLIT(a.at_home_by_each_hour, ',')[ORDINAL(6)],"[",""),"]","") AS int64) AS device_at_home_by_5am_6am,
  SAFE_CAST(REPLACE(REPLACE(SPLIT(a.at_home_by_each_hour, ',')[ORDINAL(7)],"[",""),"]","") AS int64) AS device_at_home_by_6am_7am,
  SAFE_CAST(REPLACE(REPLACE(SPLIT(a.at_home_by_each_hour, ',')[ORDINAL(8)],"[",""),"]","") AS int64) AS device_at_home_by_7am_8am,
  SAFE_CAST(REPLACE(REPLACE(SPLIT(a.at_home_by_each_hour, ',')[ORDINAL(9)],"[",""),"]","") AS int64) AS device_at_home_by_8am_9am,
  SAFE_CAST(REPLACE(REPLACE(SPLIT(a.at_home_by_each_hour, ',')[ORDINAL(10)],"[",""),"]","") AS int64) AS device_at_home_by_9am_10am,
  SAFE_CAST(REPLACE(REPLACE(SPLIT(a.at_home_by_each_hour, ',')[ORDINAL(11)],"[",""),"]","") AS int64) AS device_at_home_by_10am_11am,
  SAFE_CAST(REPLACE(REPLACE(SPLIT(a.at_home_by_each_hour, ',')[ORDINAL(12)],"[",""),"]","") AS int64) AS device_at_home_by_11am_12nn,
  SAFE_CAST(REPLACE(REPLACE(SPLIT(a.at_home_by_each_hour, ',')[ORDINAL(13)],"[",""),"]","") AS int64) AS device_at_home_by_12nn_1pm,
  SAFE_CAST(REPLACE(REPLACE(SPLIT(a.at_home_by_each_hour, ',')[ORDINAL(14)],"[",""),"]","") AS int64) AS device_at_home_by_1pm_2pm,
  SAFE_CAST(REPLACE(REPLACE(SPLIT(a.at_home_by_each_hour, ',')[ORDINAL(15)],"[",""),"]","") AS int64) AS device_at_home_by_2pm_3pm,
  SAFE_CAST(REPLACE(REPLACE(SPLIT(a.at_home_by_each_hour, ',')[ORDINAL(16)],"[",""),"]","") AS int64) AS device_at_home_by_3pm_4pm,
  SAFE_CAST(REPLACE(REPLACE(SPLIT(a.at_home_by_each_hour, ',')[ORDINAL(17)],"[",""),"]","") AS int64) AS device_at_home_by_4pm__5pm,
  SAFE_CAST(REPLACE(REPLACE(SPLIT(a.at_home_by_each_hour, ',')[ORDINAL(18)],"[",""),"]","") AS int64) AS device_at_home_by_5pm_6pm,
  SAFE_CAST(REPLACE(REPLACE(SPLIT(a.at_home_by_each_hour, ',')[ORDINAL(19)],"[",""),"]","") AS int64) AS device_at_home_by_6pm_7pm,
  SAFE_CAST(REPLACE(REPLACE(SPLIT(a.at_home_by_each_hour, ',')[ORDINAL(20)],"[",""),"]","") AS int64) AS device_at_home_by_7pm_8pm,
  SAFE_CAST(REPLACE(REPLACE(SPLIT(a.at_home_by_each_hour, ',')[ORDINAL(21)],"[",""),"]","") AS int64) AS device_at_home_by_8pm_9pm,
  SAFE_CAST(REPLACE(REPLACE(SPLIT(a.at_home_by_each_hour, ',')[ORDINAL(22)],"[",""),"]","") AS int64) AS device_at_home_by_9pm_10pm,
  SAFE_CAST(REPLACE(REPLACE(SPLIT(a.at_home_by_each_hour, ',')[ORDINAL(23)],"[",""),"]","") AS int64) AS device_at_home_by_10pm_11pm,
  SAFE_CAST(REPLACE(REPLACE(SPLIT(a.at_home_by_each_hour, ',')[ORDINAL(24)],"[",""),"]","") AS int64) AS device_at_home_by_11pm_12mn,
  SAFE_CAST(a.part_time_work_behavior_devices AS int64) AS part_time_work_behavior_devices,
  SAFE_CAST(a.full_time_work_behavior_devices AS int64) AS full_time_work_behavior_devices,
  TRIM(a.destination_cbgs) AS destination_cbgs,
  SAFE_CAST(a.delivery_behavior_devices AS int64) AS delivery_behavior_devices,
  SAFE_CAST(a.median_non_home_dwell_time AS int64) AS median_non_home_dwell_time,
  SAFE_CAST(a.candidate_device_count AS int64) AS candidate_device_count,
  SAFE_CAST(REPLACE( REPLACE( REPLACE( json_EXTRACT(REPLACE(REPLACE(a.bucketed_away_from_home_time,'>','greater'),'<','less'),
            '$.less20'), '"', '')            --strip out quotes and brackets
        , '{', ''), '}', '') AS int64) AS away_from_home_time_less20,
  SAFE_CAST(REPLACE( REPLACE( REPLACE( json_EXTRACT(REPLACE(REPLACE(a.bucketed_away_from_home_time,'>','greater'),'<','less'),
            '$.21-45'), '"', '')            --strip out quotes and brackets
        , '{', ''), '}', '') AS int64) AS away_from_home_time_21_45,
  SAFE_CAST(REPLACE( REPLACE( REPLACE( json_EXTRACT(REPLACE(REPLACE(a.bucketed_away_from_home_time,'>','greater'),'<','less'),
            '$.46-60'), '"', '')            --strip out quotes and brackets
        , '{', ''), '}', '') AS int64) AS away_from_home_time_46_60,
  SAFE_CAST(REPLACE( REPLACE( REPLACE( json_EXTRACT(REPLACE(REPLACE(a.bucketed_away_from_home_time,'>','greater'),'<','less'),
            '$.61-120'), '"', '')            --strip out quotes and brackets
        , '{', ''), '}', '') AS int64) AS away_from_home_time_61_120,
  SAFE_CAST(REPLACE( REPLACE( REPLACE( json_EXTRACT(REPLACE(REPLACE(a.bucketed_away_from_home_time,'>','greater'),'<','less'),
            '$.121-180'), '"', '')            --strip out quotes and brackets
        , '{', ''), '}', '') AS int64) AS away_from_home_time_121_180,
  SAFE_CAST(REPLACE( REPLACE( REPLACE( json_EXTRACT(REPLACE(REPLACE(a.bucketed_away_from_home_time,'>','greater'),'<','less'),
            '$.181-240'), '"', '')            --strip out quotes and brackets
        , '{', ''), '}', '') AS int64) AS away_from_home_time_181_240,
  SAFE_CAST(REPLACE( REPLACE( REPLACE( json_EXTRACT(REPLACE(REPLACE(a.bucketed_away_from_home_time,'>','greater'),'<','less'),
            '$.241-300'), '"', '')            --strip out quotes and brackets
        , '{', ''), '}', '') AS int64) AS away_from_home_time_241_300,
  SAFE_CAST(REPLACE( REPLACE( REPLACE( json_EXTRACT(REPLACE(REPLACE(a.bucketed_away_from_home_time,'>','greater'),'<','less'),
            '$.301-360'), '"', '')            --strip out quotes and brackets
        , '{', ''), '}', '') AS int64) AS away_from_home_time_301_360,
  SAFE_CAST(REPLACE( REPLACE( REPLACE( json_EXTRACT(REPLACE(REPLACE(a.bucketed_away_from_home_time,'>','greater'),'<','less'),
            '$.361-420'), '"', '')            --strip out quotes and brackets
        , '{', ''), '}', '') AS int64) AS away_from_home_time_361_420,
  SAFE_CAST(REPLACE( REPLACE( REPLACE( json_EXTRACT(REPLACE(REPLACE(a.bucketed_away_from_home_time,'>','greater'),'<','less'),
            '$.421-480'), '"', '')            --strip out quotes and brackets
        , '{', ''), '}', '') AS int64) AS away_from_home_time_421_480,
  SAFE_CAST(REPLACE( REPLACE( REPLACE( json_EXTRACT(REPLACE(REPLACE(a.bucketed_away_from_home_time,'>','greater'),'<','less'),
            '$.481-540'), '"', '')            --strip out quotes and brackets
        , '{', ''), '}', '') AS int64) AS away_from_home_time_481_540,
  SAFE_CAST(REPLACE( REPLACE( REPLACE( json_EXTRACT(REPLACE(REPLACE(a.bucketed_away_from_home_time,'>','greater'),'<','less'),
            '$.541-600'), '"', '')            --strip out quotes and brackets
        , '{', ''), '}', '') AS int64) AS away_from_home_time_541_600,
  SAFE_CAST(REPLACE( REPLACE( REPLACE( json_EXTRACT(REPLACE(REPLACE(a.bucketed_away_from_home_time,'>','greater'),'<','less'),
            '$.601-660'), '"', '')            --strip out quotes and brackets
        , '{', ''), '}', '') AS int64) AS away_from_home_time_601_660,
  SAFE_CAST(REPLACE( REPLACE( REPLACE( json_EXTRACT(REPLACE(REPLACE(a.bucketed_away_from_home_time,'>','greater'),'<','less'),
            '$.661-720'), '"', '')            --strip out quotes and brackets
        , '{', ''), '}', '') AS int64) AS away_from_home_time_661_720,
  SAFE_CAST(REPLACE( REPLACE( REPLACE( json_EXTRACT(REPLACE(REPLACE(a.bucketed_away_from_home_time,'>','greater'),'<','less'),
            '$.721-840'), '"', '')            --strip out quotes and brackets
        , '{', ''), '}', '') AS int64) AS away_from_home_time_721_840,
  SAFE_CAST(REPLACE( REPLACE( REPLACE( json_EXTRACT(REPLACE(REPLACE(a.bucketed_away_from_home_time,'>','greater'),'<','less'),
            '$.841-960'), '"', '')            --strip out quotes and brackets
        , '{', ''), '}', '') AS int64) AS away_from_home_time_841_960,
  SAFE_CAST(REPLACE( REPLACE( REPLACE( json_EXTRACT(REPLACE(REPLACE(a.bucketed_away_from_home_time,'>','greater'),'<','less'),
            '$.961-1080'), '"', '')            --strip out quotes and brackets
        , '{', ''), '}', '') AS int64) AS away_from_home_time_961_1080,
  SAFE_CAST(REPLACE( REPLACE( REPLACE( json_EXTRACT(REPLACE(REPLACE(a.bucketed_away_from_home_time,'>','greater'),'<','less'),
            '$.1081-1200'), '"', '')            --strip out quotes and brackets
        , '{', ''), '}', '') AS int64) AS away_from_home_time_1081_1200,
  SAFE_CAST(REPLACE( REPLACE( REPLACE( json_EXTRACT(REPLACE(REPLACE(a.bucketed_away_from_home_time,'>','greater'),'<','less'),
            '$.1201-1320'), '"', '')            --strip out quotes and brackets
        , '{', ''), '}', '') AS int64) AS away_from_home_time_1201_1320,
  SAFE_CAST(REPLACE( REPLACE( REPLACE( json_EXTRACT(REPLACE(REPLACE(a.bucketed_away_from_home_time,'>','greater'),'<','less'),
            '$.1321-1440'), '"', '')            --strip out quotes and brackets
        , '{', ''), '}', '') AS int64) AS away_from_home_time_1321_1440,
  SAFE_CAST(REPLACE( REPLACE( REPLACE( json_EXTRACT(REPLACE(REPLACE(a.bucketed_away_from_home_time,'>','greater'),'<','less'),
            '$.greater1440'), '"', '')            --strip out quotes and brackets
        , '{', ''), '}', '') AS int64) AS away_from_home_time_morethan1440,
  SAFE_CAST(median_percentage_time_home AS int64) AS median_percentage_time_home,
  SAFE_CAST(REPLACE( REPLACE( REPLACE( json_EXTRACT(REPLACE(REPLACE(a.bucketed_percentage_time_home,'>','greater'),'<','less'),
            '$.0-25'), '"', '')            --strip out quotes and brackets
        , '{', ''), '}', '') AS int64) AS percentage_time_home_0_25,
  SAFE_CAST(REPLACE( REPLACE( REPLACE( json_EXTRACT(REPLACE(REPLACE(a.bucketed_percentage_time_home,'>','greater'),'<','less'),
            '$.26-50'), '"', '')            --strip out quotes and brackets
        , '{', ''), '}', '') AS int64) AS percentage_time_home_26_50,
  SAFE_CAST(REPLACE( REPLACE( REPLACE( json_EXTRACT(REPLACE(REPLACE(a.bucketed_percentage_time_home,'>','greater'),'<','less'),
            '$.51-75'), '"', '')            --strip out quotes and brackets
        , '{', ''), '}', '') AS int64) AS percentage_time_home_51_75,
  SAFE_CAST(REPLACE( REPLACE( REPLACE( json_EXTRACT(REPLACE(REPLACE(a.bucketed_percentage_time_home,'>','greater'),'<','less'),
            '$.76-100'), '"', '')            --strip out quotes and brackets
        , '{', ''), '}', '') AS int64) AS percentage_time_home_76_100,
  SAFE_CAST(REPLACE( REPLACE( REPLACE( json_EXTRACT(REPLACE(REPLACE(a.bucketed_percentage_time_home,'>','greater'),'<','less'),
            '$.greater100'), '"', '')            --strip out quotes and brackets
        , '{', ''), '}', '') AS int64) AS percentage_time_home_morethan100,
  SAFE_CAST(a.mean_home_dwell_time AS int64) AS mean_home_dwell_time,
  SAFE_CAST(a.mean_non_home_dwell_time AS int64) AS mean_non_home_dwell_time,
  SAFE_CAST(a.mean_distance_traveled_from_home AS int64) AS mean_distance_traveled_from_home
FROM
  `ds-00-191017.safegraph_final.social_distancing_metrics` AS a
LEFT JOIN
  `ds-00-191017.safegraph_final.cbg_geojson` AS b
ON
  a.origin_census_block_group = b.census_block_group