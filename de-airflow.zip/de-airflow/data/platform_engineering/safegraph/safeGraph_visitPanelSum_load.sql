/*
Project: Safegraph Mobility Data
Created date: February 8, 2021
Supplier - ds-00-191017.safegraph_final
Input - visit_panel_summary
Process - safeGraph_visitPanelSum_load
Output - final_visit_panel_summary
Customer - research-01-217611.df_edp_safegraph_stage

BigQuery Processing time - 401.2 KB

Frequency - Weekly (~monnday)
*/

CREATE OR REPLACE TABLE
  `research-01-217611.df_edp_safegraph_stage.final_visit_panel_summary` (--metdata
    starting_dt DATE OPTIONS (description = 'Calendar date that the first day of the weekly data is in'),
    state STRING OPTIONS (description = 'Lowercase abbreviation of U.S. state or territory'),
    ttl_vst INT64 OPTIONS (description = 'Number of point-of-interest visits observed in the specified state'),
    ttl_uniq_vstrs INT64 OPTIONS (description = 'Number of unique visitors observed with at least 1 point-of-interest visit in the specified state') )
    OPTIONS (description = '') AS
SELECT
  DATE(starting_year, starting_month,starting_day) AS starting_dt,
  TRIM(LOWER(state)) AS state,
  SUM(num_visits) AS ttl_vst,
  SUM(num_unique_visitors) AS ttl_uniq_vstrs
FROM
  `ds-00-191017.safegraph_final.visit_panel_summary`
GROUP BY
  starting_dt,
  state