/*
Project: Safegraph Mobility Data
Created date: February 8, 2021
Supplier - ds-00-191017.safegraph_final
Input - normalization_stats
Process - safeGraph_normalizationStats_load
Output - final_normalization_stats
Customer - research-01-217611.df_edp_safegraph_stage

BigQuery Processing time - 3.7MB

Frequency - Monthly
*/

create or replace table `research-01-217611.df_edp_safegraph_stage.final_normalization_stats`
(--metdata
          full_dt DATE options (description = 'full date')
        , region STRING options (description = 'When iso_country_code == US, then this is the USA state or territory. When iso_country_code == CA, then this is the Canadian Province or territory.')
        , ttl_visits INT64 options (description = 'All visits we saw on the given day in local time (includes visits to POI and visits to homes)')
        , ttl_devices_seen INT64 options (description = 'Total devices in our panel which we saw on the given day with any visit in local time (POI or home visit)')
        , ttl_home_visits INT64 options (description = 'Visits we saw on the given day in local time to the device`s home geohash-7')
        , ttl_home_visitors INT64 options (description = 'Total devices we saw on the given day with at least 1 visit to the device`s home geohash-7')

)
OPTIONS (description = '')
as

select  DATE(year, month,day) as full_dt
        , lower(trim(region)) as region
        , sum(total_visits)             as ttl_visits
        , sum(total_devices_seen)       as ttl_devices_seen
        , sum(total_home_visits)        as ttl_home_visits
        , sum(total_home_visitors)      as ttl_home_visitors
from `ds-00-191017.safegraph_final.normalization_stats`
group by full_dt, region