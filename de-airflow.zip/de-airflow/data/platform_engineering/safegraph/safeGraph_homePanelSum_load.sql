/*
Project: Safegraph Mobility Data
Created date: February 8, 2021
Supplier - ds-00-191017.safegraph_final
Input - home_panel_summary, cdb_geojson
Process - safeGraph_homePanelSum_load
Output - final_home_panel_summary
Customer - research-01-217611.df_edp_safegraph_stage

BigQuery Processing time - 1.4GB

Frequency - Weekly (~monnday)
*/

CREATE OR REPLACE TABLE
  `research-01-217611.df_edp_safegraph_stage.final_home_panel_summary` (--metdata
    date_range_start TIMESTAMP OPTIONS (description = 'Start time for measurement period in ISO 8601 format of YYYY-MM-DDTHH:mm:SS±hh:mm (local time with offset from GMT).'),
    date_range_end TIMESTAMP OPTIONS (description = 'End time for measurement period in ISO 8601 format of YYYY-MM-DDTHH:mm:SS±hh:mm (local time with offset from GMT). '),
    census_block_group INT64 OPTIONS (description = 'FIPS code for this Census block group'),
    state STRING OPTIONS (description = 'Lowercase abbreviation of U.S. state or territory'),
    county_name STRING OPTIONS (description = 'county name for this CBG'),
    ttl_devices_residing INT64 OPTIONS (description = 'Number of distinct devices observed with a primary nighttime location in the specified census block group.') )
    OPTIONS (description = '') AS
SELECT
  a.date_range_start,
  a.date_range_end,
  SAFE_CAST(a.census_block_group AS int64) AS census_block_group,
  LOWER(TRIM(a.state)) AS state,
  LOWER(TRIM(b.country)) AS county_name,
  SUM(a.number_devices_residing) AS ttl_devices_residing
FROM
  `ds-00-191017.safegraph_final.home_panel_summary` AS a
LEFT JOIN
  `ds-00-191017.safegraph_final.cbg_geojson` AS b
ON
  a.census_block_group = b.census_block_group
GROUP BY
  a.date_range_start,
  a.date_range_end,
  a.state,
  a.census_block_group,
  county_name