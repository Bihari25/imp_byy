/*
Project: Safegraph Mobility Data
Created date: February 8, 2021
Supplier - ds-00-191017.safegraph_final
Input - cbg_geojson
Process - safegraph_censusBlockGrpGeo_load
Output - final_cbg_geojson
Customer - research-01-217611.df_edp_safegraph

BigQuery Processing time - 1.5GB

Frequency - NONE - ONE_TIME
*/

CREATE OR REPLACE TABLE
  `research-01-217611.df_edp_safegraph.final_cbg_geojson` (--metdata
    state_fips INT64 OPTIONS (description = 'FIPS code for this state'),
    country_fips INT64 OPTIONS (description = 'FIPS code for this county'),
    tract_code INT64 OPTIONS (description = 'FIPS code for this tract'),
    block_group INT64 OPTIONS (description = 'FIPS code for this block group'),
    census_block_group INT64 OPTIONS (description = 'FIPS code for this Census block group'),
    state STRING OPTIONS (description = 'Lowercase abbreviation of U.S. state or territory'),
    county STRING OPTIONS (description = 'county name for this CBG'),
    class_code STRING OPTIONS (description = 'class code'),
    geometry GEOGRAPHY OPTIONS (description = 'geometry') ) OPTIONS (description = '') AS
SELECT
  CAST(state_fips AS int64) AS state_fips,
  SAFE_CAST(country_fips AS int64) AS country_fips,
  SAFE_CAST(tract_code AS int64) AS tract_code,
  SAFE_CAST(block_group AS int64) AS block_group,
  SAFE_CAST(census_block_group AS int64) AS census_block_group,
  LOWER(TRIM(state)) AS state,
  LOWER(TRIM(country)) AS county,
  LOWER(TRIM(class_code)) AS class_code,
  geometry AS geometry
FROM
  `ds-00-191017.safegraph_final.cbg_geojson`