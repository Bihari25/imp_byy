/*
Project: Safegraph Mobility Data
Created date: February 8, 2021
Supplier - ds-00-191017.safegraph_final
Input - brand_info
Process - safeGraph_brandInfo_load
Output - final_brand_info
Customer - research-01-217611.df_edp_safegraph_stage

BigQuery Processing time - 818.3KB

Frequency - Monthly
*/

CREATE OR REPLACE TABLE
  `research-01-217611.df_edp_safegraph.final_brand_info` (--metdata
    safegraph_brand_id STRING OPTIONS (description = 'Unique and consistent ID that represents this specific brand.'),
    brand_name STRING OPTIONS (description ='brand name'),
    parent_safegraph_brand_id STRING OPTIONS (description ='If place is encompassed a larger place (e.g. mall, airport, stadium), this lists the safegraph_place_id of the parent place; otherwise null (to be retired in favor of parent_placekey)'),
    naics_code INT64 OPTIONS (description ='aA abbreviation of the North American Industry Classification System. This system is the standard used by federal statistical agencies for classifying businesses for the purpose of collecting, analyzing, and publishing data related to the U.S. economy.'),
    top_category STRING OPTIONS (description ='The label associated with the first 4 digits of the POI’s NAICS category.'),
    sub_category STRING OPTIONS (description ='The label associated with all 6 digits of the POI’s NAICS category.'),
    stock_symbol STRING OPTIONS (description ='Stock symbol'),
    stock_exchange STRING OPTIONS (description ='Stock exchange') )
    OPTIONS (description = 'Provides an easy way to isolate for only major stores. If you know you are searching for a brand that we cover, we advise searching the brand column instead of the name column.') AS
SELECT
  TRIM(safegraph_brand_id) AS safegraph_brand_id,
  LOWER(TRIM(brand_name)) AS brand_name,
  TRIM(parent_safegraph_brand_id) AS parent_safegraph_brand_id,
  naics_code,
  LOWER(TRIM(top_category)) AS top_category,
  LOWER(TRIM(sub_category)) AS sub_category,
  LOWER(TRIM(stock_symbol)) AS stock_symbol,
  LOWER(TRIM(stock_exchange)) AS stock_exchange
FROM
  `ds-00-191017.safegraph_final.brand_info`