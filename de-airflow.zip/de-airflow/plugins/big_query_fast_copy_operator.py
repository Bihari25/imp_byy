from airflow.contrib.hooks.bigquery_hook import BigQueryHook
from airflow.contrib.hooks.gcs_hook import GoogleCloudStorageHook, _parse_gcs_url
from airflow.models import BaseOperator
from airflow.utils.decorators import apply_defaults
from datetime import datetime

class BigQueryFastCopyOperator(BaseOperator):
    template_fields = ['run_id', 'fullpath']
    @apply_defaults
    def __init__( self,
        archive=False,
        sources=[],
        destinations=[],
        run_id="",
        path="",
        use_xcom=False,
        xcom_sources_key=None,
        xcom_sources_task_id=None,
        xcom_destinations_key=None,
        xcom_destinations_task_id=None,
        filename="",
        file_filter=None,
        bigquery_conn_id='bigquery_default',
        *args,
        **kwargs
    ) :
        super().__init__(**kwargs)
        self.bq_cursor = None
        if((not use_xcom or xcom_sources_key is None or xcom_sources_task_id is None) and archive is True):
            if (filename is "" or path is "" or run_id is ""):
                raise ValueError("If archive is true a filename, path, and run_id or use_xcom and filt must be provided")
        self.archive = archive
        self.sources = sources
        self.use_xcom = use_xcom
        self.xcom_sources_key = xcom_sources_key
        self.xcom_sources_task_id = xcom_sources_task_id
        self.xcom_destinations_key = xcom_destinations_key
        self.xcom_destinations_task_id = xcom_destinations_task_id
        self.destinations = destinations
        if len(self.sources) != len(self.destinations):
            raise ValueError("Source and Destination List size must be equal")
        self.path = path
        self.filename = filename
        self.run_id = run_id
        self.fullpath = path+"/"+run_id + "/" + filename
        self.file_filter = file_filter
        self.bigquery_conn_id = bigquery_conn_id
    

    def execute(self, context) :
        if self.use_xcom and self.xcom_sources_key is not None and self.xcom_sources_task_id is not None:
            self.sources = context['task_instance'].xcom_pull(task_ids=self.xcom_sources_task_id, key=self.xcom_sources_key)
        if self.use_xcom and self.xcom_destinations_key is not None and self.xcom_destinations_task_id is not None:
            self.destinations = context['task_instance'].xcom_pull(task_ids=self.xcom_destinations_task_id, key=self.xcom_destinations_key)
        if self.archive is True and not self.sources:
            datestamp = str((datetime.now()).strftime("%Y%m%d"))
            file1 = open(self.fullpath, 'r')
            lines = file1.readlines()
            skip_filter=False
            if self.file_filter is None:
                skip_filter = True
            else:
                file_filters = self.file_filter.split("|")

            for line in lines:
                line = line.strip('\n')
                if skip_filter is True:
                    destination = line + "_arc_"+datestamp
                    self.copy_tables(line, destination)
                else:
                    for f in file_filters:
                        if line.find(f) != -1:
                            destination = line + "_arc_"+datestamp
                            self.copy_tables(line, destination)
                            break
        elif self.archive is True and self.sources:
            self.log.info("sources: %s", self.sources)
            datestamp = str((datetime.now()).strftime("%Y%m%d"))
            i=0
            while i < len(self.sources):
                self.copy_tables(self.sources[i], self.sources[i]+"_arc_"+datestamp)
                i+=1

        else:
            i=0
            while i < len(self.sources):
                self.copy_tables(self.sources[i], self.destinations[i])
                i+=1


    def copy_tables(self, source, destination):
        if self.bq_cursor is None:
            hook = BigQueryHook(
                bigquery_conn_id=self.bigquery_conn_id,
                use_legacy_sql=False,
                delegate_to=None)
            conn = hook.get_conn()
            self.bq_cursor = conn.cursor()
        self.log.info('Executing fast copy from %s to %s', source, destination)
        self.bq_cursor.run_copy(source, destination, write_disposition='WRITE_TRUNCATE',create_disposition='CREATE_IF_NEEDED')



    